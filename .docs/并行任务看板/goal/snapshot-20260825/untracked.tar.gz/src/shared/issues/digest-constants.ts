export const ISSUE_DIGEST_INPUT_MAX_BYTES = 8 * 1024 * 1024
export const ISSUE_DIGEST_DIRECT_ROUND_MAX_COUNT = 2_000
export const ISSUE_DIGEST_INPUT_ITEM_MAX_BYTES = 64 * 1024
export const ISSUE_DIGEST_DRAFT_MAX_BYTES = 4 * 1024 * 1024
export const ISSUE_DIGEST_GENERATION_ERROR_MAX_BYTES = 2 * 1024

export const ISSUE_DIGEST_STATUSES = [
  'generating',
  'draft',
  'failed',
  'canceled',
  'confirmed'
] as const

export const ISSUE_DIGEST_INPUT_KINDS = [
  'direct-round',
  'direct-child-digest',
  'user-artifact'
] as const

export const ISSUE_DIGEST_INPUT_COMPLETENESS = [
  'complete',
  'partial',
  'unavailable'
] as const

export const ISSUE_DIGEST_OMISSION_REASONS = [
  'round-limit',
  'item-byte-limit',
  'total-byte-limit'
] as const
