import type { IssueDigestRecord } from '../../shared/issues/digest-types'
import type { TuiAgent } from '../../shared/tui-agent'
import type { IssueDatabase } from './issue-database'
import { IssueRepositoryError } from './issue-repository-error'

export type IssueDigestRow = {
  id: string
  issue_id: string
  version: number
  revision: number
  status: IssueDigestRecord['status']
  covers_until: number
  problem: string | null
  conclusion: string | null
  key_artifacts: string | null
  open_issues: string | null
  next_steps: string | null
  coverage_note: string | null
  input_fingerprint: string
  generator_agent: TuiAgent | null
  generation_id: string | null
  generation_error: string | null
  generation_started_at: number | null
  generation_finished_at: number | null
  created_at: number
  updated_at: number
  confirmed_at: number | null
}

export function getIssueDigest(
  database: IssueDatabase,
  id: string
): IssueDigestRecord | undefined {
  const row = database
    .prepare('SELECT * FROM issue_digests WHERE id = ?')
    .get(id) as IssueDigestRow | undefined
  return row ? issueDigestFromRow(row) : undefined
}

export function requireIssueDigest(
  database: IssueDatabase,
  id: string
): IssueDigestRecord {
  const digest = getIssueDigest(database, id)
  if (!digest) {
    throw new IssueRepositoryError('digest_not_found', `Issue Digest ${id} was not found.`)
  }
  return digest
}

export function listIssueDigestsForIssue(
  database: IssueDatabase,
  issueId: string
): IssueDigestRecord[] {
  return (
    database
      .prepare(
        `SELECT * FROM issue_digests
         WHERE issue_id = ?
         ORDER BY version DESC, id`
      )
      .all(issueId) as IssueDigestRow[]
  ).map(issueDigestFromRow)
}

function issueDigestFromRow(row: IssueDigestRow): IssueDigestRecord {
  return {
    id: row.id,
    issueId: row.issue_id,
    version: row.version,
    revision: row.revision,
    status: row.status,
    coversUntil: row.covers_until,
    problem: row.problem,
    conclusion: row.conclusion,
    keyArtifacts: row.key_artifacts,
    openIssues: row.open_issues,
    nextSteps: row.next_steps,
    coverageNote: row.coverage_note,
    inputFingerprint: row.input_fingerprint,
    generatorAgent: row.generator_agent,
    generationId: row.generation_id,
    generationError: row.generation_error,
    generationStartedAt: row.generation_started_at,
    generationFinishedAt: row.generation_finished_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    confirmedAt: row.confirmed_at
  }
}
