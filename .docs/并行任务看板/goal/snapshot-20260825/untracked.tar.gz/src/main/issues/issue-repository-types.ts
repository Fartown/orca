import type { ExecutionHostId } from '../../shared/execution-host'
import type { WorkspaceScope } from '../../shared/folder-workspace-types'
import type {
  ArchiveIssueBlocker,
  ConversationRecord,
  ConversationState,
  DeleteIssuePlan,
  ExternalIssueAvailability,
  IssueLink,
  IssueMutationIdentity,
  IssueRecord,
  IssueState,
  RoundRecord,
  RoundRecordRef,
  RoundRecordStateSource,
  RoundResolution,
  RoundTextCompleteness,
  RoundTextStorage,
  WorkspaceSnapshot
} from '../../shared/issues/types'
import type { TaskProvider } from '../../shared/task-providers'
import type { TaskSourceContext } from '../../shared/task-source-context'
import type { TuiAgent } from '../../shared/tui-agent'

export type CreateLocalIssueInput = {
  executionHostId: ExecutionHostId
  title: string
  parentId?: string | null
  index?: number
  typeLabel?: string | null
  note?: string | null
}

export type ExternalIssueSnapshot = {
  externalId: string
  number?: number
  identifier?: string
  url: string
  title: string
  state?: string
  nativeParent?: {
    externalId: string
    title: string
    sourceContext?: TaskSourceContext
  } | null
}

export type TrackExternalIssueInput = {
  executionHostId: ExecutionHostId
  provider: TaskProvider
  sourceContext: TaskSourceContext
  snapshot: ExternalIssueSnapshot
  refreshAttemptedAt?: number
  parentId?: string | null
  typeLabel?: string | null
  note?: string | null
}

export type CreateIssueInput = { kind: 'local' } & CreateLocalIssueInput

export type UpdateIssueInput = {
  id: string
  localTitle?: string | null
  typeLabel?: string | null
  note?: string | null
  executionHostId?: never
}

export type ReparentIssueInput = {
  issueId: string
  parentId: string | null
  index: number
  expectedTreeRevision: number
}

export type IssueRevisionResult = {
  factsRevision: number
  treeRevision: number
}

export type ReparentIssueResult = IssueRevisionResult & {
  issue: IssueRecord
  affectedIssueIds: string[]
}

export type ArchiveIssueRuntimeBlocker = {
  conversationId: string
  dedupeKey?: string | null
}

export type ArchiveIssueInput = {
  id: string
  expectedFactsRevision?: number
  runtimeBlockers?: readonly ArchiveIssueRuntimeBlocker[]
}

export type ArchiveIssueResult =
  | {
      status: 'archived'
      issueId: string
      archivedAt: number
      resolvedCompletionIds: string[]
      revisions: IssueRevisionResult
    }
  | {
      status: 'blocked'
      issueId: string
      blockers: ArchiveIssueBlocker[]
    }

export type ReopenIssueInput = {
  id: string
  expectedFactsRevision?: number
}

export type RefreshExternalIssueInput = {
  id: string
  snapshot: ExternalIssueSnapshot
  attemptedAt: number
}

export type FailExternalIssueRefreshInput = {
  id: string
  attemptedAt: number
  error: string
  availability?: ExternalIssueAvailability
}

export type CreateIssueLinkInput = {
  issueId: string
  target: IssueLink['target']
}

export type DeleteIssueLinkInput = {
  issueId: string
  targetAuthorityId: string
  targetHostPartitionKey: IssueLink['target']['hostPartitionKey']
  targetIssueId: string
}

export type CreateConversationInput = {
  executionHostId: ExecutionHostId
  workspaceRef: WorkspaceScope
  workspaceSnapshot: WorkspaceSnapshot
  agent: TuiAgent
  title?: string | null
  titleSource?: ConversationRecord['titleSource']
  issueId?: string | null
  state?: ConversationState
}

export type UpdateConversationInput = {
  id: string
  title?: string | null
  titleSource?: ConversationRecord['titleSource']
  state?: ConversationState
  issueId?: string | null
  executionHostId?: never
}

export type BindConversationIssueInput = {
  id: string
  issueId: string | null
  expectedFactsRevision: number
}

export type RoundTextInput = {
  text?: string | null
  completeness?: RoundTextCompleteness
  storage?: RoundTextStorage
  preview?: string | null
}

export type CreateRoundRecordInput = {
  conversationId: string
  kind: RoundRecord['kind']
  stateSource: RoundRecordStateSource
  occurredAt: number
  dedupeKey: string
  executionChainId?: string | null
  supersedesRoundId?: string | null
  userInput?: RoundTextInput
  agentOutput?: RoundTextInput
  pendingQuestion?: RoundTextInput
  refs?: readonly RoundRecordRef[]
  readAt?: number | null
  resolvedAt?: number | null
  resolution?: RoundResolution | null
  finalizedAt?: number | null
  authoritativeCurrentState?: boolean
}

export type UpdateRoundRecordInput = {
  id: string
  readAt?: number | null
  resolvedAt?: number | null
  resolution?: RoundResolution | null
}

export type MarkRoundRecordsReadInput = {
  ids: string[]
  readAt: number
}

export type IssueMutationParams<Input> = {
  identity: IssueMutationIdentity
  input: Input
}

export type DeleteRecordInput = {
  id: string
}

export type CommitDeleteIssueInput = DeleteIssuePlan

export type CommitDeleteIssueResult = IssueRevisionResult & {
  deletedIssueId: string
  affectedIssueIds: string[]
  affectedConversationIds: string[]
}

export type IssueListFilter = {
  executionHostId?: ExecutionHostId
  state?: IssueState
}

export type ConversationListFilter = {
  executionHostId?: ExecutionHostId
  issueId?: string | null
  workspaceRef?: WorkspaceScope
  state?: ConversationState
}

export type RoundRecordListFilter = {
  conversationId: string
  kind?: RoundRecord['kind']
}

export type IssueEventListFilter = {
  hostPartitionKey?: IssueLink['target']['hostPartitionKey']
  issueId?: string
  conversationId?: string
  limit?: number
}
