import type { ExecutionHostId } from '../../../shared/execution-host'
import type {
  IssueDigestConfirmationResult,
  IssueDigestMutationResult,
  IssueDigestPreparation
} from '../../../shared/issues/digest-types'
import type { StoreApi } from 'zustand/vanilla'
import type {
  IssueClientLoadResult,
  IssueDigestCancelInput,
  IssueDigestConfirmInput,
  IssueDigestGenerateInput,
  IssueDigestUpdateInput
} from './issue-client-data'

export type IssueDigestLoadState = {
  status: 'idle' | 'loading' | 'ready' | 'unsupported' | 'error'
  preparation: IssueDigestPreparation | null
  mutation: IssueDigestMutationResult | null
  confirmation: IssueDigestConfirmationResult | null
  error: string | null
}

export type IssueDigestDomainFields = {
  digestLoadsByKey: Record<string, IssueDigestLoadState>
}

export type IssueDigestDomainActions = {
  prepareDigest: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string
  ) => Promise<void>
  generateDigest: (
    routeExecutionHostId: ExecutionHostId,
    input: IssueDigestGenerateInput
  ) => Promise<void>
  cancelDigest: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string,
    input: IssueDigestCancelInput
  ) => Promise<void>
  updateDigestDraft: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string,
    input: IssueDigestUpdateInput
  ) => Promise<void>
  confirmDigest: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string,
    input: IssueDigestConfirmInput
  ) => Promise<void>
}

export type IssueDigestDomainDependencies = {
  prepareDigest: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string
  ) => Promise<IssueClientLoadResult<IssueDigestPreparation>>
  generateDigest: (
    routeExecutionHostId: ExecutionHostId,
    input: IssueDigestGenerateInput
  ) => Promise<IssueClientLoadResult<IssueDigestMutationResult>>
  cancelDigest: (
    routeExecutionHostId: ExecutionHostId,
    input: IssueDigestCancelInput
  ) => Promise<IssueClientLoadResult<IssueDigestMutationResult>>
  updateDigestDraft: (
    routeExecutionHostId: ExecutionHostId,
    input: IssueDigestUpdateInput
  ) => Promise<IssueClientLoadResult<IssueDigestMutationResult>>
  confirmDigest: (
    routeExecutionHostId: ExecutionHostId,
    input: IssueDigestConfirmInput
  ) => Promise<IssueClientLoadResult<IssueDigestConfirmationResult>>
  refreshDetail: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string
  ) => Promise<unknown>
}

export function createIssueDigestDomain<
  State extends IssueDigestDomainFields
>(
  dependencies: IssueDigestDomainDependencies,
  set: StoreApi<State>['setState'],
  get: StoreApi<State>['getState']
): IssueDigestDomainActions {
  const generations = new Map<string, number>()
  const run = async <Value>(
    routeExecutionHostId: ExecutionHostId,
    issueId: string,
    request: () => Promise<IssueClientLoadResult<Value>>,
    apply: (previous: IssueDigestLoadState, value: Value) => IssueDigestLoadState
  ): Promise<void> => {
    const key = issueDigestKey(routeExecutionHostId, issueId)
    const generation = (generations.get(key) ?? 0) + 1
    generations.set(key, generation)
    const previous = get().digestLoadsByKey[key] ?? emptyIssueDigestLoadState()
    setDigestState(set, key, { ...previous, status: 'loading', error: null })
    const result = await request()
    if (generations.get(key) !== generation) {
      return
    }
    if (result.status === 'ready' || result.status === 'cached') {
      setDigestState(set, key, apply(previous, result.value))
      await dependencies.refreshDetail(routeExecutionHostId, issueId)
      return
    }
    setDigestState(set, key, {
      ...previous,
      status: result.status,
      error: result.status === 'error' ? result.error : null
    })
  }
  return {
    prepareDigest: (routeExecutionHostId, issueId) =>
      run(
        routeExecutionHostId,
        issueId,
        () => dependencies.prepareDigest(routeExecutionHostId, issueId),
        (previous, preparation) => ({
          ...previous,
          status: 'ready',
          preparation,
          error: null
        })
      ),
    generateDigest: (routeExecutionHostId, input) =>
      run(
        routeExecutionHostId,
        input.issueId,
        () => dependencies.generateDigest(routeExecutionHostId, input),
        (previous, mutation) => ({
          ...previous,
          status: 'ready',
          mutation,
          confirmation: null,
          error: null
        })
      ),
    cancelDigest: (routeExecutionHostId, issueId, input) =>
      runMutation(
        run,
        dependencies.cancelDigest,
        routeExecutionHostId,
        issueId,
        input
      ),
    updateDigestDraft: (routeExecutionHostId, issueId, input) =>
      runMutation(
        run,
        dependencies.updateDigestDraft,
        routeExecutionHostId,
        issueId,
        input
      ),
    confirmDigest: (routeExecutionHostId, issueId, input) =>
      run(
        routeExecutionHostId,
        issueId,
        () => dependencies.confirmDigest(routeExecutionHostId, input),
        (previous, confirmation) => ({
          ...previous,
          status: 'ready',
          confirmation,
          mutation:
            confirmation.status === 'confirmed'
              ? {
                  authority: confirmation.authority,
                  digest: confirmation.digest
                }
              : previous.mutation,
          error: null
        })
      )
  }
}

export function issueDigestKey(
  routeExecutionHostId: ExecutionHostId,
  issueId: string
): string {
  return `${routeExecutionHostId}\0${issueId}`
}

export function emptyIssueDigestLoadState(): IssueDigestLoadState {
  return {
    status: 'idle',
    preparation: null,
    mutation: null,
    confirmation: null,
    error: null
  }
}

function runMutation<Input>(
  run: <Value>(
    routeExecutionHostId: ExecutionHostId,
    issueId: string,
    request: () => Promise<IssueClientLoadResult<Value>>,
    apply: (previous: IssueDigestLoadState, value: Value) => IssueDigestLoadState
  ) => Promise<void>,
  request: (
    routeExecutionHostId: ExecutionHostId,
    input: Input
  ) => Promise<IssueClientLoadResult<IssueDigestMutationResult>>,
  routeExecutionHostId: ExecutionHostId,
  issueId: string,
  input: Input
): Promise<void> {
  return run(
    routeExecutionHostId,
    issueId,
    () => request(routeExecutionHostId, input),
    (previous, mutation) => ({
      ...previous,
      status: 'ready',
      mutation,
      confirmation: null,
      error: null
    })
  )
}

function setDigestState<State extends IssueDigestDomainFields>(
  set: StoreApi<State>['setState'],
  key: string,
  value: IssueDigestLoadState
): void {
  set((state) => ({
    digestLoadsByKey: {
      ...state.digestLoadsByKey,
      [key]: value
    }
  }) as Partial<State>)
}
