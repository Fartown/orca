import type { IssueLink } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { bumpIssueHostRevisions } from './issue-host-state'
import { executeIssueMutation } from './issue-mutation-receipt'
import { requireIssueRecord } from './issue-record-queries'
import { IssueRepositoryError } from './issue-repository-error'
import type {
  CreateIssueLinkInput,
  DeleteIssueLinkInput,
  IssueMutationParams
} from './issue-repository-types'

type IssueLinkRow = {
  issue_id: string
  target_authority_id: string
  target_host_partition_key: IssueLink['target']['hostPartitionKey']
  target_issue_id: string
  target_title_snapshot: string
  created_at: number
  updated_at: number
}

export class IssueLinkRepository {
  constructor(private readonly database: IssueDatabase) {}

  create(params: IssueMutationParams<CreateIssueLinkInput>): IssueLink {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issue-links.create',
      payload: params.input,
      operation: () => {
        const issue = requireIssueRecord(this.database, params.input.issueId)
        const target = params.input.target
        if (
          target.authorityId === this.database.getAuthorityId() &&
          target.hostPartitionKey === issue.hostPartitionKey
        ) {
          throw new IssueRepositoryError(
            'issue_link_invalid',
            'Issue links are only for cross-authority or cross-partition references.'
          )
        }
        if (!target.issueId.trim() || !target.titleSnapshot.trim()) {
          throw new IssueRepositoryError(
            'issue_link_invalid',
            'Issue links require a target Issue and title snapshot.'
          )
        }
        const now = Date.now()
        this.database
          .prepare(
            `INSERT INTO issue_links (
               issue_id, target_authority_id, target_host_partition_key,
               target_issue_id, target_title_snapshot, created_at, updated_at
             ) VALUES (?, ?, ?, ?, ?, ?, ?)
             ON CONFLICT(
               issue_id, target_authority_id, target_host_partition_key, target_issue_id
             ) DO UPDATE SET
               target_title_snapshot = excluded.target_title_snapshot,
               updated_at = excluded.updated_at`
          )
          .run(
            issue.id,
            target.authorityId,
            target.hostPartitionKey,
            target.issueId,
            target.titleSnapshot,
            now,
            now
          )
        bumpIssueHostRevisions(
          this.database,
          issue.hostPartitionKey,
          { tree: false },
          now
        )
        return this.require(issue.id, target)
      }
    })
  }

  list(issueId: string): IssueLink[] {
    requireIssueRecord(this.database, issueId)
    const rows = this.database
      .prepare(
        `SELECT * FROM issue_links
         WHERE issue_id = ?
         ORDER BY created_at, target_authority_id, target_host_partition_key, target_issue_id`
      )
      .all(issueId) as IssueLinkRow[]
    return rows.map(fromRow)
  }

  delete(params: IssueMutationParams<DeleteIssueLinkInput>): { deleted: boolean } {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issue-links.delete',
      payload: params.input,
      operation: () => {
        const issue = requireIssueRecord(this.database, params.input.issueId)
        const result = this.database
          .prepare(
            `DELETE FROM issue_links
             WHERE issue_id = ?
               AND target_authority_id = ?
               AND target_host_partition_key = ?
               AND target_issue_id = ?`
          )
          .run(
            issue.id,
            params.input.targetAuthorityId,
            params.input.targetHostPartitionKey,
            params.input.targetIssueId
          )
        if (result.changes > 0) {
          bumpIssueHostRevisions(
            this.database,
            issue.hostPartitionKey,
            { tree: false },
            Date.now()
          )
        }
        return { deleted: result.changes > 0 }
      }
    })
  }

  private require(issueId: string, target: IssueLink['target']): IssueLink {
    const row = this.database
      .prepare(
        `SELECT * FROM issue_links
         WHERE issue_id = ?
           AND target_authority_id = ?
           AND target_host_partition_key = ?
           AND target_issue_id = ?`
      )
      .get(
        issueId,
        target.authorityId,
        target.hostPartitionKey,
        target.issueId
      ) as IssueLinkRow | undefined
    if (!row) {
      throw new Error('Issue link was not persisted.')
    }
    return fromRow(row)
  }
}

function fromRow(row: IssueLinkRow): IssueLink {
  return {
    issueId: row.issue_id,
    target: {
      authorityId: row.target_authority_id,
      hostPartitionKey: row.target_host_partition_key,
      issueId: row.target_issue_id,
      titleSnapshot: row.target_title_snapshot
    },
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}
