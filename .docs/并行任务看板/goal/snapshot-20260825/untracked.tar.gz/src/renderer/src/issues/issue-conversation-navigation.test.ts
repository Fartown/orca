import { describe, expect, it, vi } from 'vitest'
import type { ConversationSummary } from '../../../shared/issues/types'
import {
  openIssueConversationWithDependencies,
  type IssueConversationNavigationDependencies
} from './issue-conversation-navigation'

function conversation(
  overrides: Partial<ConversationSummary> = {}
): ConversationSummary {
  return {
    id: '22222222-2222-4222-8222-222222222222',
    hostPartitionKey: 'local',
    executionHostId: 'local',
    workspaceRef: { type: 'worktree', worktreeId: 'worktree-a' },
    workspaceSnapshot: { name: 'Workspace A', path: '/workspace/a' },
    agent: 'codex',
    title: 'Conversation',
    titleSource: 'user',
    issueId: '11111111-1111-4111-8111-111111111111',
    state: 'active',
    launchFailure: null,
    createdAt: 1,
    updatedAt: 1,
    unresolvedRoundCount: 0,
    latestRound: null,
    ...overrides
  }
}

function dependencies(
  overrides: Partial<IssueConversationNavigationDependencies> = {}
): IssueConversationNavigationDependencies {
  return {
    resolvePaneTarget: vi.fn(() => null),
    findProviderPaneTarget: vi.fn(() => null),
    findQueuedProviderTab: vi.fn(() => null),
    activateWorkspace: vi.fn(() => true),
    focusPane: vi.fn(),
    launchResume: vi.fn<IssueConversationNavigationDependencies['launchResume']>(
      async () => ({ status: 'resumed', tabId: 'tab-resumed' })
    ),
    notifyUnavailable: vi.fn(),
    ...overrides
  }
}

describe('openIssueConversationWithDependencies', () => {
  it('focuses a still-live pane without launching a duplicate resume', async () => {
    const deps = dependencies({
      resolvePaneTarget: vi.fn(() => ({
        paneKey: 'tab-live:leaf-live',
        worktreeId: 'worktree-a',
        tabId: 'tab-live',
        leafId: 'leaf-live'
      }))
    })
    const target = conversation({
      navigation: {
        paneKey: 'tab-live:leaf-live',
        providerSession: null,
        resumeLocator: null
      }
    })

    await expect(
      openIssueConversationWithDependencies(
        { routeExecutionHostId: 'local', conversation: target },
        deps
      )
    ).resolves.toEqual({
      status: 'focused',
      tabId: 'tab-live',
      leafId: 'leaf-live'
    })
    expect(deps.activateWorkspace).toHaveBeenCalledWith(target, 'local')
    expect(deps.focusPane).toHaveBeenCalledWith('tab-live', 'leaf-live')
    expect(deps.launchResume).not.toHaveBeenCalled()
  })

  it('uses an exact provider identity to select a resume queued by Workspace activation', async () => {
    const deps = dependencies({
      findQueuedProviderTab: vi.fn(() => 'tab-queued')
    })
    const target = conversation({
      workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-a' },
      navigation: {
        paneKey: null,
        providerSession: { key: 'session_id', id: 'provider-a' },
        resumeLocator: null
      }
    })

    await expect(
      openIssueConversationWithDependencies(
        { routeExecutionHostId: 'ssh:docs', conversation: target },
        deps
      )
    ).resolves.toEqual({
      status: 'resumed',
      tabId: 'tab-queued'
    })
    expect(deps.activateWorkspace).toHaveBeenCalledWith(target, 'ssh:docs')
    expect(deps.focusPane).toHaveBeenCalledWith('tab-queued', null)
    expect(deps.launchResume).not.toHaveBeenCalled()
  })

  it('does not degrade to a Workspace-only jump without a precise identity', async () => {
    const deps = dependencies()
    const target = conversation()

    await expect(
      openIssueConversationWithDependencies(
        { routeExecutionHostId: 'local', conversation: target },
        deps
      )
    ).resolves.toEqual({
      status: 'unavailable',
      reason: 'identity-unavailable'
    })
    expect(deps.activateWorkspace).not.toHaveBeenCalled()
    expect(deps.launchResume).not.toHaveBeenCalled()
    expect(deps.notifyUnavailable).toHaveBeenCalledWith(
      'identity-unavailable'
    )
  })
})
