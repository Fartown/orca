import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import { getUtf8ByteLength } from '../../shared/utf8-byte-limits'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { resolveIssueAuthorityRoute } from './issue-authority-route'
import { buildIssueDigestSnapshot } from './issue-digest-snapshot'
import { IssueQueryService } from './issue-query-service'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import { IssueRepositoryError } from './issue-repository-error'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-issue-query-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  mutationSequence += 1
  return issueMutationIdentity('query-test', `${label}-${mutationSequence}`)
}

function createIssue(
  repository: IssueRepository,
  title: string,
  parentId: string | null = null,
  executionHostId: ExecutionHostId = 'local'
) {
  return repository.issues.create({
    identity: identity(`issue-${title}`),
    input: { kind: 'local', title, parentId, executionHostId }
  })
}

function createConversation(
  repository: IssueRepository,
  label: string,
  issueId: string | null = null
) {
  return repository.conversations.create({
    identity: identity(`conversation-${label}`),
    input: {
      executionHostId: 'local',
      workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${label}` },
      workspaceSnapshot: { name: label, path: `/workspace/${label}` },
      agent: 'codex',
      title: label,
      titleSource: 'user',
      issueId
    }
  })
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('IssueQueryService tree snapshots', () => {
  it('pages parent-first attention rows and reports stale or not-modified revisions', () => {
    const repository = openRepository('tree-pages')
    const query = new IssueQueryService(repository.database)
    const route = resolveIssueAuthorityRoute('local')
    const root = createIssue(repository, 'Root')
    const child = createIssue(repository, 'Child', root.id)
    createIssue(repository, 'Other root')
    const conversation = createConversation(repository, 'attention', child.id)
    repository.rounds.create({
      identity: identity('waiting'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'query:waiting',
        pendingQuestion: { text: 'Need approval?' }
      }
    })

    const first = query.list(route, {
      mode: 'start',
      filter: 'needs-me',
      limit: 1
    })
    expect(first).toMatchObject({
      status: 'snapshot-page',
      issues: [
        {
          id: root.id,
          ownUnresolvedCount: 0,
          descendantAttentionCount: 1
        }
      ],
      unassigned: { conversationCount: 0, unresolvedCount: 0 }
    })
    if (first.status !== 'snapshot-page' || first.nextCursor === null) {
      throw new Error('Expected a paged Issue snapshot.')
    }

    const second = query.list(route, {
      mode: 'continue',
      filter: 'needs-me',
      snapshotFactsRevision: first.snapshotFactsRevision,
      snapshotTreeRevision: first.snapshotTreeRevision,
      cursor: first.nextCursor,
      limit: 1
    })
    expect(second).toMatchObject({
      status: 'snapshot-page',
      issues: [
        {
          id: child.id,
          ownUnresolvedCount: 1,
          descendantAttentionCount: 0
        }
      ],
      nextCursor: null
    })
    if (second.status !== 'snapshot-page') {
      throw new Error('Expected the second Issue snapshot page.')
    }
    expect(second.unassigned).toBeUndefined()

    createIssue(repository, 'Concurrent')
    expect(
      query.list(route, {
        mode: 'continue',
        filter: 'needs-me',
        snapshotFactsRevision: first.snapshotFactsRevision,
        snapshotTreeRevision: first.snapshotTreeRevision,
        cursor: first.nextCursor,
        limit: 1
      })
    ).toMatchObject({ status: 'stale' })

    const current = query.list(route, { mode: 'start', filter: 'all', limit: 100 })
    if (current.status !== 'snapshot-page') {
      throw new Error('Expected a current Issue snapshot.')
    }
    expect(
      query.list(route, {
        mode: 'start',
        filter: 'all',
        sinceFactsRevision: current.snapshotFactsRevision,
        limit: 100
      })
    ).toMatchObject({
      status: 'not-modified',
      factsRevision: current.snapshotFactsRevision,
      treeRevision: current.snapshotTreeRevision
    })
  })

  it('restamps runtime routes while keeping the authority local partition', () => {
    const repository = openRepository('runtime-route')
    const query = new IssueQueryService(repository.database)
    const issue = createIssue(repository, 'Local authority')
    const result = query.list(resolveIssueAuthorityRoute('runtime:remote-view'), {
      mode: 'start',
      filter: 'all',
      limit: 20
    })

    expect(result).toMatchObject({
      status: 'snapshot-page',
      authority: {
        authorityId: repository.database.getAuthorityId(),
        hostPartitionKey: 'local',
        routeExecutionHostId: 'runtime:remote-view'
      },
      issues: [{ id: issue.id, executionHostId: 'runtime:remote-view' }]
    })
  })
})

describe('IssueQueryService details and Round bodies', () => {
  it('returns the latest confirmed Digest separately from a newer stale input set', () => {
    const repository = openRepository('detail-digest')
    const query = new IssueQueryService(repository.database)
    const route = resolveIssueAuthorityRoute('local')
    const issue = createIssue(repository, 'Digest detail')
    const conversation = createConversation(repository, 'digest-detail', issue.id)
    repository.rounds.create({
      identity: identity('digest-source'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'query:digest-source',
        agentOutput: { text: 'Initial implementation complete.' }
      }
    })
    const snapshot = buildIssueDigestSnapshot(repository.database, issue, 10)
    const generating = repository.digests.createGenerating({
      identity: identity('digest-generate'),
      issue,
      agent: 'codex',
      coversUntil: snapshot.coversUntil,
      inputFingerprint: snapshot.inputFingerprint,
      coverageNote: snapshot.coverage.note,
      inputs: snapshot.inputs
    }).digest
    const draft = repository.digests.completeGeneration(generating.id, {
      problem: 'Keep Issue context durable.',
      conclusion: 'Persist the current answer.',
      keyArtifacts: 'src/main/issues',
      openIssues: null,
      nextSteps: 'Expose the confirmed answer.'
    })
    const confirmed = repository.digests.confirm({
      identity: identity('digest-confirm'),
      digestId: draft.id,
      expectedRevision: draft.revision,
      stale: false,
      currentInputFingerprint: snapshot.inputFingerprint
    })
    repository.rounds.create({
      identity: identity('digest-new-source'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 20,
        dedupeKey: 'query:digest-new-source',
        agentOutput: { text: 'A newer result arrived.' }
      }
    })

    expect(query.get(route, issue.id)).toMatchObject({
      digest: {
        latestConfirmed: {
          id: confirmed.id,
          status: 'confirmed',
          conclusion: 'Persist the current answer.'
        },
        latestAttempt: null,
        latestConfirmedIsStale: true,
        currentInputFingerprint: expect.stringMatching(/^[a-f0-9]{64}$/)
      }
    })
  })

  it('returns direct counts, unassigned Conversations, and preview-only Round pages', () => {
    const repository = openRepository('detail')
    const query = new IssueQueryService(repository.database)
    const route = resolveIssueAuthorityRoute('local')
    const issue = createIssue(repository, 'Detail')
    const bound = createConversation(repository, 'bound', issue.id)
    const unassigned = createConversation(repository, 'unassigned')
    repository.conversationLaunchClaims.create({
      conversationId: bound.id,
      launchToken: 'query-navigation',
      paneKey: 'tab-bound:leaf-bound',
      createdAt: 10,
      expiresAt: 100
    })
    repository.conversationIdentities.attach({
      conversationId: bound.id,
      agent: 'codex',
      providerSession: {
        key: 'session_id',
        id: 'provider-bound',
        transcriptPath: '/sessions/provider-bound.jsonl'
      },
      resumeLocator: '/sessions/provider-bound.jsonl',
      observedAt: 15
    })
    const round = repository.rounds.create({
      identity: identity('completion'),
      input: {
        conversationId: bound.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 20,
        dedupeKey: 'query:completion',
        userInput: { text: 'full prompt' },
        agentOutput: { text: 'full answer' }
      }
    })

    expect(query.get(route, issue.id)).toMatchObject({
      issue: {
        id: issue.id,
        ownUnresolvedCount: 1,
        directConversationCount: 1,
        activeConversationCount: 1
      },
      directConversations: [
        {
          id: bound.id,
          unresolvedRoundCount: 1,
          navigation: {
            paneKey: 'tab-bound:leaf-bound',
            providerSession: {
              key: 'session_id',
              id: 'provider-bound',
              transcriptPath: '/sessions/provider-bound.jsonl'
            },
            resumeLocator: '/sessions/provider-bound.jsonl'
          },
          latestRound: {
            id: round.id,
            agentOutput: {
              preview: 'full answer',
              completeness: 'complete',
              storage: 'full'
            }
          }
        }
      ],
      workspaceSnapshots: [{ name: 'bound', path: '/workspace/bound' }]
    })

    const unassignedPage = query.listUnassigned(route, { limit: 20 })
    expect(unassignedPage.conversations).toEqual([
      expect.objectContaining({ id: unassigned.id, issueId: null })
    ])

    const roundPage = query.listRounds(route, { issueId: issue.id, limit: 20 })
    expect(roundPage.rounds).toHaveLength(1)
    expect(roundPage.rounds[0]).toMatchObject({
      id: round.id,
      userInput: { preview: 'full prompt', completeness: 'complete', storage: 'full' },
      agentOutput: { preview: 'full answer', completeness: 'complete', storage: 'full' }
    })
    expect(roundPage.rounds[0].userInput).not.toHaveProperty('text')
    expect(roundPage.rounds[0].agentOutput).not.toHaveProperty('text')
  })

  it('chunks UTF-8 bodies without splitting code points and detects body changes', () => {
    const repository = openRepository('body-chunks')
    const query = new IssueQueryService(repository.database)
    const route = resolveIssueAuthorityRoute('local')
    const conversation = createConversation(repository, 'body')
    const originalText = 'é🙂a'
    const round = repository.rounds.create({
      identity: identity('body'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 30,
        dedupeKey: 'query:body',
        agentOutput: { text: originalText }
      }
    })

    const first = query.readRoundBody(route, {
      roundRecordId: round.id,
      field: 'agentOutput',
      expectedBodyRevision: round.bodyRevision,
      expectedStorage: 'full',
      offset: 0,
      maxBytes: 5
    })
    expect(first).toEqual({
      status: 'body-chunk',
      roundRecordId: round.id,
      field: 'agentOutput',
      bodyRevision: 0,
      storage: 'full',
      completeness: 'complete',
      offset: 0,
      nextOffset: getUtf8ByteLength('é'),
      eof: false,
      text: 'é'
    })
    if (first.status !== 'body-chunk') {
      throw new Error('Expected the first Round body chunk.')
    }

    expect(
      query.readRoundBody(route, {
        roundRecordId: round.id,
        field: 'agentOutput',
        expectedBodyRevision: round.bodyRevision,
        expectedStorage: 'full',
        offset: first.nextOffset,
        maxBytes: 5
      })
    ).toEqual({
      status: 'body-chunk',
      roundRecordId: round.id,
      field: 'agentOutput',
      bodyRevision: 0,
      storage: 'full',
      completeness: 'complete',
      offset: 2,
      nextOffset: getUtf8ByteLength(originalText),
      eof: true,
      text: '🙂a'
    })

    const upgraded = repository.rounds.create({
      identity: identity('body-upgrade'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'reconciled',
        occurredAt: 30,
        dedupeKey: 'query:body',
        agentOutput: { text: `${originalText} expanded` }
      }
    })
    expect(upgraded.bodyRevision).toBe(1)
    expect(
      query.readRoundBody(route, {
        roundRecordId: round.id,
        field: 'agentOutput',
        expectedBodyRevision: 0,
        expectedStorage: 'full',
        offset: 0,
        maxBytes: 256
      })
    ).toMatchObject({ status: 'stale', bodyRevision: 1 })
  })

  it('keeps readAt independent from resolution and exposes deleted bodies as unavailable', () => {
    const repository = openRepository('read-resolution')
    const query = new IssueQueryService(repository.database)
    const route = resolveIssueAuthorityRoute('local')
    const conversation = createConversation(repository, 'read')
    const round = repository.rounds.create({
      identity: identity('waiting'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 40,
        dedupeKey: 'query:read',
        pendingQuestion: { text: 'Continue?' }
      }
    })

    repository.rounds.update({
      identity: identity('mark-read'),
      input: { id: round.id, readAt: 50 }
    })
    expect(repository.rounds.get(round.id)).toMatchObject({
      readAt: 50,
      resolvedAt: null,
      resolution: null
    })

    repository.rounds.delete({
      identity: identity('delete-body'),
      input: { id: round.id }
    })
    const deleted = repository.rounds.get(round.id)
    expect(deleted?.bodyRevision).toBe(1)
    expect(
      query.readRoundBody(route, {
        roundRecordId: round.id,
        field: 'pendingQuestion',
        expectedBodyRevision: deleted?.bodyRevision ?? -1,
        expectedStorage: 'deleted',
        offset: 0,
        maxBytes: 256
      })
    ).toMatchObject({
      status: 'unavailable',
      storage: 'deleted',
      completeness: 'complete'
    })
  })
})

describe('Issue authority routing', () => {
  it('accepts only runtime-managed SSH partitions', () => {
    expect(
      resolveIssueAuthorityRoute('ssh:builder', {
        isManagedSshTarget: (targetId) => targetId === 'builder'
      })
    ).toEqual({
      routeExecutionHostId: 'ssh:builder',
      authorityExecutionHostId: 'ssh:builder',
      hostPartitionKey: 'ssh:builder'
    })

    try {
      resolveIssueAuthorityRoute('ssh:unknown')
    } catch (error) {
      expect(error).toBeInstanceOf(IssueRepositoryError)
      expect((error as IssueRepositoryError).code).toBe('issue_route_invalid')
      return
    }
    throw new Error('Expected unmanaged SSH routes to be rejected.')
  })
})

describe('Issue facts change notifications', () => {
  it('publishes only committed revisions and suppresses rolled-back mutations', () => {
    const repository = openRepository('facts-events')
    const changes: Array<{ factsRevision: number; treeRevision: number }> = []
    repository.database.onFactsChanged((change) => {
      changes.push(change)
    })

    createIssue(repository, 'Committed')
    expect(changes).toEqual([
      expect.objectContaining({ factsRevision: 1, treeRevision: 1 })
    ])

    expect(() =>
      repository.issues.create({
        identity: identity('rollback'),
        input: {
          kind: 'local',
          executionHostId: 'local',
          title: 'Rejected',
          parentId: '00000000-0000-4000-8000-000000000000'
        }
      })
    ).toThrow()
    expect(changes).toEqual([
      expect.objectContaining({ factsRevision: 1, treeRevision: 1 })
    ])
  })
})
