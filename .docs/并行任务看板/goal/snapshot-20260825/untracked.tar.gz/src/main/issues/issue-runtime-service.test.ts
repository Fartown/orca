import { afterEach, describe, expect, it } from 'vitest'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import { IssueRuntimeService } from './issue-runtime-service'

const repositories: IssueRepository[] = []
let sequence = 0

function openRuntime(name: string) {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-issue-runtime-${name}`)
    })
  )
  repositories.push(repository)
  return {
    repository,
    service: new IssueRuntimeService(repository, {
      isManagedSshTarget: (targetId) => targetId === 'managed'
    })
  }
}

function identity(label: string) {
  sequence += 1
  return issueMutationIdentity('runtime-test-seed', `${label}-${sequence}`)
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  sequence = 0
})

describe('IssueRuntimeService', () => {
  it('derives the authority partition from the trusted route and keeps retries idempotent', async () => {
    const { repository, service } = openRuntime('route-idempotency')
    const params = {
      executionHostId: 'runtime:paired-host' as const,
      source: { kind: 'local' as const, title: 'Runtime-routed Issue' }
    }
    const context = {
      callerFingerprint: 'paired-device',
      mutationId: 'create-once'
    }

    const first = await service.create(params, context)
    const replay = await service.create(params, context)

    expect(replay).toEqual(first)
    expect(repository.issues.list()).toEqual([
      expect.objectContaining({
        executionHostId: 'local',
        hostPartitionKey: 'local',
        localTitle: 'Runtime-routed Issue'
      })
    ])
    expect(
      service.list({
        mode: 'start',
        executionHostId: 'runtime:paired-host',
        filter: 'all',
        limit: 20
      })
    ).toMatchObject({
      status: 'snapshot-page',
      authority: {
        authorityId: repository.database.getAuthorityId(),
        hostPartitionKey: 'local',
        routeExecutionHostId: 'runtime:paired-host'
      },
      issues: [{ executionHostId: 'runtime:paired-host' }]
    })

    await expect(
      service.create(
        {
          ...params,
          source: { kind: 'local', title: 'Different payload' }
        },
        context
      )
    ).rejects.toMatchObject({
      code: 'mutation_mismatch'
    })
  })

  it('binds with a facts revision fence and never changes the Conversation workspace', async () => {
    const { repository, service } = openRuntime('binding')
    const issue = repository.issues.create({
      identity: identity('issue'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Bind target'
      }
    })
    const conversation = repository.conversations.create({
      identity: identity('conversation'),
      input: {
        executionHostId: 'local',
        workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-a' },
        workspaceSnapshot: { name: 'Folder A', path: '/workspace/a' },
        agent: 'codex'
      }
    })
    const before = service.list({
      mode: 'start',
      executionHostId: 'local',
      filter: 'all',
      limit: 20
    })
    if (before.status !== 'snapshot-page') {
      throw new Error('Expected an Issue snapshot.')
    }

    const result = service.bindConversation(
      {
        executionHostId: 'local',
        mutationId: 'bind-once',
        conversationId: conversation.id,
        issueId: issue.id,
        expectedFactsRevision: before.snapshotFactsRevision
      },
      'desktop-profile'
    )

    expect(result).toMatchObject({
      conversationId: conversation.id,
      previousIssueId: null,
      issueId: issue.id,
      affectedConversationIds: [conversation.id]
    })
    expect(repository.conversations.get(conversation.id)).toMatchObject({
      issueId: issue.id,
      workspaceRef: conversation.workspaceRef,
      workspaceSnapshot: conversation.workspaceSnapshot
    })

    expect(() =>
      service.bindConversation(
        {
          executionHostId: 'local',
          mutationId: 'stale-unbind',
          conversationId: conversation.id,
          issueId: null,
          expectedFactsRevision: before.snapshotFactsRevision
        },
        'desktop-profile'
      )
    ).toThrowError(
      expect.objectContaining({ code: 'issue_facts_revision_stale' })
    )
    expect(repository.conversations.get(conversation.id)?.issueId).toBe(issue.id)
  })

  it('keeps read acknowledgement and resolution as independent mutations', () => {
    const { repository, service } = openRuntime('round-attention')
    const conversation = repository.conversations.create({
      identity: identity('conversation'),
      input: {
        executionHostId: 'local',
        workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-a' },
        workspaceSnapshot: { name: 'Folder A', path: '/workspace/a' },
        agent: 'claude'
      }
    })
    const round = repository.rounds.create({
      identity: identity('round'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'runtime:completion',
        agentOutput: { text: 'Done' }
      }
    })

    const read = service.markRead(
      {
        executionHostId: 'local',
        mutationId: 'read-once',
        roundRecordIds: [round.id],
        readAt: 20
      },
      'desktop-profile'
    )
    expect(read.affectedRoundRecordIds).toEqual([round.id])
    expect(repository.rounds.get(round.id)).toMatchObject({
      readAt: 20,
      resolvedAt: null,
      resolution: null
    })

    service.resolveRound(
      {
        executionHostId: 'local',
        mutationId: 'resolve-once',
        roundRecordId: round.id,
        resolvedAt: 30
      },
      'desktop-profile'
    )
    expect(repository.rounds.get(round.id)).toMatchObject({
      readAt: 20,
      resolvedAt: 30,
      resolution: 'explicit'
    })
  })

  it('serves the authoritative mobile waiting projection through runtime routes', () => {
    const { repository, service } = openRuntime('mobile-pending')
    const conversation = repository.conversations.create({
      identity: identity('conversation'),
      input: {
        executionHostId: 'local',
        workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-mobile' },
        workspaceSnapshot: { name: 'Mobile', path: '/workspace/mobile' },
        agent: 'codex'
      }
    })
    const waiting = repository.rounds.create({
      identity: identity('waiting'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'runtime:mobile-pending',
        pendingQuestion: { text: 'Approve from mobile?' }
      }
    })

    expect(
      service.pendingForMobile({
        executionHostId: 'runtime:paired-host',
        limit: 20
      })
    ).toMatchObject({
      authority: {
        hostPartitionKey: 'local',
        routeExecutionHostId: 'runtime:paired-host'
      },
      entries: [
        {
          round: { id: waiting.id, kind: 'waiting', effectiveResolvedAt: null },
          conversation: {
            id: conversation.id,
            executionHostId: 'runtime:paired-host'
          },
          issue: null
        }
      ]
    })
  })

  it('rejects unmanaged SSH routes before reading or mutating local data', async () => {
    const { repository, service } = openRuntime('ssh-gate')
    repository.issues.create({
      identity: identity('local'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Local only'
      }
    })

    expect(() =>
      service.list({
        mode: 'start',
        executionHostId: 'ssh:unknown',
        filter: 'all',
        limit: 20
      })
    ).toThrowError(expect.objectContaining({ code: 'issue_route_invalid' }))
    await expect(
      service.create(
        {
          executionHostId: 'ssh:unknown',
          source: { kind: 'local', title: 'Should not exist' }
        },
        { callerFingerprint: 'desktop-profile', mutationId: 'bad-ssh' }
      )
    ).rejects.toMatchObject({
      code: 'issue_route_invalid'
    })
    expect(repository.issues.list()).toHaveLength(1)
  })
})
