import { createHash } from 'node:crypto'
import type { IssueDigestSections } from '../../shared/issues/digest-types'
import type { IssueRecord } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import type { IssueDigestInputCandidate } from './issue-digest-input-candidate'

type DigestRow = {
  id: string
  version: number
  revision: number
  input_fingerprint: string
  problem: string | null
  conclusion: string | null
  key_artifacts: string | null
  open_issues: string | null
  next_steps: string | null
}

type ChildDigestCandidateRow = DigestRow & {
  child_title: string
  child_sibling_order: number
}

type ArtifactCandidateRow = {
  id: string
  ref_kind: 'file' | 'url'
  value: string
  label: string | null
  reachable: number | null
  created_at: number
}

export function readDirectChildDigestCandidates(
  database: IssueDatabase,
  issue: IssueRecord
): IssueDigestInputCandidate[] {
  const rows = database
    .prepare(
      `SELECT digest.*, child.sibling_order AS child_sibling_order,
              CASE
                WHEN child.source_kind = 'local' THEN child.local_title
                ELSE child.source_title
              END AS child_title
       FROM issues child
       JOIN issue_digests digest ON digest.issue_id = child.id
       WHERE child.host_partition_key = ?
         AND child.parent_id = ?
         AND digest.status = 'confirmed'
         AND digest.version = (
           SELECT MAX(latest.version)
           FROM issue_digests latest
           WHERE latest.issue_id = child.id AND latest.status = 'confirmed'
         )
       ORDER BY child.sibling_order, child.id`
    )
    .all(issue.hostPartitionKey, issue.id) as ChildDigestCandidateRow[]
  return rows.map((row) => {
    const content = formatDigestSections(digestSectionsFromRow(row))
    return {
      kind: 'direct-child-digest',
      inputId: row.id,
      inputVersion: row.version,
      titleSnapshot: row.child_title,
      occurredAt: null,
      content,
      sourceCompleteness: 'complete',
      sourceFingerprint: {
        version: row.version,
        revision: row.revision,
        inputFingerprint: row.input_fingerprint,
        contentHash: createHash('sha256').update(content).digest('hex')
      }
    }
  })
}

export function readUserArtifactDigestCandidates(
  database: IssueDatabase,
  issue: IssueRecord
): IssueDigestInputCandidate[] {
  const rows = database
    .prepare(
      `SELECT id, ref_kind, value, label, reachable, created_at
       FROM issue_artifact_refs
       WHERE issue_id = ? AND source_kind = 'user'
       ORDER BY created_at DESC, id`
    )
    .all(issue.id) as ArtifactCandidateRow[]
  return rows.map((row) => {
    const content = [
      `Type: ${row.ref_kind}`,
      `Value: ${row.value}`,
      `Label: ${row.label ?? '(none)'}`,
      `Reachable: ${row.reachable === null ? 'unknown' : row.reachable === 1 ? 'yes' : 'no'}`
    ].join('\n')
    return {
      kind: 'user-artifact',
      inputId: row.id,
      inputVersion: row.created_at,
      titleSnapshot: row.label ?? row.value,
      occurredAt: row.created_at,
      content,
      sourceCompleteness: row.reachable === 0 ? 'unavailable' : 'complete',
      sourceFingerprint: {
        createdAt: row.created_at,
        refKind: row.ref_kind,
        value: row.value,
        label: row.label,
        reachable: row.reachable
      }
    }
  })
}

function digestSectionsFromRow(row: DigestRow): IssueDigestSections {
  return {
    problem: row.problem,
    conclusion: row.conclusion,
    keyArtifacts: row.key_artifacts,
    openIssues: row.open_issues,
    nextSteps: row.next_steps
  }
}

function formatDigestSections(sections: IssueDigestSections): string {
  return [
    ['Problem', sections.problem],
    ['Conclusion', sections.conclusion],
    ['Key artifacts', sections.keyArtifacts],
    ['Open issues', sections.openIssues],
    ['Next steps', sections.nextSteps]
  ]
    .map(([label, value]) => `${label}:\n${value || '(empty)'}`)
    .join('\n\n')
}
