import { randomUUID } from 'node:crypto'
import { describe, expect, it, vi } from 'vitest'
import type { IssueActivityPage } from '../../../shared/issues/types'
import { loadIssueActivity, type IssueActivityClientDependencies } from './issue-activity-client'

function page(routeExecutionHostId: 'local' | `runtime:${string}`): IssueActivityPage {
  return {
    authority: {
      authorityId: randomUUID(),
      hostPartitionKey: 'local',
      routeExecutionHostId
    },
    snapshotFactsRevision: 3,
    entries: [],
    nextCursor: null
  }
}

function dependencies(
  overrides: Partial<IssueActivityClientDependencies> = {}
): IssueActivityClientDependencies {
  return {
    supportsCapability: vi.fn().mockResolvedValue(true),
    callRpc: vi.fn().mockResolvedValue(page('local')),
    ...overrides
  }
}

describe('loadIssueActivity', () => {
  it('loads a bounded local Activity page through the existing runtime RPC path', async () => {
    const callRpc = vi.fn().mockResolvedValue(page('local'))
    const result = await loadIssueActivity('local', {}, dependencies({ callRpc }))

    expect(result).toEqual({ status: 'ready', page: pageFromResult(result) })
    expect(callRpc).toHaveBeenCalledWith('local', 'issues.listActivity', {
      executionHostId: 'local',
      limit: 500
    })
  })

  it('does not call a runtime that lacks the Issues capability', async () => {
    const callRpc = vi.fn()
    const result = await loadIssueActivity(
      'runtime:legacy',
      {},
      dependencies({
        supportsCapability: vi.fn().mockResolvedValue(false),
        callRpc
      })
    )

    expect(result).toEqual({ status: 'unsupported' })
    expect(callRpc).not.toHaveBeenCalled()
  })

  it('rejects a response stamped for another route', async () => {
    const result = await loadIssueActivity(
      'runtime:remote',
      {},
      dependencies({ callRpc: vi.fn().mockResolvedValue(page('local')) })
    )

    expect(result).toEqual({
      status: 'error',
      error: 'Issue Activity response was stamped for another route.'
    })
  })
})

function pageFromResult(result: Awaited<ReturnType<typeof loadIssueActivity>>): IssueActivityPage {
  if (result.status !== 'ready') {
    throw new Error('Expected a ready Activity page.')
  }
  return result.page
}
