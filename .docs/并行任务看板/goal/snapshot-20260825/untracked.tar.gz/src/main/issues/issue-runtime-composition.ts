import type { ProjectHostSetup } from '../../shared/project-types'
import type { Repo } from '../../shared/repo-types'
import type { TaskSourceContext } from '../../shared/task-source-context'
import {
  createExternalIssueAdapterRegistry,
  ExternalIssueTrackingService,
  type ExternalIssueRepositoryExecution
} from './external-issue-adapters'
import type { IssueRepository } from './issue-repository'
import type { IssueDigestGenerationExecutor } from './issue-digest-runtime-coordinator'
import { IssueRuntimeService } from './issue-runtime-service'

export type IssueRuntimeCompositionStore = {
  getRepos(): Repo[]
  getProjectHostSetups(): ProjectHostSetup[]
}

export function createIssueRuntimeService(options: {
  repository: IssueRepository
  store: IssueRuntimeCompositionStore
  isManagedSshTarget: (targetId: string) => boolean
  digestExecutor?: IssueDigestGenerationExecutor
}): IssueRuntimeService {
  const adapters = createExternalIssueAdapterRegistry({
    resolveRepositoryExecution: (context) =>
      Promise.resolve(
        resolveExternalIssueRepositoryExecution(options.store, context)
      )
  })
  return new IssueRuntimeService(options.repository, {
    isManagedSshTarget: options.isManagedSshTarget,
    digestExecutor: options.digestExecutor,
    externalIssues: new ExternalIssueTrackingService(
      options.repository.issues,
      adapters
    )
  })
}

export function resolveExternalIssueRepositoryExecution(
  store: IssueRuntimeCompositionStore,
  context: TaskSourceContext
): ExternalIssueRepositoryExecution | null {
  const setups = store.getProjectHostSetups()
  const setup =
    (context.projectHostSetupId
      ? setups.find((candidate) => candidate.id === context.projectHostSetupId)
      : undefined) ??
    setups.find(
      (candidate) =>
        candidate.projectId === context.projectId &&
        candidate.hostId === context.hostId &&
        (!context.repoId || candidate.repoId === context.repoId)
    )
  const repos = store.getRepos()
  const repoId = context.repoId ?? setup?.repoId
  const repo = repoId ? repos.find((candidate) => candidate.id === repoId) : undefined
  const path = setup?.path.trim() || repo?.path.trim()
  const kind = setup?.kind ?? repo?.kind ?? 'git'
  if (!path || kind !== 'git') {
    return null
  }
  return {
    repoPath: path,
    connectionId: setup?.connectionId ?? repo?.connectionId ?? null
  }
}
