import { parseExecutionHostId, type ExecutionHostId } from '../../../shared/execution-host'
import { IssueActivityPageSchema } from '../../../shared/issues/schemas'
import type { IssueActivityPage } from '../../../shared/issues/types'
import { ORCA_ISSUES_RUNTIME_CAPABILITY } from '../../../shared/protocol-version'
import {
  callRuntimeRpc,
  runtimeEnvironmentSupportsCapability,
  type RuntimeClientTarget
} from '../runtime/runtime-rpc-client'

export type IssueActivityLoadResult =
  | { status: 'ready'; page: IssueActivityPage }
  | { status: 'unsupported' }
  | { status: 'error'; error: string }

export type IssueActivityClientDependencies = {
  supportsCapability: (environmentId: string) => Promise<boolean>
  callRpc: (
    routeExecutionHostId: ExecutionHostId,
    method: string,
    params: unknown
  ) => Promise<unknown>
}

export async function loadIssueActivity(
  routeExecutionHostId: ExecutionHostId,
  options: { cursor?: string; limit?: number } = {},
  dependencies: IssueActivityClientDependencies = defaultDependencies
): Promise<IssueActivityLoadResult> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    return { status: 'error', error: 'Invalid Issue host route.' }
  }
  try {
    if (route.kind === 'runtime' && !(await dependencies.supportsCapability(route.environmentId))) {
      return { status: 'unsupported' }
    }
    const page = IssueActivityPageSchema.parse(
      await dependencies.callRpc(route.id, 'issues.listActivity', {
        executionHostId: route.id,
        ...(options.cursor ? { cursor: options.cursor } : {}),
        limit: options.limit ?? 500
      })
    )
    if (page.authority.routeExecutionHostId !== route.id) {
      throw new Error('Issue Activity response was stamped for another route.')
    }
    return { status: 'ready', page }
  } catch (error) {
    return {
      status: 'error',
      error:
        error instanceof Error && error.message.trim() ? error.message : 'Unable to load Activity.'
    }
  }
}

function runtimeTargetForRoute(routeExecutionHostId: ExecutionHostId): RuntimeClientTarget {
  const route = parseExecutionHostId(routeExecutionHostId)
  return route?.kind === 'runtime'
    ? { kind: 'environment', environmentId: route.environmentId }
    : { kind: 'local' }
}

const defaultDependencies: IssueActivityClientDependencies = {
  supportsCapability: (environmentId) =>
    runtimeEnvironmentSupportsCapability(environmentId, ORCA_ISSUES_RUNTIME_CAPABILITY),
  callRpc: (routeExecutionHostId, method, params) =>
    callRuntimeRpc(runtimeTargetForRoute(routeExecutionHostId), method, params, {
      reuseRecentCompatibilityFailure: true
    })
}
