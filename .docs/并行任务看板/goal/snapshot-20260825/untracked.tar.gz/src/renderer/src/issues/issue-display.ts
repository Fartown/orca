import type { IssueRecord } from '../../../shared/issues/types'

type DisplayableIssue = Pick<IssueRecord, 'localTitle' | 'source'>

export function getIssueDisplayTitle(issue: DisplayableIssue): string {
  if (issue.localTitle) {
    return issue.localTitle
  }
  if (issue.source.kind === 'external') {
    return issue.source.titleSnapshot
  }
  return `Issue #${issue.source.number}`
}

export function getIssueSourceLabel(issue: DisplayableIssue): string {
  if (issue.source.kind === 'local') {
    return `Local #${issue.source.number}`
  }
  const provider =
    issue.source.provider.charAt(0).toUpperCase() +
    issue.source.provider.slice(1)
  const identifier =
    issue.source.identifier ??
    (issue.source.number === undefined
      ? issue.source.externalId
      : `#${issue.source.number}`)
  return `${provider} ${identifier}`
}
