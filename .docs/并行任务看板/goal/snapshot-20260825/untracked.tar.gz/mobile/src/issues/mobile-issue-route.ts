import type { ExecutionHostId } from '../../../src/shared/execution-host'
import { normalizeExecutionHostId } from '../../../src/shared/execution-host'
import type {
  ConversationNavigationTarget,
  IssueMobilePendingEntry
} from '../../../src/shared/issues'
import { parsePaneKey } from '../../../src/shared/stable-pane-id'
import type { HostStackRouteTarget } from '../navigation/host-stack-navigation'
import { activateMobileSessionTab } from '../session/mobile-session-tab-activation'
import { mobileSessionRouteTarget } from '../session/mobile-session-route'
import type { RpcClient } from '../transport/rpc-client'

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

export type MobileIssueRouteLocator = {
  hostId: string
  executionHostId?: unknown
  conversationId?: unknown
  issueId?: unknown
  roundRecordId?: unknown
  worktreeId?: unknown
}

export type MobileIssueConversationOpenResult = {
  target: HostStackRouteTarget
  precision: 'pane' | 'workspace'
}

function readEntityId(value: unknown): string | null {
  return typeof value === 'string' && UUID_RE.test(value) ? value : null
}

function readNonEmptyString(value: unknown): string | null {
  return typeof value === 'string' && value.trim().length > 0 ? value : null
}

export function mobileIssueRouteTarget(
  locator: MobileIssueRouteLocator
): HostStackRouteTarget | null {
  const hostId = readNonEmptyString(locator.hostId)
  const executionHostId =
    typeof locator.executionHostId === 'string'
      ? normalizeExecutionHostId(locator.executionHostId)
      : null
  const conversationId = readEntityId(locator.conversationId)
  if (!hostId || !executionHostId || !conversationId) {
    return null
  }

  const params: Record<string, string> = {
    hostId,
    executionHostId,
    conversationId
  }
  const issueId = readEntityId(locator.issueId)
  const roundRecordId = readEntityId(locator.roundRecordId)
  const worktreeId = readNonEmptyString(locator.worktreeId)
  if (issueId) {
    params.issueId = issueId
  }
  if (roundRecordId) {
    params.roundRecordId = roundRecordId
  }
  if (worktreeId) {
    params.worktreeId = worktreeId
  }
  return {
    name: '[hostId]/issues/[conversationId]',
    params
  }
}

export function mobileIssuePendingEntryRouteTarget(
  hostId: string,
  executionHostId: ExecutionHostId,
  entry: IssueMobilePendingEntry
): HostStackRouteTarget {
  const target = mobileIssueRouteTarget({
    hostId,
    executionHostId,
    conversationId: entry.conversation.id,
    issueId: entry.issue?.id,
    roundRecordId: entry.round.id,
    worktreeId: mobileIssueWorkspaceId(entry.conversation)
  })
  if (!target) {
    throw new Error('Invalid pending Issue route locator.')
  }
  return target
}

export function mobileIssueWorkspaceId(
  conversation: Pick<ConversationNavigationTarget, 'workspaceRef'>
): string {
  return conversation.workspaceRef.type === 'worktree'
    ? conversation.workspaceRef.worktreeId
    : `folder:${conversation.workspaceRef.folderWorkspaceId}`
}

export function mobileIssueConversationSessionTarget(
  hostId: string,
  conversation: ConversationNavigationTarget
): HostStackRouteTarget {
  return mobileSessionRouteTarget({
    hostId,
    worktreeId: mobileIssueWorkspaceId(conversation),
    name: conversation.workspaceSnapshot.name
  })
}

export async function activateMobileIssueConversation(
  client: Pick<RpcClient, 'sendRequest'>,
  hostId: string,
  conversation: ConversationNavigationTarget
): Promise<MobileIssueConversationOpenResult> {
  const target = mobileIssueConversationSessionTarget(hostId, conversation)
  const pane = conversation.navigation?.paneKey
    ? parsePaneKey(conversation.navigation.paneKey)
    : null
  if (!pane) {
    return { target, precision: 'workspace' }
  }

  try {
    const response = await activateMobileSessionTab(client, {
      worktree: `id:${mobileIssueWorkspaceId(conversation)}`,
      tabId: pane.tabId,
      leafId: pane.leafId,
      notifyClients: false,
      navigation: 'caller',
      intent: 'user'
    })
    return {
      target,
      precision: response.ok ? 'pane' : 'workspace'
    }
  } catch {
    return { target, precision: 'workspace' }
  }
}
