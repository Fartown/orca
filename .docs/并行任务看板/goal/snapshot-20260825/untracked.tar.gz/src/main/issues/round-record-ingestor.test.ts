import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import type { WorkspaceScope } from '../../shared/folder-workspace-types'
import type { WorkspaceSnapshot } from '../../shared/issues/types'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import {
  ConversationHookIdentityIngestor,
  type ConversationHookIdentityContext
} from './conversation-hook-identity-ingestor'
import { IssueRepository } from './issue-repository'
import {
  RoundRecordIngestor,
  type RoundRecordHookEvent
} from './round-record-ingestor'
import { createProviderTurnRefValue } from './round-record-provider-turn-ref'

const repositories: IssueRepository[] = []

function openRepository(profileId: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId,
      userDataPath: createIssueTestUserDataPath(`orca-round-ingestor-${profileId}`)
    })
  )
  repositories.push(repository)
  return repository
}

function context(
  overrides: Partial<ConversationHookIdentityContext> = {}
): ConversationHookIdentityContext {
  const executionHostId: ExecutionHostId = overrides.executionHostId ?? 'local'
  const workspaceRef: WorkspaceScope =
    overrides.workspaceRef ?? { type: 'folder', folderWorkspaceId: 'folder-1' }
  const workspaceSnapshot: WorkspaceSnapshot = overrides.workspaceSnapshot ?? {
    name: 'Folder 1',
    path: '/workspace/folder-1'
  }
  return {
    executionHostId,
    workspaceRef,
    workspaceSnapshot,
    processIncarnation: 'pty-1:incarnation-1',
    connectionId: null,
    hostPlatform: 'darwin',
    ...overrides
  }
}

function createIngestor(
  repository: IssueRepository,
  resolveContext: () => Promise<ConversationHookIdentityContext | null> = async () =>
    context()
): RoundRecordIngestor {
  return new RoundRecordIngestor(
    repository,
    new ConversationHookIdentityIngestor(repository, { resolveContext })
  )
}

function event(
  overrides: Partial<RoundRecordHookEvent> = {}
): RoundRecordHookEvent {
  return {
    paneKey: 'tab-1:leaf-1',
    worktreeId: 'folder-1',
    connectionId: null,
    launchToken: 'managed-launch',
    stateStartedAt: 2_000,
    receivedAt: 2_100,
    payload: {
      state: 'done',
      agentType: 'codex',
      prompt: 'Implement it',
      lastAssistantMessage: 'Implemented'
    },
    ...overrides
  }
}

function allocateClaim(repository: IssueRepository, launchToken = 'managed-launch') {
  return repository.conversationAllocator.allocateFreshLaunch({
    ...context(),
    agent: 'codex',
    issueId: null,
    launchToken,
    paneKey: 'tab-1:leaf-1',
    processIncarnation: 'pty-1:incarnation-1',
    now: 1_000
  })
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
})

describe('RoundRecordIngestor', () => {
  it('persists a claim-only stop as bounded previews and upgrades a duplicate in place', async () => {
    const repository = openRepository('claim-stop')
    const allocated = allocateClaim(repository)
    const ingestor = createIngestor(repository)

    const first = await ingestor.ingest(event())
    const replay = await ingestor.ingest(
      event({
        receivedAt: 2_200,
        payload: {
          state: 'done',
          agentType: 'codex',
          prompt: 'Implement it',
          lastAssistantMessage: 'Implemented with more detail'
        }
      })
    )

    expect(first).toMatchObject({
      disposition: 'persisted',
      conversationId: allocated.conversation.id
    })
    expect(replay).toEqual(first)
    expect(repository.rounds.list({ conversationId: allocated.conversation.id })).toEqual([
      expect.objectContaining({
        id: first.disposition === 'persisted' ? first.roundId : '',
        stateSource: 'hook',
        resolvedAt: null,
        userInput: expect.objectContaining({
          text: null,
          preview: 'Implement it',
          completeness: 'preview-complete',
          storage: 'preview'
        }),
        agentOutput: expect.objectContaining({
          text: null,
          preview: 'Implemented with more detail',
          completeness: 'preview-complete',
          storage: 'preview'
        })
      })
    ])
  })

  it('attaches a late provider identity before persisting the stop', async () => {
    const repository = openRepository('late-identity')
    const allocated = allocateClaim(repository)
    const ingestor = createIngestor(repository)

    const result = await ingestor.ingest(
      event({
        providerSession: { key: 'session_id', id: 'provider-session-1' },
        providerPromptId: 'provider-turn-1'
      })
    )

    expect(result).toMatchObject({
      disposition: 'persisted',
      conversationId: allocated.conversation.id
    })
    expect(
      repository.conversationIdentities.listForConversation(allocated.conversation.id)
    ).toEqual([
      expect.objectContaining({
        session: { key: 'session_id', id: 'provider-session-1' },
        retiredAt: null
      })
    ])
    expect(
      repository.conversationLaunchClaims.findByToken('local', 'managed-launch', false)
    ).toMatchObject({ consumedAt: 2_100 })
    const identity =
      repository.conversationIdentities.listForConversation(allocated.conversation.id)[0]
    expect(
      repository.database
        .prepare(
          `SELECT ref_kind, value
           FROM round_refs
           WHERE round_id = ?`
        )
        .all(result.disposition === 'persisted' ? result.roundId : '')
    ).toEqual([
      {
        ref_kind: 'provider-turn',
        value: createProviderTurnRefValue(
          identity?.identityFingerprint ?? '',
          'provider-turn-1'
        )
      }
    ])
  })

  it('filters non-turn states without producing a Round Record', async () => {
    const repository = openRepository('boundary')
    const allocated = allocateClaim(repository)
    const ingestor = createIngestor(repository)

    await expect(
      ingestor.ingest(
        event({
          providerSession: { key: 'session_id', id: 'provider-session-1' },
          payload: {
            state: 'done',
            agentType: 'codex',
            sessionBoundary: true
          }
        })
      )
    ).resolves.toEqual({ disposition: 'ignored', reason: 'non-turn-status' })

    expect(repository.rounds.list({ conversationId: allocated.conversation.id })).toEqual([])
    expect(
      repository.conversationIdentities.listForConversation(allocated.conversation.id)
    ).toHaveLength(1)
  })

  it('resolves waiting on resume but requires explicit new input to resolve completion', async () => {
    const repository = openRepository('resolution')
    const allocated = allocateClaim(repository)
    const ingestor = createIngestor(repository)

    const waiting = await ingestor.ingest(
      event({
        stateStartedAt: 2_000,
        payload: {
          state: 'waiting',
          agentType: 'codex',
          interactivePrompt: 'Approve?'
        }
      })
    )
    const resumed = await ingestor.ingest(
      event({
        stateStartedAt: 3_000,
        receivedAt: 3_100,
        payload: { state: 'working', agentType: 'codex' }
      })
    )
    const completion = await ingestor.ingest(
      event({
        stateStartedAt: 4_000,
        receivedAt: 4_100,
        payload: {
          state: 'done',
          agentType: 'codex',
          lastAssistantMessage: 'Finished'
        }
      })
    )
    await ingestor.ingest(
      event({
        stateStartedAt: 5_000,
        receivedAt: 5_100,
        payload: { state: 'working', agentType: 'codex' }
      })
    )

    expect(resumed).toMatchObject({
      disposition: 'resolved',
      roundIds: [waiting.disposition === 'persisted' ? waiting.roundId : '']
    })
    expect(
      repository.rounds.get(waiting.disposition === 'persisted' ? waiting.roundId : '')
    ).toMatchObject({
      readAt: null,
      resolvedAt: 3_000,
      resolution: 'resumed'
    })
    expect(
      repository.rounds.get(completion.disposition === 'persisted' ? completion.roundId : '')
    ).toMatchObject({
      readAt: null,
      resolvedAt: null,
      resolution: null
    })

    const newInput = await ingestor.ingest(
      event({
        stateStartedAt: 6_000,
        receivedAt: 6_100,
        hasExplicitPrompt: true,
        promptInteractionKey: 'prompt-2',
        payload: {
          state: 'working',
          agentType: 'codex',
          prompt: 'Continue'
        }
      })
    )

    expect(newInput).toMatchObject({
      disposition: 'resolved',
      conversationId: allocated.conversation.id,
      roundIds: [completion.disposition === 'persisted' ? completion.roundId : '']
    })
    expect(
      repository.rounds.get(completion.disposition === 'persisted' ? completion.roundId : '')
    ).toMatchObject({
      readAt: 6_000,
      resolvedAt: 6_000,
      resolution: 'new-input'
    })
  })

  it('does not guess a Conversation from prompt or pane text', async () => {
    const repository = openRepository('unresolved')
    const ingestor = createIngestor(repository, async () => null)

    await expect(
      ingestor.ingest(
        event({
          launchToken: undefined,
          providerSession: undefined,
          payload: {
            state: 'done',
            agentType: 'codex',
            prompt: 'A shared prompt',
            lastAssistantMessage: 'A shared result'
          }
        })
      )
    ).resolves.toEqual({
      disposition: 'ignored',
      reason: 'conversation-unresolved'
    })
    expect(repository.conversations.list()).toEqual([])
    expect(
      repository.database.prepare('SELECT COUNT(*) AS count FROM round_records').get()
    ).toEqual({ count: 0 })
  })
})
