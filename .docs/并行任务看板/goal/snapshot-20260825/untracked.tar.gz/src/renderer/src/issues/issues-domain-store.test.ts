import { randomUUID } from 'node:crypto'
import { describe, expect, it, vi } from 'vitest'
import type { ExecutionHostId } from '../../../shared/execution-host'
import {
  DEFAULT_ISSUE_CLIENT_PREFERENCES,
  type IssueClientPreferences,
  type IssueClientSnapshot
} from '../../../shared/issues/client-data'
import type {
  IssueAuthorityDescriptor,
  IssueSearchResult,
  IssueSummary,
  RoundRecordPage,
  RoundRecordPreview
} from '../../../shared/issues/types'
import type {
  IssueDigestMutationResult,
  IssueDigestPreparation
} from '../../../shared/issues/digest-types'
import {
  connectIssuesDomainEvents,
  createIssuesDomainStore,
  issueRoundKey,
  type IssuesDomainDependencies
} from './issues-domain-store'

function deferred<T>(): {
  promise: Promise<T>
  resolve: (value: T) => void
} {
  let resolve!: (value: T) => void
  const promise = new Promise<T>((done) => {
    resolve = done
  })
  return { promise, resolve }
}

function authority(
  routeExecutionHostId: ExecutionHostId
): IssueAuthorityDescriptor {
  return {
    authorityId: randomUUID(),
    hostPartitionKey:
      routeExecutionHostId.startsWith('ssh:')
        ? (routeExecutionHostId as `ssh:${string}`)
        : 'local',
    routeExecutionHostId
  }
}

function issue(
  descriptor: IssueAuthorityDescriptor,
  title: string
): IssueSummary {
  return {
    id: randomUUID(),
    hostPartitionKey: descriptor.hostPartitionKey,
    executionHostId: descriptor.routeExecutionHostId,
    source: { kind: 'local', number: 1 },
    localTitle: title,
    typeLabel: null,
    note: null,
    state: 'active',
    parentId: null,
    siblingOrder: 0,
    createdAt: 1,
    updatedAt: 1,
    archivedAt: null,
    ownUnresolvedCount: 0,
    descendantAttentionCount: 0,
    directConversationCount: 0,
    activeConversationCount: 0
  }
}

function snapshot(
  routeExecutionHostId: ExecutionHostId,
  title: string
): IssueClientSnapshot {
  const descriptor = authority(routeExecutionHostId)
  return {
    authority: descriptor,
    cachedAt: 10,
    factsRevision: 1,
    treeRevision: 1,
    searchRevision: 0,
    issues: [issue(descriptor, title)],
    details: [],
    unassignedConversations: [],
    rounds: []
  }
}

function round(
  conversationId: string,
  occurredAt: number
): RoundRecordPreview {
  const body = {
    completeness: 'complete' as const,
    storage: 'full' as const,
    bytes: 4,
    preview: 'done',
    previewBytes: 4
  }
  return {
    id: randomUUID(),
    conversationId,
    kind: 'completion',
    stateSource: 'hook',
    occurredAt,
    executionChainId: null,
    supersedesRoundId: null,
    userInput: body,
    agentOutput: body,
    pendingQuestion: {
      completeness: 'not-captured',
      storage: 'none',
      bytes: 0,
      preview: null,
      previewBytes: 0
    },
    readAt: null,
    resolvedAt: null,
    resolution: null,
    effectiveResolvedAt: null,
    effectiveResolution: null,
    finalizedAt: occurredAt,
    bodyEvictedAt: null,
    bodyDeletedAt: null,
    bodyRevision: 1,
    createdAt: occurredAt
  }
}

function roundPage(
  routeExecutionHostId: ExecutionHostId,
  rounds: RoundRecordPreview[],
  options: {
    factsRevision?: number
    nextCursor?: string | null
  } = {}
): RoundRecordPage {
  return {
    authority: authority(routeExecutionHostId),
    snapshotFactsRevision: options.factsRevision ?? 1,
    rounds,
    nextCursor: options.nextCursor ?? null
  }
}

function createHarness(
  overrides: Partial<IssuesDomainDependencies> = {}
): {
  dependencies: IssuesDomainDependencies
  writes: IssueClientPreferences[]
} {
  const writes: IssueClientPreferences[] = []
  return {
    writes,
    dependencies: {
      readPreferences: async () => ({
        ...DEFAULT_ISSUE_CLIENT_PREFERENCES
      }),
      writePreferences: async (preferences) => {
        writes.push(preferences)
        return preferences
      },
      loadPartition: async (route) => ({
        status: 'ready',
        value: snapshot(route, route)
      }),
      loadDetail: async () => ({
        status: 'error',
        error: 'not configured'
      }),
      loadUnassigned: async () => ({
        status: 'ready',
        value: []
      }),
      loadRounds: async (route) => ({
        status: 'ready',
        value: roundPage(route, [])
      }),
      ...overrides
    }
  }
}

describe('issues domain store', () => {
  it('keeps only the latest authoritative search response for a host route', async () => {
    const first = deferred<
      { status: 'ready'; value: IssueSearchResult }
    >()
    const descriptor = authority('local')
    const result = (title: string): IssueSearchResult => ({
      authority: descriptor,
      searchRevision: 2,
      indexedSearchRevision: 2,
      isStale: false,
      partial: false,
      groups: [
        {
          issue: {
            id: randomUUID(),
            title,
            typeLabel: null,
            state: 'active'
          },
          matches: []
        }
      ],
      nextCursor: null
    })
    const searchIssues = vi
      .fn()
      .mockImplementationOnce(() => first.promise)
      .mockResolvedValueOnce({ status: 'ready', value: result('new') })
    const harness = createHarness()
    const store = createIssuesDomainStore({
      ...harness.dependencies,
      searchIssues
    })
    const state = store.getState()

    const older = state.search('local', 'old')
    const newer = state.search('local', 'new')
    await newer
    first.resolve({ status: 'ready', value: result('old') })
    await older

    expect(
      store.getState().searchLoadsByRoute.local
    ).toMatchObject({
      query: 'new',
      result: { groups: [{ issue: { title: 'new' } }] }
    })
  })

  it('retains Digest preparation and mutation state for the selected Issue', async () => {
    const descriptor = authority('local')
    const issueId = randomUUID()
    const preparation: IssueDigestPreparation = {
      authority: descriptor,
      issueId,
      coversUntil: 20,
      inputFingerprint: 'b'.repeat(64),
      inputs: [],
      coverage: {
        totalInputCount: 1,
        includedInputCount: 1,
        directRoundCount: 1,
        includedDirectRoundCount: 1,
        totalUtf8Bytes: 10,
        includedUtf8Bytes: 10,
        truncatedInputCount: 0,
        omittedInputCount: 0,
        complete: true,
        note: null
      }
    }
    const mutation: IssueDigestMutationResult = {
      authority: descriptor,
      digest: {
        id: randomUUID(),
        issueId,
        version: 1,
        revision: 0,
        status: 'generating',
        coversUntil: 20,
        problem: null,
        conclusion: null,
        keyArtifacts: null,
        openIssues: null,
        nextSteps: null,
        coverageNote: null,
        inputFingerprint: preparation.inputFingerprint,
        generatorAgent: 'codex',
        generationId: randomUUID(),
        generationError: null,
        generationStartedAt: 20,
        generationFinishedAt: null,
        createdAt: 20,
        updatedAt: 20,
        confirmedAt: null
      }
    }
    const harness = createHarness()
    const store = createIssuesDomainStore({
      ...harness.dependencies,
      prepareDigest: async () => ({ status: 'ready', value: preparation }),
      generateDigest: async () => ({ status: 'ready', value: mutation })
    })
    const state = store.getState()

    await state.prepareDigest('local', issueId)
    await state.generateDigest('local', {
      mutationId: 'generate-1',
      issueId,
      agent: 'codex',
      expectedInputFingerprint: preparation.inputFingerprint
    })

    expect(
      store.getState().digestLoadsByKey[`local\0${issueId}`]
    ).toMatchObject({
      status: 'ready',
      preparation: { inputFingerprint: preparation.inputFingerprint },
      mutation: { digest: { status: 'generating' } }
    })
  })

  it('merges edits made during preference hydration and persists the merged value', async () => {
    const read = deferred<IssueClientPreferences>()
    const harness = createHarness({
      readPreferences: () => read.promise
    })
    const store = createIssuesDomainStore(harness.dependencies)

    const hydration = store.getState().hydrate()
    store.getState().setFilter('needs-me')
    read.resolve({
      ...DEFAULT_ISSUE_CLIENT_PREFERENCES,
      sidebarRootMode: 'issues',
      searchQuery: 'persisted'
    })
    await hydration
    await store.getState().flushPreferences()

    expect(store.getState().preferences).toMatchObject({
      sidebarRootMode: 'issues',
      filter: 'needs-me',
      searchQuery: 'persisted'
    })
    expect(harness.writes).toHaveLength(1)
    expect(harness.writes[0]).toMatchObject({
      sidebarRootMode: 'issues',
      filter: 'needs-me',
      searchQuery: 'persisted'
    })
  })

  it('serializes preference writes without letting an older response replace newer state', async () => {
    const first = deferred<IssueClientPreferences>()
    const second = deferred<IssueClientPreferences>()
    const writePreferences = vi
      .fn<IssuesDomainDependencies['writePreferences']>()
      .mockImplementationOnce(() => first.promise)
      .mockImplementationOnce(() => second.promise)
    const harness = createHarness({ writePreferences })
    const store = createIssuesDomainStore(harness.dependencies)
    await store.getState().hydrate()

    store.getState().setSearchQuery('first')
    store.getState().setSearchQuery('second')
    first.resolve({
      ...DEFAULT_ISSUE_CLIENT_PREFERENCES,
      searchQuery: 'first'
    })
    await vi.waitFor(() => expect(writePreferences).toHaveBeenCalledTimes(2))
    second.resolve({
      ...DEFAULT_ISSUE_CLIENT_PREFERENCES,
      searchQuery: 'second'
    })
    await store.getState().flushPreferences()

    expect(store.getState().preferences.searchQuery).toBe('second')
    expect(writePreferences.mock.calls.map(([value]) => value.searchQuery)).toEqual([
      'first',
      'second'
    ])
  })

  it('reruns a route invalidated during refresh and keeps the newest snapshot', async () => {
    const first = deferred<Awaited<ReturnType<IssuesDomainDependencies['loadPartition']>>>()
    const loadPartition = vi
      .fn<IssuesDomainDependencies['loadPartition']>()
      .mockImplementationOnce(() => first.promise)
      .mockResolvedValueOnce({
        status: 'ready',
        value: snapshot('local', 'new')
      })
    const harness = createHarness({ loadPartition })
    const store = createIssuesDomainStore(harness.dependencies)

    const refresh = store.getState().refreshPartition('local')
    const rerun = store.getState().refreshPartition('local')
    first.resolve({
      status: 'ready',
      value: snapshot('local', 'old')
    })
    await Promise.all([refresh, rerun])

    expect(loadPartition).toHaveBeenCalledTimes(2)
    expect(
      store.getState().partitionsByRoute.local?.issues[0].localTitle
    ).toBe('new')
  })

  it('refreshes different host routes independently', async () => {
    const local = deferred<Awaited<ReturnType<IssuesDomainDependencies['loadPartition']>>>()
    const remote = deferred<Awaited<ReturnType<IssuesDomainDependencies['loadPartition']>>>()
    const harness = createHarness({
      loadPartition: (route) =>
        route === 'local' ? local.promise : remote.promise
    })
    const store = createIssuesDomainStore(harness.dependencies)

    const loading = store
      .getState()
      .setVisibleRoutes(['local', 'runtime:remote'])
    expect(store.getState().partitionsByRoute.local?.status).toBe('loading')
    expect(
      store.getState().partitionsByRoute['runtime:remote']?.status
    ).toBe('loading')

    remote.resolve({
      status: 'unsupported'
    })
    local.resolve({
      status: 'cached',
      value: snapshot('local', 'cached'),
      error: 'offline'
    })
    await loading

    expect(store.getState().partitionsByRoute.local).toMatchObject({
      status: 'cached',
      error: 'offline',
      issues: [{ localTitle: 'cached' }]
    })
    expect(
      store.getState().partitionsByRoute['runtime:remote']
    ).toMatchObject({
      status: 'unsupported',
      issues: []
    })
  })

  it('refreshes only the visible route named by a facts-changed event', async () => {
    const loadPartition = vi
      .fn<IssuesDomainDependencies['loadPartition']>()
      .mockImplementation(async (route) => ({
        status: 'ready',
        value: snapshot(route, route)
      }))
    const harness = createHarness({ loadPartition })
    const store = createIssuesDomainStore(harness.dependencies)
    await store.getState().setVisibleRoutes(['local'])
    loadPartition.mockClear()
    const target = new EventTarget()
    const disconnect = connectIssuesDomainEvents(store, target)

    target.dispatchEvent(
      new CustomEvent('orca:issue-facts-changed', {
        detail: {
          type: 'issueFactsChanged',
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'runtime:hidden',
          factsRevision: 2,
          treeRevision: 2
        }
      })
    )
    target.dispatchEvent(
      new CustomEvent('orca:issue-facts-changed', {
        detail: {
          type: 'issueFactsChanged',
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local',
          factsRevision: 2,
          treeRevision: 2
        }
      })
    )
    await vi.waitFor(() => expect(loadPartition).toHaveBeenCalledTimes(1))
    disconnect()

    expect(loadPartition).toHaveBeenCalledWith('local')
  })

  it('does not turn an error partition into an empty-ready state', async () => {
    const harness = createHarness({
      loadPartition: async () => ({
        status: 'error',
        error: 'database unavailable'
      })
    })
    const store = createIssuesDomainStore(harness.dependencies)

    await store.getState().setVisibleRoutes(['local'])

    expect(store.getState().partitionsByRoute.local).toMatchObject({
      status: 'error',
      error: 'database unavailable',
      issues: []
    })
  })

  it('keeps the newest Round request when an older response completes last', async () => {
    const issueId = randomUUID()
    const first = deferred<Awaited<ReturnType<IssuesDomainDependencies['loadRounds']>>>()
    const newestRound = round(randomUUID(), 20)
    const loadRounds = vi
      .fn<IssuesDomainDependencies['loadRounds']>()
      .mockImplementationOnce(() => first.promise)
      .mockResolvedValueOnce({
        status: 'ready',
        value: roundPage('local', [newestRound], { factsRevision: 2 })
      })
    const store = createIssuesDomainStore(
      createHarness({ loadRounds }).dependencies
    )

    const olderRequest = store.getState().loadRounds('local', issueId)
    const newerRequest = store.getState().loadRounds('local', issueId)
    await newerRequest
    first.resolve({
      status: 'ready',
      value: roundPage('local', [round(randomUUID(), 10)])
    })
    await olderRequest

    expect(loadRounds).toHaveBeenCalledTimes(2)
    expect(store.getState().roundLoadsByKey[issueRoundKey('local', issueId)]).toMatchObject({
      status: 'ready',
      snapshotFactsRevision: 2,
      rounds: [{ id: newestRound.id }]
    })
  })

  it('appends a revision-consistent Round page once and preserves completeness metadata', async () => {
    const issueId = randomUUID()
    const firstRound = round(randomUUID(), 20)
    const olderRound = round(randomUUID(), 10)
    olderRound.agentOutput = {
      ...olderRound.agentOutput,
      completeness: 'preview-complete',
      storage: 'preview'
    }
    const loadRounds = vi
      .fn<IssuesDomainDependencies['loadRounds']>()
      .mockResolvedValueOnce({
        status: 'ready',
        value: roundPage('local', [firstRound], {
          factsRevision: 4,
          nextCursor: 'older'
        })
      })
      .mockResolvedValueOnce({
        status: 'ready',
        value: roundPage('local', [firstRound, olderRound], {
          factsRevision: 4
        })
      })
    const store = createIssuesDomainStore(
      createHarness({ loadRounds }).dependencies
    )

    await store.getState().loadRounds('local', issueId)
    await store.getState().loadMoreRounds('local', issueId)

    expect(loadRounds.mock.calls[1]).toEqual([
      'local',
      {
        issueId,
        cursor: 'older',
        expectedFactsRevision: 4
      }
    ])
    expect(store.getState().roundLoadsByKey[issueRoundKey('local', issueId)]).toMatchObject({
      status: 'ready',
      nextCursor: null,
      rounds: [
        { id: firstRound.id },
        {
          id: olderRound.id,
          agentOutput: {
            completeness: 'preview-complete',
            storage: 'preview'
          }
        }
      ]
    })
  })

  it('keeps already loaded Rounds when loading an older page fails', async () => {
    const issueId = randomUUID()
    const firstRound = round(randomUUID(), 20)
    const loadRounds = vi
      .fn<IssuesDomainDependencies['loadRounds']>()
      .mockResolvedValueOnce({
        status: 'cached',
        value: roundPage('runtime:offline', [firstRound], {
          factsRevision: 4,
          nextCursor: 'older'
        }),
        error: 'offline'
      })
      .mockResolvedValueOnce({
        status: 'error',
        error: 'continuation expired'
      })
    const store = createIssuesDomainStore(
      createHarness({ loadRounds }).dependencies
    )

    await store.getState().loadRounds('runtime:offline', issueId)
    await store.getState().loadMoreRounds('runtime:offline', issueId)

    expect(
      store.getState().roundLoadsByKey[
        issueRoundKey('runtime:offline', issueId)
      ]
    ).toMatchObject({
      status: 'cached',
      error: 'continuation expired',
      rounds: [{ id: firstRound.id }]
    })
  })
})
