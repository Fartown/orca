import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import {
  createIssueTestUserDataPath,
  issueFileDatabaseTestsAvailable,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import type { CreateConversationInput, CreateIssueInput } from './issue-repository-types'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import {
  RoundRecordRetention,
  type RoundRecordRetentionLimits
} from './round-record-retention'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function identity(label: string) {
  mutationSequence += 1
  return issueMutationIdentity('retention-test', `${label}-${mutationSequence}`)
}

function localIssue(title: string): CreateIssueInput {
  return { kind: 'local', executionHostId: 'local', title }
}

function conversation(
  executionHostId: ExecutionHostId = 'local',
  issueId: string | null = null
): CreateConversationInput {
  return {
    executionHostId,
    workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${executionHostId}` },
    workspaceSnapshot: { name: 'Workspace', path: '/workspace' },
    agent: 'codex',
    title: 'Conversation',
    titleSource: 'user',
    issueId
  }
}

function openRepository(
  profileId: string,
  userDataPath: string,
  limits: Partial<RoundRecordRetentionLimits>
): IssueRepository {
  const database = openIssueTestDatabase({
    profileId,
    userDataPath,
    roundRetentionLimits: limits
  })
  const repository = new IssueRepository(database, limits)
  repositories.push(repository)
  return repository
}

async function waitForRoundStorage(
  repository: IssueRepository,
  roundId: string,
  storage: string
): Promise<void> {
  const deadline = Date.now() + 1_000
  while (Date.now() < deadline) {
    if (repository.rounds.get(roundId)?.pendingQuestion.storage === storage) {
      return
    }
    await new Promise((resolve) => setTimeout(resolve, 5))
  }
  throw new Error(`Round ${roundId} did not reach ${storage} storage.`)
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('RoundRecordRetention', () => {
  it('uses the documented four-tier order and two-stage eviction without resolving obligations', () => {
    const repository = openRepository(
      'retention-order',
      createIssueTestUserDataPath('orca-round-retention-order'),
      { softLimitBytes: 1_000, hardLimitBytes: 1_000 }
    )
    const archivedIssue = repository.issues.create({
      identity: identity('archived-issue'),
      input: localIssue('Archived')
    })
    const activeIssue = repository.issues.create({
      identity: identity('active-issue'),
      input: localIssue('Active')
    })
    const archivedConversation = repository.conversations.create({
      identity: identity('archived-conversation'),
      input: conversation('local', archivedIssue.id)
    })
    const activeConversation = repository.conversations.create({
      identity: identity('active-conversation'),
      input: conversation('local', activeIssue.id)
    })

    const archivedResolved = repository.rounds.create({
      identity: identity('archived-resolved'),
      input: {
        conversationId: archivedConversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 40,
        finalizedAt: 40,
        dedupeKey: 'retention:archived-resolved',
        agentOutput: { text: 'A' },
        resolvedAt: 41,
        resolution: 'explicit'
      }
    })
    const activeResolved = repository.rounds.create({
      identity: identity('active-resolved'),
      input: {
        conversationId: activeConversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 30,
        finalizedAt: 30,
        dedupeKey: 'retention:active-resolved',
        agentOutput: { text: 'B' },
        resolvedAt: 31,
        resolution: 'explicit'
      }
    })
    const outstandingCompletion = repository.rounds.create({
      identity: identity('outstanding-completion'),
      input: {
        conversationId: activeConversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 20,
        finalizedAt: 20,
        dedupeKey: 'retention:outstanding-completion',
        agentOutput: { text: 'C' }
      }
    })
    const outstandingWaiting = repository.rounds.create({
      identity: identity('outstanding-waiting'),
      input: {
        conversationId: activeConversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 10,
        finalizedAt: 10,
        dedupeKey: 'retention:outstanding-waiting',
        pendingQuestion: { text: 'D' }
      }
    })
    repository.issues.archive({
      identity: identity('archive'),
      input: { id: archivedIssue.id }
    })

    const retention = new RoundRecordRetention(repository.database, {
      softLimitBytes: 0,
      hardLimitBytes: 1_000
    })
    const result = retention.enforceSoftLimit()

    expect(result.changedRoundIds).toEqual([
      archivedResolved.id,
      activeResolved.id,
      outstandingCompletion.id,
      outstandingWaiting.id,
      archivedResolved.id,
      activeResolved.id,
      outstandingCompletion.id,
      outstandingWaiting.id
    ])
    expect(result.afterBytes).toBe(0)
    expect(repository.rounds.get(outstandingCompletion.id)).toMatchObject({
      effectiveResolvedAt: null,
      agentOutput: { completeness: 'complete', storage: 'evicted' }
    })
    expect(repository.rounds.get(outstandingWaiting.id)).toMatchObject({
      effectiveResolvedAt: null,
      pendingQuestion: { completeness: 'complete', storage: 'evicted' }
    })
    expect(
      repository.database
        .prepare(
          `SELECT entity_id
           FROM issue_search_rebuild_queue
           WHERE entity_kind = 'round'
           ORDER BY entity_id`
        )
        .all()
    ).toHaveLength(4)
  })

  it('schedules post-commit retention and reduces data to the soft watermark', async () => {
    const repository = openRepository(
      'retention-worker',
      createIssueTestUserDataPath('orca-round-retention-worker'),
      { softLimitBytes: 1, hardLimitBytes: 1_000 }
    )
    const conversationRecord = repository.conversations.create({
      identity: identity('conversation'),
      input: conversation()
    })
    const waiting = repository.rounds.create({
      identity: identity('waiting'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'retention:worker',
        pendingQuestion: { text: 'Keep this obligation' }
      }
    })

    await waitForRoundStorage(repository, waiting.id, 'evicted')

    expect(repository.rounds.get(waiting.id)).toMatchObject({
      kind: 'waiting',
      resolvedAt: null,
      effectiveResolvedAt: null,
      pendingQuestion: {
        completeness: 'complete',
        storage: 'evicted',
        text: null,
        preview: null
      }
    })
    expect(new RoundRecordRetention(repository.database).getRetainedBytes()).toBeLessThanOrEqual(1)
  })

  it.runIf(issueFileDatabaseTestsAvailable)(
    'repairs accounting and enforces the configured soft watermark on reopen',
    () => {
      const userDataPath = createIssueTestUserDataPath('orca-round-retention-reopen')
      const first = openRepository('retention-reopen', userDataPath, {
        softLimitBytes: 1_000,
        hardLimitBytes: 1_000
      })
      const conversationRecord = first.conversations.create({
        identity: identity('conversation'),
        input: conversation()
      })
      const round = first.rounds.create({
        identity: identity('round'),
        input: {
          conversationId: conversationRecord.id,
          kind: 'completion',
          stateSource: 'hook',
          occurredAt: 10,
          dedupeKey: 'retention:reopen',
          agentOutput: { text: 'persisted body' }
        }
      })
      first.database
        .prepare(
          `UPDATE issue_authority_meta
           SET retained_round_text_bytes = 999
           WHERE singleton = 1`
        )
        .run()
      first.close()

      const reopened = openRepository('retention-reopen', userDataPath, {
        softLimitBytes: 0,
        hardLimitBytes: 1_000
      })

      expect(new RoundRecordRetention(reopened.database).getRetainedBytes()).toBe(0)
      expect(reopened.rounds.get(round.id)).toMatchObject({
        agentOutput: {
          completeness: 'complete',
          storage: 'evicted',
          text: null,
          preview: null
        }
      })
    }
  )
})
