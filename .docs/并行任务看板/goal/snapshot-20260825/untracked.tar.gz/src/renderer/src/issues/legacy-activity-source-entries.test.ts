import { describe, expect, it } from 'vitest'
import type {
  AgentStatusEntry,
  MigrationUnsupportedPtyEntry
} from '../../../shared/agent-status-types'
import type { RetainedAgentEntry } from '../store/slices/agent-status'
import { buildLegacyActivitySourceEntries } from './legacy-activity-source-entries'

const PANE = 'tab-1:11111111-1111-4111-8111-111111111111'

function stoppedEntry(overrides: Partial<AgentStatusEntry> = {}): AgentStatusEntry {
  return {
    state: 'done',
    prompt: 'Finished work',
    updatedAt: 100,
    stateStartedAt: 100,
    paneKey: PANE,
    agentType: 'codex',
    stateHistory: [],
    ...overrides
  }
}

describe('buildLegacyActivitySourceEntries', () => {
  it('retains the captured worktree attribution after the original tab disappears', () => {
    const entry = stoppedEntry()
    const retained = {
      entry,
      worktreeId: 'worktree-retained',
      tab: { id: 'tab-1' },
      agentType: 'codex',
      startedAt: 50
    } as RetainedAgentEntry

    const entries = buildLegacyActivitySourceEntries({
      liveEntriesByPaneKey: {},
      retainedEntriesByPaneKey: { [PANE]: retained },
      migrationUnsupportedByPtyId: {}
    })

    expect(entries[PANE]).toMatchObject({
      paneKey: PANE,
      worktreeId: 'worktree-retained'
    })
    expect(entry.worktreeId).toBeUndefined()
  })

  it('preserves migration-unsupported worktree and tab metadata for route attribution', () => {
    const unsupported: MigrationUnsupportedPtyEntry = {
      ptyId: 'pty-legacy',
      paneKey: PANE,
      worktreeId: 'worktree-legacy',
      tabId: 'tab-1',
      reason: 'legacy-numeric-pane-key',
      source: 'ssh',
      updatedAt: 200
    }

    const entries = buildLegacyActivitySourceEntries({
      liveEntriesByPaneKey: {},
      retainedEntriesByPaneKey: {},
      migrationUnsupportedByPtyId: { [unsupported.ptyId]: unsupported }
    })

    expect(entries[PANE]).toMatchObject({
      paneKey: PANE,
      worktreeId: 'worktree-legacy',
      tabId: 'tab-1'
    })
  })
})
