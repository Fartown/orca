import { describe, expect, it } from 'vitest'
import type {
  DashboardCard,
  DashboardSnapshot
} from '../../../shared/dashboard-snapshot'
import type {
  IssueDashboardPartitionState
} from './issue-dashboard-store'
import { overlayIssueDashboardSnapshot } from './issue-dashboard-overlay'

const AUTHORITY = {
  authorityId: '11111111-1111-4111-8111-111111111111',
  hostPartitionKey: 'local',
  routeExecutionHostId: 'local'
} as const
const ISSUE_ID = '22222222-2222-4222-8222-222222222222'
const CONVERSATION_ID = '33333333-3333-4333-8333-333333333333'
const ROUND_ID = '44444444-4444-4444-8444-444444444444'

function card(overrides: Partial<DashboardCard> = {}): DashboardCard {
  return {
    paneKey: 'pane-1',
    ptyId: 'pty-1',
    agentType: 'codex',
    bucket: 'done',
    dotState: 'done',
    task: 'Review the plan',
    repoId: 'repo-1',
    worktreeId: 'worktree-1',
    tabId: 'tab-1',
    leafId: 'leaf-1',
    repoName: 'Orca',
    worktreeName: 'issues',
    executionHostId: 'local',
    startedAt: 1,
    finishedAt: 2,
    stateChangedAt: 2,
    unseen: false,
    ...overrides
  }
}

function readyPartition(readAt: number | null): IssueDashboardPartitionState {
  return {
    routeExecutionHostId: 'local',
    paneKeySignature: 'pane-1',
    requestedPaneKeys: ['pane-1'],
    status: 'ready',
    projection: {
      authority: AUTHORITY,
      snapshotFactsRevision: 7,
      panes: [
        {
          paneKey: 'pane-1',
          conversationId: CONVERSATION_ID,
          issue: {
            id: ISSUE_ID,
            title: 'Dashboard integration',
            typeLabel: 'Feature',
            state: 'active'
          },
          latestRound: {
            id: ROUND_ID,
            conversationId: CONVERSATION_ID,
            kind: 'completion',
            stateSource: 'hook',
            occurredAt: 10,
            executionChainId: null,
            supersedesRoundId: null,
            userInput: {
              completeness: 'not-captured',
              storage: 'none',
              bytes: 0,
              preview: null,
              previewBytes: 0
            },
            agentOutput: {
              completeness: 'preview-complete',
              storage: 'preview',
              bytes: 4,
              preview: 'done',
              previewBytes: 4
            },
            pendingQuestion: {
              completeness: 'not-captured',
              storage: 'none',
              bytes: 0,
              preview: null,
              previewBytes: 0
            },
            readAt,
            resolvedAt: null,
            resolution: null,
            effectiveResolvedAt: null,
            effectiveResolution: null,
            finalizedAt: 10,
            bodyEvictedAt: null,
            bodyDeletedAt: null,
            bodyRevision: 1,
            createdAt: 10
          }
        }
      ]
    },
    error: null,
    retryAt: null
  }
}

function snapshot(cards: DashboardCard[]): DashboardSnapshot {
  return { generatedAt: 1, cards }
}

describe('overlayIssueDashboardSnapshot', () => {
  it('uses latest Round readAt as the mapped card read authority', () => {
    const unread = overlayIssueDashboardSnapshot(snapshot([card()]), {
      local: readyPartition(null)
    })
    expect(unread.cards[0]).toMatchObject({
      unseen: true,
      bucket: 'done',
      issueContext: {
        status: 'mapped',
        conversationId: CONVERSATION_ID,
        latestRound: { id: ROUND_ID, readAt: null }
      }
    })

    const read = overlayIssueDashboardSnapshot(snapshot([card({ unseen: true })]), {
      local: readyPartition(20)
    })
    expect(read.cards[0]).toMatchObject({
      unseen: false,
      bucket: 'idle',
      issueContext: {
        status: 'mapped',
        latestRound: { id: ROUND_ID, readAt: 20 }
      }
    })
  })

  it('does not change runtime attention and working buckets', () => {
    const attention = overlayIssueDashboardSnapshot(
      snapshot([
        card({
          bucket: 'attention',
          dotState: 'waiting',
          unseen: false
        })
      ]),
      { local: readyPartition(null) }
    )
    expect(attention.cards[0]).toMatchObject({
      bucket: 'attention',
      unseen: true
    })
  })

  it('marks ready misses, unsupported hosts, and unavailable hosts distinctly', () => {
    const readyMiss = {
      ...readyPartition(null),
      projection: {
        ...readyPartition(null).projection!,
        panes: []
      }
    }
    const unsupported: IssueDashboardPartitionState = {
      ...readyMiss,
      status: 'unsupported',
      projection: null
    }
    const unavailable: IssueDashboardPartitionState = {
      ...readyMiss,
      status: 'error',
      projection: null,
      error: 'offline'
    }

    expect(
      overlayIssueDashboardSnapshot(snapshot([card()]), { local: readyMiss })
        .cards[0].issueContext
    ).toEqual({ status: 'unmapped' })
    expect(
      overlayIssueDashboardSnapshot(snapshot([card()]), { local: unsupported })
        .cards[0].issueContext
    ).toEqual({ status: 'unsupported' })
    expect(
      overlayIssueDashboardSnapshot(snapshot([card()]), { local: unavailable })
        .cards[0].issueContext
    ).toEqual({ status: 'unavailable' })
  })
})
