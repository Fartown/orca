import { randomUUID } from 'node:crypto'
import {
  chmodSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync
} from 'node:fs'
import { join } from 'node:path'
import { z } from 'zod'
import { IssueRouteExecutionHostId } from '../../shared/issues/schemas'
import type {
  AuthorityHostPartitionKey,
  IssueAuthorityDescriptor
} from '../../shared/issues/types'
import { writeFileDurableSync } from '../durable-file-write'
import {
  getIssueReadCacheDirectory,
  getIssueReadCacheFileHash,
  inspectIssueReadCacheHeader
} from './issue-read-cache'

const CachedIssueAuthorityRouteSchema = z.object({
  routeKey: IssueRouteExecutionHostId,
  authorityId: z.string().uuid(),
  hostPartitionKey: z.union([
    z.literal('local'),
    z.string().regex(/^ssh:[^\s]+$/)
  ]),
  cacheFileHash: z.string().regex(/^[a-f0-9]{64}$/),
  lastSeenAt: z.number().int().nonnegative()
})

const IssueCacheRouteIndexFileSchema = z.object({
  version: z.literal(1),
  routes: z.array(CachedIssueAuthorityRouteSchema).max(10_000)
})

export type CachedIssueAuthorityRoute = z.infer<
  typeof CachedIssueAuthorityRouteSchema
>

export class IssueCacheRouteIndex {
  readonly directory: string
  readonly path: string

  constructor(
    private readonly profileId: string,
    userDataPath?: string
  ) {
    this.directory = getIssueReadCacheDirectory(profileId, userDataPath)
    this.path = join(this.directory, 'index.json')
    mkdirSync(this.directory, { recursive: true, mode: 0o700 })
    if (process.platform !== 'win32') {
      chmodSync(this.directory, 0o700)
    }
  }

  resolve(routeKey: string): CachedIssueAuthorityRoute | null {
    const parsedRoute = IssueRouteExecutionHostId.safeParse(routeKey)
    if (!parsedRoute.success) {
      return null
    }
    return (
      this.readOrRebuild().routes.find(
        (entry) => entry.routeKey === parsedRoute.data
      ) ?? null
    )
  }

  record(
    routeKey: string,
    authority: IssueAuthorityDescriptor,
    lastSeenAt: number
  ): CachedIssueAuthorityRoute {
    const parsedRoute = IssueRouteExecutionHostId.parse(routeKey)
    const entry = CachedIssueAuthorityRouteSchema.parse({
      routeKey: parsedRoute,
      authorityId: authority.authorityId,
      hostPartitionKey: authority.hostPartitionKey,
      cacheFileHash: getIssueReadCacheFileHash(
        authority.authorityId,
        authority.hostPartitionKey
      ),
      lastSeenAt
    })
    const current = this.readOrRebuild()
    const routes = current.routes.filter(
      (candidate) => candidate.routeKey !== entry.routeKey
    )
    routes.push(entry)
    this.write({
      version: 1,
      routes: routes.sort((left, right) =>
        left.routeKey.localeCompare(right.routeKey)
      )
    })
    return entry
  }

  rebuild(): CachedIssueAuthorityRoute[] {
    const newestByRoute = new Map<string, CachedIssueAuthorityRoute>()
    for (const name of readdirSync(this.directory)) {
      const match = /^([a-f0-9]{64})\.db$/.exec(name)
      if (!match) {
        continue
      }
      const header = inspectIssueReadCacheHeader(join(this.directory, name))
      if (
        !header ||
        header.profileId !== this.profileId ||
        getIssueReadCacheFileHash(
          header.authorityId,
          header.hostPartitionKey
        ) !== match[1]
      ) {
        continue
      }
      const parsed = CachedIssueAuthorityRouteSchema.safeParse({
        routeKey: header.routeExecutionHostId,
        authorityId: header.authorityId,
        hostPartitionKey: header.hostPartitionKey,
        cacheFileHash: match[1],
        lastSeenAt: header.cachedAt
      })
      if (!parsed.success) {
        continue
      }
      const previous = newestByRoute.get(parsed.data.routeKey)
      if (!previous || previous.lastSeenAt < parsed.data.lastSeenAt) {
        newestByRoute.set(parsed.data.routeKey, parsed.data)
      }
    }
    const routes = [...newestByRoute.values()].sort((left, right) =>
      left.routeKey.localeCompare(right.routeKey)
    )
    this.write({ version: 1, routes })
    return routes
  }

  private readOrRebuild(): z.infer<typeof IssueCacheRouteIndexFileSchema> {
    if (existsSync(this.path)) {
      try {
        return IssueCacheRouteIndexFileSchema.parse(
          JSON.parse(readFileSync(this.path, 'utf-8'))
        )
      } catch {
        return { version: 1, routes: this.rebuild() }
      }
    }
    return { version: 1, routes: this.rebuild() }
  }

  private write(value: z.infer<typeof IssueCacheRouteIndexFileSchema>): void {
    const serialized = JSON.stringify(
      IssueCacheRouteIndexFileSchema.parse(value),
      null,
      2
    )
    const temporary = `${this.path}.${process.pid}.${randomUUID()}.tmp`
    writeFileDurableSync(temporary, this.path, serialized)
    if (process.platform !== 'win32') {
      chmodSync(this.path, 0o600)
    }
  }
}

export function issueCacheAuthorityFromRoute(
  route: CachedIssueAuthorityRoute
): Pick<IssueAuthorityDescriptor, 'authorityId' | 'hostPartitionKey'> & {
  routeExecutionHostId: typeof route.routeKey
} {
  return {
    authorityId: route.authorityId,
    hostPartitionKey: route.hostPartitionKey as AuthorityHostPartitionKey,
    routeExecutionHostId: route.routeKey
  }
}
