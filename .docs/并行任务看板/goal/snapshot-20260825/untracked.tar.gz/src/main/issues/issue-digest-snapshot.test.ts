import { afterEach, describe, expect, it } from 'vitest'
import type { IssueDigestSections } from '../../shared/issues/digest-types'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueDigestRepository } from './issue-digest-repository'
import { buildIssueDigestSnapshot } from './issue-digest-snapshot'
import { IssueRepository, issueMutationIdentity } from './issue-repository'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-issue-digest-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  mutationSequence += 1
  return issueMutationIdentity('digest-snapshot-test', `${label}-${mutationSequence}`)
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('buildIssueDigestSnapshot', () => {
  it('keeps the fingerprint stable when only the coverage boundary changes', () => {
    const repository = openRepository('stable-fingerprint')
    const issue = repository.issues.create({
      identity: identity('issue'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Stable fingerprint'
      }
    })
    const conversation = repository.conversations.create({
      identity: identity('conversation'),
      input: {
        executionHostId: 'local',
        workspaceRef: { type: 'folder', folderWorkspaceId: 'fingerprint-folder' },
        workspaceSnapshot: { name: 'Fingerprint', path: '/workspace/fingerprint' },
        agent: 'codex',
        issueId: issue.id
      }
    })
    repository.rounds.create({
      identity: identity('round'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'stable-fingerprint-round',
        agentOutput: { text: 'Unchanged source.' }
      }
    })

    const first = buildIssueDigestSnapshot(repository.database, issue, 10)
    const laterBoundary = buildIssueDigestSnapshot(repository.database, issue, 20)

    expect(laterBoundary.inputs).toEqual(first.inputs)
    expect(laterBoundary.inputFingerprint).toBe(first.inputFingerprint)
  })

  it('marks runtime-only preview text as partial coverage', () => {
    const repository = openRepository('preview-coverage')
    const issue = repository.issues.create({
      identity: identity('issue'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Preview coverage'
      }
    })
    const conversation = repository.conversations.create({
      identity: identity('conversation'),
      input: {
        executionHostId: 'local',
        workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-a' },
        workspaceSnapshot: { name: 'Folder A', path: '/workspace/a' },
        agent: 'codex',
        issueId: issue.id
      }
    })
    const round = repository.rounds.create({
      identity: identity('round'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'preview-only-round',
        userInput: {
          preview: 'Runtime user input preview.',
          completeness: 'preview-complete',
          storage: 'preview'
        },
        agentOutput: {
          preview: 'Runtime preview, not an archived transcript.',
          completeness: 'preview-complete',
          storage: 'preview'
        },
        pendingQuestion: {
          preview: 'Runtime pending-question preview.',
          completeness: 'preview-complete',
          storage: 'preview'
        }
      }
    })

    const snapshot = buildIssueDigestSnapshot(repository.database, issue, 10)

    expect(snapshot.inputs).toEqual([
      expect.objectContaining({
        kind: 'direct-round',
        inputId: round.id,
        completeness: 'partial'
      })
    ])
    expect(snapshot.coverage).toMatchObject({
      includedInputCount: 1,
      complete: false
    })
    expect(snapshot.coverage.note).toContain(
      '1 included inputs have incomplete source text.'
    )
  })

  it('prioritizes outstanding rounds before newer resolved rounds', () => {
    const repository = openRepository('round-priority')
    const issue = repository.issues.create({
      identity: identity('issue'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Round priority'
      }
    })
    const conversation = repository.conversations.create({
      identity: identity('conversation'),
      input: {
        executionHostId: 'local',
        workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-b' },
        workspaceSnapshot: { name: 'Folder B', path: '/workspace/b' },
        agent: 'claude',
        issueId: issue.id
      }
    })
    const outstanding = repository.rounds.create({
      identity: identity('outstanding'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 100,
        dedupeKey: 'outstanding-round',
        pendingQuestion: { text: 'Need a decision.' }
      }
    })
    const resolved = repository.rounds.create({
      identity: identity('resolved'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 200,
        dedupeKey: 'resolved-round',
        agentOutput: { text: 'Finished.' },
        resolvedAt: 201,
        resolution: 'explicit'
      }
    })

    const snapshot = buildIssueDigestSnapshot(repository.database, issue, 300)

    expect(
      snapshot.inputs
        .filter((input) => input.kind === 'direct-round')
        .map((input) => input.inputId)
    ).toEqual([outstanding.id, resolved.id])
  })

  it('reads only direct child confirmed digests and ignores descendants and drafts', () => {
    const repository = openRepository('direct-children')
    const parent = repository.issues.create({
      identity: identity('parent'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Parent'
      }
    })
    const child = repository.issues.create({
      identity: identity('child'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Child',
        parentId: parent.id
      }
    })
    const grandchild = repository.issues.create({
      identity: identity('grandchild'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Grandchild',
        parentId: child.id
      }
    })
    const digests = new IssueDigestRepository(
      repository.database,
      repository.issueEvents
    )
    const confirmedChild = createDigest(
      digests,
      child,
      'Child confirmed',
      true
    )
    createDigest(digests, child, 'Child newer draft', false)
    createDigest(digests, grandchild, 'Grandchild confirmed', true)

    const snapshot = buildIssueDigestSnapshot(repository.database, parent, 100)

    expect(
      snapshot.inputs
        .filter((input) => input.kind === 'direct-child-digest')
        .map((input) => input.inputId)
    ).toEqual([confirmedChild.id])
    expect(snapshot.materializedInputs[0]?.content).toContain('Child confirmed')
    expect(snapshot.materializedInputs[0]?.content).not.toContain(
      'Child newer draft'
    )
    expect(snapshot.materializedInputs[0]?.content).not.toContain(
      'Grandchild confirmed'
    )
  })
})

function createDigest(
  digests: IssueDigestRepository,
  issue: Parameters<IssueDigestRepository['createGenerating']>[0]['issue'],
  conclusion: string,
  confirmed: boolean
) {
  const generating = digests.createGenerating({
    identity: identity('generate-digest'),
    issue,
    agent: 'codex',
    coversUntil: 100,
    inputFingerprint: `${mutationSequence.toString(16).padStart(64, '0')}`,
    coverageNote: null,
    inputs: []
  }).digest
  const sections: IssueDigestSections = {
    problem: null,
    conclusion,
    keyArtifacts: null,
    openIssues: null,
    nextSteps: null
  }
  const draft = digests.completeGeneration(generating.id, sections)
  if (!confirmed) {
    return draft
  }
  return digests.confirm({
    identity: identity('confirm-digest'),
    digestId: draft.id,
    expectedRevision: draft.revision,
    stale: false,
    currentInputFingerprint: draft.inputFingerprint
  })
}
