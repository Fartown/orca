import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueMobilePendingQuery } from './issue-mobile-pending-query'
import { resolveIssueAuthorityRoute } from './issue-authority-route'
import { IssueRepository, issueMutationIdentity } from './issue-repository'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-issue-mobile-pending-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  mutationSequence += 1
  return issueMutationIdentity('mobile-pending-test', `${label}-${mutationSequence}`)
}

function createIssue(
  repository: IssueRepository,
  title: string,
  executionHostId: ExecutionHostId = 'local'
) {
  return repository.issues.create({
    identity: identity(`issue-${title}`),
    input: { kind: 'local', title, executionHostId }
  })
}

function createConversation(
  repository: IssueRepository,
  label: string,
  options: {
    executionHostId?: ExecutionHostId
    issueId?: string | null
  } = {}
) {
  const executionHostId = options.executionHostId ?? 'local'
  return repository.conversations.create({
    identity: identity(`conversation-${label}`),
    input: {
      executionHostId,
      workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${label}` },
      workspaceSnapshot: { name: label, path: `/workspace/${label}` },
      agent: 'codex',
      title: `${label} conversation`,
      titleSource: 'user',
      issueId: options.issueId ?? null
    }
  })
}

function createRound(
  repository: IssueRepository,
  input: {
    conversationId: string
    kind: 'waiting' | 'completion'
    occurredAt: number
    label: string
    readAt?: number
  }
) {
  return repository.rounds.create({
    identity: identity(`round-${input.label}`),
    input: {
      conversationId: input.conversationId,
      kind: input.kind,
      stateSource: 'hook',
      occurredAt: input.occurredAt,
      dedupeKey: `mobile-pending:${input.label}`,
      pendingQuestion:
        input.kind === 'waiting' ? { text: `Question ${input.label}` } : undefined,
      agentOutput:
        input.kind === 'completion' ? { text: `Answer ${input.label}` } : undefined,
      readAt: input.readAt
    }
  })
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('IssueMobilePendingQuery', () => {
  it('returns only unresolved waiting records with navigation and preview context', () => {
    const repository = openRepository('projection')
    const query = new IssueMobilePendingQuery(repository.database)
    const issue = createIssue(repository, 'Approval needed')
    const assigned = createConversation(repository, 'assigned', { issueId: issue.id })
    const unassigned = createConversation(repository, 'unassigned')
    repository.conversationLaunchClaims.create({
      conversationId: assigned.id,
      launchToken: 'mobile-pending-navigation',
      paneKey: 'tab-assigned:leaf-assigned',
      createdAt: 1,
      expiresAt: 1_000
    })
    repository.conversationIdentities.attach({
      conversationId: assigned.id,
      agent: 'codex',
      providerSession: {
        key: 'session_id',
        id: 'provider-assigned',
        transcriptPath: '/sessions/provider-assigned.jsonl'
      },
      resumeLocator: '/sessions/provider-assigned.jsonl',
      observedAt: 2
    })
    const assignedWaiting = createRound(repository, {
      conversationId: assigned.id,
      kind: 'waiting',
      occurredAt: 40,
      label: 'assigned',
      readAt: 41
    })
    const unassignedWaiting = createRound(repository, {
      conversationId: unassigned.id,
      kind: 'waiting',
      occurredAt: 30,
      label: 'unassigned'
    })
    createRound(repository, {
      conversationId: assigned.id,
      kind: 'completion',
      occurredAt: 50,
      label: 'completion'
    })
    const resolvedWaiting = createRound(repository, {
      conversationId: assigned.id,
      kind: 'waiting',
      occurredAt: 20,
      label: 'resolved'
    })
    repository.rounds.resolve({
      identity: identity('resolve-old-waiting'),
      input: { id: resolvedWaiting.id, resolvedAt: 21 }
    })

    const page = query.list(resolveIssueAuthorityRoute('local'), { limit: 20 })

    expect(page.entries.map((entry) => entry.round.id)).toEqual([
      assignedWaiting.id,
      unassignedWaiting.id
    ])
    expect(page.entries[0]).toMatchObject({
      round: {
        id: assignedWaiting.id,
        kind: 'waiting',
        readAt: 41,
        resolvedAt: null,
        effectiveResolvedAt: null,
        pendingQuestion: {
          preview: 'Question assigned',
          completeness: 'complete',
          storage: 'full'
        }
      },
      conversation: {
        id: assigned.id,
        workspaceSnapshot: { name: 'assigned', path: '/workspace/assigned' },
        navigation: {
          paneKey: 'tab-assigned:leaf-assigned',
          providerSession: {
            key: 'session_id',
            id: 'provider-assigned',
            transcriptPath: '/sessions/provider-assigned.jsonl'
          },
          resumeLocator: '/sessions/provider-assigned.jsonl'
        }
      },
      issue: {
        id: issue.id,
        title: 'Approval needed',
        state: 'active'
      }
    })
    expect(page.entries[0]?.round.pendingQuestion).not.toHaveProperty('text')
    expect(page.entries[1]).toMatchObject({
      round: { id: unassignedWaiting.id },
      conversation: {
        id: unassigned.id,
        issueId: null,
        workspaceSnapshot: { name: 'unassigned', path: '/workspace/unassigned' }
      },
      issue: null
    })
  })

  it('keeps read waiting records pending until they are explicitly resolved', () => {
    const repository = openRepository('read-resolution')
    const query = new IssueMobilePendingQuery(repository.database)
    const conversation = createConversation(repository, 'read-resolution')
    const waiting = createRound(repository, {
      conversationId: conversation.id,
      kind: 'waiting',
      occurredAt: 10,
      label: 'read-resolution'
    })

    repository.rounds.markRead({
      identity: identity('mark-read'),
      input: { ids: [waiting.id], readAt: 11 }
    })
    expect(
      query.list(resolveIssueAuthorityRoute('local'), { limit: 20 }).entries
    ).toEqual([
      expect.objectContaining({
        round: expect.objectContaining({
          id: waiting.id,
          readAt: 11,
          resolvedAt: null
        })
      })
    ])

    repository.rounds.resolve({
      identity: identity('resolve'),
      input: { id: waiting.id, resolvedAt: 12 }
    })
    expect(
      query.list(resolveIssueAuthorityRoute('local'), { limit: 20 }).entries
    ).toEqual([])
  })

  it('isolates SSH partitions and restamps local authority through runtime routes', () => {
    const repository = openRepository('host-routes')
    const query = new IssueMobilePendingQuery(repository.database)
    const localConversation = createConversation(repository, 'local')
    const sshIssue = createIssue(repository, 'Remote approval', 'ssh:builder')
    const sshConversation = createConversation(repository, 'ssh', {
      executionHostId: 'ssh:builder',
      issueId: sshIssue.id
    })
    const localWaiting = createRound(repository, {
      conversationId: localConversation.id,
      kind: 'waiting',
      occurredAt: 10,
      label: 'local'
    })
    const sshWaiting = createRound(repository, {
      conversationId: sshConversation.id,
      kind: 'waiting',
      occurredAt: 20,
      label: 'ssh'
    })

    const sshPage = query.list(
      resolveIssueAuthorityRoute('ssh:builder', {
        isManagedSshTarget: (targetId) => targetId === 'builder'
      }),
      { limit: 20 }
    )
    expect(sshPage.entries).toEqual([
      expect.objectContaining({
        round: expect.objectContaining({ id: sshWaiting.id }),
        conversation: expect.objectContaining({
          id: sshConversation.id,
          executionHostId: 'ssh:builder'
        })
      })
    ])

    const runtimePage = query.list(resolveIssueAuthorityRoute('runtime:paired'), {
      limit: 20
    })
    expect(runtimePage.authority).toMatchObject({
      hostPartitionKey: 'local',
      routeExecutionHostId: 'runtime:paired'
    })
    expect(runtimePage.entries).toEqual([
      expect.objectContaining({
        round: expect.objectContaining({ id: localWaiting.id }),
        conversation: expect.objectContaining({
          id: localConversation.id,
          executionHostId: 'runtime:paired'
        })
      })
    ])
  })
})
