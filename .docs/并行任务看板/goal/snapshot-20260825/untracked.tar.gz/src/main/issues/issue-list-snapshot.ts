import {
  ISSUE_LIST_PAGE_MAX_BYTES,
  ISSUE_LIST_PAGE_MAX_RECORDS
} from '../../shared/issues/constants'
import type {
  IssueListFilter,
  IssueListResult,
  IssueSummary,
  UnassignedConversationSummary
} from '../../shared/issues/types'
import type { IssueHostRevisions } from './issue-host-state'
import {
  encodeIssueQueryCursor,
  type IssueListCursor
} from './issue-query-cursor'

export function buildIssueListPage(input: {
  authority: IssueListResult['authority']
  revisions: IssueHostRevisions
  filter: IssueListFilter
  issues: IssueSummary[]
  unassigned?: UnassignedConversationSummary
  startIndex: number
  limit: number
}): IssueListResult {
  const limit = Math.min(input.limit, ISSUE_LIST_PAGE_MAX_RECORDS)
  const page: IssueSummary[] = []
  for (
    let index = input.startIndex;
    index < input.issues.length && page.length < limit;
    index += 1
  ) {
    page.push(input.issues[index])
    if (issuePageByteLength(input, page, index + 1) > ISSUE_LIST_PAGE_MAX_BYTES) {
      page.pop()
      break
    }
  }
  if (page.length === 0 && input.startIndex < input.issues.length) {
    throw new Error('One Issue summary exceeds the RPC page byte budget.')
  }
  const nextIndex = input.startIndex + page.length
  return {
    status: 'snapshot-page',
    authority: input.authority,
    snapshotFactsRevision: input.revisions.factsRevision,
    snapshotTreeRevision: input.revisions.treeRevision,
    issues: page,
    ...(input.unassigned ? { unassigned: input.unassigned } : {}),
    nextCursor:
      nextIndex < input.issues.length
        ? encodeIssueQueryCursor(cursorForNextPage(input, nextIndex))
        : null
  }
}

function issuePageByteLength(
  input: Parameters<typeof buildIssueListPage>[0],
  issues: IssueSummary[],
  nextIndex: number
): number {
  return Buffer.byteLength(
    JSON.stringify({
      status: 'snapshot-page',
      authority: input.authority,
      snapshotFactsRevision: input.revisions.factsRevision,
      snapshotTreeRevision: input.revisions.treeRevision,
      issues,
      ...(input.unassigned ? { unassigned: input.unassigned } : {}),
      nextCursor:
        nextIndex < input.issues.length
          ? encodeIssueQueryCursor(cursorForNextPage(input, nextIndex))
          : null
    }),
    'utf8'
  )
}

function cursorForNextPage(
  input: Parameters<typeof buildIssueListPage>[0],
  nextIndex: number
): IssueListCursor {
  return {
    v: 1,
    kind: 'issue-list',
    filter: input.filter,
    factsRevision: input.revisions.factsRevision,
    treeRevision: input.revisions.treeRevision,
    nextIndex,
    previousIssueId: input.issues[nextIndex - 1]?.id ?? ''
  }
}
