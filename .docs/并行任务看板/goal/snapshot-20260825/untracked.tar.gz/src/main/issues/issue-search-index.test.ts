import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import { IssueRuntimeService } from './issue-runtime-service'

const repositories: IssueRepository[] = []
let sequence = 0

function openRuntime(name: string) {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-issue-search-${name}`)
    })
  )
  repositories.push(repository)
  return {
    repository,
    service: new IssueRuntimeService(repository, {
      isManagedSshTarget: (targetId) => targetId === 'remote'
    })
  }
}

function identity(label: string) {
  sequence += 1
  return issueMutationIdentity('search-test', `${label}-${sequence}`)
}

function seedIssue(
  repository: IssueRepository,
  input: {
    executionHostId?: ExecutionHostId
    title: string
    conversationTitle?: string
    roundText?: string
  }
) {
  const executionHostId = input.executionHostId ?? 'local'
  const issue = repository.issues.create({
    identity: identity('issue'),
    input: {
      kind: 'local',
      executionHostId,
      title: input.title,
      typeLabel: 'feature',
      note: 'searchable note'
    }
  })
  const conversation = repository.conversations.create({
    identity: identity('conversation'),
    input: {
      executionHostId,
      workspaceRef: {
        type: 'folder',
        folderWorkspaceId: `folder-${executionHostId}`
      },
      workspaceSnapshot: {
        name: `Workspace ${executionHostId}`,
        path: `/workspace/${executionHostId}`
      },
      agent: 'codex',
      title: input.conversationTitle ?? 'Search conversation',
      titleSource: 'user',
      issueId: issue.id
    }
  })
  const round = repository.rounds.create({
    identity: identity('round'),
    input: {
      conversationId: conversation.id,
      kind: 'completion',
      stateSource: 'hook',
      occurredAt: sequence,
      dedupeKey: `search-round-${sequence}`,
      agentOutput: {
        text: input.roundText ?? 'Searchable round body',
        completeness: 'complete',
        storage: 'full'
      }
    }
  })
  return { issue, conversation, round }
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  sequence = 0
})

describe('IssueSearchIndex', () => {
  it('reports stale results until indexing catches up and removes deleted body text', () => {
    const { repository, service } = openRuntime('revision-and-deletion')
    const seeded = seedIssue(repository, {
      title: 'Release readiness',
      roundText: 'private-needle body retained in the authoritative Round Record'
    })

    expect(
      service.search({
        executionHostId: 'local',
        query: 'private-needle',
        limit: 20
      })
    ).toMatchObject({
      searchRevision: 3,
      indexedSearchRevision: 0,
      isStale: true,
      groups: []
    })

    repository.searchIndex.drain('local')
    const indexed = service.search({
      executionHostId: 'local',
      query: 'private-needle',
      limit: 20
    })
    expect(indexed).toMatchObject({
      searchRevision: 3,
      indexedSearchRevision: 3,
      isStale: false,
      partial: false,
      groups: [
        {
          issue: { id: seeded.issue.id, title: 'Release readiness' },
          matches: [
            {
              entityKind: 'round',
              entityId: seeded.round.id,
              issueId: seeded.issue.id,
              completeness: 'partial'
            }
          ]
        }
      ]
    })

    repository.rounds.delete({
      identity: identity('delete-body'),
      input: { id: seeded.round.id }
    })
    expect(
      service.search({
        executionHostId: 'local',
        query: 'private-needle',
        limit: 20
      })
    ).toMatchObject({
      isStale: true,
      groups: [{ matches: [{ entityId: seeded.round.id }] }]
    })

    repository.searchIndex.drain('local')
    expect(
      service.search({
        executionHostId: 'local',
        query: 'private-needle',
        limit: 20
      })
    ).toMatchObject({
      searchRevision: 4,
      indexedSearchRevision: 4,
      isStale: false,
      groups: []
    })
  })

  it('matches consecutive CJK bigrams and marks the bounded single-character fallback partial', () => {
    const { repository, service } = openRuntime('cjk')
    const seeded = seedIssue(repository, {
      title: '并行任务管理',
      roundText: '中文正文'
    })
    repository.searchIndex.drain('local')

    expect(
      service.search({
        executionHostId: 'local',
        query: '并行任务',
        limit: 20
      })
    ).toMatchObject({
      partial: false,
      groups: [
        {
          issue: { id: seeded.issue.id },
          matches: [{ entityKind: 'issue', entityId: seeded.issue.id }]
        }
      ]
    })
    expect(
      service.search({
        executionHostId: 'local',
        query: '并行管理',
        limit: 20
      }).groups
    ).toEqual([])
    expect(
      service.search({
        executionHostId: 'local',
        query: '任',
        limit: 20
      })
    ).toMatchObject({
      partial: true,
      groups: [
        {
          issue: { id: seeded.issue.id },
          matches: [{ entityKind: 'issue', entityId: seeded.issue.id }]
        }
      ]
    })
  })

  it('keeps search documents isolated by authority host partition', () => {
    const { repository, service } = openRuntime('host-isolation')
    const local = seedIssue(repository, {
      title: 'Local only marker'
    })
    const remote = seedIssue(repository, {
      executionHostId: 'ssh:remote',
      title: 'Remote only marker'
    })
    repository.searchIndex.drain('local')
    repository.searchIndex.drain('ssh:remote')

    const localResult = service.search({
      executionHostId: 'local',
      query: 'marker',
      limit: 20
    })
    const remoteResult = service.search({
      executionHostId: 'ssh:remote',
      query: 'marker',
      limit: 20
    })

    expect(localResult.groups.flatMap((group) => group.matches)).toEqual(
      expect.arrayContaining([expect.objectContaining({ entityId: local.issue.id })])
    )
    expect(localResult.groups.flatMap((group) => group.matches)).not.toEqual(
      expect.arrayContaining([expect.objectContaining({ entityId: remote.issue.id })])
    )
    expect(remoteResult.groups.flatMap((group) => group.matches)).toEqual(
      expect.arrayContaining([expect.objectContaining({ entityId: remote.issue.id })])
    )
    expect(remoteResult.groups.flatMap((group) => group.matches)).not.toEqual(
      expect.arrayContaining([expect.objectContaining({ entityId: local.issue.id })])
    )
  })
})
