export const ISSUE_MAX_DEPTH = 3
export const ORCA_ISSUES_RUNTIME_CAPABILITY = 'orca-issues.v1' as const

export const ISSUE_STATES = ['active', 'archived'] as const
export const CONVERSATION_STATES = ['active', 'closed'] as const
export const ROUND_RECORD_KINDS = ['completion', 'waiting'] as const
export const ROUND_RECORD_STATE_SOURCES = ['hook', 'scrape', 'reconciled'] as const
export const ROUND_TEXT_COMPLETENESS = [
  'not-captured',
  'preview-complete',
  'truncated',
  'complete'
] as const
export const ROUND_TEXT_STORAGE = [
  'none',
  'preview',
  'full',
  'evicted-preview',
  'evicted',
  'deleted'
] as const
export const ROUND_RESOLUTIONS = ['new-input', 'explicit', 'archive', 'resumed'] as const
export const EFFECTIVE_ROUND_RESOLUTIONS = [...ROUND_RESOLUTIONS, 'superseded'] as const
export const ISSUE_EVENT_KINDS = [
  'created',
  'metadata-updated',
  'reparented',
  'archived',
  'reopened',
  'deleted',
  'conversation-bound',
  'conversation-unbound',
  'conversation-rebound',
  'digest-confirmed',
  'source-refreshed',
  'profile-transferred-in',
  'profile-transferred-out'
] as const

export const ROUND_USER_INPUT_MAX_BYTES = 256 * 1024
export const ROUND_AGENT_OUTPUT_MAX_BYTES = 1024 * 1024
export const ROUND_PENDING_QUESTION_MAX_BYTES = 64 * 1024
export const ROUND_TEXT_PREVIEW_MAX_BYTES = 8 * 1024
export const ISSUE_LIST_PAGE_MAX_RECORDS = 500
export const ISSUE_LIST_PAGE_MAX_BYTES = 1024 * 1024
export const ROUND_BODY_CHUNK_MAX_BYTES = 256 * 1024
export const ISSUE_SEARCH_QUERY_MAX_BYTES = 2 * 1024
export const ISSUE_SEARCH_PAGE_MAX_MATCHES = 200
export const ISSUE_SEARCH_PREVIEW_MAX_BYTES = 8 * 1024
export const PROFILE_ROUND_TEXT_SOFT_LIMIT_BYTES = 256 * 1024 * 1024
export const PROFILE_ROUND_TEXT_HARD_LIMIT_BYTES = 320 * 1024 * 1024
