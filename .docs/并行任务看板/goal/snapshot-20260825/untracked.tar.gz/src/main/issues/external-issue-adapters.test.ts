import { afterEach, describe, expect, it, vi } from 'vitest'
import type { IssueRecord } from '../../shared/issues/types'
import type { TaskProvider } from '../../shared/task-providers'
import type { TaskSourceContext } from '../../shared/task-source-context'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import {
  createExternalIssueAdapterRegistry,
  ExternalIssueTrackingService,
  type ExternalIssueProviderClients
} from './external-issue-adapters'
import { IssueRepository, issueMutationIdentity } from './issue-repository'

const repositories: IssueRepository[] = []
let sequence = 0

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-external-adapters-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  sequence += 1
  return issueMutationIdentity('external-adapter-test', `${label}-${sequence}`)
}

function sourceContext(
  provider: TaskProvider,
  providerIdentity: TaskSourceContext['providerIdentity']
): TaskSourceContext {
  return {
    kind: 'task-source',
    provider,
    projectId: `project-${provider}`,
    hostId: 'runtime:untrusted-client-route',
    projectHostSetupId: `setup-${provider}`,
    repoId: `repo-${provider}`,
    providerIdentity
  }
}

function createClients(): {
  clients: ExternalIssueProviderClients
  mocks: Record<TaskProvider, ReturnType<typeof vi.fn>>
} {
  const github = vi.fn(async () => ({
    number: 12,
    title: 'GitHub title',
    state: 'open' as const,
    url: 'https://github.example/acme/orca/issues/12',
    labels: []
  }))
  const gitlab = vi.fn(async () => ({
    number: 13,
    title: 'GitLab title',
    state: 'opened' as const,
    url: 'https://gitlab.example/acme/orca/-/issues/13',
    labels: []
  }))
  const linear = vi.fn(async () => ({
    id: 'linear-id',
    workspaceId: 'workspace-linear',
    identifier: 'ENG-14',
    title: 'Linear title',
    url: 'https://linear.app/acme/issue/ENG-14',
    state: { name: 'In Progress', type: 'started', color: '#000' },
    team: { id: 'team', name: 'Engineering', key: 'ENG' },
    labels: [],
    labelIds: [],
    priority: 1,
    updatedAt: '2026-08-23T00:00:00.000Z'
  }))
  const jira = vi.fn(async () => ({
    id: 'jira-id',
    key: 'ORCA-15',
    siteId: 'site-jira',
    title: 'Jira title',
    url: 'https://jira.example/browse/ORCA-15',
    project: { id: 'project', key: 'ORCA', name: 'Orca' },
    issueType: { id: 'type', name: 'Task' },
    status: {
      id: 'status',
      name: 'Doing',
      categoryKey: 'indeterminate',
      categoryName: 'In Progress'
    },
    labels: [],
    updatedAt: '2026-08-23T00:00:00.000Z',
    createdAt: '2026-08-22T00:00:00.000Z'
  }))
  return {
    clients: { github, gitlab, linear, jira },
    mocks: { github, gitlab, linear, jira }
  }
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  sequence = 0
})

describe('ExternalIssueAdapterRegistry', () => {
  it('dispatches all providers and derives host-owned source scopes', async () => {
    const { clients, mocks } = createClients()
    const resolveRepositoryExecution = vi.fn(async () => ({
      repoPath: '/host/repository',
      connectionId: 'ssh-connection'
    }))
    const adapters = createExternalIssueAdapterRegistry({
      clients,
      resolveRepositoryExecution
    })
    const cases = [
      {
        provider: 'github' as const,
        providerIdentity: {
          provider: 'github' as const,
          owner: 'acme',
          repo: 'orca',
          host: 'github.example'
        },
        selection: { issueNumber: 12 },
        externalId: '12',
        identifier: undefined,
        title: 'GitHub title'
      },
      {
        provider: 'gitlab' as const,
        providerIdentity: {
          provider: 'gitlab' as const,
          namespace: 'acme',
          project: 'orca',
          webUrl: 'https://gitlab.example/acme/orca'
        },
        selection: { issueNumber: 13 },
        externalId: '13',
        identifier: undefined,
        title: 'GitLab title'
      },
      {
        provider: 'linear' as const,
        providerIdentity: {
          provider: 'linear' as const,
          workspaceId: 'workspace-linear',
          teamKey: 'ENG'
        },
        selection: { issueId: 'linear-id' },
        externalId: 'linear-id',
        identifier: 'ENG-14',
        title: 'Linear title'
      },
      {
        provider: 'jira' as const,
        providerIdentity: {
          provider: 'jira' as const,
          siteId: 'site-jira',
          projectKey: 'ORCA'
        },
        selection: { issueKey: 'ORCA-15' },
        externalId: 'jira-id',
        identifier: 'ORCA-15',
        title: 'Jira title'
      }
    ]

    for (const entry of cases) {
      const resolved = await adapters.resolveSelection({
        executionHostId: 'local',
        sourceContext: sourceContext(entry.provider, entry.providerIdentity),
        selection: entry.selection
      })
      expect(resolved).toMatchObject({
        provider: entry.provider,
        sourceContext: { hostId: 'local' },
        snapshot: {
          externalId: entry.externalId,
          title: entry.title
        }
      })
      expect(resolved.snapshot.identifier).toBe(entry.identifier)
      expect(resolved.sourceScopeKey).toMatch(/^[a-f0-9]{64}$/)
      expect(mocks[entry.provider]).toHaveBeenCalledTimes(1)
    }

    expect(resolveRepositoryExecution).toHaveBeenCalledTimes(2)
    expect(mocks.github).toHaveBeenCalledWith('/host/repository', 12, 'ssh-connection')
    expect(mocks.gitlab).toHaveBeenCalledWith('/host/repository', 13, 'ssh-connection')
    expect(mocks.linear).toHaveBeenCalledWith('linear-id', 'workspace-linear')
    expect(mocks.jira).toHaveBeenCalledWith('ORCA-15', 'site-jira')
  })

  it('rejects malformed selections and unavailable provider records', async () => {
    const { clients } = createClients()
    clients.github = vi.fn(async () => null)
    const adapters = createExternalIssueAdapterRegistry({
      clients,
      resolveRepositoryExecution: async () => ({ repoPath: '/repo' })
    })
    const context = sourceContext('github', {
      provider: 'github',
      owner: 'acme',
      repo: 'orca'
    })

    await expect(
      adapters.resolveSelection({
        executionHostId: 'local',
        sourceContext: context,
        selection: { issueNumber: 0 }
      })
    ).rejects.toMatchObject({ code: 'external_issue_source_invalid' })
    await expect(
      adapters.resolveSelection({
        executionHostId: 'local',
        sourceContext: context,
        selection: { issueNumber: 12 }
      })
    ).rejects.toMatchObject({ code: 'external_issue_unavailable' })
  })
})

describe('ExternalIssueTrackingService', () => {
  it('tracks through the adapter without trusting the client host and replays mutations', async () => {
    const repository = openRepository('track')
    const { clients } = createClients()
    const service = new ExternalIssueTrackingService(
      repository.issues,
      createExternalIssueAdapterRegistry({
        clients,
        resolveRepositoryExecution: async () => ({ repoPath: '/repo' })
      })
    )
    const mutation = issueMutationIdentity('stable-caller', 'track-provider-selection')
    const input = {
      executionHostId: 'local' as const,
      sourceContext: sourceContext('github', {
        provider: 'github',
        owner: 'acme',
        repo: 'orca'
      }),
      selection: { issueNumber: 12 },
      refreshAttemptedAt: 100
    }

    const first = await service.track({ identity: mutation, input })
    const replay = await service.track({ identity: mutation, input })

    expect(replay).toEqual(first)
    expect(first).toMatchObject({
      hostPartitionKey: 'local',
      source: {
        kind: 'external',
        externalId: '12',
        titleSnapshot: 'GitHub title',
        sourceContext: { hostId: 'local' }
      }
    })
    expect(repository.issues.list()).toHaveLength(1)
    expect(repository.issueEvents.list({ issueId: first.id })).toHaveLength(1)
  })

  it('keeps the last good snapshot when provider refresh is missing or fails', async () => {
    const repository = openRepository('refresh')
    const { clients } = createClients()
    const github = vi
      .fn()
      .mockResolvedValueOnce({
        number: 12,
        title: 'Original title',
        state: 'open',
        url: 'https://github.example/acme/orca/issues/12',
        labels: []
      })
      .mockResolvedValueOnce(null)
      .mockRejectedValueOnce(new Error('permission denied'))
    clients.github = github
    const service = new ExternalIssueTrackingService(
      repository.issues,
      createExternalIssueAdapterRegistry({
        clients,
        resolveRepositoryExecution: async () => ({ repoPath: '/repo' })
      })
    )
    const issue = await service.track({
      identity: identity('track'),
      input: {
        executionHostId: 'local',
        sourceContext: sourceContext('github', {
          provider: 'github',
          owner: 'acme',
          repo: 'orca'
        }),
        selection: { issueNumber: 12 },
        refreshAttemptedAt: 100
      }
    })

    const missing = await service.refresh({
      identity: identity('missing'),
      issueId: issue.id,
      attemptedAt: 200
    })
    expectExternalFailure(missing, 'Original title', 'Provider Issue was not found.')

    const denied = await service.refresh({
      identity: identity('denied'),
      issueId: issue.id,
      attemptedAt: 300
    })
    expectExternalFailure(denied, 'Original title', 'permission denied')
    expect(repository.issueEvents.list({ issueId: issue.id })).toHaveLength(3)
  })

  it('does not convert an Orca parent from provider-native metadata', async () => {
    const repository = openRepository('native-parent')
    const parent = repository.issues.create({
      identity: identity('parent'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Orca parent'
      }
    })
    const { clients } = createClients()
    const adapters = createExternalIssueAdapterRegistry({
      clients,
      resolveRepositoryExecution: async () => ({ repoPath: '/repo' })
    })
    const service = new ExternalIssueTrackingService(repository.issues, adapters)
    const tracked = await service.track({
      identity: identity('tracked'),
      input: {
        executionHostId: 'local',
        parentId: parent.id,
        sourceContext: sourceContext('jira', {
          provider: 'jira',
          siteId: 'site-jira',
          projectKey: 'ORCA'
        }),
        selection: { issueKey: 'ORCA-15' }
      }
    })

    expect(tracked.parentId).toBe(parent.id)
    expect(tracked.source).toMatchObject({
      kind: 'external',
      nativeParentSnapshot: null
    })
  })
})

function expectExternalFailure(issue: IssueRecord, titleSnapshot: string, error: string): void {
  expect(issue.source).toMatchObject({
    kind: 'external',
    titleSnapshot,
    refreshError: error,
    availability: 'unavailable'
  })
}
