import { describe, expect, it, vi } from 'vitest'
import type { CommitMessagePlan } from '../../shared/commit-message-plan'
import type { IssueRecord } from '../../shared/issues/types'
import type {
  CommitMessageGenerationTarget,
  TextGenerationExecutionOptions
} from '../text-generation/commit-message-text-generation'
import type { MaterializedIssueDigestSnapshot } from './issue-digest-snapshot'
import { createIssueDigestGenerationExecutor } from './issue-digest-generation-runner'

const issue: IssueRecord = {
  id: 'issue-1',
  hostPartitionKey: 'local',
  executionHostId: 'local',
  source: { kind: 'local', number: 1 },
  localTitle: 'Generate Digest',
  typeLabel: null,
  note: null,
  state: 'active',
  parentId: null,
  siblingOrder: 0,
  createdAt: 1,
  updatedAt: 1,
  archivedAt: null
}

const snapshot: MaterializedIssueDigestSnapshot = {
  issueId: issue.id,
  issueTitle: issue.localTitle!,
  coversUntil: 100,
  inputFingerprint: 'fingerprint',
  inputs: [],
  materializedInputs: [],
  coverage: {
    totalInputCount: 0,
    includedInputCount: 0,
    directRoundCount: 0,
    includedDirectRoundCount: 0,
    totalUtf8Bytes: 0,
    includedUtf8Bytes: 0,
    truncatedInputCount: 0,
    omittedInputCount: 0,
    complete: true,
    note: null
  },
  directConversations: []
}

const sections = {
  problem: 'Problem',
  conclusion: 'Conclusion',
  keyArtifacts: null,
  openIssues: null,
  nextSteps: 'Next'
}

describe('createIssueDigestGenerationExecutor', () => {
  it('reuses the existing plan and text-generation execution contract', async () => {
    const target: CommitMessageGenerationTarget = {
      kind: 'local',
      cwd: '/workspace/current',
      env: { CODEX_HOME: '/managed/home' }
    }
    const execute = vi.fn(
      async (
        _agentId: string,
        _plan: CommitMessagePlan,
        _target: CommitMessageGenerationTarget,
        _options: TextGenerationExecutionOptions
      ) => ({
        success: true as const,
        rawOutput: JSON.stringify(sections),
        agentLabel: 'Codex'
      })
    )
    const executor = createIssueDigestGenerationExecutor({
      getSettings: () => ({
        agentCmdOverrides: { codex: 'npx codex' },
        agentDefaultArgs: { codex: '--model gpt-5.5' }
      }),
      resolveTarget: vi.fn(async () => target),
      execute,
      cancel: vi.fn(async () => {})
    })

    await expect(
      executor.generate({
        agent: 'codex',
        digestId: 'digest-1',
        issue,
        snapshot
      })
    ).resolves.toEqual(sections)

    expect(execute).toHaveBeenCalledWith(
      'codex',
      expect.objectContaining({
        binary: 'npx',
        args: expect.arrayContaining(['codex', '--model', 'gpt-5.5'])
      }),
      target,
      {
        emptyResultName: 'Digest',
        operation: 'issue-digest'
      }
    )
    const plan = execute.mock.calls[0]?.[1]
    expect(plan?.stdinPayload ?? plan?.args.join(' ')).toContain('"problem"')
  })

  it('turns existing execution failures and invalid output into generation failures', async () => {
    const target: CommitMessageGenerationTarget = {
      kind: 'local',
      cwd: '/workspace/current'
    }
    const failed = createIssueDigestGenerationExecutor({
      getSettings: () => ({ agentCmdOverrides: {} }),
      resolveTarget: vi.fn(async () => target),
      execute: vi.fn(async () => ({
        success: false as const,
        error: 'Generation timed out after 60s.'
      })),
      cancel: vi.fn(async () => {})
    })
    await expect(
      failed.generate({ agent: 'codex', digestId: 'digest-failed', issue, snapshot })
    ).rejects.toThrow('Generation timed out after 60s.')

    const invalid = createIssueDigestGenerationExecutor({
      getSettings: () => ({ agentCmdOverrides: {} }),
      resolveTarget: vi.fn(async () => target),
      execute: vi.fn(async () => ({
        success: true as const,
        rawOutput: '{"problem":"missing sections"}'
      })),
      cancel: vi.fn(async () => {})
    })
    await expect(
      invalid.generate({ agent: 'codex', digestId: 'digest-invalid', issue, snapshot })
    ).rejects.toMatchObject({ code: 'digest_output_invalid' })
  })

  it('cancels the exact issue-digest lane and never starts after an early cancel', async () => {
    let releaseTarget!: (target: CommitMessageGenerationTarget) => void
    const targetPromise = new Promise<CommitMessageGenerationTarget>((resolve) => {
      releaseTarget = resolve
    })
    const target: CommitMessageGenerationTarget = {
      kind: 'local',
      cwd: '/workspace/current'
    }
    const execute = vi.fn(async () => ({
      success: true as const,
      rawOutput: JSON.stringify(sections)
    }))
    const cancel = vi.fn(async () => {})
    const executor = createIssueDigestGenerationExecutor({
      getSettings: () => ({ agentCmdOverrides: {} }),
      resolveTarget: vi.fn(async () => targetPromise),
      execute,
      cancel
    })
    const generation = executor.generate({
      agent: 'codex',
      digestId: 'digest-early-cancel',
      issue,
      snapshot
    })

    await executor.cancel({ digestId: 'digest-early-cancel', issue })
    releaseTarget(target)

    await expect(generation).rejects.toThrow('Generation canceled.')
    expect(execute).not.toHaveBeenCalled()
    expect(cancel).not.toHaveBeenCalled()
  })

  it('forwards cancellation to an active existing text-generation target', async () => {
    const target: CommitMessageGenerationTarget = {
      kind: 'remote',
      cwd: '/srv/workspace',
      execute: vi.fn(),
      missingBinaryLocation: 'remote PATH'
    }
    let releaseExecution!: () => void
    const execution = new Promise<{
      success: true
      rawOutput: string
    }>((resolve) => {
      releaseExecution = () => resolve({ success: true, rawOutput: JSON.stringify(sections) })
    })
    const execute = vi.fn(async () => execution)
    const cancel = vi.fn(async () => {})
    const executor = createIssueDigestGenerationExecutor({
      getSettings: () => ({ agentCmdOverrides: {} }),
      resolveTarget: vi.fn(async () => target),
      execute,
      cancel
    })
    const generation = executor.generate({
      agent: 'claude',
      digestId: 'digest-active-cancel',
      issue,
      snapshot
    })
    await vi.waitFor(() => expect(execute).toHaveBeenCalledTimes(1))

    await executor.cancel({ digestId: 'digest-active-cancel', issue })
    releaseExecution()
    await generation

    expect(cancel).toHaveBeenCalledWith(target, 'issue-digest')
  })
})
