import type {
  AgentStatusEntry,
  MigrationUnsupportedPtyEntry
} from '../../../shared/agent-status-types'
import { migrationUnsupportedToAgentStatusEntry } from '../lib/migration-unsupported-agent-entry'
import type { RetainedAgentEntry } from '../store/slices/agent-status'

export function buildLegacyActivitySourceEntries(args: {
  liveEntriesByPaneKey: Readonly<Record<string, AgentStatusEntry>>
  retainedEntriesByPaneKey: Readonly<Record<string, RetainedAgentEntry>>
  migrationUnsupportedByPtyId: Readonly<
    Record<string, MigrationUnsupportedPtyEntry>
  >
}): Record<string, AgentStatusEntry> {
  const retainedEntries = Object.fromEntries(
    Object.entries(args.retainedEntriesByPaneKey).map(
      ([paneKey, retained]) => [
        paneKey,
        {
          ...retained.entry,
          worktreeId:
            retained.entry.worktreeId ?? retained.worktreeId,
          tabId: retained.entry.tabId ?? retained.tab.id
        }
      ]
    )
  )
  const unsupportedEntries = Object.fromEntries(
    Object.values(args.migrationUnsupportedByPtyId).flatMap(
      (unsupported) => {
        const entry =
          migrationUnsupportedToAgentStatusEntry(unsupported)
        return entry
          ? [
              [
                entry.paneKey,
                {
                  ...entry,
                  worktreeId:
                    entry.worktreeId ?? unsupported.worktreeId,
                  tabId: entry.tabId ?? unsupported.tabId
                }
              ] as const
            ]
          : []
      }
    )
  )
  return {
    ...args.liveEntriesByPaneKey,
    ...retainedEntries,
    ...unsupportedEntries
  }
}
