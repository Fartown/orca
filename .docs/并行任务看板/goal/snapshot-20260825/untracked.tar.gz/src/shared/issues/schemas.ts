import { z } from 'zod'
import { TaskSourceContextSchema } from '../task-source-context-schema'
import { ALL_TUI_AGENTS } from '../tui-agent-display-names'
import type { TuiAgent } from '../tui-agent'
import { isUtf8ByteLengthWithinLimit } from '../utf8-byte-limits'
import {
  IssueAuthorityDescriptorSchema,
  IssueHostPartitionKeySchema,
  IssueRouteExecutionHostId
} from './authority-schemas'
import { IssueDigestProjectionSchema } from './digest-schemas'
import {
  CONVERSATION_STATES,
  EFFECTIVE_ROUND_RESOLUTIONS,
  ISSUE_EVENT_KINDS,
  ISSUE_LIST_PAGE_MAX_RECORDS,
  ISSUE_SEARCH_PAGE_MAX_MATCHES,
  ISSUE_SEARCH_PREVIEW_MAX_BYTES,
  ISSUE_SEARCH_QUERY_MAX_BYTES,
  ISSUE_STATES,
  ROUND_BODY_CHUNK_MAX_BYTES,
  ROUND_RECORD_KINDS,
  ROUND_RECORD_STATE_SOURCES,
  ROUND_RESOLUTIONS,
  ROUND_TEXT_PREVIEW_MAX_BYTES,
  ROUND_TEXT_COMPLETENESS,
  ROUND_TEXT_STORAGE
} from './constants'

const EntityId = z.string().uuid()
const BoundedId = z.string().min(1).max(4_096)
const PreviewText = z
  .string()
  .refine(
    (value) => isUtf8ByteLengthWithinLimit(value, ROUND_TEXT_PREVIEW_MAX_BYTES),
    'Preview text exceeds the UTF-8 byte limit'
  )
const NullablePreviewText = PreviewText.nullable()
const FactsRevision = z.number().int().nonnegative()
const TreeRevision = z.number().int().nonnegative()
const MutationId = z.string().min(1).max(128)
const Timestamp = z.number().int().nonnegative()
const NullableTimestamp = Timestamp.nullable()

export {
  IssueAuthorityDescriptorSchema,
  IssueHostPartitionKeySchema,
  IssueRouteExecutionHostId
} from './authority-schemas'

export const IssueWorkspaceRefSchema = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('worktree'),
    worktreeId: BoundedId
  }),
  z.object({
    type: z.literal('folder'),
    folderWorkspaceId: BoundedId
  })
])

const WorkspaceSnapshotSchema = z.object({
  name: PreviewText,
  path: z.string().max(32_768)
})

const TuiAgentSchema = z.custom<TuiAgent>(
  (value) => typeof value === 'string' && ALL_TUI_AGENTS.includes(value as TuiAgent),
  'Unknown agent preset'
)

const LocalIssueSourceSchema = z.object({
  kind: z.literal('local'),
  number: z.number().int().positive()
})

const NativeParentSnapshotSchema = z
  .object({
    sourceScopeKey: z.string().min(1).max(128),
    externalId: BoundedId,
    title: PreviewText
  })
  .nullable()

const ExternalIssueSourceSchema = z.object({
  kind: z.literal('external'),
  provider: z.enum(['github', 'gitlab', 'linear', 'jira']),
  sourceScopeKey: z.string().min(1).max(128),
  externalId: BoundedId,
  number: z.number().int().positive().optional(),
  identifier: z.string().max(1_024).optional(),
  url: z.string().max(32_768),
  titleSnapshot: PreviewText,
  stateSnapshot: PreviewText.optional(),
  syncedAt: Timestamp,
  refreshAttemptedAt: Timestamp,
  refreshError: z.string().max(2_048).nullable(),
  availability: z.enum(['available', 'unavailable']),
  sourceContext: TaskSourceContextSchema.optional(),
  nativeParentSnapshot: NativeParentSnapshotSchema.optional()
})

export const IssueRecordSchema = z.object({
  id: EntityId,
  hostPartitionKey: IssueHostPartitionKeySchema,
  executionHostId: IssueRouteExecutionHostId,
  source: z.discriminatedUnion('kind', [LocalIssueSourceSchema, ExternalIssueSourceSchema]),
  localTitle: NullablePreviewText,
  typeLabel: z.string().max(128).nullable(),
  note: z.string().max(32_768).nullable(),
  state: z.enum(ISSUE_STATES),
  parentId: EntityId.nullable(),
  siblingOrder: z.number().int().nonnegative(),
  createdAt: Timestamp,
  updatedAt: Timestamp,
  archivedAt: NullableTimestamp
})

export const RoundRecordTextSummarySchema = z.object({
  completeness: z.enum(ROUND_TEXT_COMPLETENESS),
  storage: z.enum(ROUND_TEXT_STORAGE),
  bytes: z.number().int().nonnegative(),
  preview: NullablePreviewText,
  previewBytes: z.number().int().nonnegative()
})

export const RoundRecordPreviewSchema = z.object({
  id: EntityId,
  conversationId: EntityId,
  kind: z.enum(ROUND_RECORD_KINDS),
  stateSource: z.enum(ROUND_RECORD_STATE_SOURCES),
  occurredAt: Timestamp,
  executionChainId: z.string().max(1_024).nullable(),
  supersedesRoundId: EntityId.nullable(),
  userInput: RoundRecordTextSummarySchema,
  agentOutput: RoundRecordTextSummarySchema,
  pendingQuestion: RoundRecordTextSummarySchema,
  readAt: NullableTimestamp,
  resolvedAt: NullableTimestamp,
  resolution: z.enum(ROUND_RESOLUTIONS).nullable(),
  effectiveResolvedAt: NullableTimestamp,
  effectiveResolution: z.enum(EFFECTIVE_ROUND_RESOLUTIONS).nullable(),
  finalizedAt: NullableTimestamp,
  bodyEvictedAt: NullableTimestamp,
  bodyDeletedAt: NullableTimestamp,
  bodyRevision: FactsRevision,
  createdAt: Timestamp
})

export const ConversationRecordSchema = z.object({
  id: EntityId,
  hostPartitionKey: IssueHostPartitionKeySchema,
  executionHostId: IssueRouteExecutionHostId,
  workspaceRef: IssueWorkspaceRefSchema,
  workspaceSnapshot: WorkspaceSnapshotSchema,
  agent: TuiAgentSchema,
  title: NullablePreviewText,
  titleSource: z.enum(['user', 'provider', 'generated', 'terminal']).nullable(),
  issueId: EntityId.nullable(),
  state: z.enum(CONVERSATION_STATES),
  launchFailure: z.string().max(2_048).nullable(),
  createdAt: Timestamp,
  updatedAt: Timestamp
})

export const ConversationNavigationHintSchema = z.object({
  paneKey: z.string().min(1).max(4_096).nullable(),
  providerSession: z
    .object({
      key: z.enum(['session_id', 'conversation_id']),
      id: z.string().min(1).max(512),
      transcriptPath: z.string().min(1).max(32_768).optional()
    })
    .nullable(),
  resumeLocator: z.string().min(1).max(32_768).nullable()
})

export const ConversationNavigationTargetSchema = ConversationRecordSchema.extend({
  navigation: ConversationNavigationHintSchema.optional()
})

export const ConversationSummarySchema = ConversationNavigationTargetSchema.extend({
  unresolvedRoundCount: z.number().int().nonnegative(),
  latestRound: RoundRecordPreviewSchema.nullable()
})

export const IssueSummarySchema = IssueRecordSchema.extend({
  ownUnresolvedCount: z.number().int().nonnegative(),
  descendantAttentionCount: z.number().int().nonnegative(),
  directConversationCount: z.number().int().nonnegative(),
  activeConversationCount: z.number().int().nonnegative()
})

export const UnassignedConversationSummarySchema = z.object({
  conversationCount: z.number().int().nonnegative(),
  unresolvedCount: z.number().int().nonnegative()
})

export const IssueDetailSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  issue: IssueSummarySchema,
  directChildren: z.array(IssueSummarySchema).max(10_000),
  directConversations: z.array(ConversationSummarySchema).max(10_000),
  workspaceSnapshots: z.array(WorkspaceSnapshotSchema).max(10_000),
  digest: IssueDigestProjectionSchema.optional()
})

const ListFilterSchema = z.enum(['all', 'needs-me', 'archived'])

export const IssuesListParams = z.discriminatedUnion('mode', [
  z.object({
    mode: z.literal('start'),
    executionHostId: IssueRouteExecutionHostId,
    filter: ListFilterSchema,
    sinceFactsRevision: FactsRevision.optional(),
    limit: z.number().int().min(1).max(ISSUE_LIST_PAGE_MAX_RECORDS).default(200)
  }),
  z.object({
    mode: z.literal('continue'),
    executionHostId: IssueRouteExecutionHostId,
    filter: ListFilterSchema,
    snapshotFactsRevision: FactsRevision,
    snapshotTreeRevision: TreeRevision,
    cursor: z.string().min(1).max(2_048),
    limit: z.number().int().min(1).max(ISSUE_LIST_PAGE_MAX_RECORDS).default(200)
  })
])

export const IssuesListResult = z.discriminatedUnion('status', [
  z.object({
    status: z.literal('not-modified'),
    authority: IssueAuthorityDescriptorSchema,
    factsRevision: FactsRevision,
    treeRevision: TreeRevision
  }),
  z.object({
    status: z.literal('stale'),
    authority: IssueAuthorityDescriptorSchema,
    factsRevision: FactsRevision,
    treeRevision: TreeRevision
  }),
  z.object({
    status: z.literal('snapshot-page'),
    authority: IssueAuthorityDescriptorSchema,
    snapshotFactsRevision: FactsRevision,
    snapshotTreeRevision: TreeRevision,
    issues: z.array(IssueSummarySchema).max(ISSUE_LIST_PAGE_MAX_RECORDS),
    unassigned: UnassignedConversationSummarySchema.optional(),
    nextCursor: z.string().max(2_048).nullable()
  })
])

const MutationEnvelope = {
  executionHostId: IssueRouteExecutionHostId,
  mutationId: MutationId
} as const

export const IssuesGetParams = z.object({
  executionHostId: IssueRouteExecutionHostId,
  issueId: EntityId
})

export const IssuesCreateParams = z.object({
  ...MutationEnvelope,
  source: z.discriminatedUnion('kind', [
    z.object({ kind: z.literal('local'), title: z.string().trim().min(1).max(512) }),
    z.object({
      kind: z.literal('external'),
      provider: z.enum(['github', 'gitlab', 'linear', 'jira']),
      selection: z.unknown(),
      sourceContext: TaskSourceContextSchema
    })
  ]),
  parentId: EntityId.nullable().optional(),
  index: z.number().int().nonnegative().optional(),
  typeLabel: z.string().trim().max(128).nullable().optional(),
  note: z.string().max(32_768).nullable().optional()
})

export const IssuesUpdateParams = z.object({
  ...MutationEnvelope,
  issueId: EntityId,
  localTitle: z.string().trim().min(1).max(512).nullable().optional(),
  typeLabel: z.string().trim().max(128).nullable().optional(),
  note: z.string().max(32_768).nullable().optional()
})

export const IssuesLifecycleParams = z.object({
  ...MutationEnvelope,
  issueId: EntityId,
  expectedFactsRevision: FactsRevision.optional()
})

export const IssuesReparentParams = z.object({
  ...MutationEnvelope,
  issueId: EntityId,
  parentId: EntityId.nullable(),
  index: z.number().int().nonnegative(),
  expectedTreeRevision: TreeRevision
})

const DeleteIssueDestinationSchema = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('root') }),
  z.object({ kind: z.literal('parent'), parentId: EntityId })
])

export const DeleteIssuePlanSchema = z.object({
  issueId: EntityId,
  expectedFactsRevision: FactsRevision,
  children: z
    .array(
      z.object({
        issueId: EntityId,
        destination: DeleteIssueDestinationSchema,
        index: z.number().int().nonnegative()
      })
    )
    .max(10_000),
  conversations: z
    .array(
      z.object({
        conversationId: EntityId,
        destinationIssueId: EntityId.nullable()
      })
    )
    .max(10_000)
})

export const IssuesPrepareDeleteParams = z.object({
  executionHostId: IssueRouteExecutionHostId,
  issueId: EntityId
})

export const IssuesDeleteParams = z.object({
  ...MutationEnvelope,
  plan: DeleteIssuePlanSchema
})

export const ConversationsBindIssueParams = z.object({
  ...MutationEnvelope,
  conversationId: EntityId,
  issueId: EntityId.nullable(),
  expectedFactsRevision: FactsRevision
})

export const ConversationsGetParams = z.object({
  executionHostId: IssueRouteExecutionHostId,
  conversationId: EntityId
})

export const ConversationsListUnassignedParams = z.object({
  executionHostId: IssueRouteExecutionHostId,
  cursor: z.string().min(1).max(2_048).optional(),
  limit: z.number().int().min(1).max(500).default(200)
})

export const ConversationPageSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  snapshotFactsRevision: FactsRevision,
  conversations: z.array(ConversationSummarySchema).max(500),
  nextCursor: z.string().max(2_048).nullable()
})

export const IssuesListRoundsParams = z
  .object({
    executionHostId: IssueRouteExecutionHostId,
    issueId: EntityId.optional(),
    conversationId: EntityId.optional(),
    cursor: z.string().min(1).max(2_048).optional(),
    limit: z.number().int().min(1).max(500).default(200)
  })
  .refine((value) => (value.issueId ? 1 : 0) + (value.conversationId ? 1 : 0) === 1, {
    message: 'Exactly one Round Record scope is required'
  })

export const RoundRecordPageSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  snapshotFactsRevision: FactsRevision,
  rounds: z.array(RoundRecordPreviewSchema).max(500),
  nextCursor: z.string().max(2_048).nullable()
})

export const IssuesReadRoundBodyParams = z.object({
  executionHostId: IssueRouteExecutionHostId,
  roundRecordId: EntityId,
  field: z.enum(['userInput', 'agentOutput', 'pendingQuestion']),
  expectedBodyRevision: FactsRevision,
  expectedStorage: z.enum(ROUND_TEXT_STORAGE).optional(),
  offset: z.number().int().nonnegative(),
  maxBytes: z.number().int().min(1).max(ROUND_BODY_CHUNK_MAX_BYTES),
  allowTranscriptFallback: z.boolean().optional().default(false)
})

const RoundBodyStatusBase = {
  roundRecordId: EntityId,
  field: z.enum(['userInput', 'agentOutput', 'pendingQuestion']),
  bodyRevision: FactsRevision,
  storage: z.enum(ROUND_TEXT_STORAGE),
  completeness: z.enum(ROUND_TEXT_COMPLETENESS)
} as const

export const RoundRecordBodyReadResultSchema = z.discriminatedUnion('status', [
  z.object({
    status: z.literal('body-chunk'),
    ...RoundBodyStatusBase,
    offset: z.number().int().nonnegative(),
    nextOffset: z.number().int().nonnegative(),
    eof: z.boolean(),
    text: z
      .string()
      .refine(
        (value) => isUtf8ByteLengthWithinLimit(value, ROUND_BODY_CHUNK_MAX_BYTES),
        'Round body chunk exceeds the UTF-8 byte limit'
      )
  }),
  z.object({ status: z.literal('stale'), ...RoundBodyStatusBase }),
  z.object({ status: z.literal('unavailable'), ...RoundBodyStatusBase })
])

export const IssuesMarkReadParams = z.object({
  ...MutationEnvelope,
  roundRecordIds: z.array(EntityId).min(1).max(500),
  readAt: Timestamp
})

export const IssuesResolveRoundParams = z.object({
  ...MutationEnvelope,
  roundRecordId: EntityId,
  resolvedAt: Timestamp
})

export const IssueMutationResultSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  factsRevision: FactsRevision,
  treeRevision: TreeRevision,
  affectedIssueIds: z.array(EntityId).max(10_000),
  affectedConversationIds: z.array(EntityId).max(10_000),
  affectedRoundRecordIds: z.array(EntityId).max(10_000)
})

const ArchiveIssueBlockerSchema = z.object({
  conversationId: EntityId,
  kind: z.enum(['unresolved-waiting', 'runtime-waiting']),
  roundRecordId: EntityId.nullable(),
  dedupeKey: z.string().max(4_096).nullable()
})

export const IssueArchiveMutationResultSchema = z.discriminatedUnion('status', [
  z.object({
    status: z.literal('blocked'),
    authority: IssueAuthorityDescriptorSchema,
    issueId: EntityId,
    blockers: z.array(ArchiveIssueBlockerSchema).max(10_000)
  }),
  z.object({
    status: z.literal('archived'),
    archivedAt: Timestamp,
    resolvedCompletionIds: z.array(EntityId).max(10_000),
    mutation: IssueMutationResultSchema
  })
])

const DeleteIssueWarningSchema = z.object({
  conversationId: EntityId,
  kind: z.enum(['active-conversation', 'unresolved-waiting']),
  roundRecordId: EntityId.optional()
})

export const IssueDeletePreparationResultSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  plan: DeleteIssuePlanSchema,
  legalParentTargetsByChild: z.record(EntityId, z.array(EntityId.nullable()).max(10_000)),
  legalConversationTargets: z.array(EntityId.nullable()).max(10_000),
  warnings: z.array(DeleteIssueWarningSchema).max(10_000)
})

export const ConversationBindingMutationResultSchema = IssueMutationResultSchema.extend({
  conversationId: EntityId,
  previousIssueId: EntityId.nullable(),
  issueId: EntityId.nullable()
})

export const IssueEventSchema = z.object({
  id: EntityId,
  hostPartitionKey: IssueHostPartitionKeySchema,
  executionHostId: IssueRouteExecutionHostId,
  kind: z.enum(ISSUE_EVENT_KINDS),
  conversationId: EntityId.nullable(),
  issueRefs: z
    .array(
      z.object({
        issueId: EntityId,
        role: z.string().min(1).max(128),
        titleSnapshot: PreviewText
      })
    )
    .max(10_000),
  payload: z.record(z.string(), z.unknown()),
  occurredAt: Timestamp,
  factsRevision: FactsRevision
})

export const IssueDisplayProjectionSchema = z.object({
  id: EntityId,
  title: PreviewText,
  typeLabel: z.string().max(128).nullable(),
  state: z.enum(ISSUE_STATES)
})

export const IssuesListActivityParams = z.object({
  executionHostId: IssueRouteExecutionHostId,
  cursor: z.string().min(1).max(2_048).optional(),
  limit: z.number().int().min(1).max(500).default(200)
})

export const IssueActivityEntrySchema = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('round'),
    id: EntityId,
    occurredAt: Timestamp,
    round: RoundRecordPreviewSchema,
    conversation: ConversationNavigationTargetSchema,
    issue: IssueDisplayProjectionSchema.nullable()
  }),
  z.object({
    type: z.literal('issue-event'),
    id: EntityId,
    occurredAt: Timestamp,
    event: IssueEventSchema,
    conversation: ConversationNavigationTargetSchema.nullable()
  })
])

export const IssueActivityPageSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  snapshotFactsRevision: FactsRevision,
  entries: z.array(IssueActivityEntrySchema).max(500),
  nextCursor: z.string().max(2_048).nullable()
})

export const LegacyActivityMigrationEntrySchema = z.object({
  legacyEventId: BoundedId,
  paneKey: BoundedId,
  state: z.enum(['done', 'waiting', 'blocked']),
  occurredAt: Timestamp,
  acknowledgedAt: NullableTimestamp,
  userInputPreview: NullablePreviewText.optional(),
  agentOutputPreview: NullablePreviewText.optional(),
  pendingQuestionPreview: NullablePreviewText.optional()
})

export const IssuesMigrateLegacyActivityParams = z.object({
  ...MutationEnvelope,
  entries: z.array(LegacyActivityMigrationEntrySchema).max(500)
})

export const LegacyActivityMigrationResultSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  migrated: z
    .array(
      z.object({
        legacyEventId: BoundedId,
        conversationId: EntityId,
        roundRecordId: EntityId
      })
    )
    .max(500),
  unresolvedLegacyEventIds: z.array(BoundedId).max(500)
})

export const IssuesProjectDashboardPanesParams = z.object({
  executionHostId: IssueRouteExecutionHostId,
  paneKeys: z.array(BoundedId).max(500)
})

export const IssueDashboardPaneProjectionSchema = z.object({
  paneKey: BoundedId,
  conversationId: EntityId,
  issue: IssueDisplayProjectionSchema.nullable(),
  latestRound: RoundRecordPreviewSchema.nullable()
})

export const IssueDashboardProjectionSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  snapshotFactsRevision: FactsRevision,
  panes: z.array(IssueDashboardPaneProjectionSchema).max(500)
})

export const IssuesSearchParams = z.object({
  executionHostId: IssueRouteExecutionHostId,
  query: z
    .string()
    .trim()
    .min(1)
    .refine(
      (value) => isUtf8ByteLengthWithinLimit(value, ISSUE_SEARCH_QUERY_MAX_BYTES),
      'Issue search query exceeds the UTF-8 byte limit'
    ),
  cursor: z.string().min(1).max(2_048).optional(),
  limit: z.number().int().min(1).max(ISSUE_SEARCH_PAGE_MAX_MATCHES).default(50)
})

const IssueSearchMatchSchema = z.object({
  entityKind: z.enum(['issue', 'conversation', 'round', 'digest', 'artifact']),
  entityId: EntityId,
  issueId: EntityId.nullable(),
  title: PreviewText,
  preview: z
    .string()
    .refine(
      (value) => isUtf8ByteLengthWithinLimit(value, ISSUE_SEARCH_PREVIEW_MAX_BYTES),
      'Issue search preview exceeds the UTF-8 byte limit'
    ),
  completeness: z.enum(['complete', 'partial', 'unavailable']).nullable()
})

export const IssueSearchResultSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  searchRevision: FactsRevision,
  indexedSearchRevision: FactsRevision,
  isStale: z.boolean(),
  partial: z.boolean(),
  groups: z
    .array(
      z.object({
        issue: IssueDisplayProjectionSchema.nullable(),
        matches: z.array(IssueSearchMatchSchema).max(ISSUE_SEARCH_PAGE_MAX_MATCHES)
      })
    )
    .max(ISSUE_SEARCH_PAGE_MAX_MATCHES),
  nextCursor: z.string().max(2_048).nullable()
})
