// @vitest-environment happy-dom

import '@testing-library/jest-dom/vitest'
import type { ComponentProps } from 'react'
import {
  cleanup,
  fireEvent,
  render,
  screen,
  within
} from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { IssueChildren } from './IssueChildren'
import { IssueConversationList } from './IssueConversationList'
import { IssueDetail } from './IssueDetail'
import { IssueTimeline } from './IssueTimeline'
import type {
  IssueDigestPreparation,
  IssueDigestRecord
} from '../../../../shared/issues/digest-types'
import {
  makeConversationSummary,
  makeIssueDetail,
  makeIssueSummary,
  makeRoundPreview
} from './issue-detail-test-data'

afterEach(cleanup)

describe('IssueConversationList', () => {
  it('groups only the supplied direct Conversations by Workspace and sorts each group', () => {
    const onOpenConversation = vi.fn()
    const older = makeConversationSummary(
      '22222222-2222-4222-8222-222222222221',
      {
        title: 'Older direct work',
        updatedAt: 10,
        latestRound: makeRoundPreview(
          '33333333-3333-4333-8333-333333333331'
        )
      }
    )
    const newer = makeConversationSummary(
      '22222222-2222-4222-8222-222222222222',
      {
        title: 'Newer direct work',
        updatedAt: 20,
        unresolvedRoundCount: 2
      }
    )
    const folder = makeConversationSummary(
      '22222222-2222-4222-8222-222222222223',
      {
        title: 'Folder work',
        workspaceRef: {
          type: 'folder',
          folderWorkspaceId: 'folder-b'
        },
        workspaceSnapshot: {
          name: 'Folder Workspace',
          path: '/workspace/folder'
        }
      }
    )

    render(
      <IssueConversationList
        conversations={[older, folder, newer]}
        onOpenConversation={onOpenConversation}
      />
    )

    const worktreeGroup = document.querySelector(
      '[data-workspace-group="worktree:workspace-a"]'
    )
    expect(worktreeGroup).not.toBeNull()
    expect(
      within(worktreeGroup as HTMLElement)
        .getAllByRole('button')
        .map((button) => button.textContent)
    ).toEqual([
      expect.stringContaining('Newer direct work'),
      expect.stringContaining('Older direct work')
    ])
    expect(screen.getByText('Folder Workspace')).toBeInTheDocument()
    expect(
      document.querySelector(
        '[data-round-capture="preview-complete:preview"]'
      )
    ).toHaveTextContent('Agent output · preview-complete · preview')

    fireEvent.click(screen.getByRole('button', { name: /Older direct work/ }))
    expect(onOpenConversation).toHaveBeenCalledWith(older)
  })
})

describe('IssueChildren', () => {
  it('renders direct children with separate own and descendant attention', () => {
    const onOpenIssue = vi.fn()
    const child = makeIssueSummary(
      '44444444-4444-4444-8444-444444444441',
      {
        localTitle: 'Direct child',
        ownUnresolvedCount: 1,
        descendantAttentionCount: 3
      }
    )

    render(
      <IssueChildren children={[child]} onOpenIssue={onOpenIssue} />
    )

    expect(screen.getByText('1 own')).toBeInTheDocument()
    expect(screen.getByText('3 descendants')).toBeInTheDocument()
    expect(screen.queryByText('Unlisted grandchild')).toBeNull()
    fireEvent.click(screen.getByRole('button', { name: /Direct child/ }))
    expect(onOpenIssue).toHaveBeenCalledWith(child)
  })
})

describe('IssueTimeline', () => {
  it('labels bounded previews with completeness and storage without merging read and resolution', () => {
    const waiting = makeRoundPreview(
      '33333333-3333-4333-8333-333333333332',
      {
        kind: 'waiting',
        readAt: 10,
        pendingQuestion: {
          completeness: 'truncated',
          storage: 'preview',
          bytes: 120,
          preview: 'Which environment should I use?',
          previewBytes: 31
        },
        agentOutput: {
          completeness: 'complete',
          storage: 'full',
          bytes: 80,
          preview: 'I need one decision before continuing.',
          previewBytes: 38
        }
      }
    )
    const resolvedUnread = makeRoundPreview(
      '33333333-3333-4333-8333-333333333333',
      {
        readAt: null,
        resolvedAt: 20,
        resolution: 'explicit',
        effectiveResolvedAt: 20,
        effectiveResolution: 'explicit'
      }
    )

    render(
      <IssueTimeline
        rounds={[waiting, resolvedUnread]}
        status="ready"
      />
    )

    const waitingCard = document.querySelector(
      `[data-round-record-id="${waiting.id}"]`
    )
    const resolvedCard = document.querySelector(
      `[data-round-record-id="${resolvedUnread.id}"]`
    )
    expect(waitingCard).not.toBeNull()
    expect(resolvedCard).not.toBeNull()
    expect(
      within(waitingCard as HTMLElement).getByText(
        'Pending question · bounded preview'
      )
    ).toBeInTheDocument()
    expect(
      within(waitingCard as HTMLElement).getByText(
        'Which environment should I use?'
      )
    ).toBeInTheDocument()
    expect(
      within(waitingCard as HTMLElement).getByText('Read')
    ).toBeInTheDocument()
    expect(
      within(waitingCard as HTMLElement).getByText('Needs attention')
    ).toBeInTheDocument()
    expect(
      within(resolvedCard as HTMLElement).getByText('Unread')
    ).toBeInTheDocument()
    expect(
      within(resolvedCard as HTMLElement).getByText('Resolved')
    ).toBeInTheDocument()

    const pending = waitingCard?.querySelector(
      '[data-round-field="pendingQuestion"]'
    )
    const output = waitingCard?.querySelector(
      '[data-round-field="agentOutput"]'
    )
    expect(pending).toHaveAttribute('data-completeness', 'truncated')
    expect(pending).toHaveAttribute('data-storage', 'preview')
    expect(output).toHaveAttribute('data-completeness', 'complete')
    expect(output).toHaveAttribute('data-storage', 'full')
  })

  it('keeps loaded history visible when an older-page request fails', () => {
    const onLoadMore = vi.fn()
    render(
      <IssueTimeline
        rounds={[
          makeRoundPreview('33333333-3333-4333-8333-333333333334')
        ]}
        status="cached"
        error="Continuation expired."
        hasMore
        onLoadMore={onLoadMore}
      />
    )

    expect(screen.getByText('Continuation expired.')).toBeInTheDocument()
    expect(
      screen.getByText('Implemented the requested change.')
    ).toBeInTheDocument()
    fireEvent.click(
      screen.getByRole('button', { name: 'Load older records' })
    )
    expect(onLoadMore).toHaveBeenCalledTimes(1)
  })
})

describe('IssueDetail', () => {
  it('keeps current answer, direct work, child Issues, and history in product order', () => {
    const parent = makeIssueSummary(
      '44444444-4444-4444-8444-444444444442',
      { localTitle: 'Parent Issue' }
    )
    const issue = makeIssueSummary(
      '11111111-1111-4111-8111-111111111111',
      {
        localTitle: 'Selected Issue',
        parentId: parent.id,
        note: 'Keep direct facts separate.'
      }
    )
    const detail = makeIssueDetail(issue, {
      directConversations: [
        makeConversationSummary(
          '22222222-2222-4222-8222-222222222224'
        )
      ],
      directChildren: [
        makeIssueSummary('44444444-4444-4444-8444-444444444443', {
          localTitle: 'Direct child'
        })
      ],
      workspaceSnapshots: [
        { name: 'Workspace A', path: '/workspace/a' }
      ]
    })

    render(
      <IssueDetail
        detail={detail}
        ancestors={[parent]}
        rounds={[
          makeRoundPreview('33333333-3333-4333-8333-333333333335')
        ]}
        roundStatus="ready"
      />
    )

    expect(
      [...document.querySelectorAll('h2')].map((heading) => heading.textContent)
    ).toEqual(['Current answer', 'Direct work', 'Child Issues', 'History'])
    expect(screen.getByText('No confirmed summary yet.')).toBeInTheDocument()
    expect(screen.getByText('Parent Issue')).toBeInTheDocument()
    expect(screen.getAllByText('Workspace A')).toHaveLength(2)
    expect(
      screen.getByText(/capture completeness and storage state/)
    ).toBeInTheDocument()
  })

  it('shows the latest confirmed Digest without hiding stale coverage', () => {
    const confirmed = makeDigest({
      status: 'confirmed',
      conclusion: 'Use the persisted Issue ledger.',
      confirmedAt: 30
    })
    const detail = {
      ...makeIssueDetail(),
      digest: {
        latestConfirmed: confirmed,
        latestAttempt: null,
        currentInputFingerprint: 'b'.repeat(64),
        latestConfirmedIsStale: true
      }
    } as unknown as ComponentProps<typeof IssueDetail>['detail']

    render(
      <IssueDetail
        detail={detail}
        rounds={[]}
        roundStatus="ready"
      />
    )

    expect(
      screen.getByText('Use the persisted Issue ledger.')
    ).toBeInTheDocument()
    expect(screen.getByText('Summary is out of date')).toBeInTheDocument()
    expect(screen.queryByText('No confirmed summary yet.')).not.toBeInTheDocument()
  })

  it('exposes prepare, generate, edit, and confirm actions with coverage state', () => {
    const onPrepareDigest = vi.fn()
    const onGenerateDigest = vi.fn()
    const onUpdateDigestDraft = vi.fn()
    const onConfirmDigest = vi.fn()
    const preparation: IssueDigestPreparation = {
      authority: makeIssueDetail().authority,
      issueId: makeIssueDetail().issue.id,
      coversUntil: 20,
      inputFingerprint: 'c'.repeat(64),
      inputs: [],
      coverage: {
        totalInputCount: 4,
        includedInputCount: 3,
        directRoundCount: 4,
        includedDirectRoundCount: 3,
        totalUtf8Bytes: 200,
        includedUtf8Bytes: 150,
        truncatedInputCount: 1,
        omittedInputCount: 1,
        complete: false,
        note: 'One source body was unavailable.'
      }
    }
    const draft = makeDigest({
      status: 'draft',
      problem: 'Original problem',
      conclusion: 'Original conclusion'
    })
    const detail = {
      ...makeIssueDetail(),
      directConversations: [
        makeConversationSummary('22222222-2222-4222-8222-222222222229')
      ],
      digest: {
        latestConfirmed: null,
        latestAttempt: draft,
        currentInputFingerprint: preparation.inputFingerprint,
        latestConfirmedIsStale: false
      }
    } satisfies ComponentProps<typeof IssueDetail>['detail']

    render(
      <IssueDetail
        detail={detail}
        rounds={[]}
        roundStatus="ready"
        digestPreparation={preparation}
        onPrepareDigest={onPrepareDigest}
        onGenerateDigest={onGenerateDigest}
        onUpdateDigestDraft={onUpdateDigestDraft}
        onConfirmDigest={onConfirmDigest}
      />
    )

    expect(screen.getByText('Coverage incomplete')).toBeInTheDocument()
    expect(screen.getByText('One source body was unavailable.')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Prepare summary' }))
    fireEvent.click(screen.getByRole('button', { name: 'Generate with codex' }))
    fireEvent.change(screen.getByLabelText('Problem'), {
      target: { value: 'Edited problem' }
    })
    fireEvent.change(screen.getByLabelText('Conclusion'), {
      target: { value: 'Edited conclusion' }
    })
    fireEvent.click(screen.getByRole('button', { name: 'Save draft' }))
    fireEvent.click(screen.getByRole('button', { name: 'Confirm summary' }))

    expect(onPrepareDigest).toHaveBeenCalledTimes(1)
    expect(onGenerateDigest).toHaveBeenCalledWith('codex')
    expect(onUpdateDigestDraft).toHaveBeenCalledWith(
      expect.objectContaining({
        problem: 'Edited problem',
        conclusion: 'Edited conclusion'
      })
    )
    expect(onConfirmDigest).toHaveBeenCalledTimes(1)
    expect(
      screen.queryByRole('button', { name: 'Cancel generation' })
    ).not.toBeInTheDocument()
  })

  it('offers cancellation only while a Digest is generating', () => {
    const onCancelDigest = vi.fn()
    const detail = {
      ...makeIssueDetail(),
      digest: {
        latestConfirmed: null,
        latestAttempt: makeDigest({
          status: 'generating',
          generationFinishedAt: null
        }),
        currentInputFingerprint: 'c'.repeat(64),
        latestConfirmedIsStale: false
      }
    } satisfies ComponentProps<typeof IssueDetail>['detail']

    render(
      <IssueDetail
        detail={detail}
        rounds={[]}
        roundStatus="ready"
        onCancelDigest={onCancelDigest}
      />
    )

    expect(screen.queryByLabelText('Problem')).not.toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Cancel generation' }))
    expect(onCancelDigest).toHaveBeenCalledTimes(1)
  })
})

function makeDigest(
  overrides: Partial<IssueDigestRecord> = {}
): IssueDigestRecord {
  return {
    id: '55555555-5555-4555-8555-555555555555',
    issueId: '11111111-1111-4111-8111-111111111111',
    version: 1,
    revision: 0,
    status: 'draft',
    coversUntil: 20,
    problem: null,
    conclusion: null,
    keyArtifacts: null,
    openIssues: null,
    nextSteps: null,
    coverageNote: null,
    inputFingerprint: 'a'.repeat(64),
    generatorAgent: 'codex',
    generationId: '66666666-6666-4666-8666-666666666666',
    generationError: null,
    generationStartedAt: 10,
    generationFinishedAt: 20,
    createdAt: 10,
    updatedAt: 20,
    confirmedAt: null,
    ...overrides
  }
}
