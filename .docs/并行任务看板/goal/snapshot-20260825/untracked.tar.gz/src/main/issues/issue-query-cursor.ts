import type { IssueListFilter, IssueSummary } from '../../shared/issues/types'
import type { IssueHostRevisions } from './issue-host-state'
import { IssueRepositoryError } from './issue-repository-error'

export type IssueListCursor = {
  v: 1
  kind: 'issue-list'
  filter: IssueListFilter
  factsRevision: number
  treeRevision: number
  nextIndex: number
  previousIssueId: string
}

export type TimelineCursor = {
  v: 1
  kind: 'round-list' | 'conversation-list' | 'activity-list' | 'mobile-pending'
  factsRevision: number
  occurredAt: number
  id: string
}

export function encodeIssueQueryCursor(cursor: IssueListCursor | TimelineCursor): string {
  return Buffer.from(JSON.stringify(cursor), 'utf8').toString('base64url')
}

export function readIssueListCursor(
  value: string,
  expected: {
    filter: IssueListFilter
    revisions: IssueHostRevisions
    issues: IssueSummary[]
  }
): number {
  const cursor = decodeCursor(value) as Partial<IssueListCursor>
  const nextIndex = cursor.nextIndex
  if (
    cursor.v !== 1 ||
    cursor.kind !== 'issue-list' ||
    cursor.filter !== expected.filter ||
    cursor.factsRevision !== expected.revisions.factsRevision ||
    cursor.treeRevision !== expected.revisions.treeRevision ||
    !Number.isInteger(nextIndex) ||
    (nextIndex ?? 0) <= 0 ||
    (nextIndex ?? 0) > expected.issues.length ||
    expected.issues[(nextIndex ?? 0) - 1]?.id !== cursor.previousIssueId
  ) {
    throw invalidCursor()
  }
  return nextIndex as number
}

export function readTimelineCursor(
  value: string,
  kind: TimelineCursor['kind'],
  factsRevision: number
): TimelineCursor {
  const cursor = decodeCursor(value) as Partial<TimelineCursor>
  if (
    cursor.v !== 1 ||
    cursor.kind !== kind ||
    cursor.factsRevision !== factsRevision ||
    typeof cursor.occurredAt !== 'number' ||
    !Number.isInteger(cursor.occurredAt) ||
    cursor.occurredAt < 0 ||
    typeof cursor.id !== 'string' ||
    cursor.id.length === 0
  ) {
    throw invalidCursor()
  }
  return cursor as TimelineCursor
}

function decodeCursor(value: string): unknown {
  try {
    return JSON.parse(Buffer.from(value, 'base64url').toString('utf8'))
  } catch {
    throw invalidCursor()
  }
}

function invalidCursor(): IssueRepositoryError {
  return new IssueRepositoryError('issue_cursor_invalid', 'Issue query cursor is invalid or stale.')
}
