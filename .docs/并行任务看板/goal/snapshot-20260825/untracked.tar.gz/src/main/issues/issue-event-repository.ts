import { randomUUID } from 'node:crypto'
import type {
  AuthorityHostPartitionKey,
  IssueEvent,
  IssueEventKind,
  IssueRecord
} from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import type { IssueEventListFilter } from './issue-repository-types'

type IssueEventRow = {
  id: string
  host_partition_key: AuthorityHostPartitionKey
  kind: IssueEventKind
  conversation_id: string | null
  payload_json: string
  occurred_at: number
  facts_revision: number
}

type IssueEventRefRow = {
  issue_id: string
  role: string
  issue_title_snapshot: string
}

export type AppendIssueEventInput = {
  hostPartitionKey: AuthorityHostPartitionKey
  kind: IssueEventKind
  conversationId?: string | null
  issueRefs: IssueEvent['issueRefs']
  payload?: Record<string, unknown>
  occurredAt: number
  factsRevision: number
  dedupeKey?: string | null
}

export class IssueEventRepository {
  constructor(private readonly database: IssueDatabase) {}

  appendWithinTransaction(input: AppendIssueEventInput): IssueEvent {
    if (input.dedupeKey) {
      const existing = this.database
        .prepare(
          `SELECT * FROM issue_events
           WHERE host_partition_key = ? AND dedupe_key = ?`
        )
        .get(input.hostPartitionKey, input.dedupeKey) as IssueEventRow | undefined
      if (existing) {
        return this.fromRow(existing)
      }
    }
    const id = randomUUID()
    this.database
      .prepare(
        `INSERT INTO issue_events (
           id, host_partition_key, kind, conversation_id, payload_json,
           occurred_at, facts_revision, dedupe_key, created_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        id,
        input.hostPartitionKey,
        input.kind,
        input.conversationId ?? null,
        JSON.stringify(input.payload ?? {}),
        input.occurredAt,
        input.factsRevision,
        input.dedupeKey ?? null,
        Date.now()
      )
    const insertRef = this.database.prepare(
      `INSERT INTO issue_event_issue_refs (
         event_id, issue_id, role, issue_title_snapshot
       ) VALUES (?, ?, ?, ?)`
    )
    for (const reference of input.issueRefs) {
      insertRef.run(id, reference.issueId, reference.role, reference.titleSnapshot)
    }
    return this.require(id)
  }

  get(id: string): IssueEvent | undefined {
    const row = this.database.prepare('SELECT * FROM issue_events WHERE id = ?').get(id) as
      | IssueEventRow
      | undefined
    return row ? this.fromRow(row) : undefined
  }

  list(filter: IssueEventListFilter = {}): IssueEvent[] {
    const conditions: string[] = []
    const bindings: (string | number)[] = []
    if (filter.hostPartitionKey) {
      conditions.push('event.host_partition_key = ?')
      bindings.push(filter.hostPartitionKey)
    }
    if (filter.conversationId) {
      conditions.push('event.conversation_id = ?')
      bindings.push(filter.conversationId)
    }
    if (filter.issueId) {
      conditions.push(
        `EXISTS (
           SELECT 1 FROM issue_event_issue_refs ref
           WHERE ref.event_id = event.id AND ref.issue_id = ?
         )`
      )
      bindings.push(filter.issueId)
    }
    const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : ''
    const limit = Math.max(1, Math.min(filter.limit ?? 200, 1_000))
    const rows = this.database
      .prepare(
        `SELECT event.* FROM issue_events event
         ${where}
         ORDER BY event.occurred_at DESC, event.id DESC
         LIMIT ?`
      )
      .all(...bindings, limit) as IssueEventRow[]
    return rows.map((row) => this.fromRow(row))
  }

  private require(id: string): IssueEvent {
    const event = this.get(id)
    if (!event) {
      throw new Error(`Issue event ${id} was not persisted.`)
    }
    return event
  }

  private fromRow(row: IssueEventRow): IssueEvent {
    const refs = this.database
      .prepare(
        `SELECT issue_id, role, issue_title_snapshot
         FROM issue_event_issue_refs
         WHERE event_id = ?
         ORDER BY role, issue_id`
      )
      .all(row.id) as IssueEventRefRow[]
    return {
      id: row.id,
      hostPartitionKey: row.host_partition_key,
      executionHostId: row.host_partition_key,
      kind: row.kind,
      conversationId: row.conversation_id,
      issueRefs: refs.map((ref) => ({
        issueId: ref.issue_id,
        role: ref.role,
        titleSnapshot: ref.issue_title_snapshot
      })),
      payload: JSON.parse(row.payload_json) as Record<string, unknown>,
      occurredAt: row.occurred_at,
      factsRevision: row.facts_revision
    }
  }
}

export function issueEventRef(
  issue: IssueRecord,
  role: string
): IssueEvent['issueRefs'][number] {
  return {
    issueId: issue.id,
    role,
    titleSnapshot: issueDisplayTitle(issue)
  }
}

export function issueDisplayTitle(issue: IssueRecord): string {
  return issue.source.kind === 'local' ? issue.localTitle ?? '' : issue.source.titleSnapshot
}
