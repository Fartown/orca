import { randomUUID } from 'node:crypto'
import { afterEach, describe, expect, it } from 'vitest'
import {
  ISSUE_DIGEST_DIRECT_ROUND_MAX_COUNT,
  ISSUE_DIGEST_INPUT_ITEM_MAX_BYTES,
  ISSUE_DIGEST_INPUT_MAX_BYTES
} from '../../shared/issues/digest-constants'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { buildIssueDigestSnapshot } from './issue-digest-snapshot'
import { IssueRepository, issueMutationIdentity } from './issue-repository'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-issue-digest-limit-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  mutationSequence += 1
  return issueMutationIdentity('digest-limit-test', `${label}-${mutationSequence}`)
}

function seedIssueConversation(repository: IssueRepository, name: string) {
  const issue = repository.issues.create({
    identity: identity('issue'),
    input: {
      kind: 'local',
      executionHostId: 'local',
      title: name
    }
  })
  const conversation = repository.conversations.create({
    identity: identity('conversation'),
    input: {
      executionHostId: 'local',
      workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${name}` },
      workspaceSnapshot: { name, path: `/workspace/${name}` },
      agent: 'codex',
      issueId: issue.id
    }
  })
  return { issue, conversation }
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('Issue Digest input budgets', () => {
  it('truncates one input at the UTF-8 item limit and reports partial coverage', () => {
    const repository = openRepository('item-limit')
    const { issue, conversation } = seedIssueConversation(repository, 'Item limit')
    const round = repository.rounds.create({
      identity: identity('round'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'oversized-round',
        agentOutput: { text: '界'.repeat(30_000) }
      }
    })

    const snapshot = buildIssueDigestSnapshot(repository.database, issue, 10)
    const input = snapshot.inputs.find((candidate) => candidate.inputId === round.id)

    expect(input).toMatchObject({
      completeness: 'partial',
      omissionReason: 'item-byte-limit'
    })
    expect(input?.includedBytes).toBeGreaterThan(0)
    expect(input?.includedBytes).toBeLessThanOrEqual(
      ISSUE_DIGEST_INPUT_ITEM_MAX_BYTES
    )
    expect(snapshot.coverage).toMatchObject({
      truncatedInputCount: 1,
      complete: false
    })
  })

  it('includes at most 2,000 direct rounds and records the omitted remainder', () => {
    const repository = openRepository('round-limit')
    const { issue, conversation } = seedIssueConversation(repository, 'Round limit')
    const insert = repository.database.prepare(
      `INSERT INTO round_records (
         id, conversation_id, kind, state_source, occurred_at, dedupe_key,
         user_input_completeness, output_completeness, question_completeness,
         created_at
       ) VALUES (?, ?, 'completion', 'hook', ?, ?, 'not-captured',
                 'not-captured', 'not-captured', ?)`
    )
    for (let index = 0; index <= ISSUE_DIGEST_DIRECT_ROUND_MAX_COUNT; index += 1) {
      insert.run(
        randomUUID(),
        conversation.id,
        index,
        `round-limit:${index}`,
        index
      )
    }

    const snapshot = buildIssueDigestSnapshot(
      repository.database,
      issue,
      ISSUE_DIGEST_DIRECT_ROUND_MAX_COUNT
    )

    expect(snapshot.coverage).toMatchObject({
      directRoundCount: ISSUE_DIGEST_DIRECT_ROUND_MAX_COUNT + 1,
      includedDirectRoundCount: ISSUE_DIGEST_DIRECT_ROUND_MAX_COUNT,
      omittedInputCount: 1,
      complete: false
    })
    expect(
      snapshot.inputs.filter((input) => input.omissionReason === 'round-limit')
    ).toHaveLength(1)
  })

  it('reserves the shared budget for outstanding rounds before user artifacts', () => {
    const repository = openRepository('unresolved-priority')
    const { issue, conversation } = seedIssueConversation(
      repository,
      'Unresolved priority'
    )
    const round = repository.rounds.create({
      identity: identity('waiting'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 1,
        dedupeKey: 'waiting-round',
        pendingQuestion: { text: 'Must not be omitted.' }
      }
    })
    const insertArtifact = repository.database.prepare(
      `INSERT INTO issue_artifact_refs (
         id, issue_id, source_kind, ref_kind, value, label, reachable, created_at
       ) VALUES (?, ?, 'user', 'file', ?, ?, 1, ?)`
    )
    const artifactValue = 'a'.repeat(ISSUE_DIGEST_INPUT_ITEM_MAX_BYTES)
    const artifactCount =
      Math.ceil(ISSUE_DIGEST_INPUT_MAX_BYTES / ISSUE_DIGEST_INPUT_ITEM_MAX_BYTES) + 1
    for (let index = 0; index < artifactCount; index += 1) {
      insertArtifact.run(
        randomUUID(),
        issue.id,
        `${artifactValue}-${index}`,
        `Artifact ${index}`,
        index
      )
    }

    const snapshot = buildIssueDigestSnapshot(repository.database, issue, 10)
    const waitingInput = snapshot.inputs.find((input) => input.inputId === round.id)

    expect(waitingInput).toMatchObject({
      kind: 'direct-round',
      includedBytes: expect.any(Number),
      omissionReason: null
    })
    expect(waitingInput?.includedBytes).toBeGreaterThan(0)
    expect(snapshot.coverage.includedUtf8Bytes).toBeLessThanOrEqual(
      ISSUE_DIGEST_INPUT_MAX_BYTES
    )
  })
})
