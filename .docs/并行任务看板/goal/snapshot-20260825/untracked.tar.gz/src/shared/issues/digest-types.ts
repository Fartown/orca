import type { TuiAgent } from '../tui-agent'
import type {
  ISSUE_DIGEST_INPUT_COMPLETENESS,
  ISSUE_DIGEST_INPUT_KINDS,
  ISSUE_DIGEST_OMISSION_REASONS,
  ISSUE_DIGEST_STATUSES
} from './digest-constants'
import type { IssueAuthorityDescriptor } from './types'

export type IssueDigestStatus = (typeof ISSUE_DIGEST_STATUSES)[number]
export type IssueDigestInputKind = (typeof ISSUE_DIGEST_INPUT_KINDS)[number]
export type IssueDigestInputCompleteness =
  (typeof ISSUE_DIGEST_INPUT_COMPLETENESS)[number]
export type IssueDigestOmissionReason = (typeof ISSUE_DIGEST_OMISSION_REASONS)[number]

export type IssueDigestSections = {
  problem: string | null
  conclusion: string | null
  keyArtifacts: string | null
  openIssues: string | null
  nextSteps: string | null
}

export type IssueDigestRecord = IssueDigestSections & {
  id: string
  issueId: string
  version: number
  revision: number
  status: IssueDigestStatus
  coversUntil: number
  coverageNote: string | null
  inputFingerprint: string
  generatorAgent: TuiAgent | null
  generationId: string | null
  generationError: string | null
  generationStartedAt: number | null
  generationFinishedAt: number | null
  createdAt: number
  updatedAt: number
  confirmedAt: number | null
}

export type IssueDigestInputSummary = {
  kind: IssueDigestInputKind
  inputId: string
  inputVersion: number
  titleSnapshot: string | null
  occurredAt: number | null
  originalBytes: number
  includedBytes: number
  completeness: IssueDigestInputCompleteness
  omissionReason: IssueDigestOmissionReason | null
}

export type IssueDigestCoverage = {
  totalInputCount: number
  includedInputCount: number
  directRoundCount: number
  includedDirectRoundCount: number
  totalUtf8Bytes: number
  includedUtf8Bytes: number
  truncatedInputCount: number
  omittedInputCount: number
  complete: boolean
  note: string | null
}

export type IssueDigestPreparation = {
  authority: IssueAuthorityDescriptor
  issueId: string
  coversUntil: number
  inputFingerprint: string
  inputs: IssueDigestInputSummary[]
  coverage: IssueDigestCoverage
}

export type IssueDigestMutationResult = {
  authority: IssueAuthorityDescriptor
  digest: IssueDigestRecord
}

export type IssueDigestConfirmationResult =
  | {
      status: 'confirmed'
      authority: IssueAuthorityDescriptor
      digest: IssueDigestRecord
      currentInputFingerprint: string
      stale: boolean
    }
  | {
      status: 'stale'
      authority: IssueAuthorityDescriptor
      digest: IssueDigestRecord
      currentInputFingerprint: string
      changeSummary: string
    }

export type IssueDigestProjection = {
  latestConfirmed: IssueDigestRecord | null
  latestAttempt: IssueDigestRecord | null
  currentInputFingerprint: string
  latestConfirmedIsStale: boolean
}
