import type { GlobalSettings } from '../../shared/global-settings-types'
import { getCommitMessageAgentSpec } from '../../shared/commit-message-agent-spec'
import {
  planCommitMessageGeneration,
  type CommitMessagePlan
} from '../../shared/commit-message-plan'
import { resolveTuiAgentLaunchArgs } from '../../shared/tui-agent-launch-defaults'
import {
  cancelTextGeneration,
  executeTextGenerationPlan,
  type CommitMessageGenerationTarget,
  type TextGenerationExecutionResult
} from '../text-generation/commit-message-text-generation'
import {
  prepareLocalCommitMessageAgentEnv,
  type CommitMessageAgentEnvironmentResolvers
} from '../text-generation/commit-message-agent-environment'
import { getLocalProjectGitExecOptions } from '../project-runtime-git-options'
import { getSshGitProvider } from '../providers/ssh-git-dispatch'
import type { Store } from '../persistence'
import type { IssueDigestGenerationExecutor } from './issue-digest-runtime-coordinator'
import { resolveIssueDigestGenerationTarget } from './issue-digest-generation-target'
import { buildIssueDigestPrompt } from './issue-digest-prompt'
import { parseIssueDigestOutput } from './issue-digest-output-parser'
import { IssueRepositoryError } from './issue-repository-error'

type IssueDigestGenerationRunnerDependencies = {
  getSettings(): Pick<GlobalSettings, 'agentCmdOverrides' | 'agentDefaultArgs'>
  resolveTarget: (
    input: Parameters<IssueDigestGenerationExecutor['generate']>[0]
  ) => Promise<CommitMessageGenerationTarget>
  execute: (
    agentId: string,
    plan: CommitMessagePlan,
    target: CommitMessageGenerationTarget,
    options: { emptyResultName: string; operation: 'issue-digest' }
  ) => Promise<TextGenerationExecutionResult>
  cancel: (
    target: CommitMessageGenerationTarget,
    operation: 'issue-digest'
  ) => Promise<void>
}

type ActiveDigestGeneration = {
  canceled: boolean
  target: CommitMessageGenerationTarget | null
}

export function createIssueDigestGenerationExecutor(
  dependencies: IssueDigestGenerationRunnerDependencies
): IssueDigestGenerationExecutor {
  const active = new Map<string, ActiveDigestGeneration>()
  return {
    async generate(input) {
      const state: ActiveDigestGeneration = { canceled: false, target: null }
      active.set(input.digestId, state)
      try {
        const prompt = buildIssueDigestPrompt(input.issue, input.snapshot)
        const spec = getCommitMessageAgentSpec(input.agent)
        if (!spec) {
          throw new IssueRepositoryError(
            'digest_target_unavailable',
            `Agent "${input.agent}" does not support non-interactive text generation.`
          )
        }
        const settings = dependencies.getSettings()
        const planned = planCommitMessageGeneration(
          {
            agentId: input.agent,
            model: spec.defaultModelId,
            agentCommandOverride: settings.agentCmdOverrides[input.agent],
            agentArgs: resolveTuiAgentLaunchArgs(input.agent, settings.agentDefaultArgs)
          },
          prompt
        )
        if (!planned.ok) {
          throw new IssueRepositoryError('digest_target_unavailable', planned.error)
        }

        const target = await dependencies.resolveTarget(input)
        if (state.canceled) {
          throw new Error('Generation canceled.')
        }
        state.target = target
        if (state.canceled) {
          throw new Error('Generation canceled.')
        }
        const result = await dependencies.execute(input.agent, planned.plan, target, {
          emptyResultName: 'Digest',
          operation: 'issue-digest'
        })
        if (!result.success) {
          throw new Error(result.error)
        }
        return parseIssueDigestOutput(result.rawOutput)
      } finally {
        if (active.get(input.digestId) === state) {
          active.delete(input.digestId)
        }
      }
    },
    async cancel(input) {
      const state = active.get(input.digestId)
      if (!state) {
        return
      }
      state.canceled = true
      if (state.target) {
        await dependencies.cancel(state.target, 'issue-digest')
      }
    }
  }
}

export function createProductionIssueDigestGenerationExecutor(options: {
  store: Store
  getAgentEnvironmentResolvers: () => CommitMessageAgentEnvironmentResolvers | undefined
}): IssueDigestGenerationExecutor {
  return createIssueDigestGenerationExecutor({
    getSettings: () => options.store.getSettings(),
    resolveTarget: (input) =>
      resolveIssueDigestGenerationTarget(
        {
          issue: input.issue,
          agent: input.agent,
          conversations: input.snapshot.directConversations
        },
        {
          store: options.store,
          getSshProvider: getSshGitProvider,
          prepareAgentEnv: (agent, target) =>
            prepareLocalCommitMessageAgentEnv(
              agent,
              options.getAgentEnvironmentResolvers(),
              target
            ),
          resolveLocalRuntimeOptions: (repo) =>
            repo ? getLocalProjectGitExecOptions(options.store, repo) : {}
        }
      ),
    execute: executeTextGenerationPlan,
    cancel: cancelTextGeneration
  })
}
