import { describe, expect, it } from 'vitest'
import type { AgentStatusEntry } from '../../../shared/agent-status-types'
import { ROUND_TEXT_PREVIEW_MAX_BYTES } from '../../../shared/issues/constants'
import { getUtf8ByteLength } from '../../../shared/utf8-byte-limits'
import { buildLegacyActivityMigrationSnapshot } from './legacy-activity-migration'

const PANE = 'tab-1:11111111-1111-4111-8111-111111111111'

function entry(overrides: Partial<AgentStatusEntry>): AgentStatusEntry {
  return {
    state: 'done',
    prompt: 'Implement the migration',
    updatedAt: 100,
    stateStartedAt: 100,
    paneKey: PANE,
    agentType: 'codex',
    stateHistory: [
      {
        state: 'done',
        prompt: 'Historical turn must not be imported',
        startedAt: 50
      }
    ],
    lastCompletedAssistantMessage: 'Migration complete',
    ...overrides
  }
}

describe('buildLegacyActivityMigrationSnapshot', () => {
  it('captures only current stopped panes with stable route-qualified event ids', () => {
    const snapshot = buildLegacyActivityMigrationSnapshot([
      {
        routeExecutionHostId: 'local',
        entry: entry({}),
        acknowledgedAt: 120
      },
      {
        routeExecutionHostId: 'local',
        entry: entry({
          paneKey: 'tab-working:11111111-1111-4111-8111-111111111112',
          state: 'working',
          stateStartedAt: 200
        }),
        acknowledgedAt: null
      },
      {
        routeExecutionHostId: 'local',
        entry: entry({
          paneKey: 'tab-boundary:11111111-1111-4111-8111-111111111113',
          sessionBoundary: true,
          stateStartedAt: 300
        }),
        acknowledgedAt: null
      }
    ])

    expect(snapshot).toEqual({
      local: [
        {
          legacyEventId: `agent:${PANE}:done:100`,
          paneKey: PANE,
          state: 'done',
          occurredAt: 100,
          acknowledgedAt: 120,
          userInputPreview: 'Implement the migration',
          agentOutputPreview: 'Migration complete',
          pendingQuestionPreview: null
        }
      ]
    })
  })

  it('bounds waiting previews without claiming the legacy snapshot is complete', () => {
    const oversizedQuestion = '你'.repeat(ROUND_TEXT_PREVIEW_MAX_BYTES)
    const snapshot = buildLegacyActivityMigrationSnapshot([
      {
        routeExecutionHostId: 'ssh:builder',
        entry: entry({
          state: 'blocked',
          stateStartedAt: 400,
          interactivePrompt: oversizedQuestion,
          lastCompletedAssistantMessage: undefined,
          lastAssistantMessage: 'Partial output'
        }),
        acknowledgedAt: 399
      }
    ])
    const candidate = snapshot['ssh:builder']?.[0]

    expect(candidate).toMatchObject({
      state: 'blocked',
      occurredAt: 400,
      acknowledgedAt: null,
      agentOutputPreview: 'Partial output'
    })
    expect(candidate?.pendingQuestionPreview).toBeTruthy()
    expect(getUtf8ByteLength(candidate?.pendingQuestionPreview ?? '')).toBeLessThanOrEqual(
      ROUND_TEXT_PREVIEW_MAX_BYTES
    )
  })
})
