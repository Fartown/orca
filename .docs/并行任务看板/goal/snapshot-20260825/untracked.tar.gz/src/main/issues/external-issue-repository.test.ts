import { afterEach, describe, expect, it } from 'vitest'
import type { TaskSourceContext } from '../../shared/task-source-context'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import { IssueRepositoryError, type IssueRepositoryErrorCode } from './issue-repository-error'

const repositories: IssueRepository[] = []
let sequence = 0

function openRepository(name: string): IssueRepository {
  const userDataPath = createIssueTestUserDataPath(`orca-external-issues-${name}`)
  const repository = new IssueRepository(
    openIssueTestDatabase({ profileId: name, userDataPath })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  sequence += 1
  return issueMutationIdentity('external-issue-test', `${label}-${sequence}`)
}

function sourceContext(
  projectId: string,
  hostId: TaskSourceContext['hostId'] = 'runtime:client-route'
): TaskSourceContext {
  return {
    kind: 'task-source',
    provider: 'github',
    projectId,
    hostId,
    repoId: `repo-${projectId}`,
    providerIdentity: {
      provider: 'github',
      owner: 'orca',
      repo: projectId,
      host: 'github.example.com'
    },
    accountLabel: 'Display-only account'
  }
}

function expectCode(operation: () => unknown, code: IssueRepositoryErrorCode): void {
  try {
    operation()
  } catch (error) {
    expect(error).toBeInstanceOf(IssueRepositoryError)
    expect((error as IssueRepositoryError).code).toBe(code)
    return
  }
  throw new Error(`Expected IssueRepositoryError(${code}).`)
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  sequence = 0
})

describe('External Issue repository', () => {
  it('derives source identity on the host and deduplicates client route aliases', () => {
    const repository = openRepository('identity')
    const mutation = issueMutationIdentity('stable-caller', 'track-external')
    const input = {
      executionHostId: 'local' as const,
      provider: 'github' as const,
      sourceContext: sourceContext('project-a'),
      refreshAttemptedAt: 100,
      snapshot: {
        externalId: '42',
        number: 42,
        url: 'https://github.example.com/orca/project-a/issues/42',
        title: 'External work',
        state: 'open'
      }
    }

    const first = repository.issues.trackExternal({ identity: mutation, input })
    const replay = repository.issues.trackExternal({ identity: mutation, input })

    expect(replay).toEqual(first)
    expect(first.source).toMatchObject({
      kind: 'external',
      externalId: '42',
      syncedAt: 100,
      refreshAttemptedAt: 100,
      availability: 'available',
      sourceContext: {
        hostId: 'local',
        projectId: 'project-a'
      }
    })
    expectCode(
      () =>
        repository.issues.trackExternal({
          identity: identity('duplicate-route'),
          input: {
            ...input,
            sourceContext: sourceContext('project-a', 'runtime:another-client-route')
          }
        }),
      'external_issue_already_tracked'
    )
    const sameExternalIdDifferentProject = repository.issues.trackExternal({
      identity: identity('different-project'),
      input: {
        ...input,
        sourceContext: sourceContext('project-b'),
        snapshot: {
          ...input.snapshot,
          url: 'https://github.example.com/orca/project-b/issues/42'
        }
      }
    })
    expect(
      (sameExternalIdDifferentProject.source as Extract<
        typeof sameExternalIdDifferentProject.source,
        { kind: 'external' }
      >).sourceScopeKey
    ).not.toBe(
      (first.source as Extract<typeof first.source, { kind: 'external' }>).sourceScopeKey
    )
  })

  it('retains the last good snapshot on failure and refreshes provider-owned fields only', () => {
    const repository = openRepository('refresh')
    const parent = repository.issues.create({
      identity: identity('parent'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Orca parent'
      }
    })
    const external = repository.issues.trackExternal({
      identity: identity('track'),
      input: {
        executionHostId: 'local',
        provider: 'github',
        sourceContext: sourceContext('project-a'),
        refreshAttemptedAt: 100,
        parentId: parent.id,
        note: 'Orca-owned note',
        snapshot: {
          externalId: '42',
          number: 42,
          url: 'https://github.example.com/orca/project-a/issues/42',
          title: 'Original title',
          state: 'open'
        }
      }
    })
    const failed = repository.issues.failExternalRefresh({
      identity: identity('refresh-failed'),
      input: {
        id: external.id,
        attemptedAt: 200,
        error: 'permission denied'
      }
    })

    expect(failed).toMatchObject({
      parentId: parent.id,
      note: 'Orca-owned note',
      source: {
        kind: 'external',
        titleSnapshot: 'Original title',
        stateSnapshot: 'open',
        syncedAt: 100,
        refreshAttemptedAt: 200,
        refreshError: 'permission denied',
        availability: 'unavailable'
      }
    })

    const refreshed = repository.issues.refreshExternal({
      identity: identity('refresh-success'),
      input: {
        id: external.id,
        attemptedAt: 300,
        snapshot: {
          externalId: '42',
          number: 42,
          identifier: 'ORCA-42',
          url: 'https://github.example.com/orca/project-a/issues/42',
          title: 'Provider title',
          state: 'closed',
          nativeParent: {
            externalId: '7',
            title: 'Provider parent'
          }
        }
      }
    })
    expect(refreshed).toMatchObject({
      parentId: parent.id,
      note: 'Orca-owned note',
      source: {
        kind: 'external',
        identifier: 'ORCA-42',
        titleSnapshot: 'Provider title',
        stateSnapshot: 'closed',
        syncedAt: 300,
        refreshAttemptedAt: 300,
        refreshError: null,
        availability: 'available',
        nativeParentSnapshot: {
          externalId: '7',
          title: 'Provider parent'
        }
      }
    })
    expectCode(
      () =>
        repository.issues.update({
          identity: identity('provider-title-write'),
          input: { id: external.id, localTitle: 'Local overwrite' }
        }),
      'external_issue_source_invalid'
    )
  })

  it('keeps provider state independent from Orca archive state', () => {
    const repository = openRepository('archive')
    const external = repository.issues.trackExternal({
      identity: identity('track'),
      input: {
        executionHostId: 'local',
        provider: 'github',
        sourceContext: sourceContext('project-a'),
        snapshot: {
          externalId: '42',
          url: 'https://github.example.com/orca/project-a/issues/42',
          title: 'Provider work',
          state: 'open'
        }
      }
    })

    repository.issues.archive({
      identity: identity('archive'),
      input: { id: external.id }
    })

    expect(repository.issues.get(external.id)).toMatchObject({
      state: 'archived',
      source: {
        kind: 'external',
        stateSnapshot: 'open'
      }
    })
  })

  it('allows only cross-authority or cross-partition links and replays link mutations', () => {
    const repository = openRepository('links')
    const issue = repository.issues.create({
      identity: identity('issue'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Source'
      }
    })
    const authorityId = repository.database.getAuthorityId()
    expectCode(
      () =>
        repository.issueLinks.create({
          identity: identity('same-partition'),
          input: {
            issueId: issue.id,
            target: {
              authorityId,
              hostPartitionKey: 'local',
              issueId: 'other',
              titleSnapshot: 'Other'
            }
          }
        }),
      'issue_link_invalid'
    )

    const mutation = issueMutationIdentity('stable-caller', 'cross-authority-link')
    const input = {
      issueId: issue.id,
      target: {
        authorityId: 'other-authority',
        hostPartitionKey: 'local' as const,
        issueId: 'other',
        titleSnapshot: 'Other'
      }
    }
    const first = repository.issueLinks.create({ identity: mutation, input })
    expect(repository.issueLinks.create({ identity: mutation, input })).toEqual(first)
    expect(repository.issueLinks.list(issue.id)).toEqual([first])
  })
})
