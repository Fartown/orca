import type {
  ConversationSummary,
  IssueDetail,
  IssueSummary,
  RoundRecordPreview,
  RoundRecordTextSummary
} from '../../../../shared/issues/types'

const EMPTY_TEXT: RoundRecordTextSummary = {
  completeness: 'not-captured',
  storage: 'none',
  bytes: 0,
  preview: null,
  previewBytes: 0
}

export function makeIssueSummary(
  id: string,
  overrides: Partial<IssueSummary> = {}
): IssueSummary {
  return {
    id,
    hostPartitionKey: 'local',
    executionHostId: 'local',
    source: { kind: 'local', number: 1 },
    localTitle: `Issue ${id.slice(0, 4)}`,
    typeLabel: null,
    note: null,
    state: 'active',
    parentId: null,
    siblingOrder: 0,
    createdAt: 1,
    updatedAt: 1,
    archivedAt: null,
    ownUnresolvedCount: 0,
    descendantAttentionCount: 0,
    directConversationCount: 0,
    activeConversationCount: 0,
    ...overrides
  }
}

export function makeConversationSummary(
  id: string,
  overrides: Partial<ConversationSummary> = {}
): ConversationSummary {
  return {
    id,
    hostPartitionKey: 'local',
    executionHostId: 'local',
    workspaceRef: { type: 'worktree', worktreeId: 'workspace-a' },
    workspaceSnapshot: { name: 'Workspace A', path: '/workspace/a' },
    agent: 'codex',
    title: `Conversation ${id.slice(0, 4)}`,
    titleSource: 'user',
    issueId: '11111111-1111-4111-8111-111111111111',
    state: 'active',
    launchFailure: null,
    createdAt: 1,
    updatedAt: 1,
    unresolvedRoundCount: 0,
    latestRound: null,
    ...overrides
  }
}

export function makeRoundPreview(
  id: string,
  overrides: Partial<RoundRecordPreview> = {}
): RoundRecordPreview {
  return {
    id,
    conversationId: '22222222-2222-4222-8222-222222222222',
    kind: 'completion',
    stateSource: 'hook',
    occurredAt: Date.UTC(2026, 7, 23, 8, 0, 0),
    executionChainId: null,
    supersedesRoundId: null,
    userInput: { ...EMPTY_TEXT },
    agentOutput: {
      completeness: 'preview-complete',
      storage: 'preview',
      bytes: 24,
      preview: 'Implemented the requested change.',
      previewBytes: 33
    },
    pendingQuestion: { ...EMPTY_TEXT },
    readAt: null,
    resolvedAt: null,
    resolution: null,
    effectiveResolvedAt: null,
    effectiveResolution: null,
    finalizedAt: null,
    bodyEvictedAt: null,
    bodyDeletedAt: null,
    bodyRevision: 1,
    createdAt: Date.UTC(2026, 7, 23, 8, 0, 0),
    ...overrides
  }
}

export function makeIssueDetail(
  issue: IssueSummary = makeIssueSummary(
    '11111111-1111-4111-8111-111111111111'
  ),
  overrides: Partial<IssueDetail> = {}
): IssueDetail {
  return {
    authority: {
      authorityId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
      hostPartitionKey: 'local',
      routeExecutionHostId: 'local'
    },
    issue,
    directChildren: [],
    directConversations: [],
    workspaceSnapshots: [],
    ...overrides
  }
}
