import {
  ISSUE_DIGEST_DIRECT_ROUND_MAX_COUNT,
  ISSUE_DIGEST_INPUT_ITEM_MAX_BYTES,
  ISSUE_DIGEST_INPUT_MAX_BYTES
} from '../../shared/issues/digest-constants'
import type {
  IssueDigestCoverage,
  IssueDigestInputCompleteness,
  IssueDigestInputSummary,
  IssueDigestOmissionReason
} from '../../shared/issues/digest-types'
import {
  clampUtf8TextPrefix,
  getUtf8ByteLength
} from '../../shared/utf8-byte-limits'
import type { IssueDigestInputCandidate } from './issue-digest-input-candidate'

export type MaterializedIssueDigestInput = {
  summary: IssueDigestInputSummary
  content: string
}

export function applyIssueDigestInputBudget(
  candidates: IssueDigestInputCandidate[]
): {
  inputs: IssueDigestInputSummary[]
  materializedInputs: MaterializedIssueDigestInput[]
  coverage: IssueDigestCoverage
} {
  let remainingBytes = ISSUE_DIGEST_INPUT_MAX_BYTES
  let directRoundCount = 0
  let includedDirectRoundCount = 0
  let totalUtf8Bytes = 0
  let includedUtf8Bytes = 0
  let truncatedInputCount = 0
  let omittedInputCount = 0
  const inputs: IssueDigestInputSummary[] = []
  const materializedInputs: MaterializedIssueDigestInput[] = []

  for (const candidate of candidates) {
    const originalBytes = getUtf8ByteLength(candidate.content)
    totalUtf8Bytes += originalBytes
    let omissionReason: IssueDigestOmissionReason | null = null
    let content = candidate.content
    if (candidate.kind === 'direct-round') {
      directRoundCount += 1
      if (directRoundCount > ISSUE_DIGEST_DIRECT_ROUND_MAX_COUNT) {
        content = ''
        omissionReason = 'round-limit'
      }
    }
    if (content && originalBytes > ISSUE_DIGEST_INPUT_ITEM_MAX_BYTES) {
      content = clampUtf8TextPrefix(content, ISSUE_DIGEST_INPUT_ITEM_MAX_BYTES)
      omissionReason = 'item-byte-limit'
    }
    if (content) {
      const itemBytes = getUtf8ByteLength(content)
      if (remainingBytes <= 0) {
        content = ''
        omissionReason = 'total-byte-limit'
      } else if (itemBytes > remainingBytes) {
        content = clampUtf8TextPrefix(content, remainingBytes)
        omissionReason = 'total-byte-limit'
      }
    }
    const includedBytes = getUtf8ByteLength(content)
    remainingBytes -= includedBytes
    includedUtf8Bytes += includedBytes
    if (includedBytes === 0) {
      omittedInputCount += 1
    } else {
      if (candidate.kind === 'direct-round') {
        includedDirectRoundCount += 1
      }
      if (includedBytes < originalBytes) {
        truncatedInputCount += 1
      }
    }
    const summary = summarizeCandidate(
      candidate,
      originalBytes,
      includedBytes,
      omissionReason
    )
    inputs.push(summary)
    if (includedBytes > 0) {
      materializedInputs.push({ summary, content })
    }
  }

  const sourceIncompleteCount = inputs.filter(
    (input) => input.includedBytes > 0 && input.completeness !== 'complete'
  ).length
  const notes: string[] = []
  if (truncatedInputCount > 0) {
    notes.push(`${truncatedInputCount} inputs were truncated by Digest limits.`)
  }
  if (omittedInputCount > 0) {
    notes.push(`${omittedInputCount} inputs were omitted by Digest limits.`)
  }
  if (sourceIncompleteCount > 0) {
    notes.push(`${sourceIncompleteCount} included inputs have incomplete source text.`)
  }
  return {
    inputs,
    materializedInputs,
    coverage: {
      totalInputCount: candidates.length,
      includedInputCount: materializedInputs.length,
      directRoundCount,
      includedDirectRoundCount,
      totalUtf8Bytes,
      includedUtf8Bytes,
      truncatedInputCount,
      omittedInputCount,
      complete:
        truncatedInputCount === 0 &&
        omittedInputCount === 0 &&
        sourceIncompleteCount === 0,
      note: notes.length > 0 ? notes.join(' ') : null
    }
  }
}

function summarizeCandidate(
  candidate: IssueDigestInputCandidate,
  originalBytes: number,
  includedBytes: number,
  omissionReason: IssueDigestOmissionReason | null
): IssueDigestInputSummary {
  const completeness: IssueDigestInputCompleteness =
    includedBytes === 0
      ? 'unavailable'
      : includedBytes < originalBytes || candidate.sourceCompleteness !== 'complete'
        ? 'partial'
        : 'complete'
  return {
    kind: candidate.kind,
    inputId: candidate.inputId,
    inputVersion: candidate.inputVersion,
    titleSnapshot: candidate.titleSnapshot,
    occurredAt: candidate.occurredAt,
    originalBytes,
    includedBytes,
    completeness,
    omissionReason
  }
}
