import type { AgentStatusEntry } from '../../../shared/agent-status-types'
import {
  parseExecutionHostId,
  type ExecutionHostId
} from '../../../shared/execution-host'
import { ROUND_TEXT_PREVIEW_MAX_BYTES } from '../../../shared/issues/constants'
import { LegacyActivityMigrationResultSchema } from '../../../shared/issues/schemas'
import type {
  LegacyActivityMigrationEntry,
  LegacyActivityMigrationResult
} from '../../../shared/issues/types'
import { ORCA_ISSUES_RUNTIME_CAPABILITY } from '../../../shared/protocol-version'
import { clampUtf8TextPrefix } from '../../../shared/utf8-byte-limits'
import { createBrowserUuid } from '../lib/browser-uuid'
import {
  callRuntimeRpc,
  runtimeEnvironmentSupportsCapability,
  type RuntimeClientTarget
} from '../runtime/runtime-rpc-client'

const LEGACY_ACTIVITY_MIGRATION_BATCH_SIZE = 500

export type LegacyActivityMigrationSource = {
  routeExecutionHostId: ExecutionHostId
  entry: AgentStatusEntry
  acknowledgedAt: number | null
}

export type LegacyActivityMigrationSnapshot = Partial<
  Record<ExecutionHostId, LegacyActivityMigrationEntry[]>
>

export type LegacyActivityMigrationClientResult =
  | { status: 'ready'; result: LegacyActivityMigrationResult }
  | { status: 'unsupported' }
  | { status: 'error'; error: string }

export type LegacyActivityMigrationDependencies = {
  supportsCapability: (environmentId: string) => Promise<boolean>
  callRpc: (
    routeExecutionHostId: ExecutionHostId,
    method: string,
    params: unknown
  ) => Promise<unknown>
  createMutationId: () => string
}

export function buildLegacyActivityMigrationSnapshot(
  sources: readonly LegacyActivityMigrationSource[]
): LegacyActivityMigrationSnapshot {
  const entriesByRoute = new Map<
    ExecutionHostId,
    Map<string, LegacyActivityMigrationEntry>
  >()
  for (const source of sources) {
    const route = parseExecutionHostId(source.routeExecutionHostId)
    if (!route || !isStoppedLegacyEntry(source.entry)) {
      continue
    }
    const occurredAt = source.entry.stateStartedAt
    const legacyEventId =
      `agent:${source.entry.paneKey}:${source.entry.state}:${occurredAt}`
    const entries =
      entriesByRoute.get(route.id) ??
      new Map<string, LegacyActivityMigrationEntry>()
    entries.set(legacyEventId, {
      legacyEventId,
      paneKey: source.entry.paneKey,
      state: source.entry.state,
      occurredAt,
      acknowledgedAt:
        source.acknowledgedAt !== null &&
        source.acknowledgedAt >= occurredAt
          ? source.acknowledgedAt
          : null,
      userInputPreview: boundedPreview(source.entry.prompt),
      agentOutputPreview: boundedPreview(
        source.entry.state === 'done'
          ? source.entry.lastCompletedAssistantMessage ??
              source.entry.lastAssistantMessage
          : source.entry.lastAssistantMessage ??
              source.entry.lastCompletedAssistantMessage
      ),
      pendingQuestionPreview: boundedPreview(
        source.entry.state === 'done'
          ? null
          : source.entry.interactivePrompt
      )
    })
    entriesByRoute.set(route.id, entries)
  }

  return Object.fromEntries(
    [...entriesByRoute].map(([routeExecutionHostId, entries]) => [
      routeExecutionHostId,
      [...entries.values()].sort(compareMigrationEntries)
    ])
  ) as LegacyActivityMigrationSnapshot
}

export function legacyActivityMigrationSnapshotKey(
  entries: readonly LegacyActivityMigrationEntry[]
): string {
  return JSON.stringify([...entries].sort(compareMigrationEntries))
}

export async function migrateLegacyActivity(
  routeExecutionHostId: ExecutionHostId,
  entries: readonly LegacyActivityMigrationEntry[],
  dependencies: LegacyActivityMigrationDependencies = defaultDependencies
): Promise<LegacyActivityMigrationClientResult> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    return { status: 'error', error: 'Invalid Issue host route.' }
  }
  try {
    if (
      route.kind === 'runtime' &&
      !(await dependencies.supportsCapability(route.environmentId))
    ) {
      return { status: 'unsupported' }
    }
    const migrated: LegacyActivityMigrationResult['migrated'] = []
    const unresolvedLegacyEventIds: string[] = []
    let authority: LegacyActivityMigrationResult['authority'] | null = null
    for (
      let offset = 0;
      offset < entries.length;
      offset += LEGACY_ACTIVITY_MIGRATION_BATCH_SIZE
    ) {
      const result = LegacyActivityMigrationResultSchema.parse(
        await dependencies.callRpc(
          route.id,
          'issues.migrateLegacyActivity',
          {
            executionHostId: route.id,
            mutationId: dependencies.createMutationId(),
            entries: entries.slice(
              offset,
              offset + LEGACY_ACTIVITY_MIGRATION_BATCH_SIZE
            )
          }
        )
      )
      if (result.authority.routeExecutionHostId !== route.id) {
        throw new Error(
          'Issue Activity migration response was stamped for another route.'
        )
      }
      authority = result.authority
      migrated.push(...result.migrated)
      unresolvedLegacyEventIds.push(...result.unresolvedLegacyEventIds)
    }
    if (!authority) {
      throw new Error('Issue Activity migration requires at least one entry.')
    }
    return {
      status: 'ready',
      result: {
        authority,
        migrated,
        unresolvedLegacyEventIds: [...new Set(unresolvedLegacyEventIds)]
      }
    }
  } catch (error) {
    return {
      status: 'error',
      error:
        error instanceof Error && error.message.trim()
          ? error.message
          : 'Unable to migrate legacy Activity.'
    }
  }
}

function isStoppedLegacyEntry(
  entry: AgentStatusEntry
): entry is AgentStatusEntry & {
  state: LegacyActivityMigrationEntry['state']
} {
  if (entry.sessionBoundary === true) {
    return false
  }
  return (
    entry.state === 'done' ||
    entry.state === 'waiting' ||
    entry.state === 'blocked'
  )
}

function boundedPreview(value: string | null | undefined): string | null {
  const trimmed = value?.trim()
  return trimmed
    ? clampUtf8TextPrefix(trimmed, ROUND_TEXT_PREVIEW_MAX_BYTES)
    : null
}

function compareMigrationEntries(
  left: LegacyActivityMigrationEntry,
  right: LegacyActivityMigrationEntry
): number {
  return (
    left.occurredAt - right.occurredAt ||
    left.legacyEventId.localeCompare(right.legacyEventId)
  )
}

function runtimeTargetForRoute(
  routeExecutionHostId: ExecutionHostId
): RuntimeClientTarget {
  const route = parseExecutionHostId(routeExecutionHostId)
  return route?.kind === 'runtime'
    ? { kind: 'environment', environmentId: route.environmentId }
    : { kind: 'local' }
}

const defaultDependencies: LegacyActivityMigrationDependencies = {
  supportsCapability: (environmentId) =>
    runtimeEnvironmentSupportsCapability(
      environmentId,
      ORCA_ISSUES_RUNTIME_CAPABILITY
    ),
  callRpc: (routeExecutionHostId, method, params) =>
    callRuntimeRpc(
      runtimeTargetForRoute(routeExecutionHostId),
      method,
      params,
      { reuseRecentCompatibilityFailure: true }
    ),
  createMutationId: createBrowserUuid
}
