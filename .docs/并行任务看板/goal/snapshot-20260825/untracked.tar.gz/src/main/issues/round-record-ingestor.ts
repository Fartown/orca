import { createHash } from 'node:crypto'
import type { AgentStatusState } from '../../shared/agent-status-types'
import type { RoundRecord } from '../../shared/issues/types'
import { isTuiAgent } from '../../shared/tui-agent-config'
import type {
  ConversationHookIdentityEvent,
  ConversationHookIdentityIngestResult,
  ConversationHookIdentityIngestor
} from './conversation-hook-identity-ingestor'
import type { IssueRepository } from './issue-repository'
import type { CreateRoundRecordInput } from './issue-repository-types'
import { createProviderTurnRefValue } from './round-record-provider-turn-ref'

export type RoundRecordHookEvent = ConversationHookIdentityEvent & {
  hasExplicitPrompt?: boolean
  promptInteractionKey?: string
  providerPromptId?: string
  providerTurnId?: string
  stateStartedAt: number
  payload: {
    state: AgentStatusState
    agentType?: ConversationHookIdentityEvent['payload']['agentType']
    prompt?: string
    interactivePrompt?: string
    lastAssistantMessage?: string
    sessionBoundary?: boolean
  }
}

export type RoundRecordIngestResult =
  | { disposition: 'persisted'; conversationId: string; roundId: string }
  | { disposition: 'resolved'; conversationId: string; roundIds: string[] }
  | {
      disposition: 'ignored'
      reason:
        | 'not-a-stable-state'
        | 'non-turn-status'
        | 'conversation-unresolved'
        | 'agent-unsupported'
    }

export type RoundRecordIngestorDependencies = {
  onDiagnostic?(result: RoundRecordIngestResult, event: RoundRecordHookEvent): void
  scheduleReconciliation?(conversationId: string): void
}

const INGEST_CALLER_FINGERPRINT = 'orca-round-hook-ingestor'

export class RoundRecordIngestor {
  private readonly paneQueues = new Map<string, Promise<void>>()

  constructor(
    private readonly repository: IssueRepository,
    private readonly identityIngestor: ConversationHookIdentityIngestor,
    private readonly dependencies: RoundRecordIngestorDependencies = {}
  ) {}

  ingest(event: RoundRecordHookEvent): Promise<RoundRecordIngestResult> {
    const previous = this.paneQueues.get(event.paneKey) ?? Promise.resolve()
    let resolveResult!: (result: RoundRecordIngestResult) => void
    let rejectResult!: (error: unknown) => void
    const result = new Promise<RoundRecordIngestResult>((resolve, reject) => {
      resolveResult = resolve
      rejectResult = reject
    })
    const next = previous
      .catch(() => undefined)
      .then(async () => {
        try {
          resolveResult(await this.ingestOne(event))
        } catch (error) {
          rejectResult(error)
        }
      })
      .finally(() => {
        if (this.paneQueues.get(event.paneKey) === next) {
          this.paneQueues.delete(event.paneKey)
        }
      })
    this.paneQueues.set(event.paneKey, next)
    return result
  }

  private async ingestOne(event: RoundRecordHookEvent): Promise<RoundRecordIngestResult> {
    const identity = await this.identityIngestor.ingest(event)
    if (
      event.providerSessionOnly ||
      event.restoredUnconfirmed ||
      event.payload.sessionBoundary
    ) {
      return this.finish({ disposition: 'ignored', reason: 'non-turn-status' }, event)
    }
    if (!isTuiAgent(event.payload.agentType)) {
      return this.finish({ disposition: 'ignored', reason: 'agent-unsupported' }, event)
    }
    if (
      event.payload.state !== 'done' &&
      event.payload.state !== 'waiting' &&
      event.payload.state !== 'blocked' &&
      event.payload.state !== 'working'
    ) {
      return this.finish({ disposition: 'ignored', reason: 'not-a-stable-state' }, event)
    }
    const conversationId = this.resolveConversationId(event, identity)
    if (!conversationId) {
      return this.finish(
        { disposition: 'ignored', reason: 'conversation-unresolved' },
        event
      )
    }
    if (event.payload.state === 'working') {
      const result = this.resolvePriorObligations(conversationId, event)
      this.dependencies.scheduleReconciliation?.(conversationId)
      return result
    }

    const input = createRoundInput(
      conversationId,
      event,
      this.providerTurnRef(conversationId, event)
    )
    const round = this.repository.rounds.create({
      identity: {
        callerFingerprint: INGEST_CALLER_FINGERPRINT,
        mutationId: mutationId('persist', input)
      },
      input
    })
    this.dependencies.scheduleReconciliation?.(conversationId)
    return this.finish(
      { disposition: 'persisted', conversationId, roundId: round.id },
      event
    )
  }

  private resolveConversationId(
    event: RoundRecordHookEvent,
    identity: ConversationHookIdentityIngestResult
  ): string | null {
    if (identity.disposition !== 'ignored') {
      return identity.conversationId
    }
    if (!event.launchToken) {
      return null
    }
    const hostPartitionKey = event.connectionId
      ? (`ssh:${event.connectionId}` as const)
      : 'local'
    return (
      this.repository.conversationLaunchClaims.findByToken(
        hostPartitionKey,
        event.launchToken,
        false
      )?.conversationId ?? null
    )
  }

  private resolvePriorObligations(
    conversationId: string,
    event: RoundRecordHookEvent
  ): RoundRecordIngestResult {
    const roundIds: string[] = []
    const waiting = this.findLatestOutstanding(conversationId, 'waiting', event.stateStartedAt)
    if (waiting) {
      this.repository.rounds.update({
        identity: {
          callerFingerprint: INGEST_CALLER_FINGERPRINT,
          mutationId: mutationId('resume', {
            roundId: waiting.id,
            resolvedAt: event.stateStartedAt
          })
        },
        input: {
          id: waiting.id,
          resolvedAt: event.stateStartedAt,
          resolution: 'resumed'
        }
      })
      roundIds.push(waiting.id)
    }
    if (event.hasExplicitPrompt) {
      const completion = this.findLatestOutstanding(
        conversationId,
        'completion',
        event.stateStartedAt
      )
      if (completion) {
        this.repository.rounds.update({
          identity: {
            callerFingerprint: INGEST_CALLER_FINGERPRINT,
            mutationId: mutationId('new-input', {
              roundId: completion.id,
              resolvedAt: event.stateStartedAt
            })
          },
          input: {
            id: completion.id,
            readAt: event.stateStartedAt,
            resolvedAt: event.stateStartedAt,
            resolution: 'new-input'
          }
        })
        roundIds.push(completion.id)
      }
    }
    return this.finish({ disposition: 'resolved', conversationId, roundIds }, event)
  }

  private findLatestOutstanding(
    conversationId: string,
    kind: RoundRecord['kind'],
    beforeOrAt: number
  ): Pick<RoundRecord, 'id'> | undefined {
    return this.repository.database
      .prepare(
        `SELECT id
         FROM round_record_effective_state
         WHERE conversation_id = ?
           AND kind = ?
           AND effective_resolved_at IS NULL
           AND occurred_at <= ?
         ORDER BY occurred_at DESC, id DESC
         LIMIT 1`
      )
      .get(conversationId, kind, beforeOrAt) as Pick<RoundRecord, 'id'> | undefined
  }

  private providerTurnRef(
    conversationId: string,
    event: RoundRecordHookEvent
  ): CreateRoundRecordInput['refs'] {
    const providerTurnId =
      event.providerTurnId ?? event.providerPromptId
    if (!providerTurnId) {
      return undefined
    }
    const identity = this.repository.conversationIdentities
      .listForConversation(conversationId)
      .find((candidate) => candidate.retiredAt === null)
    if (!identity) {
      return undefined
    }
    return [
      {
        kind: 'provider-turn',
        value: createProviderTurnRefValue(identity.identityFingerprint, providerTurnId),
        reachable: true
      }
    ]
  }

  private finish(
    result: RoundRecordIngestResult,
    event: RoundRecordHookEvent
  ): RoundRecordIngestResult {
    this.dependencies.onDiagnostic?.(result, event)
    return result
  }
}

function createRoundInput(
  conversationId: string,
  event: RoundRecordHookEvent,
  refs: CreateRoundRecordInput['refs']
): CreateRoundRecordInput {
  const userInput = previewInput(event.payload.prompt)
  const agentOutput = previewInput(event.payload.lastAssistantMessage)
  const pendingQuestion = previewInput(event.payload.interactivePrompt)
  return {
    conversationId,
    kind: event.payload.state === 'done' ? 'completion' : 'waiting',
    stateSource: 'hook',
    occurredAt: event.stateStartedAt,
    dedupeKey: hookDedupeKey(conversationId, event),
    finalizedAt: event.receivedAt,
    refs,
    ...(userInput ? { userInput } : {}),
    ...(agentOutput ? { agentOutput } : {}),
    ...(pendingQuestion ? { pendingQuestion } : {})
  }
}

function previewInput(text: string | undefined): {
  preview: string
  completeness: 'preview-complete'
  storage: 'preview'
} | null {
  return text
    ? {
        preview: text,
        completeness: 'preview-complete',
        storage: 'preview'
      }
    : null
}

function hookDedupeKey(
  conversationId: string,
  event: RoundRecordHookEvent
): string {
  return `round:hook:v1:${hashValue({
    conversationId,
    state: event.payload.state,
    stateStartedAt: event.stateStartedAt,
    providerTurnId: event.providerTurnId ?? null,
    providerPromptId: event.providerPromptId ?? null,
    promptInteractionKey: event.promptInteractionKey ?? null
  })}`
}

function mutationId(action: string, value: unknown): string {
  return `round-hook:${action}:${hashValue(value)}`
}

function hashValue(value: unknown): string {
  return createHash('sha256').update(JSON.stringify(value)).digest('hex')
}
