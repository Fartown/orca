// @vitest-environment happy-dom

import { randomUUID } from 'node:crypto'
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor
} from '@testing-library/react'
import '@testing-library/jest-dom/vitest'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { ExecutionHostId } from '../../../../../shared/execution-host'
import {
  DEFAULT_ISSUE_CLIENT_PREFERENCES,
  type IssueClientSnapshot
} from '../../../../../shared/issues/client-data'
import type {
  ConversationSummary,
  IssueAuthorityDescriptor,
  IssueDetail,
  IssueSearchResult,
  IssueSummary
} from '../../../../../shared/issues/types'
import {
  createIssuesDomainStore,
  type IssuesDomainDependencies
} from '../../../issues/issues-domain-store'
import type { SidebarHostOption } from '../sidebar-host-options'
import { IssueSidebarView } from './issue-sidebar'

const navigationMocks = vi.hoisted(() => ({
  openIssueConversation: vi.fn()
}))

vi.mock('../../../issues/issue-conversation-navigation', () => navigationMocks)

vi.mock('@tanstack/react-virtual', () => ({
  useVirtualizer: ({ count }: { count: number }) => ({
    getTotalSize: () => count * 32,
    getVirtualItems: () =>
      Array.from({ length: count }, (_, index) => ({
        index,
        key: index,
        start: index * 32,
        size: 32
      })),
    measureElement: () => undefined
  })
}))

afterEach(cleanup)

function authority(
  routeExecutionHostId: ExecutionHostId
): IssueAuthorityDescriptor {
  return {
    authorityId: randomUUID(),
    hostPartitionKey: 'local',
    routeExecutionHostId
  }
}

function issue(
  descriptor: IssueAuthorityDescriptor,
  directConversationCount = 0
): IssueSummary {
  return {
    id: randomUUID(),
    hostPartitionKey: descriptor.hostPartitionKey,
    executionHostId: descriptor.routeExecutionHostId,
    source: { kind: 'local', number: 1 },
    localTitle: 'Issue one',
    typeLabel: 'Feature',
    note: null,
    state: 'active',
    parentId: null,
    siblingOrder: 0,
    createdAt: 1,
    updatedAt: 1,
    archivedAt: null,
    ownUnresolvedCount: 0,
    descendantAttentionCount: 0,
    directConversationCount,
    activeConversationCount: 0
  }
}

function conversation(
  descriptor: IssueAuthorityDescriptor,
  issueId: string | null
): ConversationSummary {
  return {
    id: randomUUID(),
    hostPartitionKey: descriptor.hostPartitionKey,
    executionHostId: descriptor.routeExecutionHostId,
    workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-a' },
    workspaceSnapshot: { name: 'Docs', path: '/tmp/docs' },
    agent: 'claude',
    title: issueId ? 'Bound work' : 'Unassigned work',
    titleSource: 'user',
    issueId,
    state: 'active',
    launchFailure: null,
    createdAt: 1,
    updatedAt: 1,
    unresolvedRoundCount: 0,
    latestRound: null
  }
}

function snapshot(
  descriptor: IssueAuthorityDescriptor,
  summary: IssueSummary
): IssueClientSnapshot {
  return {
    authority: descriptor,
    cachedAt: 1,
    factsRevision: 1,
    treeRevision: 1,
    searchRevision: 0,
    issues: [summary],
    unassigned: { conversationCount: 1, unresolvedCount: 0 },
    details: [],
    unassignedConversations: [],
    rounds: []
  }
}

function host(id: ExecutionHostId, label: string): SidebarHostOption {
  return {
    id,
    label,
    detail: id === 'local' ? 'This computer' : 'Orca server',
    kind: id === 'local' ? 'local' : 'runtime',
    health: id === 'local' ? 'local' : 'available',
    presence: id === 'local' ? 'local' : 'configured'
  }
}

describe('IssueSidebarView', () => {
  it('loads every route from the existing host registry and filters without changing the tree source', async () => {
    const loadPartition = vi.fn<IssuesDomainDependencies['loadPartition']>(
      async (route) => {
        const descriptor = authority(route)
        return {
          status: 'ready',
          value: snapshot(descriptor, issue(descriptor))
        }
      }
    )
    const store = createIssuesDomainStore({
      readPreferences: async () => DEFAULT_ISSUE_CLIENT_PREFERENCES,
      writePreferences: async (preferences) => preferences,
      loadPartition,
      loadDetail: async () => ({ status: 'error', error: 'unused' }),
      loadUnassigned: async () => ({ status: 'ready', value: [] }),
      loadRounds: async () => ({ status: 'error', error: 'unused' })
    })

    render(
      <IssueSidebarView
        hostOptions={[
          host('local', 'This Mac'),
          host('runtime:remote', 'Build Server')
        ]}
        store={store}
        eventTarget={new EventTarget()}
        onOpenIssue={vi.fn()}
      />
    )

    await waitFor(() => expect(loadPartition).toHaveBeenCalledTimes(2))
    expect(loadPartition.mock.calls.map(([route]) => route)).toEqual([
      'local',
      'runtime:remote'
    ])

    fireEvent.click(screen.getByRole('button', { name: 'Needs me' }))
    expect(store.getState().preferences.filter).toBe('needs-me')
    expect(screen.getAllByText('Nothing needs your attention.')).toHaveLength(2)
  })

  it('loads Issue detail from the host only when an unloaded leaf is expanded', async () => {
    const descriptor = authority('local')
    const summary = issue(descriptor, 1)
    const bound = conversation(descriptor, summary.id)
    const detail: IssueDetail = {
      authority: descriptor,
      issue: summary,
      directChildren: [],
      directConversations: [bound],
      workspaceSnapshots: [bound.workspaceSnapshot]
    }
    const loadDetail = vi.fn<
      IssuesDomainDependencies['loadDetail']
    >(async () => ({ status: 'ready', value: detail }))
    const store = createIssuesDomainStore({
      readPreferences: async () => DEFAULT_ISSUE_CLIENT_PREFERENCES,
      writePreferences: async (preferences) => preferences,
      loadPartition: async () => ({
        status: 'ready',
        value: snapshot(descriptor, summary)
      }),
      loadDetail,
      loadUnassigned: async () => ({ status: 'ready', value: [] }),
      loadRounds: async () => ({ status: 'error', error: 'unused' })
    })

    render(
      <IssueSidebarView
        hostOptions={[host('local', 'This Mac')]}
        store={store}
        eventTarget={new EventTarget()}
        onOpenIssue={vi.fn()}
      />
    )

    const expand = await screen.findByRole('button', {
      name: 'Collapse Issue one'
    })
    expect(screen.queryByText('Bound work')).not.toBeInTheDocument()
    fireEvent.click(expand)

    await waitFor(() =>
      expect(loadDetail).toHaveBeenCalledWith('local', summary.id)
    )
    expect(await screen.findByText('Bound work')).toBeInTheDocument()
  })

  it('keeps unassigned Conversations collapsed until the user requests them', async () => {
    const descriptor = authority('local')
    const summary = issue(descriptor)
    const orphan = conversation(descriptor, null)
    const loadUnassigned = vi.fn<
      IssuesDomainDependencies['loadUnassigned']
    >(async () => ({ status: 'ready', value: [orphan] }))
    const store = createIssuesDomainStore({
      readPreferences: async () => DEFAULT_ISSUE_CLIENT_PREFERENCES,
      writePreferences: async (preferences) => preferences,
      loadPartition: async () => ({
        status: 'ready',
        value: snapshot(descriptor, summary)
      }),
      loadDetail: async () => ({ status: 'error', error: 'unused' }),
      loadUnassigned,
      loadRounds: async () => ({ status: 'error', error: 'unused' })
    })

    render(
      <IssueSidebarView
        hostOptions={[host('local', 'This Mac')]}
        store={store}
        eventTarget={new EventTarget()}
        onOpenIssue={vi.fn()}
      />
    )

    const unassigned = await screen.findByRole('button', {
      name: /Unassigned/
    })
    expect(unassigned).toHaveAttribute('aria-expanded', 'false')
    expect(screen.queryByText('Unassigned work')).not.toBeInTheDocument()

    fireEvent.click(unassigned)

    await waitFor(() => expect(loadUnassigned).toHaveBeenCalledWith('local'))
    expect(await screen.findByText('Unassigned work')).toBeInTheDocument()
    expect(unassigned).toHaveAttribute('aria-expanded', 'true')
  })

  it('opens a Conversation through the default precise navigation path', async () => {
    navigationMocks.openIssueConversation.mockReset()
    const descriptor = authority('local')
    const summary = issue(descriptor, 1)
    const bound = conversation(descriptor, summary.id)
    const detail: IssueDetail = {
      authority: descriptor,
      issue: summary,
      directChildren: [],
      directConversations: [bound],
      workspaceSnapshots: [bound.workspaceSnapshot]
    }
    const store = createIssuesDomainStore({
      readPreferences: async () => DEFAULT_ISSUE_CLIENT_PREFERENCES,
      writePreferences: async (preferences) => preferences,
      loadPartition: async () => ({
        status: 'ready',
        value: snapshot(descriptor, summary)
      }),
      loadDetail: async () => ({ status: 'ready', value: detail }),
      loadUnassigned: async () => ({ status: 'ready', value: [] }),
      loadRounds: async () => ({ status: 'error', error: 'unused' })
    })

    render(
      <IssueSidebarView
        hostOptions={[host('local', 'This Mac')]}
        store={store}
        eventTarget={new EventTarget()}
        onOpenIssue={vi.fn()}
      />
    )

    fireEvent.click(
      await screen.findByRole('button', { name: 'Collapse Issue one' })
    )
    fireEvent.click(
      await screen.findByRole('button', { name: /Bound work/ })
    )

    expect(navigationMocks.openIssueConversation).toHaveBeenCalledWith({
      routeExecutionHostId: 'local',
      conversation: bound
    })
  })

  it('renders authoritative Round search matches with stale and completeness markers', async () => {
    const descriptor = authority('local')
    const summary = issue(descriptor)
    const searchResult: IssueSearchResult = {
      authority: descriptor,
      searchRevision: 4,
      indexedSearchRevision: 3,
      isStale: true,
      partial: true,
      groups: [
        {
          issue: {
            id: summary.id,
            title: summary.localTitle ?? 'Issue one',
            typeLabel: summary.typeLabel,
            state: summary.state
          },
          matches: [
            {
              entityKind: 'round',
              entityId: randomUUID(),
              issueId: summary.id,
              title: 'Agent answer',
              preview: 'A quantum-only phrase from the Round body.',
              completeness: 'partial'
            }
          ]
        }
      ],
      nextCursor: null
    }
    const searchIssues = vi.fn(async () => ({
      status: 'ready' as const,
      value: searchResult
    }))
    const store = createIssuesDomainStore({
      readPreferences: async () => DEFAULT_ISSUE_CLIENT_PREFERENCES,
      writePreferences: async (preferences) => preferences,
      loadPartition: async () => ({
        status: 'ready',
        value: snapshot(descriptor, summary)
      }),
      loadDetail: async () => ({ status: 'error', error: 'unused' }),
      loadUnassigned: async () => ({ status: 'ready', value: [] }),
      loadRounds: async () => ({ status: 'error', error: 'unused' }),
      searchIssues
    } as IssuesDomainDependencies)

    render(
      <IssueSidebarView
        hostOptions={[host('local', 'This Mac')]}
        store={store}
        eventTarget={new EventTarget()}
        onOpenIssue={vi.fn()}
      />
    )

    fireEvent.change(await screen.findByLabelText('Search Issues'), {
      target: { value: 'quantum-only' }
    })

    await waitFor(() =>
      expect(searchIssues).toHaveBeenCalledWith('local', 'quantum-only')
    )
    expect(await screen.findByText('Agent answer')).toBeInTheDocument()
    expect(screen.getByText('Round · partial')).toBeInTheDocument()
    expect(screen.getByText('Search index updating')).toBeInTheDocument()
    expect(screen.getByText('Partial search')).toBeInTheDocument()
  })
})
