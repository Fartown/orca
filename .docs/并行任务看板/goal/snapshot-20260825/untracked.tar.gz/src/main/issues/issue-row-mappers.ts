import type {
  AuthorityHostPartitionKey,
  ConversationRecord,
  IssueRecord,
  IssueSource,
  RoundRecord,
  RoundRecordText
} from '../../shared/issues/types'
import type { WorkspaceScope } from '../../shared/folder-workspace-types'
import type { TaskProvider } from '../../shared/task-providers'

export type IssueRow = {
  id: string
  host_partition_key: AuthorityHostPartitionKey
  execution_host_id: IssueRecord['executionHostId']
  source_kind: 'local' | 'external'
  source_provider: TaskProvider | null
  source_scope_key: string | null
  source_external_id: string | null
  source_number: number | null
  source_identifier: string | null
  source_url: string | null
  source_title: string | null
  source_state: string | null
  source_synced_at: number | null
  source_refresh_attempted_at: number | null
  source_refresh_error: string | null
  source_availability: 'available' | 'unavailable' | null
  source_context_json: string | null
  native_parent_json: string | null
  local_title: string | null
  type_label: string | null
  note: string | null
  state: IssueRecord['state']
  parent_id: string | null
  sibling_order: number
  created_at: number
  updated_at: number
  archived_at: number | null
}

export type ConversationRow = {
  id: string
  host_partition_key: AuthorityHostPartitionKey
  execution_host_id: ConversationRecord['executionHostId']
  workspace_kind: WorkspaceScope['type']
  workspace_id: string
  workspace_name_snapshot: string
  workspace_path_snapshot: string
  agent: ConversationRecord['agent']
  title: string | null
  title_source: ConversationRecord['titleSource']
  issue_id: string | null
  state: ConversationRecord['state']
  launch_failure: string | null
  created_at: number
  updated_at: number
}

export type RoundRecordRow = {
  id: string
  conversation_id: string
  kind: RoundRecord['kind']
  state_source: RoundRecord['stateSource']
  occurred_at: number
  dedupe_key: string
  execution_chain_id: string | null
  supersedes_round_id: string | null
  user_input: string | null
  user_input_completeness: RoundRecordText['completeness']
  user_input_storage: RoundRecordText['storage']
  user_input_bytes: number
  user_input_preview: string | null
  user_input_preview_bytes: number
  agent_output: string | null
  output_completeness: RoundRecordText['completeness']
  output_storage: RoundRecordText['storage']
  output_bytes: number
  output_preview: string | null
  output_preview_bytes: number
  pending_question: string | null
  question_completeness: RoundRecordText['completeness']
  question_storage: RoundRecordText['storage']
  question_bytes: number
  question_preview: string | null
  question_preview_bytes: number
  read_at: number | null
  resolved_at: number | null
  resolution: RoundRecord['resolution']
  effective_resolved_at: number | null
  effective_resolution: RoundRecord['effectiveResolution']
  finalized_at: number | null
  body_evicted_at: number | null
  body_deleted_at: number | null
  body_revision: number
  created_at: number
}

export function issueFromRow(row: IssueRow): IssueRecord {
  return {
    id: row.id,
    hostPartitionKey: row.host_partition_key,
    executionHostId: row.execution_host_id,
    source: issueSourceFromRow(row),
    localTitle: row.local_title,
    typeLabel: row.type_label,
    note: row.note,
    state: row.state,
    parentId: row.parent_id,
    siblingOrder: row.sibling_order,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    archivedAt: row.archived_at
  }
}

function issueSourceFromRow(row: IssueRow): IssueSource {
  if (row.source_kind === 'local') {
    return { kind: 'local', number: required(row.source_number, 'source_number') }
  }
  return {
    kind: 'external',
    provider: required(row.source_provider, 'source_provider') as Extract<
      IssueSource,
      { kind: 'external' }
    >['provider'],
    sourceScopeKey: required(row.source_scope_key, 'source_scope_key'),
    externalId: required(row.source_external_id, 'source_external_id'),
    ...(row.source_number === null ? {} : { number: row.source_number }),
    ...(row.source_identifier === null ? {} : { identifier: row.source_identifier }),
    url: required(row.source_url, 'source_url'),
    titleSnapshot: required(row.source_title, 'source_title'),
    ...(row.source_state === null ? {} : { stateSnapshot: row.source_state }),
    syncedAt: required(row.source_synced_at, 'source_synced_at'),
    refreshAttemptedAt: required(
      row.source_refresh_attempted_at,
      'source_refresh_attempted_at'
    ),
    refreshError: row.source_refresh_error,
    availability: required(row.source_availability, 'source_availability'),
    ...(row.source_context_json === null
      ? {}
      : { sourceContext: JSON.parse(row.source_context_json) }),
    nativeParentSnapshot:
      row.native_parent_json === null ? null : JSON.parse(row.native_parent_json)
  }
}

export function conversationFromRow(row: ConversationRow): ConversationRecord {
  return {
    id: row.id,
    hostPartitionKey: row.host_partition_key,
    executionHostId: row.execution_host_id,
    workspaceRef:
      row.workspace_kind === 'worktree'
        ? { type: 'worktree', worktreeId: row.workspace_id }
        : { type: 'folder', folderWorkspaceId: row.workspace_id },
    workspaceSnapshot: {
      name: row.workspace_name_snapshot,
      path: row.workspace_path_snapshot
    },
    agent: row.agent,
    title: row.title,
    titleSource: row.title_source,
    issueId: row.issue_id,
    state: row.state,
    launchFailure: row.launch_failure,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}

export function roundRecordFromRow(row: RoundRecordRow): RoundRecord {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    kind: row.kind,
    stateSource: row.state_source,
    occurredAt: row.occurred_at,
    dedupeKey: row.dedupe_key,
    executionChainId: row.execution_chain_id,
    supersedesRoundId: row.supersedes_round_id,
    userInput: textFromRow(row, 'user_input'),
    agentOutput: textFromRow(row, 'output'),
    pendingQuestion: textFromRow(row, 'question'),
    readAt: row.read_at,
    resolvedAt: row.resolved_at,
    resolution: row.resolution,
    effectiveResolvedAt: row.effective_resolved_at,
    effectiveResolution: row.effective_resolution,
    finalizedAt: row.finalized_at,
    bodyEvictedAt: row.body_evicted_at,
    bodyDeletedAt: row.body_deleted_at,
    bodyRevision: row.body_revision,
    createdAt: row.created_at
  }
}

function textFromRow(
  row: RoundRecordRow,
  prefix: 'user_input' | 'output' | 'question'
): RoundRecordText {
  if (prefix === 'user_input') {
    return {
      text: row.user_input,
      completeness: row.user_input_completeness,
      storage: row.user_input_storage,
      bytes: row.user_input_bytes,
      preview: row.user_input_preview,
      previewBytes: row.user_input_preview_bytes
    }
  }
  if (prefix === 'output') {
    return {
      text: row.agent_output,
      completeness: row.output_completeness,
      storage: row.output_storage,
      bytes: row.output_bytes,
      preview: row.output_preview,
      previewBytes: row.output_preview_bytes
    }
  }
  return {
    text: row.pending_question,
    completeness: row.question_completeness,
    storage: row.question_storage,
    bytes: row.question_bytes,
    preview: row.question_preview,
    previewBytes: row.question_preview_bytes
  }
}

function required<Value>(value: Value | null, column: string): Value {
  if (value === null) {
    throw new Error(`Issue database row is missing ${column}.`)
  }
  return value
}
