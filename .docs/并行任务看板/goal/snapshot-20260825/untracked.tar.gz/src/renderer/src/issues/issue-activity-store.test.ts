import { randomUUID } from 'node:crypto'
import { describe, expect, it, vi } from 'vitest'
import type { IssueActivityEntry } from '../../../shared/issues/types'
import {
  connectIssueActivityEvents,
  createIssueActivityStore
} from './issue-activity-store'

function roundEntry(): IssueActivityEntry {
  const conversationId = randomUUID()
  const roundRecordId = randomUUID()
  return {
    type: 'round',
    id: roundRecordId,
    occurredAt: 100,
    round: {
      id: roundRecordId,
      conversationId,
      kind: 'waiting',
      stateSource: 'hook',
      occurredAt: 100,
      executionChainId: null,
      supersedesRoundId: null,
      userInput: {
        completeness: 'not-captured',
        storage: 'none',
        bytes: 0,
        preview: null,
        previewBytes: 0
      },
      agentOutput: {
        completeness: 'not-captured',
        storage: 'none',
        bytes: 0,
        preview: null,
        previewBytes: 0
      },
      pendingQuestion: {
        completeness: 'preview-complete',
        storage: 'preview',
        bytes: 8,
        preview: 'Approve?',
        previewBytes: 8
      },
      readAt: null,
      resolvedAt: null,
      resolution: null,
      effectiveResolvedAt: null,
      effectiveResolution: null,
      finalizedAt: 100,
      bodyEvictedAt: null,
      bodyDeletedAt: null,
      bodyRevision: 1,
      createdAt: 100
    },
    conversation: {
      id: conversationId,
      hostPartitionKey: 'local',
      executionHostId: 'local',
      workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-a' },
      workspaceSnapshot: { name: 'Folder A', path: '/folder-a' },
      agent: 'codex',
      title: 'Review',
      titleSource: 'user',
      issueId: null,
      state: 'active',
      launchFailure: null,
      createdAt: 1,
      updatedAt: 2
    },
    issue: null
  }
}

describe('issueActivityStore', () => {
  it('deduplicates route loads and patches only readAt for acknowledged rounds', async () => {
    const entry = roundEntry()
    const load = vi.fn().mockResolvedValue({
      status: 'ready',
      page: {
        authority: {
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local'
        },
        snapshotFactsRevision: 1,
        entries: [entry],
        nextCursor: null
      }
    })
    const store = createIssueActivityStore({
      load,
      migrateLegacy: vi.fn()
    })

    await store.getState().setVisibleRoutes(['local', 'local'])
    await store.getState().syncLegacyMigration(['local'], {})
    expect(load).toHaveBeenCalledTimes(1)

    store.getState().patchRoundsRead('local', [entry.id], 200)
    const patched = store.getState().partitionsByRoute.local?.entries[0]
    expect(patched?.type === 'round' ? patched.round.readAt : null).toBe(200)
    expect(patched?.type === 'round' ? patched.round.resolvedAt : undefined).toBeNull()
  })

  it('refreshes only the visible route named by an Issue facts event', async () => {
    const entry = roundEntry()
    const load = vi.fn().mockResolvedValue({
      status: 'ready',
      page: {
        authority: {
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local'
        },
        snapshotFactsRevision: 1,
        entries: [entry],
        nextCursor: null
      }
    })
    const store = createIssueActivityStore({
      load,
      migrateLegacy: vi.fn()
    })
    await store.getState().setVisibleRoutes(['local'])
    load.mockClear()
    const target = new EventTarget()
    const disconnect = connectIssueActivityEvents(store, target)

    target.dispatchEvent(
      new CustomEvent('orca:issue-facts-changed', {
        detail: {
          type: 'issueFactsChanged',
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'runtime:hidden',
          factsRevision: 2,
          treeRevision: 2
        }
      })
    )
    target.dispatchEvent(
      new CustomEvent('orca:issue-facts-changed', {
        detail: {
          type: 'issueFactsChanged',
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local',
          factsRevision: 2,
          treeRevision: 2
        }
      })
    )
    await vi.waitFor(() => expect(load).toHaveBeenCalledTimes(1))

    disconnect()
  })

  it('does not establish authority until the current legacy snapshot is migrated and reloaded', async () => {
    const migratedEntry = roundEntry()
    const load = vi
      .fn()
      .mockResolvedValueOnce({
        status: 'ready',
        page: {
          authority: {
            authorityId: randomUUID(),
            hostPartitionKey: 'local',
            routeExecutionHostId: 'local'
          },
          snapshotFactsRevision: 1,
          entries: [],
          nextCursor: null
        }
      })
      .mockResolvedValueOnce({
        status: 'ready',
        page: {
          authority: {
            authorityId: randomUUID(),
            hostPartitionKey: 'local',
            routeExecutionHostId: 'local'
          },
          snapshotFactsRevision: 2,
          entries: [migratedEntry],
          nextCursor: null
        }
      })
    const migrateLegacy = vi.fn().mockResolvedValue({
      status: 'ready',
      result: {
        authority: {
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local'
        },
        migrated: [
          {
            legacyEventId: 'agent:pane:done:100',
            conversationId:
              migratedEntry.type === 'round'
                ? migratedEntry.conversation.id
                : '',
            roundRecordId: migratedEntry.id
          }
        ],
        unresolvedLegacyEventIds: []
      }
    })
    const store = createIssueActivityStore({ load, migrateLegacy })
    const entry = {
      legacyEventId: 'agent:pane:done:100',
      paneKey: 'pane',
      state: 'done' as const,
      occurredAt: 100,
      acknowledgedAt: null
    }

    await store.getState().setVisibleRoutes(['local'])
    expect(
      store.getState().partitionsByRoute.local?.legacyMigrationStatus
    ).toBe('idle')

    await store
      .getState()
      .syncLegacyMigration(['local'], { local: [entry] })

    expect(migrateLegacy).toHaveBeenCalledOnce()
    expect(load).toHaveBeenCalledTimes(2)
    expect(
      store.getState().partitionsByRoute.local
    ).toMatchObject({
      status: 'ready',
      legacyMigrationStatus: 'complete',
      entries: [migratedEntry]
    })
  })

  it('closes authority again when a new legacy stop appears', async () => {
    const load = vi.fn().mockResolvedValue({
      status: 'ready',
      page: {
        authority: {
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local'
        },
        snapshotFactsRevision: 1,
        entries: [],
        nextCursor: null
      }
    })
    const migration = vi.fn().mockResolvedValue({
      status: 'ready',
      result: {
        authority: {
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local'
        },
        migrated: [],
        unresolvedLegacyEventIds: []
      }
    })
    const store = createIssueActivityStore({
      load,
      migrateLegacy: migration
    })

    await store.getState().setVisibleRoutes(['local'])
    await store.getState().syncLegacyMigration(['local'], {})
    expect(
      store.getState().partitionsByRoute.local?.legacyMigrationStatus
    ).toBe('complete')

    const pendingMigration = new Promise<never>(() => {})
    migration.mockReturnValueOnce(pendingMigration)
    void store.getState().syncLegacyMigration(['local'], {
      local: [
        {
          legacyEventId: 'agent:pane:waiting:200',
          paneKey: 'pane',
          state: 'waiting',
          occurredAt: 200,
          acknowledgedAt: null
        }
      ]
    })
    await vi.waitFor(() =>
      expect(
        store.getState().partitionsByRoute.local
          ?.legacyMigrationStatus
      ).toBe('migrating')
    )
  })

  it('retries a transient migration error without requiring a facts revision change', async () => {
    const load = vi.fn().mockResolvedValue({
      status: 'ready',
      page: {
        authority: {
          authorityId: randomUUID(),
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local'
        },
        snapshotFactsRevision: 1,
        entries: [],
        nextCursor: null
      }
    })
    const migrateLegacy = vi
      .fn()
      .mockResolvedValueOnce({
        status: 'error',
        error: 'temporary network failure'
      })
      .mockResolvedValueOnce({
        status: 'ready',
        result: {
          authority: {
            authorityId: randomUUID(),
            hostPartitionKey: 'local',
            routeExecutionHostId: 'local'
          },
          migrated: [],
          unresolvedLegacyEventIds: []
        }
      })
    const store = createIssueActivityStore({ load, migrateLegacy })
    const snapshot = {
      local: [
        {
          legacyEventId: 'agent:pane:waiting:200',
          paneKey: 'pane',
          state: 'waiting' as const,
          occurredAt: 200,
          acknowledgedAt: null
        }
      ]
    }

    await store.getState().setVisibleRoutes(['local'])
    await store.getState().syncLegacyMigration(['local'], snapshot)
    expect(store.getState().partitionsByRoute.local).toMatchObject({
      legacyMigrationStatus: 'error',
      snapshotFactsRevision: 1,
      legacyMigrationAttemptFactsRevision: 1
    })

    await store.getState().retryLegacyMigration('local')

    expect(migrateLegacy).toHaveBeenCalledTimes(2)
    expect(store.getState().partitionsByRoute.local).toMatchObject({
      legacyMigrationStatus: 'complete',
      legacyMigrationError: null
    })
  })
})
