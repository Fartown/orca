import {
  LOCAL_EXECUTION_HOST_ID,
  normalizeExecutionHostId,
  type ExecutionHostId
} from '../../../src/shared/execution-host'
import type { RpcClient } from '../transport/rpc-client'
import { WORKTREE_PS_FULL_LIMIT } from '../worktree/worktree-catalog-snapshot-client'

export type MobileIssueAuthorityDiscovery = {
  status: 'ready' | 'invalid' | 'unreachable'
  executionHostIds: ExecutionHostId[]
  message?: string
}

type IssueAuthorityClient = Pick<RpcClient, 'sendRequest'>

function executionHostIdsFromWorktrees(worktrees: readonly unknown[]): {
  executionHostIds: ExecutionHostId[]
  invalidHostId: boolean
} {
  const ids = new Set<ExecutionHostId>([LOCAL_EXECUTION_HOST_ID])
  let invalidHostId = false
  for (const value of worktrees) {
    if (!value || typeof value !== 'object') {
      invalidHostId = true
      continue
    }
    const hostId = (value as { hostId?: unknown }).hostId
    if (hostId === undefined || hostId === null) {
      continue
    }
    const normalized = typeof hostId === 'string' ? normalizeExecutionHostId(hostId) : null
    if (normalized) {
      ids.add(normalized)
    } else {
      invalidHostId = true
    }
  }
  return {
    executionHostIds: [
      LOCAL_EXECUTION_HOST_ID,
      ...[...ids].filter((id) => id !== LOCAL_EXECUTION_HOST_ID).sort()
    ],
    invalidHostId
  }
}

export async function loadMobileIssueAuthorities(
  client: IssueAuthorityClient
): Promise<MobileIssueAuthorityDiscovery> {
  try {
    const response = await client.sendRequest('worktree.ps', {
      limit: WORKTREE_PS_FULL_LIMIT
    })
    if (!response.ok) {
      return {
        status: 'unreachable',
        executionHostIds: [LOCAL_EXECUTION_HOST_ID],
        message: response.error.message
      }
    }
    const worktrees = (response.result as { worktrees?: unknown }).worktrees
    if (!Array.isArray(worktrees)) {
      return {
        status: 'invalid',
        executionHostIds: [LOCAL_EXECUTION_HOST_ID],
        message: 'The host returned an invalid Workspace catalog.'
      }
    }
    const discovered = executionHostIdsFromWorktrees(worktrees)
    return {
      status: discovered.invalidHostId ? 'invalid' : 'ready',
      executionHostIds: discovered.executionHostIds,
      ...(discovered.invalidHostId
        ? { message: 'Some Workspace authority routes were invalid.' }
        : {})
    }
  } catch (error) {
    return {
      status: 'unreachable',
      executionHostIds: [LOCAL_EXECUTION_HOST_ID],
      message: error instanceof Error ? error.message : 'The host is unreachable.'
    }
  }
}
