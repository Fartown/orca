import type { AuthorityHostPartitionKey } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { bumpIssueHostRevisions } from './issue-host-state'

export function markRoundRecordSearchableChange(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey,
  roundIds: readonly string[],
  now: number
): void {
  if (roundIds.length === 0) {
    return
  }
  const revisions = bumpIssueHostRevisions(
    database,
    hostPartitionKey,
    { tree: false, searchable: true },
    now
  )
  const enqueue = database.prepare(
    `INSERT INTO issue_search_rebuild_queue (
       host_partition_key, entity_kind, entity_id, requested_revision
     ) VALUES (?, 'round', ?, ?)
     ON CONFLICT(host_partition_key, entity_kind, entity_id)
     DO UPDATE SET requested_revision = MAX(
       requested_revision,
       excluded.requested_revision
     )`
  )
  for (const roundId of roundIds) {
    enqueue.run(hostPartitionKey, roundId, revisions.searchRevision)
  }
}
