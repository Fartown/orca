import { createStore, type StoreApi } from 'zustand/vanilla'
import { afterEach, describe, expect, it } from 'vitest'
import type { AppState } from '../store/types'
import {
  createWorktreeNavHistorySlice,
  setWorktreeNavViewActivator,
  type WorktreeNavHistoryIssueDetailEntry,
  type WorktreeNavHistorySlice,
  type WorktreeNavHistoryViewEntry
} from '../store/slices/worktree-nav-history'

type HistoryState = WorktreeNavHistorySlice &
  Pick<AppState, 'folderWorkspaces' | 'worktreesByRepo'>

function createHistoryStore(): StoreApi<HistoryState> {
  return createStore<HistoryState>()((set, get, api) => ({
    folderWorkspaces: [],
    worktreesByRepo: {},
    ...createWorktreeNavHistorySlice(
      set as Parameters<typeof createWorktreeNavHistorySlice>[0],
      get as Parameters<typeof createWorktreeNavHistorySlice>[1],
      api as Parameters<typeof createWorktreeNavHistorySlice>[2]
    )
  }))
}

function issueEntry(
  authorityId: string,
  hostPartitionKey: string,
  routeExecutionHostId = 'local'
): WorktreeNavHistoryIssueDetailEntry {
  return {
    kind: 'issue-detail',
    authorityId,
    hostPartitionKey,
    routeExecutionHostId,
    issueId: '11111111-1111-4111-8111-111111111111'
  } as WorktreeNavHistoryIssueDetailEntry
}

describe('Issue detail navigation history', () => {
  afterEach(() => {
    setWorktreeNavViewActivator(null)
  })

  it('dedupes route aliases for one authority but separates the same Issue id across authorities', () => {
    const store = createHistoryStore()
    const local = issueEntry('authority-a', 'partition-a')
    const routeAlias = issueEntry('authority-a', 'partition-a', 'runtime:relay-a')
    const otherAuthority = issueEntry('authority-b', 'partition-b')

    store.getState().recordViewVisit(local)
    store.getState().recordViewVisit(routeAlias)
    store.getState().recordViewVisit(otherAuthority)

    expect(store.getState().worktreeNavHistory).toEqual([local, otherAuthority])
    expect(store.getState().worktreeNavHistoryIndex).toBe(1)
  })

  it('keeps deleted Issue detail entries replayable so the page can show its placeholder', () => {
    const store = createHistoryStore()
    const first = issueEntry('authority-a', 'partition-a')
    const second = {
      ...issueEntry('authority-a', 'partition-a'),
      issueId: '22222222-2222-4222-8222-222222222222'
    } as WorktreeNavHistoryIssueDetailEntry
    const replayed: WorktreeNavHistoryViewEntry[] = []
    setWorktreeNavViewActivator((entry) => replayed.push(entry))

    store.getState().recordViewVisit(first)
    store.getState().recordViewVisit(second)
    store.getState().goBackWorktree()

    expect(replayed).toEqual([first])
    expect(store.getState().worktreeNavHistoryIndex).toBe(0)
  })
})
