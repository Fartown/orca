import {
  parseExecutionHostId,
  type ExecutionHostId
} from '../../../shared/execution-host'
import {
  IssueDashboardProjectionSchema,
  IssuesProjectDashboardPanesParams
} from '../../../shared/issues/schemas'
import type {
  IssueAuthorityDescriptor,
  IssueDashboardPaneProjection,
  IssueDashboardProjection
} from '../../../shared/issues/types'
import { ORCA_ISSUES_RUNTIME_CAPABILITY } from '../../../shared/protocol-version'
import {
  callRuntimeRpc,
  runtimeEnvironmentSupportsCapability,
  type RuntimeClientTarget
} from '../runtime/runtime-rpc-client'

const DASHBOARD_PANE_PAGE_SIZE = 500

export type IssueDashboardLoadResult =
  | { status: 'ready'; projection: IssueDashboardProjection }
  | { status: 'unsupported' }
  | { status: 'error'; error: string }

export type IssueDashboardClientDependencies = {
  supportsCapability: (environmentId: string) => Promise<boolean>
  callRpc: (
    routeExecutionHostId: ExecutionHostId,
    method: string,
    params: unknown
  ) => Promise<unknown>
}

export async function loadIssueDashboardProjection(
  routeExecutionHostId: ExecutionHostId,
  paneKeys: readonly string[],
  dependencies: IssueDashboardClientDependencies = defaultDependencies
): Promise<IssueDashboardLoadResult> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    return { status: 'error', error: 'Invalid Issue host route.' }
  }
  try {
    if (
      route.kind === 'runtime' &&
      !(await dependencies.supportsCapability(route.environmentId))
    ) {
      return { status: 'unsupported' }
    }
    const uniquePaneKeys = [...new Set(paneKeys)]
    let authority: IssueAuthorityDescriptor | null = null
    let snapshotFactsRevision: number | null = null
    const panes: IssueDashboardPaneProjection[] = []
    for (
      let offset = 0;
      offset < uniquePaneKeys.length;
      offset += DASHBOARD_PANE_PAGE_SIZE
    ) {
      const params = IssuesProjectDashboardPanesParams.parse({
        executionHostId: route.id,
        paneKeys: uniquePaneKeys.slice(offset, offset + DASHBOARD_PANE_PAGE_SIZE)
      })
      const page = IssueDashboardProjectionSchema.parse(
        await dependencies.callRpc(route.id, 'issues.projectDashboardPanes', params)
      )
      assertProjectionIdentity(
        page,
        route.id,
        authority,
        snapshotFactsRevision
      )
      authority ??= page.authority
      snapshotFactsRevision ??= page.snapshotFactsRevision
      panes.push(...page.panes)
    }
    if (!authority || snapshotFactsRevision === null) {
      const page = IssueDashboardProjectionSchema.parse(
        await dependencies.callRpc(route.id, 'issues.projectDashboardPanes', {
          executionHostId: route.id,
          paneKeys: []
        })
      )
      assertProjectionIdentity(page, route.id, null, null)
      authority = page.authority
      snapshotFactsRevision = page.snapshotFactsRevision
    }
    return {
      status: 'ready',
      projection: {
        authority,
        snapshotFactsRevision,
        panes
      }
    }
  } catch (error) {
    return {
      status: 'error',
      error:
        error instanceof Error && error.message.trim()
          ? error.message
          : 'Unable to load Issue dashboard projection.'
    }
  }
}

function assertProjectionIdentity(
  projection: IssueDashboardProjection,
  routeExecutionHostId: ExecutionHostId,
  authority: IssueAuthorityDescriptor | null,
  snapshotFactsRevision: number | null
): void {
  if (projection.authority.routeExecutionHostId !== routeExecutionHostId) {
    throw new Error('Issue dashboard response was stamped for another route.')
  }
  if (
    authority &&
    (projection.authority.authorityId !== authority.authorityId ||
      projection.authority.hostPartitionKey !== authority.hostPartitionKey)
  ) {
    throw new Error('Issue dashboard authority changed between pages.')
  }
  if (
    snapshotFactsRevision !== null &&
    projection.snapshotFactsRevision !== snapshotFactsRevision
  ) {
    throw new Error('Issue dashboard facts changed between pages.')
  }
}

function runtimeTargetForRoute(
  routeExecutionHostId: ExecutionHostId
): RuntimeClientTarget {
  const route = parseExecutionHostId(routeExecutionHostId)
  return route?.kind === 'runtime'
    ? { kind: 'environment', environmentId: route.environmentId }
    : { kind: 'local' }
}

const defaultDependencies: IssueDashboardClientDependencies = {
  supportsCapability: (environmentId) =>
    runtimeEnvironmentSupportsCapability(
      environmentId,
      ORCA_ISSUES_RUNTIME_CAPABILITY
    ),
  callRpc: (routeExecutionHostId, method, params) =>
    callRuntimeRpc(runtimeTargetForRoute(routeExecutionHostId), method, params, {
      reuseRecentCompatibilityFailure: true
    })
}
