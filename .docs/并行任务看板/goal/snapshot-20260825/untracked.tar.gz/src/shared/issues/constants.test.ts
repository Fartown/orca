import { describe, expect, it } from 'vitest'
import {
  CONVERSATION_STATES,
  EFFECTIVE_ROUND_RESOLUTIONS,
  ISSUE_MAX_DEPTH,
  ISSUE_STATES,
  ORCA_ISSUES_RUNTIME_CAPABILITY,
  ROUND_RECORD_KINDS
} from './constants'
import type { ConversationRecord, IssueRecord, RoundRecord } from './types'

describe('issue shared contracts', () => {
  it('exports the stable states and capability used by main', () => {
    expect(ISSUE_STATES).toEqual(['active', 'archived'])
    expect(CONVERSATION_STATES).toEqual(['active', 'closed'])
    expect(ROUND_RECORD_KINDS).toEqual(['completion', 'waiting'])
    expect(EFFECTIVE_ROUND_RESOLUTIONS).toContain('superseded')
    expect(ISSUE_MAX_DEPTH).toBe(3)
    expect(ORCA_ISSUES_RUNTIME_CAPABILITY).toBe('orca-issues.v1')
  })

  it('keeps Issue, Conversation, and RoundRecord as compatible exported contracts', () => {
    const issueId: IssueRecord['id'] = 'issue-1'
    const conversationIssueId: ConversationRecord['issueId'] = issueId
    const roundConversationId: RoundRecord['conversationId'] = 'conversation-1'

    expect({ issueId, conversationIssueId, roundConversationId }).toEqual({
      issueId: 'issue-1',
      conversationIssueId: 'issue-1',
      roundConversationId: 'conversation-1'
    })
  })
})
