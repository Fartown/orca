import type {
  IssueDigestRecord,
  IssueDigestSections
} from '../../shared/issues/digest-types'
import type { IssueMutationIdentity } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import {
  issueDisplayTitle,
  issueEventRef,
  type IssueEventRepository
} from './issue-event-repository'
import { requireIssueDigest } from './issue-digest-record'
import { bumpIssueHostRevisions } from './issue-host-state'
import { executeIssueMutation } from './issue-mutation-receipt'
import { requireIssueRecord } from './issue-record-queries'
import { IssueRepositoryError } from './issue-repository-error'

export function updateIssueDigestDraft(
  database: IssueDatabase,
  params: {
    identity: IssueMutationIdentity
    digestId: string
    expectedRevision: number
    patch: Partial<IssueDigestSections>
  }
): IssueDigestRecord {
  return executeIssueMutation({
    database,
    identity: params.identity,
    method: 'issues.updateDigestDraft',
    payload: {
      digestId: params.digestId,
      expectedRevision: params.expectedRevision,
      patch: params.patch
    },
    operation: () => {
      const digest = requireIssueDigest(database, params.digestId)
      requireDraftRevision(digest, params.expectedRevision, 'edited')
      const next = { ...digest, ...params.patch }
      const now = Date.now()
      const update = database
        .prepare(
          `UPDATE issue_digests
           SET problem = ?, conclusion = ?, key_artifacts = ?,
               open_issues = ?, next_steps = ?,
               revision = revision + 1, updated_at = ?
           WHERE id = ? AND status = 'draft' AND revision = ?`
        )
        .run(
          next.problem,
          next.conclusion,
          next.keyArtifacts,
          next.openIssues,
          next.nextSteps,
          now,
          digest.id,
          params.expectedRevision
        )
      if (update.changes !== 1) {
        throw staleRevisionError(digest.id, 'edited')
      }
      const issue = requireIssueRecord(database, digest.issueId)
      bumpIssueHostRevisions(
        database,
        issue.hostPartitionKey,
        { tree: false, searchable: true },
        now
      )
      return requireIssueDigest(database, digest.id)
    }
  })
}

export function confirmIssueDigest(
  database: IssueDatabase,
  events: IssueEventRepository,
  params: {
    identity: IssueMutationIdentity
    digestId: string
    expectedRevision: number
    stale: boolean
    currentInputFingerprint: string
  }
): IssueDigestRecord {
  return executeIssueMutation({
    database,
    identity: params.identity,
    method: 'issues.confirmDigest',
    payload: {
      digestId: params.digestId,
      expectedRevision: params.expectedRevision,
      stale: params.stale,
      currentInputFingerprint: params.currentInputFingerprint
    },
    operation: () => {
      const digest = requireIssueDigest(database, params.digestId)
      requireDraftRevision(digest, params.expectedRevision, 'confirmed')
      const issue = requireIssueRecord(database, digest.issueId)
      const now = Date.now()
      const update = database
        .prepare(
          `UPDATE issue_digests
           SET status = 'confirmed', confirmed_at = ?, updated_at = ?
           WHERE id = ? AND status = 'draft' AND revision = ?`
        )
        .run(now, now, digest.id, params.expectedRevision)
      if (update.changes !== 1) {
        throw staleRevisionError(digest.id, 'confirmed')
      }
      const revisions = bumpIssueHostRevisions(
        database,
        issue.hostPartitionKey,
        { tree: false, searchable: true },
        now
      )
      events.appendWithinTransaction({
        hostPartitionKey: issue.hostPartitionKey,
        kind: 'digest-confirmed',
        issueRefs: [issueEventRef(issue, 'digest')],
        payload: {
          digestId: digest.id,
          digestVersion: digest.version,
          inputFingerprint: digest.inputFingerprint,
          currentInputFingerprint: params.currentInputFingerprint,
          stale: params.stale,
          titleSnapshot: issueDisplayTitle(issue)
        },
        occurredAt: now,
        factsRevision: revisions.factsRevision,
        dedupeKey: `digest-confirmed:${digest.id}`
      })
      return requireIssueDigest(database, digest.id)
    }
  })
}

export function checkAndConfirmIssueDigest(
  database: IssueDatabase,
  events: IssueEventRepository,
  params: {
    identity: IssueMutationIdentity
    digestId: string
    expectedRevision: number
    inputFingerprint: string
    confirmStaleAgainstFingerprint?: string
    resolveCurrentInputFingerprint: () => string
  }
):
  | {
      status: 'confirmed'
      digest: IssueDigestRecord
      currentInputFingerprint: string
      stale: boolean
    }
  | {
      status: 'stale'
      digest: IssueDigestRecord
      currentInputFingerprint: string
      changeSummary: string
    } {
  return executeIssueMutation({
    database,
    identity: params.identity,
    method: 'issues.confirmDigest',
    payload: {
      digestId: params.digestId,
      expectedRevision: params.expectedRevision,
      inputFingerprint: params.inputFingerprint,
      confirmStaleAgainstFingerprint:
        params.confirmStaleAgainstFingerprint ?? null
    },
    operation: () => {
      const digest = requireIssueDigest(database, params.digestId)
      requireDraftRevision(digest, params.expectedRevision, 'confirmed')
      if (params.inputFingerprint !== digest.inputFingerprint) {
        throw new IssueRepositoryError(
          'digest_input_stale',
          `Issue Digest ${digest.id} does not match the supplied input fingerprint.`,
          {
            digestInputFingerprint: digest.inputFingerprint,
            suppliedInputFingerprint: params.inputFingerprint
          }
        )
      }
      const currentInputFingerprint = params.resolveCurrentInputFingerprint()
      const stale = currentInputFingerprint !== digest.inputFingerprint
      if (
        stale &&
        params.confirmStaleAgainstFingerprint !== currentInputFingerprint
      ) {
        return {
          status: 'stale' as const,
          digest,
          currentInputFingerprint,
          changeSummary:
            'Digest inputs changed after this draft was generated. Review the latest rounds and direct child Digests before confirming.'
        }
      }
      return {
        status: 'confirmed' as const,
        digest: confirmDraftWithinTransaction(
          database,
          events,
          digest,
          currentInputFingerprint,
          stale
        ),
        currentInputFingerprint,
        stale
      }
    }
  })
}

function confirmDraftWithinTransaction(
  database: IssueDatabase,
  events: IssueEventRepository,
  digest: IssueDigestRecord,
  currentInputFingerprint: string,
  stale: boolean
): IssueDigestRecord {
  const issue = requireIssueRecord(database, digest.issueId)
  const now = Date.now()
  const update = database
    .prepare(
      `UPDATE issue_digests
       SET status = 'confirmed', confirmed_at = ?, updated_at = ?
       WHERE id = ? AND status = 'draft' AND revision = ?`
    )
    .run(now, now, digest.id, digest.revision)
  if (update.changes !== 1) {
    throw staleRevisionError(digest.id, 'confirmed')
  }
  const revisions = bumpIssueHostRevisions(
    database,
    issue.hostPartitionKey,
    { tree: false, searchable: true },
    now
  )
  events.appendWithinTransaction({
    hostPartitionKey: issue.hostPartitionKey,
    kind: 'digest-confirmed',
    issueRefs: [issueEventRef(issue, 'digest')],
    payload: {
      digestId: digest.id,
      digestVersion: digest.version,
      inputFingerprint: digest.inputFingerprint,
      currentInputFingerprint,
      stale,
      titleSnapshot: issueDisplayTitle(issue)
    },
    occurredAt: now,
    factsRevision: revisions.factsRevision,
    dedupeKey: `digest-confirmed:${digest.id}`
  })
  return requireIssueDigest(database, digest.id)
}

function requireDraftRevision(
  digest: IssueDigestRecord,
  expectedRevision: number,
  action: string
): void {
  if (digest.status !== 'draft') {
    throw new IssueRepositoryError(
      'digest_status_invalid',
      `Issue Digest ${digest.id} is not an editable draft.`
    )
  }
  if (digest.revision !== expectedRevision) {
    throw staleRevisionError(digest.id, action, digest.revision)
  }
}

function staleRevisionError(
  digestId: string,
  action: string,
  currentRevision?: number
): IssueRepositoryError {
  return new IssueRepositoryError(
    'digest_revision_stale',
    `Issue Digest ${digestId} changed before it was ${action}.`,
    currentRevision === undefined ? undefined : { currentRevision }
  )
}
