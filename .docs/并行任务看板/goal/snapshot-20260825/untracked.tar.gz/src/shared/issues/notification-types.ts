import type { ExecutionHostId } from '../execution-host'

export type IssueNotificationNavigationTarget = {
  executionHostId: ExecutionHostId
  conversationId?: string
  issueId?: string
  roundRecordId?: string
  worktreeId?: string
  paneKey?: string
}
