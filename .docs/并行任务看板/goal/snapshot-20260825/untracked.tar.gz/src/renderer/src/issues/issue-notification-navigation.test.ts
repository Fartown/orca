import { describe, expect, it, vi } from 'vitest'
import type {
  ConversationSummary,
  IssueDetail,
  RoundRecordPage
} from '../../../shared/issues/types'
import {
  openIssueNotification,
  type IssueNotificationNavigationDependencies
} from './issue-notification-navigation'

const conversationId = '33333333-3333-4333-8333-333333333333'
const issueId = '22222222-2222-4222-8222-222222222222'
const roundRecordId = '44444444-4444-4444-8444-444444444444'

function conversation(
  overrides: Partial<ConversationSummary> = {}
): ConversationSummary {
  return {
    id: conversationId,
    hostPartitionKey: 'ssh:docs',
    executionHostId: 'ssh:docs',
    workspaceRef: { type: 'worktree', worktreeId: 'repo::wt1' },
    workspaceSnapshot: { name: 'wt1', path: '/repo/wt1' },
    agent: 'codex',
    title: 'Fix notifications',
    titleSource: 'user',
    issueId,
    state: 'active',
    launchFailure: null,
    createdAt: 1,
    updatedAt: 1,
    unresolvedRoundCount: 1,
    latestRound: null,
    navigation: {
      paneKey: 'tab-1:11111111-1111-4111-8111-111111111111',
      providerSession: null,
      resumeLocator: null
    },
    ...overrides
  }
}

function detail(
  openedIssueId: string = issueId,
  directConversations: ConversationSummary[] = [conversation()]
): IssueDetail {
  return {
    authority: {
      authorityId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
      hostPartitionKey: 'ssh:docs',
      routeExecutionHostId: 'ssh:docs'
    },
    issue: {
      id: openedIssueId,
      hostPartitionKey: 'ssh:docs',
      executionHostId: 'ssh:docs',
      source: { kind: 'local', number: 1 },
      localTitle: 'Notification routing',
      typeLabel: null,
      note: null,
      state: 'active',
      parentId: null,
      siblingOrder: 0,
      createdAt: 1,
      updatedAt: 1,
      archivedAt: null,
      ownUnresolvedCount: 1,
      descendantAttentionCount: 0,
      directConversationCount: 1,
      activeConversationCount: 1
    },
    directChildren: [],
    directConversations,
    workspaceSnapshots: []
  }
}

function rounds(ids: string[]): RoundRecordPage {
  return {
    authority: detail().authority,
    snapshotFactsRevision: 1,
    rounds: ids.map((id) => ({
      id,
      conversationId,
      kind: 'waiting',
      stateSource: 'hook',
      occurredAt: 10,
      executionChainId: null,
      supersedesRoundId: null,
      userInput: {
        completeness: 'not-captured',
        storage: 'none',
        bytes: 0,
        preview: null,
        previewBytes: 0
      },
      agentOutput: {
        completeness: 'not-captured',
        storage: 'none',
        bytes: 0,
        preview: null,
        previewBytes: 0
      },
      pendingQuestion: {
        completeness: 'preview-complete',
        storage: 'preview',
        bytes: 8,
        preview: 'Approve?',
        previewBytes: 8
      },
      readAt: null,
      resolvedAt: null,
      resolution: null,
      effectiveResolvedAt: null,
      effectiveResolution: null,
      finalizedAt: null,
      bodyEvictedAt: null,
      bodyDeletedAt: null,
      bodyRevision: 1,
      createdAt: 10
    })),
    nextCursor: null
  }
}

function harness(
  overrides: Partial<IssueNotificationNavigationDependencies> = {}
): {
  dependencies: IssueNotificationNavigationDependencies
  destination: { value: string | null }
} {
  const destination = { value: null as string | null }
  return {
    destination,
    dependencies: {
      loadConversation: vi.fn().mockResolvedValue({
        status: 'ready',
        value: conversation()
      }),
      loadIssueDetail: vi.fn().mockResolvedValue({
        status: 'ready',
        value: detail()
      }),
      loadIssueRounds: vi.fn().mockResolvedValue({
        status: 'ready',
        value: rounds([roundRecordId])
      }),
      openIssue: (_authority, openedIssueId) => {
        destination.value = `round:${openedIssueId}`
      },
      revealRound: (openedRoundId) => {
        destination.value += `:${openedRoundId}`
      },
      openConversation: async (_route, openedConversation) => {
        destination.value = `conversation:${openedConversation.id}`
        return { status: 'focused', tabId: 'tab-1', leafId: 'leaf-1' }
      },
      openWorkspace: () => {
        destination.value = 'workspace'
        return true
      },
      ...overrides
    }
  }
}

describe('openIssueNotification', () => {
  it('opens and reveals the exact Round Record when it still belongs to the Issue', async () => {
    const { dependencies, destination } = harness()

    const result = await openIssueNotification(
      {
        executionHostId: 'ssh:docs',
        issueId,
        conversationId,
        roundRecordId,
        worktreeId: 'repo::wt1'
      },
      dependencies
    )

    expect(result).toEqual({ status: 'round', issueId, roundRecordId })
    expect(destination.value).toBe(`round:${issueId}:${roundRecordId}`)
  })

  it('falls back to the Conversation when the exact Round is unavailable', async () => {
    const { dependencies, destination } = harness({
      loadIssueRounds: vi.fn().mockResolvedValue({
        status: 'ready',
        value: rounds([])
      })
    })

    const result = await openIssueNotification(
      {
        executionHostId: 'ssh:docs',
        issueId,
        conversationId,
        roundRecordId,
        worktreeId: 'repo::wt1'
      },
      dependencies
    )

    expect(result).toEqual({ status: 'conversation', conversationId })
    expect(destination.value).toBe(`conversation:${conversationId}`)
  })

  it('resolves an unassigned Conversation without requiring an Issue', async () => {
    const unassigned = { ...conversation(), issueId: null }
    const { dependencies, destination } = harness({
      loadConversation: vi.fn().mockResolvedValue({
        status: 'ready',
        value: unassigned
      })
    })

    const result = await openIssueNotification(
      {
        executionHostId: 'ssh:docs',
        conversationId,
        worktreeId: 'repo::wt1'
      },
      dependencies
    )

    expect(result).toEqual({ status: 'conversation', conversationId })
    expect(destination.value).toBe(`conversation:${conversationId}`)
  })

  it('uses the current Conversation binding instead of the stale notification Issue', async () => {
    const reboundIssueId = '66666666-6666-4666-8666-666666666666'
    const rebound = conversation({ issueId: reboundIssueId })
    const { dependencies, destination } = harness({
      loadConversation: vi.fn().mockResolvedValue({
        status: 'ready',
        value: rebound
      }),
      loadIssueDetail: vi.fn().mockResolvedValue({
        status: 'ready',
        value: detail(reboundIssueId, [rebound])
      })
    })

    const result = await openIssueNotification(
      {
        executionHostId: 'ssh:docs',
        issueId,
        conversationId,
        roundRecordId,
        worktreeId: 'repo::wt1'
      },
      dependencies
    )

    expect(result).toEqual({
      status: 'round',
      issueId: reboundIssueId,
      roundRecordId
    })
    expect(destination.value).toBe(`round:${reboundIssueId}:${roundRecordId}`)
  })

  it('falls back to the Workspace when Conversation navigation is unavailable', async () => {
    const { dependencies, destination } = harness({
      openConversation: vi.fn().mockResolvedValue({
        status: 'unavailable',
        reason: 'pane-unavailable'
      })
    })

    const result = await openIssueNotification(
      {
        executionHostId: 'ssh:docs',
        issueId,
        conversationId,
        roundRecordId: '55555555-5555-4555-8555-555555555555',
        worktreeId: 'repo::wt1'
      },
      dependencies
    )

    expect(result).toEqual({ status: 'workspace' })
    expect(destination.value).toBe('workspace')
  })
})
