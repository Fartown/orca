// @vitest-environment happy-dom

import { describe, expect, it, vi } from 'vitest'
import type { IssueFactsChangedEvent } from '../../../shared/issues/types'
import {
  ISSUE_FACTS_CHANGED_EVENT,
  type IssueFactsChangedEventDetail
} from './issue-facts-changed-event'
import { subscribeLocalIssueFacts } from './local-issue-facts-subscription'

describe('subscribeLocalIssueFacts', () => {
  it('maps local and SSH authority changes onto the shared renderer event', () => {
    const listeners: Array<(event: IssueFactsChangedEvent) => void> = []
    const unsubscribe = vi.fn()
    const observed: IssueFactsChangedEventDetail[] = []
    window.addEventListener(ISSUE_FACTS_CHANGED_EVENT, (event) => {
      observed.push(
        (event as CustomEvent<IssueFactsChangedEventDetail>).detail
      )
    })

    const stop = subscribeLocalIssueFacts({
      onFactsChanged: (callback) => {
        listeners.push(callback)
        return unsubscribe
      }
    })
    const base = {
      type: 'issueFactsChanged' as const,
      authorityId: 'authority-local',
      factsRevision: 2,
      treeRevision: 1
    }

    listeners[0]?.({ ...base, hostPartitionKey: 'local' })
    listeners[0]?.({
      ...base,
      authorityId: 'authority-ssh',
      hostPartitionKey: 'ssh:builder'
    })

    expect(observed).toEqual([
      {
        ...base,
        hostPartitionKey: 'local',
        routeExecutionHostId: 'local'
      },
      {
        ...base,
        authorityId: 'authority-ssh',
        hostPartitionKey: 'ssh:builder',
        routeExecutionHostId: 'ssh:builder'
      }
    ])

    stop()
    expect(unsubscribe).toHaveBeenCalledTimes(1)
  })

  it('remains compatible with a preload that predates facts subscriptions', () => {
    expect(() => subscribeLocalIssueFacts({})()).not.toThrow()
    expect(() => subscribeLocalIssueFacts(undefined)()).not.toThrow()
  })
})
