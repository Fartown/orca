import { statSync } from 'node:fs'
import { afterEach, describe, expect, it } from 'vitest'
import SyncDatabase from '../sqlite/sync-database'
import {
  getIssueDatabasePath,
  IssueDatabase,
  type OpenIssueDatabaseOptions
} from './issue-database'
import {
  createIssueTestUserDataPath,
  issueFileDatabaseTestsAvailable,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { ISSUE_DATABASE_SCHEMA_VERSION, migrateIssueDatabase } from './issue-database-migrations'
import { ISSUE_DATABASE_CORE_SCHEMA } from './issue-database-core-schema'
import { ISSUE_DATABASE_ROUND_SCHEMA } from './issue-database-round-schema'
import { ISSUE_DATABASE_SUPPORT_SCHEMA } from './issue-database-support-schema'

const databases: IssueDatabase[] = []

function createUserDataPath(): string {
  return createIssueTestUserDataPath('orca-issues-db')
}

function openDatabase(
  profileId: string,
  userDataPath: string,
  options: Pick<OpenIssueDatabaseOptions, 'migrationHooks'> = {}
): IssueDatabase {
  const database = openIssueTestDatabase({ profileId, userDataPath, ...options })
  databases.push(database)
  return database
}

afterEach(() => {
  for (const database of databases.splice(0)) {
    database.close()
  }
  removeIssueTestDirectories()
})

describe('IssueDatabase', () => {
  it('rolls back schema and user_version when migration fails before the bump', () => {
    const raw = new SyncDatabase(':memory:')

    expect(() =>
      migrateIssueDatabase(raw, {
        beforeVersionBump: () => {
          throw new Error('injected migration failure')
        }
      })
    ).toThrow('injected migration failure')

    expect(raw.pragma('user_version', { simple: true })).toBe(0)
    expect(
      raw
        .prepare(
          `SELECT name FROM sqlite_master
           WHERE type = 'table' AND name IN ('issues', 'conversations', 'round_records')`
        )
        .all()
    ).toEqual([])

    migrateIssueDatabase(raw)
    expect(raw.pragma('user_version', { simple: true })).toBe(ISSUE_DATABASE_SCHEMA_VERSION)
    expect(
      raw
        .prepare(
          `SELECT name FROM sqlite_master
           WHERE type = 'table' AND name IN ('issues', 'conversations', 'round_records')
           ORDER BY name`
        )
        .all()
    ).toEqual([{ name: 'conversations' }, { name: 'issues' }, { name: 'round_records' }])
    raw.close()
  })

  it('rolls back a v1 to v2 migration without exposing partial schema', () => {
    const raw = createVersionOneDatabase()

    expect(() =>
      migrateIssueDatabase(raw, {
        beforeVersionBump: () => {
          throw new Error('v2 migration failure')
        }
      })
    ).toThrow('v2 migration failure')

    expect(raw.pragma('user_version', { simple: true })).toBe(1)
    expect(
      raw
        .prepare(`SELECT name FROM pragma_table_info('conversations') WHERE name = 'launch_failure'`)
        .all()
    ).toEqual([])
    expect(
      raw
        .prepare(
          `SELECT name FROM sqlite_master
           WHERE type = 'index' AND name LIKE 'idx_launch_claim_%'`
        )
        .all()
    ).toEqual([])

    migrateIssueDatabase(raw)
    expect(raw.pragma('user_version', { simple: true })).toBe(ISSUE_DATABASE_SCHEMA_VERSION)
    expect(
      raw
        .prepare(`SELECT name FROM pragma_table_info('conversations') WHERE name = 'launch_failure'`)
        .all()
    ).toEqual([{ name: 'launch_failure' }])
    raw.close()
  })

  it('migrates v2 provider refs atomically and leaves a conflicting v2 database usable', () => {
    const success = createVersionTwoDatabase()
    success.exec(`
      INSERT INTO round_refs (round_id, ref_kind, value, reachable)
      VALUES
        ('round-1', 'provider-turn', 'turn-1', 1),
        ('round-2', 'provider-turn', 'turn-2', 1);
    `)

    migrateIssueDatabase(success)

    expect(success.pragma('user_version', { simple: true })).toBe(
      ISSUE_DATABASE_SCHEMA_VERSION
    )
    expect(
      success
        .prepare(
          `SELECT name FROM sqlite_master
           WHERE type = 'index' AND name = 'idx_round_refs_provider_turn'`
        )
        .get()
    ).toEqual({ name: 'idx_round_refs_provider_turn' })
    expect(() =>
      success
        .prepare(
          `INSERT INTO round_refs (round_id, ref_kind, value, reachable)
           VALUES ('round-3', 'provider-turn', 'turn-1', 1)`
        )
        .run()
    ).toThrow()
    success.close()

    const conflicting = createVersionTwoDatabase()
    conflicting.exec(`
      INSERT INTO round_refs (round_id, ref_kind, value, reachable)
      VALUES
        ('round-1', 'provider-turn', 'duplicate-turn', 1),
        ('round-2', 'provider-turn', 'duplicate-turn', 1);
    `)

    expect(() => migrateIssueDatabase(conflicting)).toThrow()
    expect(conflicting.pragma('user_version', { simple: true })).toBe(2)
    expect(
      conflicting
        .prepare(
          `SELECT name FROM sqlite_master
           WHERE type = 'index' AND name = 'idx_round_refs_provider_turn'`
        )
        .get()
    ).toBeUndefined()
    expect(
      conflicting
        .prepare(
          `SELECT round_id, value FROM round_refs
           WHERE ref_kind = 'provider-turn'
           ORDER BY round_id`
        )
        .all()
    ).toEqual([
      { round_id: 'round-1', value: 'duplicate-turn' },
      { round_id: 'round-2', value: 'duplicate-turn' }
    ])
    conflicting
      .prepare(
        `INSERT INTO round_refs (round_id, ref_kind, value, reachable)
         VALUES ('round-3', 'provider-turn', 'another-turn', 1)`
      )
      .run()
    expect(
      conflicting.prepare(`SELECT COUNT(*) AS count FROM round_refs`).get()
    ).toEqual({ count: 3 })
    conflicting.close()
  })

  it('migrates v4 digest inputs without losing rows and accepts user artifacts', () => {
    const raw = createVersionFourDatabase()
    seedVersionFourDigest(raw)

    migrateIssueDatabase(raw)

    expect(raw.pragma('user_version', { simple: true })).toBe(ISSUE_DATABASE_SCHEMA_VERSION)
    expect(
      raw
        .prepare(
          `SELECT digest_id, input_kind, input_id, input_version, title_snapshot
           FROM issue_digest_inputs ORDER BY input_kind, input_id`
        )
        .all()
    ).toEqual([
      {
        digest_id: 'digest-1',
        input_kind: 'direct-round',
        input_id: 'round-1',
        input_version: 3,
        title_snapshot: 'Existing round'
      }
    ])

    raw
      .prepare(
        `INSERT INTO issue_digest_inputs (
           digest_id, input_kind, input_id, input_version, title_snapshot
         ) VALUES ('digest-1', 'user-artifact', 'artifact-1', 9, 'User artifact')`
      )
      .run()
    expect(
      raw
        .prepare(
          `SELECT input_kind, input_id FROM issue_digest_inputs
           WHERE input_kind = 'user-artifact'`
        )
        .get()
    ).toEqual({ input_kind: 'user-artifact', input_id: 'artifact-1' })
    raw.close()
  })

  it('rolls back the v4 digest-input rebuild and keeps the old constraint usable', () => {
    const raw = createVersionFourDatabase()
    seedVersionFourDigest(raw)

    expect(() =>
      migrateIssueDatabase(raw, {
        beforeVersionBump: () => {
          throw new Error('v5 migration failure')
        }
      })
    ).toThrow('v5 migration failure')

    expect(raw.pragma('user_version', { simple: true })).toBe(4)
    expect(
      raw
        .prepare(
          `SELECT digest_id, input_kind, input_id, input_version, title_snapshot
           FROM issue_digest_inputs`
        )
        .all()
    ).toEqual([
      {
        digest_id: 'digest-1',
        input_kind: 'direct-round',
        input_id: 'round-1',
        input_version: 3,
        title_snapshot: 'Existing round'
      }
    ])
    expect(() =>
      raw
        .prepare(
          `INSERT INTO issue_digest_inputs (
             digest_id, input_kind, input_id, input_version, title_snapshot
           ) VALUES ('digest-1', 'user-artifact', 'artifact-1', 9, 'User artifact')`
        )
        .run()
    ).toThrow()

    raw
      .prepare(
        `INSERT INTO issue_digest_inputs (
           digest_id, input_kind, input_id, input_version, title_snapshot
         ) VALUES ('digest-1', 'direct-child-digest', 'digest-child', 1, 'Child')`
      )
      .run()
    expect(
      raw.prepare(`SELECT COUNT(*) AS count FROM issue_digest_inputs`).get()
    ).toEqual({ count: 2 })
    raw.close()
  })

  it('configures NORMAL sync, busy timeout, and real foreign-key enforcement', () => {
    const database = openDatabase('pragmas', createUserDataPath())

    expect(database.pragma('synchronous', { simple: true })).toBe(1)
    expect(database.pragma('busy_timeout', { simple: true })).toBe(5000)
    expect(database.pragma('foreign_keys', { simple: true })).toBe(1)
    expect(() =>
      database
        .prepare(
          `INSERT INTO issue_links (
             issue_id, target_authority_id, target_host_partition_key,
             target_issue_id, target_title_snapshot, created_at, updated_at
           ) VALUES ('missing', 'authority', 'local', 'target', 'Missing', 1, 1)`
        )
        .run()
    ).toThrow(/FOREIGN KEY constraint failed/i)
  })

  it.runIf(issueFileDatabaseTestsAvailable)(
    'opens profile storage in WAL mode and recovers after a failed migration',
    () => {
      const userDataPath = createUserDataPath()
      const profileId = 'file-migration-recovery'
      const path = getIssueDatabasePath(profileId, userDataPath)

      expect(() =>
        IssueDatabase.open({
          profileId,
          userDataPath,
          migrationHooks: {
            beforeVersionBump: () => {
              throw new Error('injected migration failure')
            }
          }
        })
      ).toThrow('injected migration failure')

      const failed = new SyncDatabase(path, { fileMustExist: true })
      expect(failed.pragma('user_version', { simple: true })).toBe(0)
      failed.close()

      const recovered = openDatabase(profileId, userDataPath)
      expect(recovered.pragma('journal_mode', { simple: true })).toBe('wal')
      expect(recovered.pragma('user_version', { simple: true })).toBe(ISSUE_DATABASE_SCHEMA_VERSION)
    }
  )

  it('persists one stable authority id for a profile database', () => {
    const userDataPath = createUserDataPath()
    const first = openDatabase('stable-authority', userDataPath)
    const authorityId = first.getAuthorityId()

    if (issueFileDatabaseTestsAvailable) {
      first.close()
      const reopened = openDatabase('stable-authority', userDataPath)
      expect(reopened.getAuthorityId()).toBe(authorityId)
    } else {
      expect(first.getAuthorityId()).toBe(authorityId)
    }
  })

  it.runIf(issueFileDatabaseTestsAvailable)(
    'repairs retained Round body accounting when a profile database reopens',
    () => {
      const userDataPath = createUserDataPath()
      const first = openDatabase('retained-byte-repair', userDataPath)
      first
        .prepare(
          `UPDATE issue_authority_meta
           SET retained_round_text_bytes = 123456
           WHERE singleton = 1`
        )
        .run()
      first.close()

      const reopened = openDatabase('retained-byte-repair', userDataPath)
      expect(
        reopened
          .prepare(
            `SELECT retained_round_text_bytes AS bytes
             FROM issue_authority_meta WHERE singleton = 1`
          )
          .get()
      ).toEqual({ bytes: 0 })
    }
  )
})

function createVersionTwoDatabase(): SyncDatabase.Database {
  const database = createCurrentDatabase()
  database.exec(`
    DROP INDEX idx_round_refs_provider_turn;
    ALTER TABLE issues DROP COLUMN source_refresh_attempted_at;
    ALTER TABLE issues DROP COLUMN source_refresh_error;
    ALTER TABLE issues DROP COLUMN source_availability;
    PRAGMA user_version = 2;
  `)
  database.exec(`
    INSERT INTO conversations (
      id, host_partition_key, execution_host_id, workspace_kind, workspace_id,
      workspace_name_snapshot, workspace_path_snapshot, agent, title, title_source,
      issue_id, state, launch_failure, created_at, updated_at
    ) VALUES (
      'conversation-1', 'local', 'local', 'folder', 'folder-1',
      'Workspace', '/workspace', 'codex', 'Conversation', 'user',
      NULL, 'active', NULL, 1, 1
    );
    INSERT INTO round_records (
      id, conversation_id, kind, state_source, occurred_at, dedupe_key,
      user_input_completeness, output_completeness, question_completeness, created_at
    ) VALUES
      (
        'round-1', 'conversation-1', 'completion', 'hook', 1, 'round-1',
        'not-captured', 'not-captured', 'not-captured', 1
      ),
      (
        'round-2', 'conversation-1', 'completion', 'hook', 2, 'round-2',
        'not-captured', 'not-captured', 'not-captured', 2
      ),
      (
        'round-3', 'conversation-1', 'completion', 'hook', 3, 'round-3',
        'not-captured', 'not-captured', 'not-captured', 3
      );
  `)
  return database
}

function createVersionFourDatabase(): SyncDatabase.Database {
  const database = new SyncDatabase(':memory:')
  database.pragma('foreign_keys = OFF')
  database.exec(ISSUE_DATABASE_CORE_SCHEMA)
  database.exec(ISSUE_DATABASE_ROUND_SCHEMA)
  database.exec(
    ISSUE_DATABASE_SUPPORT_SCHEMA.replace(
      "'direct-round', 'direct-child-digest', 'user-artifact'",
      "'direct-round', 'direct-child-digest'"
    )
  )
  database.pragma('foreign_keys = ON')
  database.pragma('user_version = 4')
  return database
}

function seedVersionFourDigest(database: SyncDatabase.Database): void {
  database.exec(`
    INSERT INTO issues (
      id, host_partition_key, execution_host_id, source_kind, source_number,
      local_title, state, sibling_order, created_at, updated_at
    ) VALUES (
      'issue-1', 'local', 'local', 'local', 1,
      'Digest source', 'active', 0, 1, 1
    );
    INSERT INTO issue_digests (
      id, issue_id, version, revision, status, covers_until,
      input_fingerprint, created_at, updated_at
    ) VALUES (
      'digest-1', 'issue-1', 1, 0, 'draft', 10,
      'fingerprint', 1, 1
    );
    INSERT INTO issue_digest_inputs (
      digest_id, input_kind, input_id, input_version, title_snapshot
    ) VALUES (
      'digest-1', 'direct-round', 'round-1', 3, 'Existing round'
    );
  `)
}

function createVersionOneDatabase(): SyncDatabase.Database {
  const database = createCurrentDatabase()
  database.exec(`
    DROP INDEX idx_launch_claim_active_token;
    DROP INDEX idx_launch_claim_pane;
    DROP INDEX idx_round_refs_provider_turn;
    ALTER TABLE conversations DROP COLUMN launch_failure;
    ALTER TABLE issues DROP COLUMN source_refresh_attempted_at;
    ALTER TABLE issues DROP COLUMN source_refresh_error;
    ALTER TABLE issues DROP COLUMN source_availability;
    PRAGMA user_version = 1;
  `)
  return database
}

function createCurrentDatabase(): SyncDatabase.Database {
  const database = new SyncDatabase(':memory:')
  database.pragma('foreign_keys = OFF')
  database.exec(ISSUE_DATABASE_CORE_SCHEMA)
  database.exec(ISSUE_DATABASE_ROUND_SCHEMA)
  database.exec(ISSUE_DATABASE_SUPPORT_SCHEMA)
  database.pragma('foreign_keys = ON')
  return database
}

describe.skipIf(process.platform === 'win32' || !issueFileDatabaseTestsAvailable)(
  'IssueDatabase permissions',
  () => {
    it('restricts the database and live WAL sidecars to the current user', () => {
      const database = openDatabase('permissions', createUserDataPath())

      for (const path of [database.path, `${database.path}-wal`, `${database.path}-shm`]) {
        expect(statSync(path).mode & 0o777).toBe(0o600)
      }
    })
  }
)
