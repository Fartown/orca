import {
  PROFILE_ROUND_TEXT_HARD_LIMIT_BYTES,
  PROFILE_ROUND_TEXT_SOFT_LIMIT_BYTES
} from '../../shared/issues/constants'
import type { AuthorityHostPartitionKey, RoundRecord } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import {
  retainedRoundRecordBytes,
  roundRecordBodiesEqual,
  writeRoundRecordBodies,
  type RoundRecordBodies
} from './round-record-body-persistence'
import { requireRoundRecord } from './round-record-queries'
import { markRoundRecordSearchableChange } from './round-record-search-rebuild'
import {
  evictRoundRecordTextCompletely,
  evictRoundRecordTextToPreview
} from './round-record-text'

export type RoundRecordRetentionLimits = {
  softLimitBytes: number
  hardLimitBytes: number
}

export type RoundRecordRetentionResult = {
  beforeBytes: number
  afterBytes: number
  changedRoundIds: string[]
}

export type RoundRecordRetentionTransactionResult = RoundRecordRetentionResult & {
  changedByHost: Map<AuthorityHostPartitionKey, Set<string>>
}

type RetentionCandidateRow = {
  id: string
  host_partition_key: AuthorityHostPartitionKey
}

const DEFAULT_LIMITS: RoundRecordRetentionLimits = {
  softLimitBytes: PROFILE_ROUND_TEXT_SOFT_LIMIT_BYTES,
  hardLimitBytes: PROFILE_ROUND_TEXT_HARD_LIMIT_BYTES
}

export function repairRoundRecordRetainedByteAccounting(database: IssueDatabase): {
  previousBytes: number
  actualBytes: number
  repaired: boolean
} {
  const previousBytes = getRetainedRoundTextBytes(database)
  const actualBytes = (
    database
      .prepare(
        `SELECT COALESCE(SUM(
           user_input_bytes + user_input_preview_bytes +
           output_bytes + output_preview_bytes +
           question_bytes + question_preview_bytes
         ), 0) AS bytes
         FROM round_records`
      )
      .get() as { bytes: number }
  ).bytes
  if (previousBytes !== actualBytes) {
    database
      .prepare(
        `UPDATE issue_authority_meta
         SET retained_round_text_bytes = ?
         WHERE singleton = 1`
      )
      .run(actualBytes)
  }
  return { previousBytes, actualBytes, repaired: previousBytes !== actualBytes }
}

export function getRetainedRoundTextBytes(database: IssueDatabase): number {
  return (
    database
      .prepare(
        `SELECT retained_round_text_bytes AS bytes
         FROM issue_authority_meta WHERE singleton = 1`
      )
      .get() as { bytes: number }
  ).bytes
}

export class RoundRecordRetention {
  readonly limits: RoundRecordRetentionLimits

  constructor(
    private readonly database: IssueDatabase,
    limits: Partial<RoundRecordRetentionLimits> = {}
  ) {
    this.limits = validateLimits({ ...DEFAULT_LIMITS, ...limits })
  }

  repairAndEnforceOnOpen(): RoundRecordRetentionResult {
    return this.database.transaction(() => {
      const repaired = repairRoundRecordRetainedByteAccounting(this.database)
      const result = this.enforceLimitWithinTransaction(this.limits.softLimitBytes)
      this.markChanges(result.changedByHost, Date.now())
      return {
        beforeBytes: repaired.previousBytes,
        afterBytes: result.afterBytes,
        changedRoundIds: result.changedRoundIds
      }
    })
  }

  enforceHardLimitWithinTransaction(): RoundRecordRetentionTransactionResult {
    return this.enforceLimitWithinTransaction(this.limits.hardLimitBytes)
  }

  getRetainedBytes(): number {
    return getRetainedRoundTextBytes(this.database)
  }

  needsSoftRetention(): boolean {
    return this.getRetainedBytes() > this.limits.softLimitBytes
  }

  enforceSoftLimit(): RoundRecordRetentionResult {
    return this.database.transaction(() => {
      const result = this.enforceLimitWithinTransaction(this.limits.softLimitBytes)
      this.markChanges(result.changedByHost, Date.now())
      return toPublicResult(result)
    })
  }

  private enforceLimitWithinTransaction(targetBytes: number): InternalRetentionResult {
    const beforeBytes = getRetainedRoundTextBytes(this.database)
    if (beforeBytes <= targetBytes) {
      return {
        beforeBytes,
        afterBytes: beforeBytes,
        changedRoundIds: [],
        changedByHost: new Map()
      }
    }

    let retainedBytes = beforeBytes
    const changedRoundIds: string[] = []
    const changedByHost = new Map<AuthorityHostPartitionKey, Set<string>>()
    const candidates = this.listCandidates()
    for (const stage of ['preview', 'empty'] as const) {
      for (const candidate of candidates) {
        if (retainedBytes <= targetBytes) {
          break
        }
        const current = requireRoundRecord(this.database, candidate.id)
        const next = evictRoundBodies(current, stage)
        if (roundRecordBodiesEqual(current, next)) {
          continue
        }
        const previousBytes = retainedRoundRecordBytes(current)
        const nextBytes = retainedRoundRecordBytes(next)
        writeRoundRecordBodies(this.database, current.id, next, { evictedAt: Date.now() })
        this.adjustRetainedBytes(nextBytes - previousBytes)
        retainedBytes += nextBytes - previousBytes
        changedRoundIds.push(current.id)
        addChangedRound(changedByHost, candidate.host_partition_key, current.id)
      }
    }
    return { beforeBytes, afterBytes: retainedBytes, changedRoundIds, changedByHost }
  }

  markChanges(
    changedByHost: ReadonlyMap<AuthorityHostPartitionKey, ReadonlySet<string>>,
    now: number
  ): void {
    for (const [hostPartitionKey, ids] of changedByHost) {
      markRoundRecordSearchableChange(this.database, hostPartitionKey, [...ids], now)
    }
  }

  private listCandidates(): RetentionCandidateRow[] {
    return this.database
      .prepare(
        `SELECT round.id, conversation.host_partition_key
         FROM round_record_effective_state round
         JOIN conversations conversation ON conversation.id = round.conversation_id
         LEFT JOIN issues issue ON issue.id = conversation.issue_id
         WHERE (
           round.user_input_bytes + round.user_input_preview_bytes +
           round.output_bytes + round.output_preview_bytes +
           round.question_bytes + round.question_preview_bytes
         ) > 0
         ORDER BY
           CASE
             WHEN round.effective_resolved_at IS NOT NULL
               AND (
                 issue.state = 'archived' OR
                 (conversation.state = 'closed' AND conversation.issue_id IS NULL)
               ) THEN 1
             WHEN round.effective_resolved_at IS NOT NULL THEN 2
             WHEN round.kind = 'completion' THEN 3
             ELSE 4
           END,
           round.finalized_at ASC,
           round.occurred_at ASC,
           round.id ASC`
      )
      .all() as RetentionCandidateRow[]
  }

  private adjustRetainedBytes(delta: number): void {
    this.database
      .prepare(
        `UPDATE issue_authority_meta
         SET retained_round_text_bytes = MAX(0, retained_round_text_bytes + ?)
         WHERE singleton = 1`
      )
      .run(delta)
  }
}

export class RoundRecordRetentionWorker {
  private scheduled = false
  private closed = false
  private timer: ReturnType<typeof setTimeout> | null = null

  constructor(private readonly retention: RoundRecordRetention) {}

  scheduleIfNeeded(): void {
    if (
      this.closed ||
      this.scheduled ||
      !this.retention.needsSoftRetention()
    ) {
      return
    }
    this.scheduled = true
    this.timer = setTimeout(() => {
      this.scheduled = false
      this.timer = null
      if (!this.closed) {
        this.retention.enforceSoftLimit()
      }
    }, 0)
  }

  close(): void {
    this.closed = true
    if (this.timer) {
      clearTimeout(this.timer)
      this.timer = null
    }
  }

}

type InternalRetentionResult = RoundRecordRetentionTransactionResult

function evictRoundBodies(
  round: RoundRecord,
  stage: 'preview' | 'empty'
): RoundRecordBodies {
  const evict =
    stage === 'preview' ? evictRoundRecordTextToPreview : evictRoundRecordTextCompletely
  return {
    userInput: evict(round.userInput),
    agentOutput: evict(round.agentOutput),
    pendingQuestion: evict(round.pendingQuestion)
  }
}

function addChangedRound(
  changedByHost: Map<AuthorityHostPartitionKey, Set<string>>,
  hostPartitionKey: AuthorityHostPartitionKey,
  roundId: string
): void {
  const ids = changedByHost.get(hostPartitionKey) ?? new Set<string>()
  ids.add(roundId)
  changedByHost.set(hostPartitionKey, ids)
}

function toPublicResult(result: InternalRetentionResult): RoundRecordRetentionResult {
  return {
    beforeBytes: result.beforeBytes,
    afterBytes: result.afterBytes,
    changedRoundIds: result.changedRoundIds
  }
}

function validateLimits(limits: RoundRecordRetentionLimits): RoundRecordRetentionLimits {
  if (
    !Number.isSafeInteger(limits.softLimitBytes) ||
    !Number.isSafeInteger(limits.hardLimitBytes) ||
    limits.softLimitBytes < 0 ||
    limits.hardLimitBytes < limits.softLimitBytes
  ) {
    throw new Error('Round retention limits must be non-negative and soft <= hard.')
  }
  return limits
}
