import { describe, expect, it } from 'vitest'
import { isTopLevelView } from '../top-level-view'

describe('Issue top-level view', () => {
  it('accepts Issues as a durable view without accepting inherited object keys', () => {
    expect(isTopLevelView('issues')).toBe(true)
    expect(isTopLevelView('constructor')).toBe(false)
    expect(isTopLevelView('__proto__')).toBe(false)
  })
})
