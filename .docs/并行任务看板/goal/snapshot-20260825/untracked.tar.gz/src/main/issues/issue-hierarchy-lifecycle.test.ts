import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { getIssueHostRevisions } from './issue-host-state'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import { IssueRepositoryError, type IssueRepositoryErrorCode } from './issue-repository-error'

const repositories: IssueRepository[] = []
let sequence = 0

function openRepository(name: string): IssueRepository {
  const userDataPath = createIssueTestUserDataPath(`orca-issues-${name}`)
  const repository = new IssueRepository(
    openIssueTestDatabase({ profileId: name, userDataPath })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  sequence += 1
  return issueMutationIdentity('hierarchy-lifecycle-test', `${label}-${sequence}`)
}

function createIssue(
  repository: IssueRepository,
  title: string,
  parentId: string | null = null,
  executionHostId: ExecutionHostId = 'local'
) {
  return repository.issues.create({
    identity: identity(`create-${title}`),
    input: {
      kind: 'local',
      executionHostId,
      title,
      parentId
    }
  })
}

function createConversation(
  repository: IssueRepository,
  issueId: string | null,
  label: string
) {
  return repository.conversations.create({
    identity: identity(`conversation-${label}`),
    input: {
      executionHostId: 'local',
      workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${label}` },
      workspaceSnapshot: { name: label, path: `/workspace/${label}` },
      agent: 'codex',
      title: label,
      titleSource: 'user',
      issueId
    }
  })
}

function expectCode(operation: () => unknown, code: IssueRepositoryErrorCode): void {
  try {
    operation()
  } catch (error) {
    expect(error).toBeInstanceOf(IssueRepositoryError)
    expect((error as IssueRepositoryError).code).toBe(code)
    return
  }
  throw new Error(`Expected IssueRepositoryError(${code}).`)
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  sequence = 0
})

describe('Issue hierarchy mutations', () => {
  it('reparents and reorders in one revision, then replays the receipt without side effects', () => {
    const repository = openRepository('atomic-reparent')
    const firstRoot = createIssue(repository, 'First root')
    const secondRoot = createIssue(repository, 'Second root')
    const child = createIssue(repository, 'Child', firstRoot.id)
    const before = getIssueHostRevisions(repository.database, 'local')
    const mutation = issueMutationIdentity('stable-caller', 'stable-reparent')
    const input = {
      issueId: child.id,
      parentId: secondRoot.id,
      index: 0,
      expectedTreeRevision: before.treeRevision
    }

    const first = repository.issues.reparent({ identity: mutation, input })
    const replay = repository.issues.reparent({ identity: mutation, input })
    const after = getIssueHostRevisions(repository.database, 'local')

    expect(replay).toEqual(first)
    expect(first).toMatchObject({
      issue: { id: child.id, parentId: secondRoot.id, siblingOrder: 0 },
      factsRevision: before.factsRevision + 1,
      treeRevision: before.treeRevision + 1
    })
    expect(after).toEqual({
      ...before,
      factsRevision: before.factsRevision + 1,
      treeRevision: before.treeRevision + 1
    })
    expect(repository.issues.list().map(({ id, parentId, siblingOrder }) => ({
      id,
      parentId,
      siblingOrder
    }))).toEqual([
      { id: firstRoot.id, parentId: null, siblingOrder: 0 },
      { id: secondRoot.id, parentId: null, siblingOrder: 1 },
      { id: child.id, parentId: secondRoot.id, siblingOrder: 0 }
    ])
    expect(repository.issueEvents.list({ issueId: child.id })).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          kind: 'reparented',
          payload: {
            previousParentId: firstRoot.id,
            parentId: secondRoot.id,
            index: 0
          }
        })
      ])
    )
  })

  it('rejects stale, cyclic, and whole-subtree depth violations without partial writes', () => {
    const repository = openRepository('reparent-rejections')
    const root = createIssue(repository, 'Root')
    const child = createIssue(repository, 'Child', root.id)
    const grandchild = createIssue(repository, 'Grandchild', child.id)
    const secondRoot = createIssue(repository, 'Second root')
    const secondChild = createIssue(repository, 'Second child', secondRoot.id)
    const stable = repository.issues.list()
    const currentRevision = getIssueHostRevisions(repository.database, 'local').treeRevision

    expectCode(
      () =>
        repository.issues.reparent({
          identity: identity('stale'),
          input: {
            issueId: child.id,
            parentId: secondRoot.id,
            index: 0,
            expectedTreeRevision: currentRevision - 1
          }
        }),
      'issue_tree_revision_stale'
    )
    expectCode(
      () =>
        repository.issues.reparent({
          identity: identity('cycle'),
          input: {
            issueId: root.id,
            parentId: grandchild.id,
            index: 0,
            expectedTreeRevision: currentRevision
          }
        }),
      'parent_cycle'
    )
    expectCode(
      () =>
        repository.issues.reparent({
          identity: identity('depth'),
          input: {
            issueId: child.id,
            parentId: secondChild.id,
            index: 0,
            expectedTreeRevision: currentRevision
          }
        }),
      'issue_depth_exceeded'
    )

    expect(repository.issues.list()).toEqual(stable)
    expect(getIssueHostRevisions(repository.database, 'local').treeRevision).toBe(
      currentRevision
    )
  })
})

describe('Issue delete plan', () => {
  it('rolls back child and Conversation moves if a later write fails, then retries safely', () => {
    const repository = openRepository('delete-rollback')
    const doomed = createIssue(repository, 'Doomed')
    const child = createIssue(repository, 'Child', doomed.id)
    const conversation = createConversation(repository, doomed.id, 'delete')
    const round = repository.rounds.create({
      identity: identity('round'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 1,
        dedupeKey: 'delete:round',
        agentOutput: { text: 'Keep me' }
      }
    })
    const plan = repository.issues.prepareDelete(doomed.id).plan
    const mutation = issueMutationIdentity('stable-caller', 'delete-with-retry')
    const before = getIssueHostRevisions(repository.database, 'local')
    repository.database.exec(`
      CREATE TRIGGER reject_test_conversation_move
      BEFORE UPDATE OF issue_id ON conversations
      BEGIN
        SELECT RAISE(ABORT, 'injected delete failure');
      END;
    `)

    expect(() =>
      repository.issues.delete({ identity: mutation, input: plan })
    ).toThrow('injected delete failure')
    expect(repository.issues.get(doomed.id)).toEqual(doomed)
    expect(repository.issues.get(child.id)?.parentId).toBe(doomed.id)
    expect(repository.conversations.get(conversation.id)?.issueId).toBe(doomed.id)
    expect(repository.rounds.get(round.id)?.agentOutput.text).toBe('Keep me')
    expect(getIssueHostRevisions(repository.database, 'local')).toEqual(before)
    expect(
      repository.database
        .prepare(
          `SELECT COUNT(*) AS count FROM issue_mutation_receipts
           WHERE caller_fingerprint = 'stable-caller' AND mutation_id = 'delete-with-retry'`
        )
        .get()
    ).toEqual({ count: 0 })

    repository.database.exec('DROP TRIGGER reject_test_conversation_move')
    const result = repository.issues.delete({ identity: mutation, input: plan })

    expect(result).toMatchObject({
      deletedIssueId: doomed.id,
      affectedConversationIds: [conversation.id]
    })
    expect(repository.issues.get(doomed.id)).toBeUndefined()
    expect(repository.issues.get(child.id)).toMatchObject({
      parentId: null,
      siblingOrder: 0
    })
    expect(repository.conversations.get(conversation.id)?.issueId).toBeNull()
    expect(repository.rounds.get(round.id)?.agentOutput.text).toBe('Keep me')
    expect(repository.issueEvents.list({ issueId: doomed.id })).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          kind: 'deleted',
          issueRefs: [
            expect.objectContaining({
              issueId: doomed.id,
              titleSnapshot: 'Doomed'
            })
          ]
        })
      ])
    )
  })

  it('rejects a stale delete plan before changing children or bindings', () => {
    const repository = openRepository('delete-stale')
    const doomed = createIssue(repository, 'Doomed')
    const child = createIssue(repository, 'Child', doomed.id)
    const conversation = createConversation(repository, doomed.id, 'stale')
    const plan = repository.issues.prepareDelete(doomed.id).plan
    createIssue(repository, 'Concurrent change')
    const stableDoomed = repository.issues.get(doomed.id)

    expectCode(
      () =>
        repository.issues.delete({
          identity: identity('stale-delete'),
          input: plan
        }),
      'issue_facts_revision_stale'
    )
    expect(repository.issues.get(doomed.id)).toEqual(stableDoomed)
    expect(repository.issues.get(child.id)?.parentId).toBe(doomed.id)
    expect(repository.conversations.get(conversation.id)?.issueId).toBe(doomed.id)
  })
})

describe('Issue lifecycle', () => {
  it('keeps read and resolution independent and blocks archive on unresolved waiting', () => {
    const repository = openRepository('archive-blocker')
    const issue = createIssue(repository, 'Needs input')
    const conversation = createConversation(repository, issue.id, 'waiting')
    const waiting = repository.rounds.create({
      identity: identity('waiting'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'waiting:blocker',
        pendingQuestion: { text: 'Approve?' }
      }
    })
    repository.rounds.update({
      identity: identity('read'),
      input: { id: waiting.id, readAt: 20 }
    })

    expect(repository.issues.archive({
      identity: identity('blocked-archive'),
      input: { id: issue.id }
    })).toMatchObject({
      status: 'blocked',
      blockers: [
        {
          conversationId: conversation.id,
          kind: 'unresolved-waiting',
          roundRecordId: waiting.id,
          dedupeKey: 'waiting:blocker'
        }
      ]
    })
    expect(repository.rounds.get(waiting.id)).toMatchObject({
      readAt: 20,
      resolvedAt: null,
      resolution: null
    })
    expect(repository.issues.get(issue.id)?.state).toBe('active')
  })

  it('archives direct completions without changing child lifecycle', () => {
    const repository = openRepository('archive-independent')
    const parent = createIssue(repository, 'Parent')
    const child = createIssue(repository, 'Child', parent.id)
    const conversation = createConversation(repository, parent.id, 'completion')
    const completion = repository.rounds.create({
      identity: identity('completion'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'archive:completion',
        agentOutput: { text: 'Done' }
      }
    })

    expect(repository.issues.archive({
      identity: identity('archive'),
      input: { id: parent.id }
    })).toMatchObject({
      status: 'archived',
      resolvedCompletionIds: [completion.id]
    })
    expect(repository.rounds.get(completion.id)).toMatchObject({
      resolvedAt: expect.any(Number),
      resolution: 'archive'
    })
    expect(repository.issues.get(parent.id)?.state).toBe('archived')
    expect(repository.issues.get(child.id)?.state).toBe('active')
  })

  it('reopens only for a newer stop or an authoritative delayed waiting stop', () => {
    const repository = openRepository('auto-reopen')
    const issue = createIssue(repository, 'Archived work')
    const conversation = createConversation(repository, issue.id, 'reopen')
    const firstArchive = repository.issues.archive({
      identity: identity('archive-first'),
      input: { id: issue.id }
    })
    if (firstArchive.status !== 'archived') {
      throw new Error('Expected Issue to archive.')
    }
    repository.rounds.create({
      identity: identity('old-completion'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'reconciled',
        occurredAt: firstArchive.archivedAt - 1,
        dedupeKey: 'reopen:old-completion',
        agentOutput: { text: 'Historical' }
      }
    })
    expect(repository.issues.get(issue.id)?.state).toBe('archived')

    repository.rounds.create({
      identity: identity('old-waiting'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: firstArchive.archivedAt - 1,
        dedupeKey: 'reopen:authoritative-waiting',
        pendingQuestion: { text: 'Still waiting' },
        authoritativeCurrentState: true
      }
    })
    expect(repository.issues.get(issue.id)?.state).toBe('active')

    repository.rounds.update({
      identity: identity('resolve-waiting'),
      input: {
        id: repository.rounds
          .list({ conversationId: conversation.id, kind: 'waiting' })[0].id,
        resolvedAt: Date.now(),
        resolution: 'resumed'
      }
    })
    const secondArchive = repository.issues.archive({
      identity: identity('archive-second'),
      input: { id: issue.id }
    })
    if (secondArchive.status !== 'archived') {
      throw new Error('Expected Issue to archive again.')
    }
    repository.rounds.create({
      identity: identity('new-completion'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: secondArchive.archivedAt + 1,
        dedupeKey: 'reopen:new-completion',
        agentOutput: { text: 'New work' }
      }
    })

    expect(repository.issues.get(issue.id)?.state).toBe('active')
    expect(
      repository.issueEvents
        .list({ issueId: issue.id })
        .filter((event) => event.kind === 'reopened')
        .map((event) => event.payload.cause)
    ).toEqual(['new-round', 'new-round'])
  })
})
