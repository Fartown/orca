import { z } from 'zod'
import { parseExecutionHostId } from '../execution-host'
import type { AuthorityHostPartitionKey } from './types'

const AuthorityId = z.string().uuid()

export const IssueRouteExecutionHostId = z.string().transform((value, context) => {
  const parsed = parseExecutionHostId(value)
  if (parsed) {
    return parsed.id
  }
  context.addIssue({ code: 'custom', message: 'Invalid execution host id' })
  return z.NEVER
})

export const IssueHostPartitionKeySchema = z
  .union([
    z.literal('local'),
    z
      .string()
      .regex(/^ssh:[^\s]+$/)
      .max(4_096)
  ])
  .transform((value): AuthorityHostPartitionKey => value as AuthorityHostPartitionKey)

export const IssueAuthorityDescriptorSchema = z.object({
  authorityId: AuthorityId,
  hostPartitionKey: IssueHostPartitionKeySchema,
  routeExecutionHostId: IssueRouteExecutionHostId
})
