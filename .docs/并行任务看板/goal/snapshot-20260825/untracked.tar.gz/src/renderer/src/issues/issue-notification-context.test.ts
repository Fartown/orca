import { describe, expect, it, vi } from 'vitest'
import type {
  IssueDashboardPaneProjection,
  RoundRecordPreview
} from '../../../shared/issues/types'
import {
  loadIssueNotificationContext,
  readCachedIssueNotificationContext,
  roundRecordRectIsVisible,
  type IssueNotificationContextDependencies
} from './issue-notification-context'

const waitingRound = {
  id: '44444444-4444-4444-8444-444444444444',
  conversationId: '33333333-3333-4333-8333-333333333333',
  kind: 'waiting',
  occurredAt: 123
} as RoundRecordPreview

function pane(
  latestRound: RoundRecordPreview | null = waitingRound
): IssueDashboardPaneProjection {
  return {
    paneKey: 'tab-1:11111111-1111-4111-8111-111111111111',
    conversationId: waitingRound.conversationId,
    issue: {
      id: '22222222-2222-4222-8222-222222222222',
      title: 'Notification routing',
      typeLabel: null,
      state: 'active'
    },
    latestRound
  }
}

function dependencies(
  overrides: Partial<IssueNotificationContextDependencies> = {}
): IssueNotificationContextDependencies {
  return {
    readCachedPane: () => null,
    loadProjection: vi.fn().mockResolvedValue({ status: 'unsupported' }),
    isRoundRecordVisible: () => false,
    ...overrides
  }
}

describe('loadIssueNotificationContext', () => {
  it('uses an exact cached Round Record without another projection request', async () => {
    const loadProjection = vi.fn()
    const result = await loadIssueNotificationContext(
      {
        executionHostId: 'local',
        paneKey: pane().paneKey,
        expectedRound: { kind: 'waiting', occurredAt: 123 }
      },
      dependencies({
        readCachedPane: () => pane(),
        loadProjection,
        isRoundRecordVisible: (roundRecordId) =>
          roundRecordId === waitingRound.id
      })
    )

    expect(result).toEqual({
      executionHostId: 'local',
      conversationId: waitingRound.conversationId,
      issueId: pane().issue?.id,
      roundRecordId: waitingRound.id,
      isVisibleRoundRecord: true
    })
    expect(loadProjection).not.toHaveBeenCalled()
  })

  it('replaces a stale cache entry with the authority projection', async () => {
    const staleRound = {
      ...waitingRound,
      id: '55555555-5555-4555-8555-555555555555',
      occurredAt: 100
    }
    const loadProjection = vi.fn().mockResolvedValue({
      status: 'ready',
      projection: {
        authority: {
          authorityId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local'
        },
        snapshotFactsRevision: 2,
        panes: [pane()]
      }
    })

    const result = await loadIssueNotificationContext(
      {
        executionHostId: 'local',
        paneKey: pane().paneKey,
        expectedRound: { kind: 'waiting', occurredAt: 123 }
      },
      dependencies({
        readCachedPane: () => pane(staleRound),
        loadProjection
      })
    )

    expect(loadProjection).toHaveBeenCalledWith('local', [pane().paneKey])
    expect(result.roundRecordId).toBe(waitingRound.id)
  })

  it('keeps a cached Conversation fallback but never labels a stale Round as current', async () => {
    const staleRound = {
      ...waitingRound,
      id: '55555555-5555-4555-8555-555555555555',
      occurredAt: 100
    }
    const result = await loadIssueNotificationContext(
      {
        executionHostId: 'local',
        paneKey: pane().paneKey,
        expectedRound: { kind: 'waiting', occurredAt: 123 }
      },
      dependencies({
        readCachedPane: () => pane(staleRound)
      })
    )

    expect(result).toEqual({
      executionHostId: 'local',
      conversationId: waitingRound.conversationId,
      issueId: pane().issue?.id
    })
  })
})

describe('readCachedIssueNotificationContext', () => {
  it('returns null when the cached Round does not match the notification event', () => {
    expect(
      readCachedIssueNotificationContext(
        {
          executionHostId: 'local',
          paneKey: pane().paneKey,
          expectedRound: { kind: 'completion', occurredAt: 123 }
        },
        {
          readCachedPane: () => pane(),
          isRoundRecordVisible: () => false
        }
      )
    ).toBeNull()
  })
})

describe('roundRecordRectIsVisible', () => {
  it('requires a foreground document and viewport intersection', () => {
    const visibleRect = {
      top: 10,
      right: 200,
      bottom: 80,
      left: 20,
      width: 180,
      height: 70
    }

    expect(
      roundRecordRectIsVisible(visibleRect, {
        foreground: true,
        viewportWidth: 800,
        viewportHeight: 600
      })
    ).toBe(true)
    expect(
      roundRecordRectIsVisible(visibleRect, {
        foreground: false,
        viewportWidth: 800,
        viewportHeight: 600
      })
    ).toBe(false)
    expect(
      roundRecordRectIsVisible(
        { ...visibleRect, top: 700, bottom: 770 },
        { foreground: true, viewportWidth: 800, viewportHeight: 600 }
      )
    ).toBe(false)
  })
})
