import { afterEach, describe, expect, it } from 'vitest'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from '../../../issues/issue-database.test-environment'
import { IssueRepository, issueMutationIdentity } from '../../../issues/issue-repository'
import { IssueRuntimeService } from '../../../issues/issue-runtime-service'
import type { OrcaRuntimeService } from '../../orca-runtime'
import type { RpcRequest } from '../core'
import { RpcDispatcher } from '../dispatcher'
import { ISSUE_METHODS, setIssueRuntimeServiceForRpc } from './issues'

const repositories: IssueRepository[] = []

function request(method: string, params: unknown): RpcRequest {
  return {
    id: `${method}-request`,
    authToken: 'paired-device-token',
    method,
    params
  }
}

function openDispatcher(): {
  repository: IssueRepository
  dispatcher: RpcDispatcher
} {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: 'rpc',
      userDataPath: createIssueTestUserDataPath('orca-issues-rpc')
    })
  )
  repositories.push(repository)
  setIssueRuntimeServiceForRpc(new IssueRuntimeService(repository))
  const runtime = {
    getRuntimeId: () => 'runtime-test'
  } as OrcaRuntimeService
  return {
    repository,
    dispatcher: new RpcDispatcher({ runtime, methods: ISSUE_METHODS })
  }
}

afterEach(() => {
  setIssueRuntimeServiceForRpc(null)
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
})

describe('Issue RPC methods', () => {
  it('registers and dispatches the complete Digest RPC surface', async () => {
    const { repository, dispatcher } = openDispatcher()
    const issue = repository.issues.create({
      identity: issueMutationIdentity('rpc-digest', 'create-issue'),
      input: {
        kind: 'local',
        title: 'Digest RPC Issue',
        executionHostId: 'local'
      }
    })

    expect(ISSUE_METHODS.map((method) => method.name)).toEqual(
      expect.arrayContaining([
        'issues.prepareDigest',
        'issues.generateDigest',
        'issues.cancelDigest',
        'issues.updateDigestDraft',
        'issues.confirmDigest'
      ])
    )
    const preparation = await dispatcher.dispatch(
      request('issues.prepareDigest', {
        executionHostId: 'local',
        issueId: issue.id,
        coversUntil: 100
      })
    )

    expect(preparation).toMatchObject({
      ok: true,
      result: {
        issueId: issue.id,
        coversUntil: 100,
        inputFingerprint: expect.stringMatching(/^[a-f0-9]{64}$/),
        inputs: [],
        coverage: {
          totalInputCount: 0,
          includedInputCount: 0,
          complete: true
        }
      }
    })
  })

  it('uses the authenticated caller receipt and returns schema-validated snapshots', async () => {
    const { repository, dispatcher } = openDispatcher()
    const create = request('issues.create', {
      executionHostId: 'local',
      mutationId: 'rpc-create-once',
      callerFingerprint: 'forged-client-identity',
      source: { kind: 'local', title: 'RPC Issue' }
    })

    const first = await dispatcher.dispatch(create)
    const replay = await dispatcher.dispatch(create)
    const list = await dispatcher.dispatch(
      request('issues.list', {
        mode: 'start',
        executionHostId: 'local',
        filter: 'all',
        limit: 20
      })
    )

    expect(first).toMatchObject({
      ok: true,
      result: {
        affectedIssueIds: [expect.any(String)],
        affectedConversationIds: [],
        affectedRoundRecordIds: []
      }
    })
    expect(replay).toEqual({
      ...first,
      id: create.id
    })
    expect(repository.issues.list()).toHaveLength(1)
    expect(list).toMatchObject({
      ok: true,
      result: {
        status: 'snapshot-page',
        issues: [{ localTitle: 'RPC Issue' }]
      }
    })
  })

  it('rejects oversized or malformed inputs before touching SQLite', async () => {
    const { repository, dispatcher } = openDispatcher()
    const response = await dispatcher.dispatch(
      request('issues.create', {
        executionHostId: 'local',
        mutationId: 'rpc-invalid',
        source: { kind: 'local', title: 'x'.repeat(513) }
      })
    )

    expect(response).toMatchObject({
      ok: false,
      error: { code: 'invalid_argument' }
    })
    expect(repository.issues.list()).toEqual([])
  })

  it('returns persistent Activity and Dashboard projections through the dispatcher', async () => {
    const { repository, dispatcher } = openDispatcher()
    const issue = repository.issues.create({
      identity: issueMutationIdentity('rpc-projection', 'create-issue'),
      input: {
        kind: 'local',
        title: 'Projected Issue',
        executionHostId: 'local'
      }
    })
    const conversation = repository.conversations.create({
      identity: issueMutationIdentity('rpc-projection', 'create-conversation'),
      input: {
        executionHostId: 'local',
        workspaceRef: {
          type: 'folder',
          folderWorkspaceId: 'rpc-projection-folder'
        },
        workspaceSnapshot: {
          name: 'Projection workspace',
          path: '/workspace/projection'
        },
        agent: 'codex',
        title: 'Projection conversation',
        titleSource: 'user',
        issueId: issue.id
      }
    })
    repository.conversationLaunchClaims.create({
      conversationId: conversation.id,
      launchToken: 'rpc-projection-launch',
      paneKey: 'tab:rpc-projection',
      createdAt: 10,
      expiresAt: 10_000
    })
    const round = repository.rounds.create({
      identity: issueMutationIdentity('rpc-projection', 'create-round'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 20,
        dedupeKey: 'rpc:projection:round',
        pendingQuestion: { text: 'Approve?' },
        readAt: 21
      }
    })

    const activity = await dispatcher.dispatch(
      request('issues.listActivity', {
        executionHostId: 'local',
        limit: 20
      })
    )
    const dashboard = await dispatcher.dispatch(
      request('issues.projectDashboardPanes', {
        executionHostId: 'local',
        paneKeys: ['tab:rpc-projection']
      })
    )

    expect(activity).toMatchObject({
      ok: true,
      result: {
        entries: expect.arrayContaining([
          expect.objectContaining({
            type: 'round',
            id: round.id,
            round: expect.objectContaining({
              readAt: 21,
              resolvedAt: null
            }),
            conversation: expect.objectContaining({ id: conversation.id }),
            issue: expect.objectContaining({
              id: issue.id,
              title: 'Projected Issue'
            })
          })
        ])
      }
    })
    expect(dashboard).toMatchObject({
      ok: true,
      result: {
        panes: [
          {
            paneKey: 'tab:rpc-projection',
            conversationId: conversation.id,
            issue: { id: issue.id, title: 'Projected Issue' },
            latestRound: { id: round.id, readAt: 21, resolvedAt: null }
          }
        ]
      }
    })
  })

  it('returns unresolved waiting records from the authoritative mobile projection', async () => {
    const { repository, dispatcher } = openDispatcher()
    const conversation = repository.conversations.create({
      identity: issueMutationIdentity('rpc-mobile', 'create-conversation'),
      input: {
        executionHostId: 'local',
        workspaceRef: {
          type: 'folder',
          folderWorkspaceId: 'rpc-mobile-folder'
        },
        workspaceSnapshot: {
          name: 'Mobile workspace',
          path: '/workspace/mobile'
        },
        agent: 'codex'
      }
    })
    const waiting = repository.rounds.create({
      identity: issueMutationIdentity('rpc-mobile', 'create-waiting'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 20,
        dedupeKey: 'rpc:mobile:waiting',
        pendingQuestion: { text: 'Approve?' },
        readAt: 21
      }
    })

    const response = await dispatcher.dispatch(
      request('issues.pendingForMobile', {
        executionHostId: 'local',
        limit: 20
      })
    )

    expect(response).toMatchObject({
      ok: true,
      result: {
        entries: [
          {
            round: {
              id: waiting.id,
              kind: 'waiting',
              readAt: 21,
              resolvedAt: null
            },
            conversation: {
              id: conversation.id,
              workspaceSnapshot: {
                name: 'Mobile workspace',
                path: '/workspace/mobile'
              }
            },
            issue: null
          }
        ]
      }
    })
  })

  it('reads one authoritative Conversation with navigation and latest Round state', async () => {
    const { repository, dispatcher } = openDispatcher()
    const conversation = repository.conversations.create({
      identity: issueMutationIdentity('rpc-conversation', 'create-conversation'),
      input: {
        executionHostId: 'local',
        workspaceRef: {
          type: 'folder',
          folderWorkspaceId: 'rpc-conversation-folder'
        },
        workspaceSnapshot: {
          name: 'Conversation workspace',
          path: '/workspace/conversation'
        },
        agent: 'codex'
      }
    })
    repository.conversationLaunchClaims.create({
      conversationId: conversation.id,
      launchToken: 'rpc-conversation-launch',
      paneKey: 'tab:rpc-conversation',
      createdAt: 10,
      expiresAt: 10_000
    })
    const waiting = repository.rounds.create({
      identity: issueMutationIdentity('rpc-conversation', 'create-waiting'),
      input: {
        conversationId: conversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 20,
        dedupeKey: 'rpc:conversation:waiting',
        pendingQuestion: { text: 'Approve?' }
      }
    })

    const response = await dispatcher.dispatch(
      request('conversations.get', {
        executionHostId: 'local',
        conversationId: conversation.id
      })
    )

    expect(response).toMatchObject({
      ok: true,
      result: {
        id: conversation.id,
        executionHostId: 'local',
        unresolvedRoundCount: 1,
        latestRound: {
          id: waiting.id,
          pendingQuestion: {
            preview: 'Approve?',
            completeness: 'complete',
            storage: 'full'
          }
        },
        navigation: {
          paneKey: 'tab:rpc-conversation'
        }
      }
    })
  })
})
