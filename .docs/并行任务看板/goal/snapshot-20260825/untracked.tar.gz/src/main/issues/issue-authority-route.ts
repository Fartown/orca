import {
  LOCAL_EXECUTION_HOST_ID,
  parseExecutionHostId,
  type ExecutionHostId
} from '../../shared/execution-host'
import type {
  AuthorityHostPartitionKey,
  IssueAuthorityDescriptor
} from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { IssueRepositoryError } from './issue-repository-error'

export type IssueAuthorityRoute = {
  routeExecutionHostId: ExecutionHostId
  authorityExecutionHostId: ExecutionHostId
  hostPartitionKey: AuthorityHostPartitionKey
}

export function resolveIssueAuthorityRoute(
  executionHostId: ExecutionHostId,
  options: { isManagedSshTarget?: (targetId: string) => boolean } = {}
): IssueAuthorityRoute {
  const parsed = parseExecutionHostId(executionHostId)
  if (!parsed) {
    throw new IssueRepositoryError(
      'issue_route_invalid',
      `Invalid Issue execution host route: ${executionHostId}.`
    )
  }
  if (parsed.kind === 'ssh') {
    if (!options.isManagedSshTarget?.(parsed.targetId)) {
      throw new IssueRepositoryError(
        'issue_route_invalid',
        `SSH target ${parsed.targetId} is not managed by this runtime.`
      )
    }
    return {
      routeExecutionHostId: parsed.id,
      authorityExecutionHostId: parsed.id,
      hostPartitionKey: parsed.id
    }
  }
  return {
    routeExecutionHostId: parsed.id,
    authorityExecutionHostId: LOCAL_EXECUTION_HOST_ID,
    hostPartitionKey: 'local'
  }
}

export function issueAuthorityDescriptor(
  database: IssueDatabase,
  route: IssueAuthorityRoute
): IssueAuthorityDescriptor {
  return {
    authorityId: database.getAuthorityId(),
    hostPartitionKey: route.hostPartitionKey,
    routeExecutionHostId: route.routeExecutionHostId
  }
}
