import { useCallback, useRef, useState } from 'react'
import { ActivityIndicator, FlatList, Pressable, RefreshControl, Text, View } from 'react-native'
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context'
import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router'
import { Bell, ChevronLeft, ChevronRight, RefreshCw } from 'lucide-react-native'
import type { MobileIssuePendingItem } from '../../../src/issues/mobile-issue-data'
import type { MobileIssueAuthorityDiscovery } from '../../../src/issues/mobile-issue-authorities'
import { loadMobileIssueAuthorities } from '../../../src/issues/mobile-issue-authorities'
import { loadMobileIssuePending } from '../../../src/issues/mobile-issue-data'
import { mobileIssuePendingEntryRouteTarget } from '../../../src/issues/mobile-issue-route'
import {
  buildMobileIssuePendingRow,
  supportsMobileIssues
} from '../../../src/issues/mobile-issue-screen-model'
import { mobileIssueScreenStyles as styles } from '../../../src/issues/mobile-issue-screen-styles'
import { useOpenHostStackRoute } from '../../../src/navigation/use-open-host-stack-route'
import { useHostProtocolGates } from '../../../src/components/HostProtocolGate'
import { useHostClient } from '../../../src/transport/client-context'
import { colors, spacing } from '../../../src/theme/mobile-theme'

type WaitingScreenState =
  | { status: 'loading' }
  | { status: 'unreachable'; message: string }
  | {
      status: 'ready'
      discovery: MobileIssueAuthorityDiscovery
      items: MobileIssuePendingItem[]
      warnings: string[]
    }

function formatOccurredAt(value: number): string {
  return new Date(value).toLocaleString()
}

export default function MobileIssueWaitingScreen() {
  const { hostId } = useLocalSearchParams<{ hostId: string }>()
  const router = useRouter()
  const insets = useSafeAreaInsets()
  const openHostStackRoute = useOpenHostStackRoute()
  const { client, state: connectionState } = useHostClient(hostId)
  const { hostCapabilities } = useHostProtocolGates()
  const supported = supportsMobileIssues(hostCapabilities)
  const requestRef = useRef(0)
  const [refreshing, setRefreshing] = useState(false)
  const [screen, setScreen] = useState<WaitingScreenState>({ status: 'loading' })

  const refresh = useCallback(
    async (showRefresh = false) => {
      const requestId = ++requestRef.current
      if (showRefresh) {
        setRefreshing(true)
      } else {
        setScreen({ status: 'loading' })
      }
      if (!client || connectionState !== 'connected') {
        setScreen({ status: 'unreachable', message: 'Reconnect to the host and try again.' })
        setRefreshing(false)
        return
      }
      try {
        const discovery = await loadMobileIssueAuthorities(client)
        const pending = await loadMobileIssuePending(client, discovery.executionHostIds)
        if (requestRef.current !== requestId) {
          return
        }
        const warnings = [
          ...(discovery.status === 'ready'
            ? []
            : [discovery.message ?? 'Authority discovery failed.']),
          ...pending.partitions
            .filter((partition) => partition.status !== 'ready')
            .map(
              (partition) =>
                `${partition.executionHostId}: ${partition.message ?? 'Issue waiting is unavailable.'}`
            )
        ]
        setScreen({
          status: 'ready',
          discovery,
          items: pending.items,
          warnings
        })
      } catch (error) {
        if (requestRef.current === requestId) {
          setScreen({
            status: 'unreachable',
            message: error instanceof Error ? error.message : 'The host is unreachable.'
          })
        }
      } finally {
        if (requestRef.current === requestId) {
          setRefreshing(false)
        }
      }
    },
    [client, connectionState]
  )

  useFocusEffect(
    useCallback(() => {
      if (supported) {
        void refresh()
      }
      return () => {
        requestRef.current++
      }
    }, [refresh, supported])
  )

  const openItem = useCallback(
    (item: MobileIssuePendingItem) => {
      const target = mobileIssuePendingEntryRouteTarget(hostId, item.executionHostId, item.entry)
      openHostStackRoute(hostId, target)
    },
    [hostId, openHostStackRoute]
  )

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Pressable
          style={styles.headerButton}
          onPress={() => router.back()}
          accessibilityRole="button"
          accessibilityLabel="Back"
        >
          <ChevronLeft size={22} color={colors.textPrimary} />
        </Pressable>
        <View style={styles.headerTitleWrap}>
          <Text style={styles.headerTitle}>Needs your input</Text>
          <Text style={styles.headerSubtitle}>Waiting across visible host authorities</Text>
        </View>
        <Pressable
          style={styles.headerButton}
          onPress={() => void refresh(true)}
          disabled={!supported || refreshing}
          accessibilityRole="button"
          accessibilityLabel="Refresh waiting items"
        >
          {refreshing ? (
            <ActivityIndicator size="small" color={colors.textSecondary} />
          ) : (
            <RefreshCw size={18} color={supported ? colors.textSecondary : colors.textMuted} />
          )}
        </Pressable>
      </View>

      {!supported ? (
        <View style={styles.stateWrap}>
          <View style={styles.stateCard}>
            <View style={styles.stateIcon}>
              <Bell size={24} color={colors.statusAmber} />
            </View>
            <Text style={styles.stateTitle}>Host update required</Text>
            <Text style={styles.stateMessage}>
              This host does not advertise mobile Issue waiting support.
            </Text>
          </View>
        </View>
      ) : screen.status === 'loading' ? (
        <View style={styles.stateWrap}>
          <ActivityIndicator color={colors.textSecondary} />
          <Text style={styles.stateMessage}>Loading waiting items…</Text>
        </View>
      ) : screen.status === 'unreachable' ? (
        <View style={styles.stateWrap}>
          <View style={styles.stateCard}>
            <View style={styles.stateIcon}>
              <Bell size={24} color={colors.statusRed} />
            </View>
            <Text style={styles.stateTitle}>Host unreachable</Text>
            <Text style={styles.stateMessage}>{screen.message}</Text>
          </View>
        </View>
      ) : (
        <FlatList
          data={screen.items}
          keyExtractor={(item) => `${item.executionHostId}:${item.entry.round.id}`}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: insets.bottom + spacing.xl },
            screen.items.length === 0 && { flexGrow: 1 }
          ]}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => void refresh(true)}
              tintColor={colors.textSecondary}
            />
          }
          ListHeaderComponent={
            screen.warnings.length > 0 ? (
              <View style={styles.warning}>
                <Text style={styles.warningText}>
                  Some authorities could not be loaded. Showing verified results from the others.
                  {'\n'}
                  {screen.warnings.join('\n')}
                </Text>
              </View>
            ) : null
          }
          ListEmptyComponent={
            <View style={styles.stateWrap}>
              <View style={styles.stateCard}>
                <View style={styles.stateIcon}>
                  <Bell size={24} color={colors.statusGreen} />
                </View>
                <Text style={styles.stateTitle}>Nothing is waiting</Text>
                <Text style={styles.stateMessage}>
                  Waiting items remain authoritative on the host and will appear here when needed.
                </Text>
              </View>
            </View>
          }
          renderItem={({ item }) => {
            const row = buildMobileIssuePendingRow(item.executionHostId, item.entry)
            return (
              <Pressable
                style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}
                onPress={() => openItem(item)}
                accessibilityRole="button"
                accessibilityLabel={`Open ${row.conversationTitle}`}
              >
                <View style={styles.rowTop}>
                  {row.isUnread ? <View style={styles.unreadDot} /> : null}
                  <Text style={styles.rowTitle} numberOfLines={1}>
                    {row.issueTitle}
                  </Text>
                  <ChevronRight size={16} color={colors.textMuted} />
                </View>
                <Text style={styles.rowMeta} numberOfLines={1}>
                  {row.conversationTitle} · {row.workspaceName}
                </Text>
                {row.preview ? (
                  <Text style={styles.preview} numberOfLines={3}>
                    {row.preview}
                  </Text>
                ) : null}
                <Text style={styles.captureLabel}>
                  {row.captureLabel} · {formatOccurredAt(row.occurredAt)}
                </Text>
              </Pressable>
            )
          }}
        />
      )}
    </SafeAreaView>
  )
}
