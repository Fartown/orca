import { ROUND_BODY_CHUNK_MAX_BYTES } from '../../shared/issues/constants'
import { buildAttentionPreservingIssueRows } from '../../shared/issues/attention'
import type {
  ConversationPage,
  ConversationSummary,
  IssueDetail,
  IssueListFilter,
  IssueListResult,
  IssueSummary,
  RoundRecord,
  RoundRecordBodyField,
  RoundRecordBodyReadResult,
  RoundRecordPage
} from '../../shared/issues/types'
import {
  getUtf8ByteLength,
  getUtf8ChunkEndIndex
} from '../../shared/utf8-byte-limits'
import type { IssueAuthorityRoute } from './issue-authority-route'
import { issueAuthorityDescriptor } from './issue-authority-route'
import type { IssueDatabase } from './issue-database'
import { listIssueDigestsForIssue } from './issue-digest-record'
import { buildIssueDigestSnapshot } from './issue-digest-snapshot'
import { buildIssueListPage } from './issue-list-snapshot'
import {
  encodeIssueQueryCursor,
  readIssueListCursor,
  readTimelineCursor
} from './issue-query-cursor'
import {
  compareIssueSummaryOrder,
  getRoundForRoute,
  readConversationSummaries,
  readHostRevisions,
  readIssueSummaryCounts,
  readUnassignedSummary,
  toRoundRecordPreview,
  uniqueWorkspaceSnapshots,
  utf8IndexAtByteOffset
} from './issue-query-projections'
import { issueFromRow, roundRecordFromRow } from './issue-row-mappers'
import type { IssueRow, RoundRecordRow } from './issue-row-mappers'
import { IssueRepositoryError } from './issue-repository-error'

type RoundBodyFallback = (input: {
  round: RoundRecord
  field: RoundRecordBodyField
}) => string | null

const EMPTY_COUNTS = {
  ownUnresolvedCount: 0,
  directConversationCount: 0,
  activeConversationCount: 0
}

export class IssueQueryService {
  constructor(
    private readonly database: IssueDatabase,
    private readonly readRoundBodyFallback?: RoundBodyFallback
  ) {}

  list(
    route: IssueAuthorityRoute,
    params:
      | {
          mode: 'start'
          filter: IssueListFilter
          sinceFactsRevision?: number
          limit: number
        }
      | {
          mode: 'continue'
          filter: IssueListFilter
          snapshotFactsRevision: number
          snapshotTreeRevision: number
          cursor: string
          limit: number
        }
  ): IssueListResult {
    return this.database.readTransaction(() => {
      const revisions = readHostRevisions(this.database, route.hostPartitionKey)
      const authority = issueAuthorityDescriptor(this.database, route)
      if (params.mode === 'start' && params.sinceFactsRevision === revisions.factsRevision) {
        return {
          status: 'not-modified',
          authority,
          factsRevision: revisions.factsRevision,
          treeRevision: revisions.treeRevision
        }
      }
      if (
        params.mode === 'continue' &&
        (params.snapshotFactsRevision !== revisions.factsRevision ||
          params.snapshotTreeRevision !== revisions.treeRevision)
      ) {
        return {
          status: 'stale',
          authority,
          factsRevision: revisions.factsRevision,
          treeRevision: revisions.treeRevision
        }
      }

      const summaries = this.listIssueSummaries(route)
      const projected = buildAttentionPreservingIssueRows(summaries, params.filter).rows.map(
        ({ issue, descendantAttentionCount }) => ({
          ...issue,
          descendantAttentionCount,
          executionHostId: route.routeExecutionHostId
        })
      )
      const startIndex =
        params.mode === 'start'
          ? 0
          : readIssueListCursor(params.cursor, {
              filter: params.filter,
              revisions,
              issues: projected
            })
      return buildIssueListPage({
        authority,
        revisions,
        filter: params.filter,
        issues: projected,
        unassigned:
          startIndex === 0
            ? readUnassignedSummary(this.database, route.hostPartitionKey)
            : undefined,
        startIndex,
        limit: params.limit
      })
    })
  }

  get(route: IssueAuthorityRoute, issueId: string): IssueDetail {
    return this.database.readTransaction(() => {
      const summaries = this.listIssueSummaries(route)
      const summaryById = new Map(summaries.map((summary) => [summary.id, summary]))
      const issue = summaryById.get(issueId)
      if (!issue) {
        throw new IssueRepositoryError('issue_not_found', `Issue ${issueId} was not found.`)
      }
      const projected = buildAttentionPreservingIssueRows(summaries, 'all')
      const descendantById = new Map(
        projected.rows.map((row) => [row.issue.id, row.descendantAttentionCount])
      )
      const stamp = (value: IssueSummary): IssueSummary => ({
        ...value,
        descendantAttentionCount: descendantById.get(value.id) ?? 0,
        executionHostId: route.routeExecutionHostId
      })
      const directConversations = this.listConversationSummaries(
        route,
        'WHERE conversation.host_partition_key = ? AND conversation.issue_id = ?',
        [route.hostPartitionKey, issueId]
      )
      const digests = listIssueDigestsForIssue(this.database, issueId)
      const latestConfirmed =
        digests.find((digest) => digest.status === 'confirmed') ?? null
      const latestAttempt =
        digests.find(
          (digest) =>
            digest.status !== 'confirmed' &&
            (!latestConfirmed || digest.version > latestConfirmed.version)
        ) ?? null
      const coversUntil = Math.max(
        Date.now(),
        latestConfirmed?.coversUntil ?? 0,
        latestAttempt?.coversUntil ?? 0
      )
      const currentInputFingerprint = buildIssueDigestSnapshot(
        this.database,
        issue,
        coversUntil
      ).inputFingerprint
      return {
        authority: issueAuthorityDescriptor(this.database, route),
        issue: stamp(issue),
        directChildren: summaries
          .filter((candidate) => candidate.parentId === issueId)
          .sort(compareIssueSummaryOrder)
          .map(stamp),
        directConversations,
        workspaceSnapshots: uniqueWorkspaceSnapshots(directConversations),
        digest: {
          latestConfirmed,
          latestAttempt,
          currentInputFingerprint,
          latestConfirmedIsStale:
            latestConfirmed !== null &&
            latestConfirmed.inputFingerprint !== currentInputFingerprint
        }
      }
    })
  }

  getConversation(
    route: IssueAuthorityRoute,
    conversationId: string
  ): ConversationSummary {
    return this.database.readTransaction(() => {
      const [conversation] = this.listConversationSummaries(
        route,
        `WHERE conversation.host_partition_key = ?
           AND conversation.id = ?`,
        [route.hostPartitionKey, conversationId]
      )
      if (!conversation) {
        throw new IssueRepositoryError(
          'conversation_not_found',
          `Conversation ${conversationId} was not found.`
        )
      }
      return conversation
    })
  }

  listUnassigned(
    route: IssueAuthorityRoute,
    params: { cursor?: string; limit: number }
  ): ConversationPage {
    return this.database.readTransaction(() => {
      const revisions = readHostRevisions(this.database, route.hostPartitionKey)
      const cursor = params.cursor
        ? readTimelineCursor(params.cursor, 'conversation-list', revisions.factsRevision)
        : null
      const conversations = this.listConversationSummaries(
        route,
        `WHERE conversation.host_partition_key = ?
           AND conversation.issue_id IS NULL`,
        [route.hostPartitionKey]
      ).filter((conversation) =>
        cursor
          ? conversation.updatedAt < cursor.occurredAt ||
            (conversation.updatedAt === cursor.occurredAt &&
              conversation.id.localeCompare(cursor.id) < 0)
          : true
      )
      const page = conversations.slice(0, params.limit)
      const last = page.at(-1)
      return {
        authority: issueAuthorityDescriptor(this.database, route),
        snapshotFactsRevision: revisions.factsRevision,
        conversations: page,
        nextCursor:
          conversations.length > page.length && last
            ? encodeIssueQueryCursor({
                v: 1,
                kind: 'conversation-list',
                factsRevision: revisions.factsRevision,
                occurredAt: last.updatedAt,
                id: last.id
              })
            : null
      }
    })
  }

  listRounds(
    route: IssueAuthorityRoute,
    params: {
      issueId?: string
      conversationId?: string
      cursor?: string
      limit: number
    }
  ): RoundRecordPage {
    return this.database.readTransaction(() => {
      const revisions = readHostRevisions(this.database, route.hostPartitionKey)
      const cursor = params.cursor
        ? readTimelineCursor(params.cursor, 'round-list', revisions.factsRevision)
        : null
      const rows = this.database
        .prepare(
          `SELECT round.*
           FROM round_record_effective_state round
           JOIN conversations conversation ON conversation.id = round.conversation_id
           WHERE conversation.host_partition_key = ?
             AND (
               (? IS NOT NULL AND conversation.issue_id = ?) OR
               (? IS NOT NULL AND conversation.id = ?)
             )
           ORDER BY round.occurred_at DESC, round.id DESC`
        )
        .all(
          route.hostPartitionKey,
          params.issueId ?? null,
          params.issueId ?? null,
          params.conversationId ?? null,
          params.conversationId ?? null
        ) as RoundRecordRow[]
      const rounds = rows
        .map(roundRecordFromRow)
        .filter((round) =>
          cursor
            ? round.occurredAt < cursor.occurredAt ||
              (round.occurredAt === cursor.occurredAt &&
                round.id.localeCompare(cursor.id) < 0)
            : true
        )
      const page = rounds.slice(0, params.limit).map(toRoundRecordPreview)
      const last = page.at(-1)
      return {
        authority: issueAuthorityDescriptor(this.database, route),
        snapshotFactsRevision: revisions.factsRevision,
        rounds: page,
        nextCursor:
          rounds.length > page.length && last
            ? encodeIssueQueryCursor({
                v: 1,
                kind: 'round-list',
                factsRevision: revisions.factsRevision,
                occurredAt: last.occurredAt,
                id: last.id
              })
            : null
      }
    })
  }

  readRoundBody(
    route: IssueAuthorityRoute,
    params: {
      roundRecordId: string
      field: RoundRecordBodyField
      expectedBodyRevision: number
      expectedStorage?: RoundRecord['userInput']['storage']
      offset: number
      maxBytes: number
      allowTranscriptFallback?: boolean
    }
  ): RoundRecordBodyReadResult {
    return this.database.readTransaction(() => {
      const round = getRoundForRoute(
        this.database,
        route.hostPartitionKey,
        params.roundRecordId
      )
      const body = round[params.field]
      const base = {
        roundRecordId: round.id,
        field: params.field,
        bodyRevision: round.bodyRevision,
        storage: body.storage,
        completeness: body.completeness
      } as const
      if (
        round.bodyRevision !== params.expectedBodyRevision ||
        (params.expectedStorage !== undefined && body.storage !== params.expectedStorage)
      ) {
        return { status: 'stale', ...base }
      }
      const text =
        body.text ??
        (params.allowTranscriptFallback
          ? this.readRoundBodyFallback?.({ round, field: params.field }) ?? null
          : null)
      if (text === null) {
        return { status: 'unavailable', ...base }
      }
      const maxBytes = Math.min(params.maxBytes, ROUND_BODY_CHUNK_MAX_BYTES)
      const startIndex = utf8IndexAtByteOffset(text, params.offset)
      const endIndex = getUtf8ChunkEndIndex(text, startIndex, maxBytes)
      const chunk = text.slice(startIndex, endIndex)
      const nextOffset = params.offset + getUtf8ByteLength(chunk)
      return {
        status: 'body-chunk',
        ...base,
        offset: params.offset,
        nextOffset,
        eof: endIndex === text.length,
        text: chunk
      }
    })
  }

  private listIssueSummaries(route: IssueAuthorityRoute): IssueSummary[] {
    const rows = this.database
      .prepare(
        `SELECT *
         FROM issues
         WHERE host_partition_key = ?
         ORDER BY parent_id, sibling_order, id`
      )
      .all(route.hostPartitionKey) as IssueRow[]
    const counts = readIssueSummaryCounts(this.database, route.hostPartitionKey)
    return rows.map((row) => {
      const issue = issueFromRow(row)
      return {
        ...issue,
        ...EMPTY_COUNTS,
        ...(counts.get(issue.id) ?? {}),
        descendantAttentionCount: 0
      }
    })
  }

  private listConversationSummaries(
    route: IssueAuthorityRoute,
    where: string,
    bindings: readonly (string | number | null)[]
  ): ConversationSummary[] {
    return readConversationSummaries(this.database, route, where, bindings)
  }
}
