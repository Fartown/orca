import { createHash } from 'node:crypto'
import {
  ISSUE_SEARCH_PAGE_MAX_MATCHES,
  ISSUE_SEARCH_PREVIEW_MAX_BYTES
} from '../../shared/issues/constants'
import type {
  AuthorityHostPartitionKey,
  IssueDisplayProjection,
  IssueSearchCompleteness,
  IssueSearchEntityKind,
  IssueSearchMatch,
  IssueSearchResult
} from '../../shared/issues/types'
import { clampUtf8TextPrefix } from '../../shared/utf8-byte-limits'
import { issueAuthorityDescriptor, type IssueAuthorityRoute } from './issue-authority-route'
import type { IssueDatabase } from './issue-database'
import {
  buildIssueSearchDocuments,
} from './issue-search-document-builder'
import { ensureIssueHostState, getIssueHostRevisions } from './issue-host-state'
import { readHostRevisions } from './issue-query-projections'
import { IssueRepositoryError } from './issue-repository-error'

type SearchRow = {
  rowid: number
  entity_kind: IssueSearchEntityKind
  entity_id: string
  issue_id: string | null
  title: string
  body: string
  completeness: IssueSearchCompleteness | null
}

type SearchCursor = {
  version: 1
  queryHash: string
  indexedSearchRevision: number
  offset: number
}

export class IssueSearchIndex {
  constructor(private readonly database: IssueDatabase) {}

  drain(hostPartitionKey: AuthorityHostPartitionKey): void {
    this.database.transaction(() => {
      ensureIssueHostState(this.database, hostPartitionKey, Date.now())
      const revisions = getIssueHostRevisions(this.database, hostPartitionKey)
      if (
        revisions.searchRevision === revisions.indexedSearchRevision &&
        this.isIntegrityValid()
      ) {
        this.clearCoveredQueue(hostPartitionKey, revisions.searchRevision)
        return
      }
      this.rebuildPartition(hostPartitionKey, revisions.searchRevision)
    })
  }

  search(
    route: IssueAuthorityRoute,
    params: { query: string; cursor?: string; limit: number }
  ): IssueSearchResult {
    return this.database.readTransaction(() => {
      const revisions = readHostRevisions(this.database, route.hostPartitionKey)
      const query = params.query.trim()
      const cursor = params.cursor
        ? decodeSearchCursor(params.cursor, query, revisions.indexedSearchRevision)
        : { offset: 0 }
      const singleCjkFallback = isSingleCjkQuery(query)
      const limit = Math.min(params.limit, ISSUE_SEARCH_PAGE_MAX_MATCHES)
      const rows = singleCjkFallback
        ? this.searchSingleCjk(route.hostPartitionKey, query, cursor.offset, limit + 1)
        : this.searchFts(route.hostPartitionKey, query, cursor.offset, limit + 1)
      const page = rows.slice(0, limit)
      return {
        authority: issueAuthorityDescriptor(this.database, route),
        searchRevision: revisions.searchRevision,
        indexedSearchRevision: revisions.indexedSearchRevision,
        isStale: revisions.searchRevision !== revisions.indexedSearchRevision,
        partial: singleCjkFallback,
        groups: groupMatches(page.map(toSearchMatch), this.readIssueProjections(page)),
        nextCursor:
          rows.length > limit
            ? encodeSearchCursor({
                version: 1,
                queryHash: hashQuery(query),
                indexedSearchRevision: revisions.indexedSearchRevision,
                offset: cursor.offset + limit
              })
            : null
      }
    })
  }

  private rebuildPartition(
    hostPartitionKey: AuthorityHostPartitionKey,
    indexedRevision: number
  ): void {
    this.database
      .prepare('DELETE FROM issue_search_documents WHERE host_partition_key = ?')
      .run(hostPartitionKey)
    const insert = this.database.prepare(
      `INSERT INTO issue_search_documents (
         host_partition_key, issue_id, entity_kind, entity_id,
         title, body, keywords, completeness, indexed_revision
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    for (const document of buildIssueSearchDocuments(this.database, hostPartitionKey)) {
      insert.run(
        hostPartitionKey,
        document.issueId,
        document.entityKind,
        document.entityId,
        document.title,
        document.body,
        document.keywords,
        document.completeness,
        indexedRevision
      )
    }
    this.database.exec(`INSERT INTO issue_search_fts(issue_search_fts) VALUES('rebuild')`)
    this.database
      .prepare(
        `UPDATE issue_host_state
         SET indexed_search_revision = ?,
             search_index_dirty = 0,
             updated_at = ?
         WHERE host_partition_key = ?`
      )
      .run(indexedRevision, Date.now(), hostPartitionKey)
    this.clearCoveredQueue(hostPartitionKey, indexedRevision)
  }

  private searchFts(
    hostPartitionKey: AuthorityHostPartitionKey,
    query: string,
    offset: number,
    limit: number
  ): SearchRow[] {
    const matchExpression = buildFtsMatchExpression(query)
    if (!matchExpression) {
      return []
    }
    return this.database
      .prepare(
        `SELECT document.rowid, document.entity_kind, document.entity_id,
                document.issue_id, document.title, document.body,
                document.completeness
         FROM issue_search_fts
         JOIN issue_search_documents document
           ON document.rowid = issue_search_fts.rowid
         WHERE issue_search_fts MATCH ?
           AND document.host_partition_key = ?
         ORDER BY bm25(issue_search_fts), document.rowid
         LIMIT ? OFFSET ?`
      )
      .all(matchExpression, hostPartitionKey, limit, offset) as SearchRow[]
  }

  private searchSingleCjk(
    hostPartitionKey: AuthorityHostPartitionKey,
    query: string,
    offset: number,
    limit: number
  ): SearchRow[] {
    const pattern = `%${escapeLike(query)}%`
    return this.database
      .prepare(
        `SELECT rowid, entity_kind, entity_id, issue_id, title, body, completeness
         FROM issue_search_documents
         WHERE host_partition_key = ?
           AND (title LIKE ? ESCAPE '\\' OR body LIKE ? ESCAPE '\\')
         ORDER BY rowid
         LIMIT ? OFFSET ?`
      )
      .all(hostPartitionKey, pattern, pattern, limit, offset) as SearchRow[]
  }

  private readIssueProjections(rows: readonly SearchRow[]): Map<string, IssueDisplayProjection> {
    const ids = [...new Set(rows.flatMap((row) => (row.issue_id ? [row.issue_id] : [])))]
    const projections = new Map<string, IssueDisplayProjection>()
    const statement = this.database.prepare(
      `SELECT id, COALESCE(local_title, source_title, '') AS title,
              type_label AS typeLabel, state
       FROM issues WHERE id = ?`
    )
    for (const id of ids) {
      const issue = statement.get(id) as IssueDisplayProjection | undefined
      if (issue) {
        projections.set(id, issue)
      }
    }
    return projections
  }

  private isIntegrityValid(): boolean {
    try {
      this.database.exec(
        `INSERT INTO issue_search_fts(issue_search_fts, rank)
         VALUES('integrity-check', 1)`
      )
      return true
    } catch {
      return false
    }
  }

  private clearCoveredQueue(
    hostPartitionKey: AuthorityHostPartitionKey,
    indexedRevision: number
  ): void {
    this.database
      .prepare(
        `DELETE FROM issue_search_rebuild_queue
         WHERE host_partition_key = ? AND requested_revision <= ?`
      )
      .run(hostPartitionKey, indexedRevision)
  }
}

export class IssueSearchIndexWorker {
  private readonly pending = new Set<AuthorityHostPartitionKey>()
  private timer: ReturnType<typeof setTimeout> | null = null
  private closed = false

  constructor(private readonly index: IssueSearchIndex) {}

  schedule(hostPartitionKey: AuthorityHostPartitionKey): void {
    if (this.closed) {
      return
    }
    this.pending.add(hostPartitionKey)
    this.timer ??= setTimeout(() => this.flush(), 0)
  }

  close(): void {
    this.closed = true
    this.pending.clear()
    if (this.timer) {
      clearTimeout(this.timer)
      this.timer = null
    }
  }

  private flush(): void {
    this.timer = null
    for (const hostPartitionKey of [...this.pending]) {
      this.pending.delete(hostPartitionKey)
      try {
        this.index.drain(hostPartitionKey)
      } catch (error) {
        console.error('[issues] search index rebuild failed', error)
      }
    }
  }
}

function buildFtsMatchExpression(query: string): string {
  const tokens = query.match(/\p{Script=Han}+|[\p{L}\p{N}_-]+/gu) ?? []
  return tokens
    .flatMap((token) => {
      if (/\p{Script=Han}/u.test(token)) {
        const characters = [...token]
        if (characters.length < 2) {
          return []
        }
        const bigrams: string[] = []
        for (let index = 0; index + 1 < characters.length; index += 1) {
          bigrams.push(`${characters[index]}${characters[index + 1]}`)
        }
        return [`"${bigrams.join(' ')}"`]
      }
      return [`"${token.replaceAll('"', '""')}"*`]
    })
    .join(' AND ')
}

function groupMatches(
  matches: readonly IssueSearchMatch[],
  issues: ReadonlyMap<string, IssueDisplayProjection>
): IssueSearchResult['groups'] {
  const groups = new Map<string, IssueSearchResult['groups'][number]>()
  for (const match of matches) {
    const key = match.issueId ?? 'unassigned'
    const group = groups.get(key) ?? {
      issue: match.issueId ? (issues.get(match.issueId) ?? null) : null,
      matches: []
    }
    group.matches.push(match)
    groups.set(key, group)
  }
  return [...groups.values()]
}

function toSearchMatch(row: SearchRow): IssueSearchMatch {
  return {
    entityKind: row.entity_kind,
    entityId: row.entity_id,
    issueId: row.issue_id,
    title: clampUtf8TextPrefix(row.title, ISSUE_SEARCH_PREVIEW_MAX_BYTES),
    preview: clampUtf8TextPrefix(row.body, ISSUE_SEARCH_PREVIEW_MAX_BYTES),
    completeness: row.completeness
  }
}

function encodeSearchCursor(cursor: SearchCursor): string {
  return Buffer.from(JSON.stringify(cursor)).toString('base64url')
}

function decodeSearchCursor(
  encoded: string,
  query: string,
  indexedSearchRevision: number
): Pick<SearchCursor, 'offset'> {
  try {
    const cursor = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SearchCursor
    if (
      cursor.version !== 1 ||
      cursor.queryHash !== hashQuery(query) ||
      cursor.indexedSearchRevision !== indexedSearchRevision ||
      !Number.isSafeInteger(cursor.offset) ||
      cursor.offset < 0
    ) {
      throw new Error('stale')
    }
    return { offset: cursor.offset }
  } catch {
    throw new IssueRepositoryError(
      'issue_cursor_invalid',
      'Issue search cursor no longer matches the indexed revision.'
    )
  }
}

function hashQuery(query: string): string {
  return createHash('sha256').update(query).digest('hex')
}

function isSingleCjkQuery(query: string): boolean {
  return /^\p{Script=Han}$/u.test(query)
}

function escapeLike(value: string): string {
  return value.replaceAll('\\', '\\\\').replaceAll('%', '\\%').replaceAll('_', '\\_')
}
