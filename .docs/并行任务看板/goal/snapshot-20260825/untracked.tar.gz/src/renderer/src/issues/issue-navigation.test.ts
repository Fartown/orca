import { describe, expect, it } from 'vitest'
import type { IssueAuthorityDescriptor } from '../../../shared/issues/types'
import type { ExecutionHostId } from '../../../shared/execution-host'
import type { WorktreeNavHistoryViewEntry } from '../store/slices/worktree-nav-history'
import {
  issueNavigationHistoryEntry,
  openIssueDetail,
  replayIssueDetailHistoryEntry,
  type IssueNavigationDependencies
} from './issue-navigation'

const authority: IssueAuthorityDescriptor = {
  authorityId: 'authority-a',
  hostPartitionKey: 'local',
  routeExecutionHostId: 'runtime:relay-a'
}

function navigationHarness(isNavigatingHistory = false): {
  dependencies: IssueNavigationDependencies
  read: () => {
    activeView: string
    history: WorktreeNavHistoryViewEntry[]
    selected: {
      routeExecutionHostId: ExecutionHostId | null
      issueId: string | null
    } | null
  }
} {
  let activeView = 'tasks'
  const history: WorktreeNavHistoryViewEntry[] = []
  let selected: {
    routeExecutionHostId: ExecutionHostId | null
    issueId: string | null
  } | null = null
  return {
    dependencies: {
      getAppState: () => ({
        isNavigatingHistory,
        openIssuesPage: () => {
          activeView = 'issues'
        },
        recordViewVisit: (entry) => {
          history.push(entry)
        },
        setActiveView: (view) => {
          activeView = view
        }
      }),
      getIssuesState: () => ({
        selectIssue: (routeExecutionHostId, issueId) => {
          selected = { routeExecutionHostId, issueId }
        }
      })
    },
    read: () => ({ activeView, history, selected })
  }
}

describe('Issue navigation', () => {
  it('selects the authority route, opens Issues, and records its stable identity', () => {
    const harness = navigationHarness()

    openIssueDetail(
      {
        authority,
        issueId: '11111111-1111-4111-8111-111111111111'
      },
      harness.dependencies
    )

    expect(harness.read()).toEqual({
      activeView: 'issues',
      history: [
        issueNavigationHistoryEntry({
          authority,
          issueId: '11111111-1111-4111-8111-111111111111'
        })
      ],
      selected: {
        routeExecutionHostId: 'runtime:relay-a',
        issueId: '11111111-1111-4111-8111-111111111111'
      }
    })
  })

  it('replays a history entry without appending another entry', () => {
    const harness = navigationHarness(true)
    const entry = issueNavigationHistoryEntry({
      authority,
      issueId: '22222222-2222-4222-8222-222222222222'
    })

    replayIssueDetailHistoryEntry(entry, harness.dependencies)

    expect(harness.read()).toEqual({
      activeView: 'issues',
      history: [],
      selected: {
        routeExecutionHostId: 'runtime:relay-a',
        issueId: '22222222-2222-4222-8222-222222222222'
      }
    })
  })
})
