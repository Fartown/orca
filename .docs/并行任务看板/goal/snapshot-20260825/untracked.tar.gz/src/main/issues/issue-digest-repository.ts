import type {
  IssueDigestInputSummary,
  IssueDigestRecord,
  IssueDigestSections
} from '../../shared/issues/digest-types'
import type { IssueMutationIdentity, IssueRecord } from '../../shared/issues/types'
import type { TuiAgent } from '../../shared/tui-agent'
import type { IssueDatabase } from './issue-database'
import {
  checkAndConfirmIssueDigest,
  confirmIssueDigest,
  updateIssueDigestDraft
} from './issue-digest-draft-state'
import {
  cancelIssueDigestGeneration,
  createCheckedGeneratingIssueDigest,
  createGeneratingIssueDigest,
  finishIssueDigestGeneration,
  recoverInterruptedIssueDigests
} from './issue-digest-generation-state'
import {
  getIssueDigest,
  listIssueDigestsForIssue,
  requireIssueDigest
} from './issue-digest-record'
import type { IssueEventRepository } from './issue-event-repository'

export class IssueDigestRepository {
  constructor(
    private readonly database: IssueDatabase,
    private readonly events: IssueEventRepository
  ) {}

  recoverInterrupted(): string[] {
    return recoverInterruptedIssueDigests(this.database)
  }

  get(id: string): IssueDigestRecord | undefined {
    return getIssueDigest(this.database, id)
  }

  require(id: string): IssueDigestRecord {
    return requireIssueDigest(this.database, id)
  }

  listForIssue(issueId: string): IssueDigestRecord[] {
    return listIssueDigestsForIssue(this.database, issueId)
  }

  createGenerating(params: {
    identity: IssueMutationIdentity
    issue: IssueRecord
    agent: TuiAgent
    coversUntil: number
    inputFingerprint: string
    coverageNote: string | null
    inputs: IssueDigestInputSummary[]
  }): { digest: IssueDigestRecord; replayed: boolean } {
    return createGeneratingIssueDigest(this.database, params)
  }

  createGeneratingChecked<
    Snapshot extends {
      inputFingerprint: string
      coverageNote: string | null
      inputs: IssueDigestInputSummary[]
    }
  >(params: {
    identity: IssueMutationIdentity
    issue: IssueRecord
    agent: TuiAgent
    coversUntil: number
    expectedInputFingerprint: string
    resolveSnapshot: () => Snapshot
  }): { digest: IssueDigestRecord; replayed: boolean; snapshot?: Snapshot } {
    return createCheckedGeneratingIssueDigest(this.database, params)
  }

  completeGeneration(id: string, sections: IssueDigestSections): IssueDigestRecord {
    return finishIssueDigestGeneration(this.database, id, {
      status: 'draft',
      sections,
      error: null,
      searchable: true
    })
  }

  failGeneration(id: string, error: string): IssueDigestRecord {
    return finishIssueDigestGeneration(this.database, id, {
      status: 'failed',
      sections: null,
      error,
      searchable: false
    })
  }

  cancel(params: {
    identity: IssueMutationIdentity
    digestId: string
  }): { digest: IssueDigestRecord; changed: boolean; replayed: boolean } {
    return cancelIssueDigestGeneration(this.database, params)
  }

  updateDraft(params: {
    identity: IssueMutationIdentity
    digestId: string
    expectedRevision: number
    patch: Partial<IssueDigestSections>
  }): IssueDigestRecord {
    return updateIssueDigestDraft(this.database, params)
  }

  confirm(params: {
    identity: IssueMutationIdentity
    digestId: string
    expectedRevision: number
    stale: boolean
    currentInputFingerprint: string
  }): IssueDigestRecord {
    return confirmIssueDigest(this.database, this.events, params)
  }

  confirmChecked(params: {
    identity: IssueMutationIdentity
    digestId: string
    expectedRevision: number
    inputFingerprint: string
    confirmStaleAgainstFingerprint?: string
    resolveCurrentInputFingerprint: () => string
  }) {
    return checkAndConfirmIssueDigest(this.database, this.events, params)
  }
}
