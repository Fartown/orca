import { BrowserWindow, ipcMain } from 'electron'
import type { IssueClientDataService } from '../issues/issue-client-data-service'
import type { IssueRuntimeService } from '../issues/issue-runtime-service'

export function registerIssueClientDataHandlers(
  service: IssueClientDataService,
  factsSource: Pick<IssueRuntimeService, 'onFactsChanged'>
): () => void {
  ipcMain.removeHandler('issues:readCache')
  ipcMain.removeHandler('issues:replaceCache')
  ipcMain.removeHandler('issues:readPreferences')
  ipcMain.removeHandler('issues:writePreferences')

  ipcMain.handle('issues:readCache', (_event, args: unknown) =>
    service.readCache(args)
  )
  ipcMain.handle('issues:replaceCache', (_event, args: unknown) =>
    service.replaceCache(args)
  )
  ipcMain.handle('issues:readPreferences', () => service.readPreferences())
  ipcMain.handle('issues:writePreferences', (_event, value: unknown) =>
    service.writePreferences(value)
  )

  return factsSource.onFactsChanged((event) => {
    for (const window of BrowserWindow.getAllWindows()) {
      if (window.isDestroyed() || window.webContents.isDestroyed()) {
        continue
      }
      try {
        window.webContents.send('issues:factsChanged', event)
      } catch (error) {
        console.warn('[issues] failed to broadcast facts change', error)
      }
    }
  })
}
