import React from 'react'
import {
  AlertCircle,
  Archive,
  ChevronDown,
  ChevronRight,
  CircleDot,
  Folder,
  FileSearch,
  Loader2,
  MessageSquare,
  Server
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { ExecutionHostId } from '../../../../../shared/execution-host'
import { getIssueDisplayTitle } from '../../../issues/issue-display'
import type { IssueSidebarRow } from './issue-row-types'

type IssueVirtualRowProps = {
  row: IssueSidebarRow
  hostLabelById: ReadonlyMap<ExecutionHostId, string>
  selectedIssueId: string | null
  unassignedLoaded: boolean
  onToggleIssue: (row: Extract<IssueSidebarRow, { type: 'issue' }>) => void
  onSelectIssue: (row: Extract<IssueSidebarRow, { type: 'issue' }>) => void
  onToggleUnassigned: (
    row: Extract<IssueSidebarRow, { type: 'unassigned-summary' }>
  ) => void
  onSelectConversation: (
    row: Extract<IssueSidebarRow, { type: 'conversation' }>
  ) => void
  onSelectSearchResult: (
    row: Extract<IssueSidebarRow, { type: 'search-result' }>
  ) => void
}

export const IssueVirtualRow = React.memo(function IssueVirtualRow({
  row,
  hostLabelById,
  selectedIssueId,
  unassignedLoaded,
  onToggleIssue,
  onSelectIssue,
  onToggleUnassigned,
  onSelectConversation,
  onSelectSearchResult
}: IssueVirtualRowProps): React.JSX.Element {
  switch (row.type) {
    case 'host-state':
      return (
        <HostStateRow
          label={hostLabelById.get(row.routeExecutionHostId) ?? row.routeExecutionHostId}
          status={row.status}
          error={row.error}
        />
      )
    case 'issue':
      return (
        <IssueRow
          row={row}
          selected={selectedIssueId === row.issue.id}
          onToggle={() => onToggleIssue(row)}
          onSelect={() => onSelectIssue(row)}
        />
      )
    case 'workspace-header':
      return (
        <div
          className="flex h-6 min-w-0 items-center gap-1.5 pr-2 text-[11px] text-muted-foreground"
          style={{ paddingLeft: rowIndent(row.depth) }}
        >
          <Folder className="size-3 shrink-0" />
          <span className="min-w-0 flex-1 truncate">{row.workspace.name}</span>
          <span className="tabular-nums">{row.count}</span>
        </div>
      )
    case 'conversation':
      return (
        <button
          type="button"
          className="flex h-7 w-full min-w-0 items-center gap-1.5 rounded-sm pr-2 text-left text-xs hover:bg-worktree-sidebar-accent focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          style={{ paddingLeft: rowIndent(row.depth) }}
          onClick={() => onSelectConversation(row)}
        >
          <MessageSquare className="size-3 shrink-0 text-muted-foreground" />
          <span className="min-w-0 flex-1 truncate">
            {row.conversation.title || 'Untitled conversation'}
          </span>
          {row.conversation.unresolvedRoundCount > 0 ? (
            <AttentionCount count={row.conversation.unresolvedRoundCount} />
          ) : null}
        </button>
      )
    case 'unassigned-summary': {
      const expanded = row.expanded && unassignedLoaded
      return (
        <button
          type="button"
          className="mt-1 flex h-8 w-full min-w-0 items-center gap-1.5 border-t border-border/60 px-2 text-left text-xs hover:bg-worktree-sidebar-accent focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          aria-expanded={expanded}
          onClick={() => onToggleUnassigned(row)}
        >
          {expanded ? (
            <ChevronDown className="size-3 shrink-0 text-muted-foreground" />
          ) : (
            <ChevronRight className="size-3 shrink-0 text-muted-foreground" />
          )}
          <span className="min-w-0 flex-1 truncate">Unassigned</span>
          <span className="tabular-nums text-muted-foreground">
            {row.conversationCount}
          </span>
          {row.unresolvedCount > 0 ? (
            <AttentionCount count={row.unresolvedCount} />
          ) : null}
        </button>
      )
    }
    case 'empty':
      return (
        <div className="px-4 py-8 text-center text-xs text-muted-foreground">
          {row.filter === 'needs-me'
            ? 'Nothing needs your attention.'
            : row.filter === 'archived'
              ? 'No archived Issues.'
              : 'No active Issues.'}
        </div>
      )
    case 'search-status':
      return (
        <div className="flex min-h-7 flex-wrap items-center gap-1 px-2 py-1 text-[11px] text-muted-foreground">
          {row.isStale ? (
            <span className="rounded-sm bg-muted px-1.5 py-0.5">
              Search index updating
            </span>
          ) : null}
          {row.partial ? (
            <span className="rounded-sm bg-muted px-1.5 py-0.5">
              Partial search
            </span>
          ) : null}
        </div>
      )
    case 'search-group':
      return (
        <div className="flex h-7 items-center gap-1.5 px-2 text-[11px] font-medium text-muted-foreground">
          <CircleDot className="size-3 shrink-0" />
          <span className="min-w-0 flex-1 truncate">
            {row.issue?.title ?? 'Unassigned conversations'}
          </span>
        </div>
      )
    case 'search-result':
      return (
        <button
          type="button"
          className="flex min-h-10 w-full min-w-0 items-start gap-2 rounded-sm px-3 py-1.5 text-left hover:bg-worktree-sidebar-accent focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          onClick={() => onSelectSearchResult(row)}
        >
          <FileSearch className="mt-0.5 size-3 shrink-0 text-muted-foreground" />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-xs">{row.match.title}</span>
            <span className="block truncate text-[11px] text-muted-foreground">
              {searchMatchLabel(row)}
            </span>
            {row.match.preview ? (
              <span className="mt-0.5 block line-clamp-2 text-[11px] leading-4 text-muted-foreground">
                {row.match.preview}
              </span>
            ) : null}
          </span>
        </button>
      )
    case 'search-empty':
      return (
        <div className="px-4 py-8 text-center text-xs text-muted-foreground">
          No matching Issue records.
        </div>
      )
  }
})

function searchMatchLabel(
  row: Extract<IssueSidebarRow, { type: 'search-result' }>
): string {
  const kind =
    row.match.entityKind === 'round'
      ? 'Round'
      : row.match.entityKind.charAt(0).toUpperCase() +
        row.match.entityKind.slice(1)
  return row.match.completeness
    ? `${kind} · ${row.match.completeness}`
    : kind
}

function HostStateRow({
  label,
  status,
  error
}: {
  label: string
  status: Extract<IssueSidebarRow, { type: 'host-state' }>['status']
  error: string | null
}): React.JSX.Element {
  const waiting = status === 'idle' || status === 'loading'
  const problem = status === 'error' || status === 'unsupported'
  return (
    <div className="flex h-7 min-w-0 items-center gap-1.5 px-2 text-[11px] font-medium text-muted-foreground">
      {waiting ? (
        <Loader2 className="size-3 shrink-0 animate-spin" />
      ) : problem ? (
        <AlertCircle className="size-3 shrink-0" />
      ) : (
        <Server className="size-3 shrink-0" />
      )}
      <span className="min-w-0 flex-1 truncate">{label}</span>
      {status === 'cached' ? <span>Cached</span> : null}
      {status === 'unsupported' ? <span>Update required</span> : null}
      {status === 'error' ? (
        <span className="max-w-28 truncate" title={error ?? undefined}>
          Unavailable
        </span>
      ) : null}
    </div>
  )
}

function IssueRow({
  row,
  selected,
  onToggle,
  onSelect
}: {
  row: Extract<IssueSidebarRow, { type: 'issue' }>
  selected: boolean
  onToggle: () => void
  onSelect: () => void
}): React.JSX.Element {
  const title = getIssueDisplayTitle(row.issue)
  return (
    <div
      className={cn(
        'group flex h-8 min-w-0 items-center rounded-sm pr-2 text-xs',
        selected
          ? 'bg-worktree-sidebar-accent text-worktree-sidebar-accent-foreground'
          : 'hover:bg-worktree-sidebar-accent/70',
        row.contextOnly && 'text-muted-foreground'
      )}
      style={{ paddingLeft: rowIndent(row.depth) }}
    >
      <button
        type="button"
        className="flex size-5 shrink-0 items-center justify-center rounded-sm text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:opacity-30"
        aria-label={`${row.expanded ? 'Collapse' : 'Expand'} ${title}`}
        aria-expanded={row.expanded}
        disabled={!row.expandable}
        onClick={onToggle}
      >
        {row.expanded ? (
          <ChevronDown className="size-3" />
        ) : (
          <ChevronRight className="size-3" />
        )}
      </button>
      <button
        type="button"
        className="flex h-full min-w-0 flex-1 items-center gap-1.5 text-left focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
        aria-label={`Open ${title}`}
        onClick={onSelect}
      >
        {row.issue.state === 'archived' ? (
          <Archive className="size-3 shrink-0 text-muted-foreground" />
        ) : (
          <CircleDot className="size-3 shrink-0 text-muted-foreground" />
        )}
        <span className="min-w-0 flex-1 truncate">{title}</span>
        {row.issue.activeConversationCount > 0 ? (
          <span
            className="tabular-nums text-muted-foreground"
            title={`${row.issue.activeConversationCount} active conversations`}
          >
            {row.issue.activeConversationCount}
          </span>
        ) : null}
        {row.issue.ownUnresolvedCount > 0 ? (
          <AttentionCount count={row.issue.ownUnresolvedCount} />
        ) : row.issue.descendantAttentionCount > 0 ? (
          <span className="tabular-nums text-muted-foreground">
            {row.issue.descendantAttentionCount}
          </span>
        ) : null}
      </button>
    </div>
  )
}

function AttentionCount({ count }: { count: number }): React.JSX.Element {
  return (
    <span className="inline-flex min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-medium tabular-nums text-primary-foreground">
      {count}
    </span>
  )
}

function rowIndent(depth: number): number {
  return 6 + Math.min(depth, 4) * 12
}
