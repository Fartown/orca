import type { ConversationAllocator } from './conversation-allocator'
import { IssueRepository } from './issue-repository'

export type OpenActiveProfileIssueRepositoryOptions = {
  profileId: string
  userDataPath: string
}

export class ActiveProfileIssueRepository {
  readonly repository: IssueRepository
  private closed = false

  private constructor(repository: IssueRepository) {
    this.repository = repository
  }

  static open(options: OpenActiveProfileIssueRepositoryOptions): ActiveProfileIssueRepository {
    return new ActiveProfileIssueRepository(IssueRepository.open(options))
  }

  get conversationAllocator(): ConversationAllocator {
    if (this.closed) {
      throw new Error('Active profile Issue repository is closed.')
    }
    return this.repository.conversationAllocator
  }

  close(): void {
    if (this.closed) {
      return
    }
    this.repository.close()
    this.closed = true
  }
}
