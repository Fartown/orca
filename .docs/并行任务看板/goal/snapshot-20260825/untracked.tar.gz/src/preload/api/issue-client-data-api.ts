import type {
  IssueClientCacheReadResult,
  IssueClientPreferences,
  IssueClientSnapshot
} from '../../shared/issues/client-data'
import type { ExecutionHostId } from '../../shared/execution-host'
import type { IssueFactsChangedEvent } from '../../shared/issues/types'

export type IssueClientDataApi = {
  readCache: (args: {
    routeExecutionHostId: ExecutionHostId
  }) => Promise<IssueClientCacheReadResult>
  replaceCache: (args: {
    routeExecutionHostId: ExecutionHostId
    snapshot: IssueClientSnapshot
  }) => Promise<IssueClientSnapshot>
  readPreferences: () => Promise<IssueClientPreferences>
  writePreferences: (
    preferences: IssueClientPreferences
  ) => Promise<IssueClientPreferences>
  onFactsChanged?: (
    callback: (event: IssueFactsChangedEvent) => void
  ) => () => void
}
