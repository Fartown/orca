import { isPathInsideOrEqual } from '../../shared/cross-platform-path'
import {
  getRepoExecutionHostId,
  toSshExecutionHostId
} from '../../shared/execution-host'
import type { FolderWorkspace } from '../../shared/folder-workspace-types'
import type { ConversationRecord, IssueRecord } from '../../shared/issues/types'
import type { ProjectGroup } from '../../shared/project-group-types'
import type { Repo } from '../../shared/repo-types'
import type { TuiAgent } from '../../shared/tui-agent'
import { splitWorktreeIdForFilesystem } from '../../shared/worktree/id'
import type { WorktreeMeta } from '../../shared/worktree/meta-types'
import { inferFolderWorkspacePathConnection } from '../project-groups/folder-workspace-path-status'
import type {
  CommitMessageGenerationTarget,
  RemoteCommitMessageExecResult,
  TextGenerationOperation
} from '../text-generation/commit-message-text-generation'
import type { CommitMessagePlan } from '../../shared/commit-message-plan'
import { IssueRepositoryError } from './issue-repository-error'

export type IssueDigestGenerationTargetStore = {
  getRepos(): Repo[]
  getFolderWorkspaces(): FolderWorkspace[]
  getProjectGroups(): ProjectGroup[]
  getWorktreeMeta(worktreeId: string): WorktreeMeta | undefined
}

type SshDigestGenerationProvider = {
  executeCommitMessagePlan(
    plan: CommitMessagePlan,
    cwd: string,
    timeoutMs: number,
    operation?: TextGenerationOperation
  ): Promise<RemoteCommitMessageExecResult>
  cancelGenerateCommitMessage(
    cwd: string,
    operation?: TextGenerationOperation
  ): Promise<void>
}

export type IssueDigestGenerationTargetDependencies = {
  store: IssueDigestGenerationTargetStore
  getSshProvider?: (connectionId: string) => SshDigestGenerationProvider | undefined
  prepareAgentEnv: (
    agent: TuiAgent,
    target: { runtime: 'host' | 'wsl'; wslDistro?: string }
  ) => Promise<{ ok: true; env?: NodeJS.ProcessEnv } | { ok: false; error: string }>
  resolveLocalRuntimeOptions: (repo?: Repo) => { wslDistro?: string }
}

export async function resolveIssueDigestGenerationTarget(
  input: {
    issue: IssueRecord
    agent: TuiAgent
    conversations: ConversationRecord[]
  },
  dependencies: IssueDigestGenerationTargetDependencies
): Promise<CommitMessageGenerationTarget> {
  const candidates = input.conversations
    .filter(
      (conversation) =>
        conversation.state === 'active' &&
        conversation.issueId === input.issue.id &&
        conversation.executionHostId === input.issue.executionHostId
    )
    .sort((left, right) => right.updatedAt - left.updatedAt || right.createdAt - left.createdAt)

  for (const conversation of candidates) {
    try {
      return await resolveConversationTarget(input.issue, input.agent, conversation, dependencies)
    } catch (error) {
      if (!(error instanceof IssueRepositoryError) || error.code !== 'digest_target_unavailable') {
        throw error
      }
    }
  }
  throw unavailable('No active Conversation has a current executable workspace.')
}

async function resolveConversationTarget(
  issue: IssueRecord,
  agent: TuiAgent,
  conversation: ConversationRecord,
  dependencies: IssueDigestGenerationTargetDependencies
): Promise<CommitMessageGenerationTarget> {
  if (conversation.workspaceRef.type === 'worktree') {
    return resolveWorktreeTarget(issue, agent, conversation.workspaceRef.worktreeId, dependencies)
  }
  return resolveFolderTarget(
    issue,
    agent,
    conversation.workspaceRef.folderWorkspaceId,
    dependencies
  )
}

async function resolveWorktreeTarget(
  issue: IssueRecord,
  agent: TuiAgent,
  worktreeId: string,
  dependencies: IssueDigestGenerationTargetDependencies
): Promise<CommitMessageGenerationTarget> {
  const parsed = splitWorktreeIdForFilesystem(worktreeId)
  if (!parsed?.repoId || !parsed.worktreePath) {
    throw unavailable('Conversation worktree identity is invalid.')
  }
  if (dependencies.store.getWorktreeMeta(worktreeId)?.isArchived === true) {
    throw unavailable('Conversation worktree is archived.')
  }
  const repo = dependencies.store
    .getRepos()
    .find(
      (candidate) =>
        candidate.id === parsed.repoId &&
        getRepoExecutionHostId(candidate) === issue.executionHostId
    )
  if (!repo) {
    throw unavailable('Conversation worktree is not owned by this Issue execution host.')
  }
  return createTargetForConnection(
    issue,
    agent,
    parsed.worktreePath,
    repo.connectionId ?? null,
    repo,
    dependencies
  )
}

async function resolveFolderTarget(
  issue: IssueRecord,
  agent: TuiAgent,
  folderWorkspaceId: string,
  dependencies: IssueDigestGenerationTargetDependencies
): Promise<CommitMessageGenerationTarget> {
  const folder = dependencies.store
    .getFolderWorkspaces()
    .find((candidate) => candidate.id === folderWorkspaceId)
  if (!folder || folder.isArchived) {
    throw unavailable('Conversation folder workspace is unavailable.')
  }
  if (folder.executionHostId && folder.executionHostId !== issue.executionHostId) {
    throw unavailable('Conversation folder workspace belongs to a different execution host.')
  }

  const groups = dependencies.store.getProjectGroups()
  const repos = dependencies.store.getRepos()
  const group = groups.find((candidate) => candidate.id === folder.projectGroupId)
  const connection = inferFolderWorkspacePathConnection({
    folderPath: folder.folderPath,
    projectGroupId: folder.projectGroupId,
    connectionId: folder.connectionId ?? group?.connectionId ?? null,
    projectGroups: groups,
    repos
  })
  if (connection.kind === 'ambiguous') {
    throw unavailable('Conversation folder workspace has ambiguous host ownership.')
  }
  const repo = findFolderRuntimeRepo(folder, repos)
  return createTargetForConnection(
    issue,
    agent,
    folder.folderPath,
    connection.kind === 'ssh' ? connection.connectionId : null,
    repo,
    dependencies
  )
}

async function createTargetForConnection(
  issue: IssueRecord,
  agent: TuiAgent,
  cwd: string,
  connectionId: string | null,
  runtimeRepo: Repo | undefined,
  dependencies: IssueDigestGenerationTargetDependencies
): Promise<CommitMessageGenerationTarget> {
  if (connectionId) {
    if (toSshExecutionHostId(connectionId) !== issue.executionHostId) {
      throw unavailable('Conversation workspace belongs to a different SSH host.')
    }
    const provider = dependencies.getSshProvider?.(connectionId)
    if (!provider) {
      throw unavailable('Conversation SSH execution provider is unavailable.')
    }
    return {
      kind: 'remote',
      cwd,
      execute: (plan, targetCwd, timeoutMs, operation) =>
        provider.executeCommitMessagePlan(plan, targetCwd, timeoutMs, operation),
      cancel: (targetCwd, operation) =>
        provider.cancelGenerateCommitMessage(targetCwd, operation),
      missingBinaryLocation: `SSH target ${connectionId}`
    }
  }
  if (issue.executionHostId !== 'local') {
    throw unavailable('Conversation workspace is not owned by the local runtime.')
  }

  let runtimeOptions: { wslDistro?: string }
  try {
    runtimeOptions = dependencies.resolveLocalRuntimeOptions(runtimeRepo)
  } catch (error) {
    throw unavailable(error instanceof Error ? error.message : 'Project runtime is unavailable.')
  }
  const runtimeTarget = runtimeOptions.wslDistro
    ? { runtime: 'wsl' as const, wslDistro: runtimeOptions.wslDistro }
    : { runtime: 'host' as const }
  const prepared = await dependencies.prepareAgentEnv(agent, runtimeTarget)
  if (!prepared.ok) {
    throw unavailable(prepared.error)
  }
  return {
    kind: 'local',
    cwd,
    ...(runtimeOptions.wslDistro ? { wslDistro: runtimeOptions.wslDistro } : {}),
    ...(prepared.env ? { env: prepared.env } : {})
  }
}

function findFolderRuntimeRepo(folder: FolderWorkspace, repos: Repo[]): Repo | undefined {
  return repos.find(
    (repo) =>
      !repo.connectionId &&
      (repo.projectGroupId === folder.projectGroupId ||
        isPathInsideOrEqual(folder.folderPath, repo.path) ||
        isPathInsideOrEqual(repo.path, folder.folderPath))
  )
}

function unavailable(message: string): IssueRepositoryError {
  return new IssueRepositoryError('digest_target_unavailable', message)
}
