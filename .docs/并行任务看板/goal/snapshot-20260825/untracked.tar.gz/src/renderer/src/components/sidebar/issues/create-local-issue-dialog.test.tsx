// @vitest-environment happy-dom

import { randomUUID } from 'node:crypto'
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor
} from '@testing-library/react'
import '@testing-library/jest-dom/vitest'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { IssueMutationResult } from '../../../../../shared/issues/types'
import type { SidebarHostOption } from '../sidebar-host-options'
import CreateLocalIssueDialog from './create-local-issue-dialog'

afterEach(cleanup)

const localHost: SidebarHostOption = {
  id: 'local',
  label: 'This Mac',
  detail: 'This computer',
  kind: 'local',
  health: 'local',
  presence: 'local'
}

function mutationResult(issueId: string): IssueMutationResult {
  return {
    authority: {
      authorityId: randomUUID(),
      hostPartitionKey: 'local',
      routeExecutionHostId: 'local'
    },
    factsRevision: 1,
    treeRevision: 1,
    affectedIssueIds: [issueId],
    affectedConversationIds: [],
    affectedRoundRecordIds: []
  }
}

describe('CreateLocalIssueDialog', () => {
  it('submits a local Issue and returns the created route and id', async () => {
    const issueId = randomUUID()
    const result = mutationResult(issueId)
    const createIssue = vi.fn(async () => result)
    const onCreated = vi.fn()
    const onOpenChange = vi.fn()
    render(
      <CreateLocalIssueDialog
        open
        hostOptions={[localHost]}
        onOpenChange={onOpenChange}
        onCreated={onCreated}
        createIssue={createIssue}
      />
    )

    fireEvent.change(screen.getByLabelText('Title'), {
      target: { value: 'Ship the Issue view' }
    })
    fireEvent.click(screen.getByRole('button', { name: 'Create Issue' }))

    await waitFor(() => expect(createIssue).toHaveBeenCalledTimes(1))
    expect(createIssue).toHaveBeenCalledWith({
      executionHostId: 'local',
      mutationId: expect.any(String),
      title: 'Ship the Issue view',
      typeLabel: null,
      note: null
    })
    expect(onCreated).toHaveBeenCalledWith(result.authority, issueId)
    expect(onOpenChange).toHaveBeenCalledWith(false)
  })

  it('reuses the same mutation id after an uncertain failure', async () => {
    const issueId = randomUUID()
    const createIssue = vi
      .fn()
      .mockRejectedValueOnce(new Error('Connection closed'))
      .mockResolvedValueOnce(mutationResult(issueId))
    render(
      <CreateLocalIssueDialog
        open
        hostOptions={[localHost]}
        onOpenChange={vi.fn()}
        onCreated={vi.fn()}
        createIssue={createIssue}
      />
    )

    fireEvent.change(screen.getByLabelText('Title'), {
      target: { value: 'Retry safely' }
    })
    fireEvent.click(screen.getByRole('button', { name: 'Create Issue' }))
    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Connection closed'
    )
    fireEvent.click(screen.getByRole('button', { name: 'Create Issue' }))

    await waitFor(() => expect(createIssue).toHaveBeenCalledTimes(2))
    expect(createIssue.mock.calls[1]?.[0].mutationId).toBe(
      createIssue.mock.calls[0]?.[0].mutationId
    )
  })

  it('does not submit an empty title', () => {
    const createIssue = vi.fn()
    render(
      <CreateLocalIssueDialog
        open
        hostOptions={[localHost]}
        onOpenChange={vi.fn()}
        onCreated={vi.fn()}
        createIssue={createIssue}
      />
    )

    expect(screen.getByRole('button', { name: 'Create Issue' })).toBeDisabled()
    expect(createIssue).not.toHaveBeenCalled()
  })
})
