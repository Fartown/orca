import { useEffect, useMemo } from 'react'
import { useShallow } from 'zustand/react/shallow'
import type { ExecutionHostId } from '../../../shared/execution-host'
import { useAppStore } from '../store'
import { getAllWorktreesFromState } from '../store/selectors'
import {
  buildLegacyActivityMigrationSnapshot,
  type LegacyActivityMigrationSnapshot,
  type LegacyActivityMigrationSource
} from './legacy-activity-migration'
import { resolveLegacyActivityPaneRoutes } from './legacy-activity-pane-routes'
import { buildLegacyActivitySourceEntries } from './legacy-activity-source-entries'
import { issueActivityStore } from './issue-activity-store'

export function useLegacyActivityMigration(
  routeExecutionHostIds: readonly ExecutionHostId[],
  enabled: boolean
): LegacyActivityMigrationSnapshot {
  const sourceState = useAppStore(
    useShallow((state) => ({
      acknowledgedAgentsByPaneKey: state.acknowledgedAgentsByPaneKey,
      agentStatusByPaneKey: state.agentStatusByPaneKey,
      migrationUnsupportedByPtyId:
        state.migrationUnsupportedByPtyId,
      repos: state.repos,
      retainedAgentsByPaneKey: state.retainedAgentsByPaneKey,
      tabsByWorktree: state.tabsByWorktree,
      worktreesByRepo: state.worktreesByRepo
    }))
  )
  const snapshot = useMemo(() => {
    const entriesByPaneKey = buildLegacyActivitySourceEntries({
      liveEntriesByPaneKey: sourceState.agentStatusByPaneKey,
      retainedEntriesByPaneKey:
        sourceState.retainedAgentsByPaneKey,
      migrationUnsupportedByPtyId:
        sourceState.migrationUnsupportedByPtyId
    })
    const routesByPaneKey = resolveLegacyActivityPaneRoutes({
      entriesByPaneKey,
      tabsByWorktree: sourceState.tabsByWorktree,
      worktrees: getAllWorktreesFromState(sourceState),
      repos: sourceState.repos
    })
    const sources: LegacyActivityMigrationSource[] = []
    for (const [paneKey, entry] of Object.entries(entriesByPaneKey)) {
      const routeExecutionHostId = routesByPaneKey[paneKey]
      if (!routeExecutionHostId) {
        continue
      }
      sources.push({
        routeExecutionHostId,
        entry,
        acknowledgedAt:
          sourceState.acknowledgedAgentsByPaneKey[paneKey] ?? null
      })
    }
    return buildLegacyActivityMigrationSnapshot(sources)
  }, [sourceState])
  const routesKey = routeExecutionHostIds.join('\0')
  const stableRoutes = useMemo(
    () => [...routeExecutionHostIds],
    [routesKey]
  )

  useEffect(() => {
    if (!enabled) {
      return
    }
    void issueActivityStore
      .getState()
      .syncLegacyMigration(stableRoutes, snapshot)
  }, [enabled, snapshot, stableRoutes])

  return snapshot
}
