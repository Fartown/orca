import {
  parseExecutionHostId,
  type ExecutionHostId
} from '../../../shared/execution-host'
import {
  IssueClientSnapshotSchema,
  type IssueClientCacheReadResult,
  type IssueClientSnapshot
} from '../../../shared/issues/client-data'
import {
  IssueDigestConfirmationResultSchema,
  IssueDigestMutationResultSchema,
  IssueDigestPreparationSchema
} from '../../../shared/issues/digest-schemas'
import type {
  IssueDigestConfirmationResult,
  IssueDigestMutationResult,
  IssueDigestPreparation,
  IssueDigestSections
} from '../../../shared/issues/digest-types'
import {
  ConversationPageSchema,
  ConversationSummarySchema,
  IssueDetailSchema,
  IssueSearchResultSchema,
  IssuesListResult,
  RoundRecordPageSchema
} from '../../../shared/issues/schemas'
import type {
  ConversationSummary,
  IssueAuthorityDescriptor,
  IssueDetail,
  IssueListFilter,
  IssueSearchResult,
  RoundRecordPage,
  RoundRecordPreview
} from '../../../shared/issues/types'
import type { TuiAgent } from '../../../shared/tui-agent'
import { ORCA_ISSUES_RUNTIME_CAPABILITY } from '../../../shared/protocol-version'
import {
  callRuntimeRpc,
  runtimeEnvironmentSupportsCapability,
  type RuntimeClientTarget
} from '../runtime/runtime-rpc-client'

const SNAPSHOT_RETRY_LIMIT = 3
const MAX_SNAPSHOT_RECORDS = 100_000

export type IssueClientLoadResult<T> =
  | { status: 'ready'; value: T }
  | { status: 'cached'; value: T; error: string }
  | { status: 'unsupported' }
  | { status: 'error'; error: string }

export type IssueClientDataDependencies = {
  readCache: (
    routeExecutionHostId: ExecutionHostId
  ) => Promise<IssueClientCacheReadResult>
  replaceCache: (
    routeExecutionHostId: ExecutionHostId,
    snapshot: IssueClientSnapshot
  ) => Promise<void>
  supportsCapability: (environmentId: string) => Promise<boolean>
  callRpc: (
    routeExecutionHostId: ExecutionHostId,
    method: string,
    params: unknown
  ) => Promise<unknown>
  now: () => number
}

export type IssueRoundLoadScope =
  | {
      issueId: string
      conversationId?: never
      cursor?: string
      expectedFactsRevision?: number
      limit?: number
    }
  | {
      issueId?: never
      conversationId: string
      cursor?: string
      expectedFactsRevision?: number
      limit?: number
    }

export type IssueSearchInput = {
  query: string
  cursor?: string
  limit?: number
}

export type IssueDigestGenerateInput = {
  mutationId: string
  issueId: string
  coversUntil?: number
  agent: TuiAgent
  expectedInputFingerprint: string
}

export type IssueDigestCancelInput = {
  mutationId: string
  digestId: string
}

export type IssueDigestUpdateInput = {
  mutationId: string
  digestId: string
  expectedDigestRevision: number
} & Partial<IssueDigestSections>

export type IssueDigestConfirmInput = {
  mutationId: string
  digestId: string
  expectedDigestRevision: number
  inputFingerprint: string
  confirmStaleAgainstFingerprint?: string
}

type CollectedIssueFilter = {
  authority: IssueAuthorityDescriptor
  factsRevision: number
  treeRevision: number
  issues: IssueClientSnapshot['issues']
  unassigned?: IssueClientSnapshot['unassigned']
}

class StaleIssueSnapshotError extends Error {}

export async function loadIssuePartition(
  routeExecutionHostId: ExecutionHostId,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueClientSnapshot>> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    return { status: 'error', error: 'Invalid Issue host route.' }
  }
  const cached = await readCacheSafely(routeExecutionHostId, dependencies)
  try {
    if (
      route.kind === 'runtime' &&
      !(await dependencies.supportsCapability(route.environmentId))
    ) {
      return { status: 'unsupported' }
    }
    const snapshot = await fetchConsistentIssueSnapshot(
      routeExecutionHostId,
      cached?.snapshot,
      dependencies
    )
    await dependencies
      .replaceCache(routeExecutionHostId, snapshot)
      .catch(() => undefined)
    return { status: 'ready', value: snapshot }
  } catch (error) {
    const message = issueClientErrorMessage(error)
    return cached
      ? { status: 'cached', value: cached.snapshot, error: message }
      : { status: 'error', error: message }
  }
}

export async function loadIssueDetail(
  routeExecutionHostId: ExecutionHostId,
  issueId: string,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueDetail>> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    return { status: 'error', error: 'Invalid Issue host route.' }
  }
  const cached = await readCacheSafely(routeExecutionHostId, dependencies)
  try {
    if (
      route.kind === 'runtime' &&
      !(await dependencies.supportsCapability(route.environmentId))
    ) {
      return { status: 'unsupported' }
    }
    const detail = IssueDetailSchema.parse(
      await dependencies.callRpc(
        routeExecutionHostId,
        'issues.get',
        { executionHostId: routeExecutionHostId, issueId }
      )
    )
    assertAuthorityRoute(detail.authority, routeExecutionHostId)
    if (cached && sameAuthority(cached.snapshot.authority, detail.authority)) {
      const snapshot = {
        ...cached.snapshot,
        cachedAt: dependencies.now(),
        details: [
          ...cached.snapshot.details.filter(
            (candidate) => candidate.issue.id !== issueId
          ),
          detail
        ]
      }
      await dependencies
        .replaceCache(routeExecutionHostId, snapshot)
        .catch(() => undefined)
    }
    return { status: 'ready', value: detail }
  } catch (error) {
    const cachedDetail = cached?.snapshot.details.find(
      (candidate) => candidate.issue.id === issueId
    )
    const message = issueClientErrorMessage(error)
    return cachedDetail
      ? { status: 'cached', value: cachedDetail, error: message }
      : { status: 'error', error: message }
  }
}

export async function loadConversation(
  routeExecutionHostId: ExecutionHostId,
  conversationId: string,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<ConversationSummary>> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    return { status: 'error', error: 'Invalid Issue host route.' }
  }
  const cached = await readCacheSafely(routeExecutionHostId, dependencies)
  try {
    if (
      route.kind === 'runtime' &&
      !(await dependencies.supportsCapability(route.environmentId))
    ) {
      return { status: 'unsupported' }
    }
    const conversation = ConversationSummarySchema.parse(
      await dependencies.callRpc(
        routeExecutionHostId,
        'conversations.get',
        { executionHostId: routeExecutionHostId, conversationId }
      )
    )
    assertConversationRoute(conversation, routeExecutionHostId)
    return { status: 'ready', value: conversation }
  } catch (error) {
    const cachedConversation = cached
      ? findCachedConversation(cached.snapshot, conversationId)
      : null
    const message = issueClientErrorMessage(error)
    return cachedConversation
      ? { status: 'cached', value: cachedConversation, error: message }
      : { status: 'error', error: message }
  }
}

export async function loadUnassignedConversations(
  routeExecutionHostId: ExecutionHostId,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<ConversationSummary[]>> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    return { status: 'error', error: 'Invalid Issue host route.' }
  }
  const cached = await readCacheSafely(routeExecutionHostId, dependencies)
  try {
    if (
      route.kind === 'runtime' &&
      !(await dependencies.supportsCapability(route.environmentId))
    ) {
      return { status: 'unsupported' }
    }
    const conversations: ConversationSummary[] = []
    let cursor: string | undefined
    let authority: IssueAuthorityDescriptor | null = null
    do {
      const page = ConversationPageSchema.parse(
        await dependencies.callRpc(
          routeExecutionHostId,
          'conversations.listUnassigned',
          {
            executionHostId: routeExecutionHostId,
            ...(cursor ? { cursor } : {}),
            limit: 500
          }
        )
      )
      assertAuthorityRoute(page.authority, routeExecutionHostId)
      authority ??= page.authority
      if (!sameAuthority(authority, page.authority)) {
        throw new StaleIssueSnapshotError(
          'Issue authority changed while loading unassigned conversations.'
        )
      }
      conversations.push(...page.conversations)
      if (conversations.length > MAX_SNAPSHOT_RECORDS) {
        throw new Error('Unassigned Conversation snapshot is too large.')
      }
      cursor = page.nextCursor ?? undefined
    } while (cursor)
    if (cached && authority && sameAuthority(cached.snapshot.authority, authority)) {
      const snapshot = {
        ...cached.snapshot,
        cachedAt: dependencies.now(),
        unassignedConversations: conversations
      }
      await dependencies
        .replaceCache(routeExecutionHostId, snapshot)
        .catch(() => undefined)
    }
    return { status: 'ready', value: conversations }
  } catch (error) {
    const message = issueClientErrorMessage(error)
    return cached
      ? {
          status: 'cached',
          value: cached.snapshot.unassignedConversations,
          error: message
        }
      : { status: 'error', error: message }
  }
}

export async function loadIssueRounds(
  routeExecutionHostId: ExecutionHostId,
  scope: IssueRoundLoadScope,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<RoundRecordPage>> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    return { status: 'error', error: 'Invalid Issue host route.' }
  }
  const cached = await readCacheSafely(routeExecutionHostId, dependencies)
  try {
    if (
      route.kind === 'runtime' &&
      !(await dependencies.supportsCapability(route.environmentId))
    ) {
      return { status: 'unsupported' }
    }
    const page = RoundRecordPageSchema.parse(
      await dependencies.callRpc(routeExecutionHostId, 'issues.listRounds', {
        executionHostId: routeExecutionHostId,
        ...('issueId' in scope
          ? { issueId: scope.issueId }
          : { conversationId: scope.conversationId }),
        ...(scope.cursor ? { cursor: scope.cursor } : {}),
        limit: scope.limit ?? 200
      })
    )
    assertAuthorityRoute(page.authority, routeExecutionHostId)
    if (
      scope.expectedFactsRevision !== undefined &&
      page.snapshotFactsRevision !== scope.expectedFactsRevision
    ) {
      throw new StaleIssueSnapshotError(
        'Round Record facts changed while loading the next page.'
      )
    }
    assertRoundScope(cached?.snapshot, scope, page.rounds)
    if (
      cached &&
      sameAuthority(cached.snapshot.authority, page.authority) &&
      cached.snapshot.factsRevision === page.snapshotFactsRevision
    ) {
      const snapshot = mergeRoundPageIntoCache(cached.snapshot, scope, page.rounds)
      if (snapshot) {
        await dependencies
          .replaceCache(routeExecutionHostId, snapshot)
          .catch(() => undefined)
      }
    }
    return { status: 'ready', value: page }
  } catch (error) {
    const message = issueClientErrorMessage(error)
    if (!scope.cursor && cached) {
      return {
        status: 'cached',
        value: cachedRoundPage(cached.snapshot, scope),
        error: message
      }
    }
    return { status: 'error', error: message }
  }
}

export async function searchIssues(
  routeExecutionHostId: ExecutionHostId,
  query: string,
  dependencies?: IssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueSearchResult>>
export async function searchIssues(
  routeExecutionHostId: ExecutionHostId,
  input: IssueSearchInput,
  dependencies?: IssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueSearchResult>>
export async function searchIssues(
  routeExecutionHostId: ExecutionHostId,
  queryOrInput: string | IssueSearchInput,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueSearchResult>> {
  const input =
    typeof queryOrInput === 'string'
      ? { query: queryOrInput }
      : queryOrInput
  return callIssueResult(
    routeExecutionHostId,
    'issues.search',
    {
      executionHostId: routeExecutionHostId,
      query: input.query,
      ...(input.cursor ? { cursor: input.cursor } : {}),
      limit: input.limit ?? 50
    },
    IssueSearchResultSchema,
    dependencies
  )
}

export async function prepareIssueDigest(
  routeExecutionHostId: ExecutionHostId,
  issueId: string,
  dependencies?: IssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueDigestPreparation>>
export async function prepareIssueDigest(
  routeExecutionHostId: ExecutionHostId,
  input: { issueId: string; coversUntil?: number },
  dependencies?: IssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueDigestPreparation>>
export async function prepareIssueDigest(
  routeExecutionHostId: ExecutionHostId,
  issueOrInput: string | { issueId: string; coversUntil?: number },
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueDigestPreparation>> {
  const input =
    typeof issueOrInput === 'string'
      ? { issueId: issueOrInput }
      : issueOrInput
  return callIssueResult(
    routeExecutionHostId,
    'issues.prepareDigest',
    {
      executionHostId: routeExecutionHostId,
      issueId: input.issueId,
      ...(input.coversUntil === undefined
        ? {}
        : { coversUntil: input.coversUntil })
    },
    IssueDigestPreparationSchema,
    dependencies
  )
}

export function generateIssueDigest(
  routeExecutionHostId: ExecutionHostId,
  input: IssueDigestGenerateInput,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueDigestMutationResult>> {
  return callIssueResult(
    routeExecutionHostId,
    'issues.generateDigest',
    { executionHostId: routeExecutionHostId, ...input },
    IssueDigestMutationResultSchema,
    dependencies
  )
}

export function cancelIssueDigest(
  routeExecutionHostId: ExecutionHostId,
  input: IssueDigestCancelInput,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueDigestMutationResult>> {
  return callIssueResult(
    routeExecutionHostId,
    'issues.cancelDigest',
    { executionHostId: routeExecutionHostId, ...input },
    IssueDigestMutationResultSchema,
    dependencies
  )
}

export function updateIssueDigestDraft(
  routeExecutionHostId: ExecutionHostId,
  input: IssueDigestUpdateInput,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueDigestMutationResult>> {
  return callIssueResult(
    routeExecutionHostId,
    'issues.updateDigestDraft',
    { executionHostId: routeExecutionHostId, ...input },
    IssueDigestMutationResultSchema,
    dependencies
  )
}

export function confirmIssueDigest(
  routeExecutionHostId: ExecutionHostId,
  input: IssueDigestConfirmInput,
  dependencies: IssueClientDataDependencies = defaultIssueClientDataDependencies
): Promise<IssueClientLoadResult<IssueDigestConfirmationResult>> {
  return callIssueResult(
    routeExecutionHostId,
    'issues.confirmDigest',
    { executionHostId: routeExecutionHostId, ...input },
    IssueDigestConfirmationResultSchema,
    dependencies
  )
}

async function callIssueResult<T>(
  routeExecutionHostId: ExecutionHostId,
  method: string,
  params: unknown,
  schema: { parse(value: unknown): T },
  dependencies: IssueClientDataDependencies
): Promise<IssueClientLoadResult<T>> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    return { status: 'error', error: 'Invalid Issue host route.' }
  }
  try {
    if (
      route.kind === 'runtime' &&
      !(await dependencies.supportsCapability(route.environmentId))
    ) {
      return { status: 'unsupported' }
    }
    const value = schema.parse(
      await dependencies.callRpc(routeExecutionHostId, method, params)
    )
    const authority = (value as { authority?: IssueAuthorityDescriptor }).authority
    if (authority) {
      assertAuthorityRoute(authority, routeExecutionHostId)
    }
    return { status: 'ready', value }
  } catch (error) {
    return { status: 'error', error: issueClientErrorMessage(error) }
  }
}

async function fetchConsistentIssueSnapshot(
  routeExecutionHostId: ExecutionHostId,
  previous: IssueClientSnapshot | undefined,
  dependencies: IssueClientDataDependencies
): Promise<IssueClientSnapshot> {
  for (let attempt = 0; attempt < SNAPSHOT_RETRY_LIMIT; attempt += 1) {
    let active: CollectedIssueFilter
    let archived: CollectedIssueFilter
    try {
      active = await collectIssueFilter(
        routeExecutionHostId,
        'all',
        dependencies
      )
      archived = await collectIssueFilter(
        routeExecutionHostId,
        'archived',
        dependencies
      )
    } catch (error) {
      if (error instanceof StaleIssueSnapshotError) {
        continue
      }
      throw error
    }
    if (
      active.factsRevision !== archived.factsRevision ||
      active.treeRevision !== archived.treeRevision ||
      !sameAuthority(active.authority, archived.authority)
    ) {
      continue
    }
    const issueById = new Map(
      [...active.issues, ...archived.issues].map((issue) => [issue.id, issue])
    )
    const preserveDetailFacts =
      previous &&
      previous.factsRevision === active.factsRevision &&
      previous.treeRevision === active.treeRevision &&
      sameAuthority(previous.authority, active.authority)
    const snapshot = {
      authority: active.authority,
      cachedAt: dependencies.now(),
      factsRevision: active.factsRevision,
      treeRevision: active.treeRevision,
      searchRevision: preserveDetailFacts ? previous.searchRevision : 0,
      issues: [...issueById.values()],
      ...(active.unassigned ? { unassigned: active.unassigned } : {}),
      details: preserveDetailFacts ? previous.details : [],
      unassignedConversations: preserveDetailFacts
        ? previous.unassignedConversations
        : [],
      rounds: preserveDetailFacts ? previous.rounds : []
    }
    return IssueClientSnapshotSchema.parse(snapshot) as IssueClientSnapshot
  }
  throw new StaleIssueSnapshotError(
    'Issue facts changed repeatedly while loading the tree.'
  )
}

async function collectIssueFilter(
  routeExecutionHostId: ExecutionHostId,
  filter: IssueListFilter,
  dependencies: IssueClientDataDependencies
): Promise<CollectedIssueFilter> {
  let cursor: string | null = null
  let authority: IssueAuthorityDescriptor | null = null
  let factsRevision: number | null = null
  let treeRevision: number | null = null
  let unassigned: CollectedIssueFilter['unassigned']
  const issues: IssueClientSnapshot['issues'] = []
  do {
    const params =
      cursor === null
        ? {
            mode: 'start' as const,
            executionHostId: routeExecutionHostId,
            filter,
            limit: 500
          }
        : {
            mode: 'continue' as const,
            executionHostId: routeExecutionHostId,
            filter,
            snapshotFactsRevision: factsRevision!,
            snapshotTreeRevision: treeRevision!,
            cursor,
            limit: 500
          }
    const result = IssuesListResult.parse(
      await dependencies.callRpc(
        routeExecutionHostId,
        'issues.list',
        params
      )
    )
    if (result.status === 'stale') {
      throw new StaleIssueSnapshotError(
        'Issue facts changed while loading a snapshot page.'
      )
    }
    if (result.status === 'not-modified') {
      throw new Error('Issue host returned not-modified without a revision hint.')
    }
    assertAuthorityRoute(result.authority, routeExecutionHostId)
    authority ??= result.authority
    factsRevision ??= result.snapshotFactsRevision
    treeRevision ??= result.snapshotTreeRevision
    if (
      !sameAuthority(authority, result.authority) ||
      factsRevision !== result.snapshotFactsRevision ||
      treeRevision !== result.snapshotTreeRevision
    ) {
      throw new StaleIssueSnapshotError(
        'Issue snapshot identity changed between pages.'
      )
    }
    issues.push(...result.issues)
    if (issues.length > MAX_SNAPSHOT_RECORDS) {
      throw new Error('Issue snapshot is too large.')
    }
    unassigned ??= result.unassigned
    cursor = result.nextCursor
  } while (cursor)
  if (!authority || factsRevision === null || treeRevision === null) {
    throw new Error('Issue host returned no snapshot page.')
  }
  return {
    authority,
    factsRevision,
    treeRevision,
    issues,
    ...(unassigned ? { unassigned } : {})
  }
}

async function readCacheSafely(
  routeExecutionHostId: ExecutionHostId,
  dependencies: IssueClientDataDependencies
): Promise<Extract<IssueClientCacheReadResult, { status: 'hit' }> | null> {
  try {
    const result = await dependencies.readCache(routeExecutionHostId)
    return result.status === 'hit' ? result : null
  } catch {
    return null
  }
}

function assertAuthorityRoute(
  authority: IssueAuthorityDescriptor,
  routeExecutionHostId: ExecutionHostId
): void {
  if (authority.routeExecutionHostId !== routeExecutionHostId) {
    throw new Error('Issue authority response was stamped for another route.')
  }
}

function assertConversationRoute(
  conversation: ConversationSummary,
  routeExecutionHostId: ExecutionHostId
): void {
  const route = parseExecutionHostId(routeExecutionHostId)
  const expectedPartition = route?.kind === 'ssh' ? route.id : 'local'
  if (
    conversation.executionHostId !== routeExecutionHostId ||
    conversation.hostPartitionKey !== expectedPartition
  ) {
    throw new Error('Conversation response was stamped for another route.')
  }
}

function findCachedConversation(
  snapshot: IssueClientSnapshot,
  conversationId: string
): ConversationSummary | null {
  for (const detail of snapshot.details) {
    const conversation = detail.directConversations.find(
      (candidate) => candidate.id === conversationId
    )
    if (conversation) {
      return conversation
    }
  }
  return (
    snapshot.unassignedConversations.find(
      (candidate) => candidate.id === conversationId
    ) ?? null
  )
}

function sameAuthority(
  left: IssueAuthorityDescriptor,
  right: IssueAuthorityDescriptor
): boolean {
  return (
    left.authorityId === right.authorityId &&
    left.hostPartitionKey === right.hostPartitionKey
  )
}

function assertRoundScope(
  snapshot: IssueClientSnapshot | undefined,
  scope: IssueRoundLoadScope,
  rounds: readonly RoundRecordPreview[]
): void {
  if ('conversationId' in scope) {
    if (rounds.some((round) => round.conversationId !== scope.conversationId)) {
      throw new Error('Round Record response included another Conversation.')
    }
    return
  }
  const conversationIds = issueConversationIds(snapshot, scope.issueId)
  if (
    conversationIds &&
    rounds.some((round) => !conversationIds.has(round.conversationId))
  ) {
    throw new Error('Round Record response included another Issue.')
  }
}

function mergeRoundPageIntoCache(
  snapshot: IssueClientSnapshot,
  scope: IssueRoundLoadScope,
  page: readonly RoundRecordPreview[]
): IssueClientSnapshot | null {
  const conversationIds = roundScopeConversationIds(snapshot, scope, page)
  if (!conversationIds) {
    return null
  }
  const retained = scope.cursor
    ? snapshot.rounds
    : snapshot.rounds.filter(
        (round) => !conversationIds.has(round.conversationId)
      )
  const merged = dedupeRounds([...retained, ...page])
  if (merged.length > MAX_SNAPSHOT_RECORDS) {
    return null
  }
  return {
    ...snapshot,
    rounds: merged
  }
}

function cachedRoundPage(
  snapshot: IssueClientSnapshot,
  scope: IssueRoundLoadScope
): RoundRecordPage {
  const conversationIds = roundScopeConversationIds(snapshot, scope, [])
  return {
    authority: snapshot.authority,
    snapshotFactsRevision: snapshot.factsRevision,
    rounds: conversationIds
      ? snapshot.rounds.filter((round) =>
          conversationIds.has(round.conversationId)
        )
      : [],
    nextCursor: null
  }
}

function roundScopeConversationIds(
  snapshot: IssueClientSnapshot,
  scope: IssueRoundLoadScope,
  _page: readonly RoundRecordPreview[]
): Set<string> | null {
  if (scope.conversationId) {
    return new Set([scope.conversationId])
  }
  return scope.issueId
    ? issueConversationIds(snapshot, scope.issueId)
    : null
}

function issueConversationIds(
  snapshot: IssueClientSnapshot | undefined,
  issueId: string
): Set<string> | null {
  const detail = snapshot?.details.find(
    (candidate) => candidate.issue.id === issueId
  )
  return detail
    ? new Set(
        detail.directConversations.map((conversation) => conversation.id)
      )
    : null
}

function dedupeRounds(
  rounds: readonly RoundRecordPreview[]
): RoundRecordPreview[] {
  const byId = new Map(rounds.map((round) => [round.id, round]))
  return [...byId.values()].sort(
    (left, right) =>
      right.occurredAt - left.occurredAt ||
      right.id.localeCompare(left.id)
  )
}

function runtimeTargetForRoute(
  routeExecutionHostId: ExecutionHostId
): RuntimeClientTarget {
  const route = parseExecutionHostId(routeExecutionHostId)
  return route?.kind === 'runtime'
    ? { kind: 'environment', environmentId: route.environmentId }
    : { kind: 'local' }
}

function issueClientErrorMessage(error: unknown): string {
  return error instanceof Error && error.message.trim()
    ? error.message
    : 'Unable to load Issues.'
}

const defaultIssueClientDataDependencies: IssueClientDataDependencies = {
  readCache: (routeExecutionHostId) =>
    window.api.issueClientData.readCache({ routeExecutionHostId }),
  replaceCache: async (routeExecutionHostId, snapshot) => {
    await window.api.issueClientData.replaceCache({
      routeExecutionHostId,
      snapshot
    })
  },
  supportsCapability: (environmentId) =>
    runtimeEnvironmentSupportsCapability(
      environmentId,
      ORCA_ISSUES_RUNTIME_CAPABILITY
    ),
  callRpc: (routeExecutionHostId, method, params) =>
    callRuntimeRpc(
      runtimeTargetForRoute(routeExecutionHostId),
      method,
      params,
      { reuseRecentCompatibilityFailure: true }
    ),
  now: () => Date.now()
}
