import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { resolveIssueAuthorityRoute } from './issue-authority-route'
import { IssueDashboardProjectionQuery } from './issue-dashboard-projection'
import { IssueRepository, issueMutationIdentity } from './issue-repository'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-dashboard-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  mutationSequence += 1
  return issueMutationIdentity('dashboard-test', `${label}-${mutationSequence}`)
}

function createIssue(
  repository: IssueRepository,
  title: string,
  executionHostId: ExecutionHostId
) {
  return repository.issues.create({
    identity: identity(`issue-${title}`),
    input: { kind: 'local', title, executionHostId }
  })
}

function createConversation(
  repository: IssueRepository,
  label: string,
  executionHostId: ExecutionHostId,
  issueId: string | null
) {
  return repository.conversations.create({
    identity: identity(`conversation-${label}`),
    input: {
      executionHostId,
      workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${label}` },
      workspaceSnapshot: { name: label, path: `/workspace/${label}` },
      agent: 'codex',
      title: label,
      titleSource: 'user',
      issueId
    }
  })
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('IssueDashboardProjectionQuery', () => {
  it('uses the newest pane claim and the latest Round Record', () => {
    const repository = openRepository('newest')
    const query = new IssueDashboardProjectionQuery(repository.database)
    const oldIssue = createIssue(repository, 'Old issue', 'local')
    const currentIssue = createIssue(repository, 'Current issue', 'local')
    const oldConversation = createConversation(
      repository,
      'old',
      'local',
      oldIssue.id
    )
    const currentConversation = createConversation(
      repository,
      'current',
      'local',
      currentIssue.id
    )
    repository.conversationLaunchClaims.create({
      conversationId: oldConversation.id,
      launchToken: 'dashboard-old',
      paneKey: 'tab:shared-pane',
      createdAt: 10,
      expiresAt: 10_000
    })
    repository.conversationLaunchClaims.create({
      conversationId: currentConversation.id,
      launchToken: 'dashboard-current',
      paneKey: 'tab:shared-pane',
      createdAt: 20,
      expiresAt: 10_000
    })
    repository.rounds.create({
      identity: identity('older-round'),
      input: {
        conversationId: currentConversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 30,
        dedupeKey: 'dashboard:older'
      }
    })
    const latestRound = repository.rounds.create({
      identity: identity('latest-round'),
      input: {
        conversationId: currentConversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 40,
        dedupeKey: 'dashboard:latest',
        pendingQuestion: { text: 'Approve?' },
        readAt: 41
      }
    })

    const result = query.project(resolveIssueAuthorityRoute('local'), [
      'tab:shared-pane',
      'tab:shared-pane',
      'tab:missing'
    ])
    expect(result.panes).toEqual([
      {
        paneKey: 'tab:shared-pane',
        conversationId: currentConversation.id,
        issue: {
          id: currentIssue.id,
          title: 'Current issue',
          typeLabel: null,
          state: 'active'
        },
        latestRound: expect.objectContaining({
          id: latestRound.id,
          kind: 'waiting',
          readAt: 41,
          resolvedAt: null,
          effectiveResolvedAt: null
        })
      }
    ])
  })

  it('does not project a same-named pane from another host partition', () => {
    const repository = openRepository('hosts')
    const query = new IssueDashboardProjectionQuery(repository.database)
    const localIssue = createIssue(repository, 'Local issue', 'local')
    const remoteIssue = createIssue(repository, 'Remote issue', 'ssh:builder')
    const localConversation = createConversation(
      repository,
      'local',
      'local',
      localIssue.id
    )
    const remoteConversation = createConversation(
      repository,
      'remote',
      'ssh:builder',
      remoteIssue.id
    )
    for (const [conversationId, launchToken, createdAt] of [
      [localConversation.id, 'dashboard-local', 10],
      [remoteConversation.id, 'dashboard-remote', 20]
    ] as const) {
      repository.conversationLaunchClaims.create({
        conversationId,
        launchToken,
        paneKey: 'tab:same-pane',
        createdAt,
        expiresAt: 10_000
      })
    }

    expect(
      query.project(resolveIssueAuthorityRoute('local'), ['tab:same-pane']).panes
    ).toEqual([
      expect.objectContaining({
        conversationId: localConversation.id,
        issue: expect.objectContaining({ id: localIssue.id })
      })
    ])

    const remoteRoute = resolveIssueAuthorityRoute('ssh:builder', {
      isManagedSshTarget: (targetId) => targetId === 'builder'
    })
    expect(query.project(remoteRoute, ['tab:same-pane']).panes).toEqual([
      expect.objectContaining({
        conversationId: remoteConversation.id,
        issue: expect.objectContaining({ id: remoteIssue.id })
      })
    ])
  })
})
