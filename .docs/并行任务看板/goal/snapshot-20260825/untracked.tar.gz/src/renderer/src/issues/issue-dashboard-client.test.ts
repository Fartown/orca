import { describe, expect, it, vi } from 'vitest'
import type { ExecutionHostId } from '../../../shared/execution-host'
import type { IssueDashboardProjection } from '../../../shared/issues/types'
import {
  loadIssueDashboardProjection,
  type IssueDashboardClientDependencies
} from './issue-dashboard-client'

const AUTHORITY = {
  authorityId: '11111111-1111-4111-8111-111111111111',
  hostPartitionKey: 'local',
  routeExecutionHostId: 'local'
} as const

function projection(
  overrides: Partial<IssueDashboardProjection> = {}
): IssueDashboardProjection {
  return {
    authority: AUTHORITY,
    snapshotFactsRevision: 3,
    panes: [],
    ...overrides
  }
}

function dependencies(
  callRpc: IssueDashboardClientDependencies['callRpc']
): IssueDashboardClientDependencies {
  return {
    supportsCapability: vi.fn(async () => true),
    callRpc
  }
}

describe('loadIssueDashboardProjection', () => {
  it('skips RPC when a runtime lacks the Issues capability', async () => {
    const deps = dependencies(vi.fn())
    vi.mocked(deps.supportsCapability).mockResolvedValue(false)

    await expect(
      loadIssueDashboardProjection('runtime:legacy', ['pane-1'], deps)
    ).resolves.toEqual({ status: 'unsupported' })
    expect(deps.callRpc).not.toHaveBeenCalled()
  })

  it('deduplicates pane keys and merges bounded pages without changing authority', async () => {
    const paneKeys = Array.from({ length: 501 }, (_, index) => `pane-${index}`)
    const callRpc = vi.fn(async (_route: ExecutionHostId, _method: string, params: unknown) => {
      const request = params as { paneKeys: string[] }
      return projection({
        panes: request.paneKeys.map((paneKey, index) => ({
          paneKey,
          conversationId: `${index.toString().padStart(8, '0')}-1111-4111-8111-111111111111`,
          issue: null,
          latestRound: null
        }))
      })
    })

    const result = await loadIssueDashboardProjection(
      'local',
      [...paneKeys, paneKeys[0]],
      dependencies(callRpc)
    )

    expect(result.status).toBe('ready')
    if (result.status !== 'ready') {
      return
    }
    expect(callRpc).toHaveBeenCalledTimes(2)
    expect(callRpc.mock.calls[0]?.[2]).toMatchObject({
      executionHostId: 'local',
      paneKeys: paneKeys.slice(0, 500)
    })
    expect(result.projection.panes).toHaveLength(501)
  })

  it('rejects a response stamped for another route', async () => {
    const result = await loadIssueDashboardProjection(
      'ssh:build-box',
      ['pane-1'],
      dependencies(
        vi.fn(async () =>
          projection({
            authority: {
              ...AUTHORITY,
              routeExecutionHostId: 'local'
            }
          })
        )
      )
    )

    expect(result).toEqual({
      status: 'error',
      error: 'Issue dashboard response was stamped for another route.'
    })
  })
})
