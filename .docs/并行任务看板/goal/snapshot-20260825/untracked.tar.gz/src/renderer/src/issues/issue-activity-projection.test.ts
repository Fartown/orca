import { randomUUID } from 'node:crypto'
import { describe, expect, it } from 'vitest'
import type {
  ConversationNavigationTarget,
  IssueActivityEntry,
  IssueAuthorityDescriptor,
  RoundRecordPreview
} from '../../../shared/issues/types'
import { buildIssueActivityThreadProjections } from './issue-activity-projection'

const authority: IssueAuthorityDescriptor = {
  authorityId: randomUUID(),
  hostPartitionKey: 'local',
  routeExecutionHostId: 'local'
}

function conversation(
  id: string,
  paneKey: string | null = null
): ConversationNavigationTarget {
  return {
    id,
    hostPartitionKey: 'local',
    executionHostId: 'local',
    workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-a' },
    workspaceSnapshot: { name: 'Workspace A', path: '/workspace-a' },
    agent: 'codex',
    title: 'Investigate race',
    titleSource: 'user',
    issueId: 'issue-a',
    state: 'active',
    launchFailure: null,
    createdAt: 1,
    updatedAt: 2,
    navigation: {
      paneKey,
      providerSession: null,
      resumeLocator: null
    }
  }
}

function round(
  id: string,
  conversationId: string,
  occurredAt: number,
  options: Partial<RoundRecordPreview> = {}
): RoundRecordPreview {
  return {
    id,
    conversationId,
    kind: 'completion',
    stateSource: 'hook',
    occurredAt,
    executionChainId: null,
    supersedesRoundId: null,
    userInput: {
      completeness: 'preview-complete',
      storage: 'preview',
      bytes: 6,
      preview: 'Review',
      previewBytes: 6
    },
    agentOutput: {
      completeness: 'preview-complete',
      storage: 'preview',
      bytes: 4,
      preview: 'Done',
      previewBytes: 4
    },
    pendingQuestion: {
      completeness: 'not-captured',
      storage: 'none',
      bytes: 0,
      preview: null,
      previewBytes: 0
    },
    readAt: null,
    resolvedAt: null,
    resolution: null,
    effectiveResolvedAt: null,
    effectiveResolution: null,
    finalizedAt: occurredAt,
    bodyEvictedAt: null,
    bodyDeletedAt: null,
    bodyRevision: 1,
    createdAt: occurredAt,
    ...options
  }
}

function roundEntry(
  id: string,
  target: ConversationNavigationTarget,
  occurredAt: number,
  options: Partial<RoundRecordPreview> = {}
): IssueActivityEntry {
  return {
    type: 'round',
    id,
    occurredAt,
    round: round(id, target.id, occurredAt, options),
    conversation: target,
    issue: {
      id: 'issue-a',
      title: 'Issue A',
      typeLabel: 'Feature',
      state: 'active'
    }
  }
}

describe('buildIssueActivityThreadProjections', () => {
  it('keeps persisted rounds visible without a live pane and uses readAt as unread truth', () => {
    const target = conversation('conversation-a')
    const unread = roundEntry('round-new', target, 20)
    const read = roundEntry('round-old', target, 10, { readAt: 15 })

    const threads = buildIssueActivityThreadProjections([
      {
        routeExecutionHostId: 'local',
        authority,
        entries: [read, unread]
      }
    ])

    expect(threads).toHaveLength(1)
    expect(threads[0]).toMatchObject({
      key: 'local\u0000conversation:conversation-a',
      paneKey: null,
      unread: true,
      roundRecordIds: ['round-old', 'round-new'],
      unreadRoundRecordIds: ['round-new'],
      latestOccurredAt: 20,
      preview: 'Done'
    })
    expect(threads[0].entries.map((entry) => entry.id)).toEqual([
      'round-new',
      'round-old'
    ])
  })

  it('coalesces lifecycle and round entries by Conversation while preserving navigation', () => {
    const paneKey = 'tab-a:11111111-1111-4111-8111-111111111111'
    const target = conversation('conversation-a', paneKey)
    const entries: IssueActivityEntry[] = [
      roundEntry('round-a', target, 10),
      {
        type: 'issue-event',
        id: 'event-a',
        occurredAt: 30,
        event: {
          id: 'event-a',
          hostPartitionKey: 'local',
          executionHostId: 'local',
          kind: 'conversation-bound',
          conversationId: target.id,
          issueRefs: [{ issueId: 'issue-a', role: 'target', titleSnapshot: 'Issue A' }],
          payload: {},
          occurredAt: 30,
          factsRevision: 3
        },
        conversation: target
      }
    ]

    const [thread] = buildIssueActivityThreadProjections([
      { routeExecutionHostId: 'local', authority, entries }
    ])

    expect(thread).toMatchObject({
      paneKey,
      title: 'Issue A',
      preview: 'Conversation Bound: Issue A',
      unread: true
    })
    expect(thread.entries.map((entry) => entry.id)).toEqual(['event-a', 'round-a'])
  })

  it('keeps issue-only lifecycle events as standalone timeline rows', () => {
    const entries: IssueActivityEntry[] = [
      {
        type: 'issue-event',
        id: 'event-only',
        occurredAt: 40,
        event: {
          id: 'event-only',
          hostPartitionKey: 'local',
          executionHostId: 'local',
          kind: 'archived',
          conversationId: null,
          issueRefs: [{ issueId: 'issue-a', role: 'target', titleSnapshot: 'Issue A' }],
          payload: {},
          occurredAt: 40,
          factsRevision: 4
        },
        conversation: null
      }
    ]

    const [thread] = buildIssueActivityThreadProjections([
      { routeExecutionHostId: 'local', authority, entries }
    ])

    expect(thread).toMatchObject({
      key: 'local\u0000event:event-only',
      conversation: null,
      issue: { id: 'issue-a', title: 'Issue A', state: 'archived' },
      title: 'Issue A',
      preview: 'Archived: Issue A',
      unread: false
    })
  })
})
