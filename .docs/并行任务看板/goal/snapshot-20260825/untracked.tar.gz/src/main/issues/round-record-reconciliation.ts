import { createHash } from 'node:crypto'
import { resolveNativeChatTranscriptAgent } from '../../shared/native-chat-agent-support'
import type { RoundRecord } from '../../shared/issues/types'
import {
  readNativeChatTranscript,
  type ReadTranscriptResult
} from '../native-chat/transcript-reader'
import { requireConversationRecord } from './conversation-record-queries'
import type { IssueRepository } from './issue-repository'
import type { CreateRoundRecordInput } from './issue-repository-types'
import { createProviderTurnRefValue } from './round-record-provider-turn-ref'
import {
  buildRoundTranscriptFacts,
  type RoundTranscriptFact
} from './round-record-transcript-facts'

export type RoundRecordReconciliationResult =
  | {
      disposition: 'reconciled'
      conversationId: string
      createdRoundIds: string[]
      upgradedRoundIds: string[]
      unchangedRoundIds: string[]
    }
  | {
      disposition: 'skipped'
      conversationId: string
      reason:
        | 'identity-missing'
        | 'provider-unsupported'
        | 'remote-transcript-unavailable'
        | 'transcript-not-found'
        | 'transcript-read-failed'
      detail?: string
    }

export type RoundRecordReconcilerDependencies = {
  readTranscript?: typeof readNativeChatTranscript
  onDiagnostic?(result: RoundRecordReconciliationResult): void
}

const RECONCILIATION_CALLER_FINGERPRINT = 'orca-round-transcript-reconciler'

export class RoundRecordReconciler {
  private readonly scheduled = new Map<string, Promise<RoundRecordReconciliationResult>>()

  constructor(
    private readonly repository: IssueRepository,
    private readonly dependencies: RoundRecordReconcilerDependencies = {}
  ) {}

  schedule(conversationId: string): Promise<RoundRecordReconciliationResult> {
    const existing = this.scheduled.get(conversationId)
    if (existing) {
      return existing
    }
    const scheduled = Promise.resolve()
      .then(() => this.reconcile(conversationId))
      .finally(() => {
        if (this.scheduled.get(conversationId) === scheduled) {
          this.scheduled.delete(conversationId)
        }
      })
    this.scheduled.set(conversationId, scheduled)
    return scheduled
  }

  async reconcile(conversationId: string): Promise<RoundRecordReconciliationResult> {
    const conversation = requireConversationRecord(this.repository.database, conversationId)
    const transcriptAgent = resolveNativeChatTranscriptAgent(conversation.agent)
    if (!transcriptAgent) {
      return this.finish({
        disposition: 'skipped',
        conversationId,
        reason: 'provider-unsupported'
      })
    }
    if (conversation.hostPartitionKey !== 'local') {
      return this.finish({
        disposition: 'skipped',
        conversationId,
        reason: 'remote-transcript-unavailable'
      })
    }
    const identity = this.repository.conversationIdentities
      .listForConversation(conversationId)
      .find((candidate) => candidate.retiredAt === null)
    if (!identity) {
      return this.finish({
        disposition: 'skipped',
        conversationId,
        reason: 'identity-missing'
      })
    }

    let readResult: ReadTranscriptResult
    try {
      readResult = await (this.dependencies.readTranscript ?? readNativeChatTranscript)(
        conversation.agent,
        identity.session.id,
        { transcriptPath: identity.session.transcriptPath }
      )
    } catch (error) {
      return this.finish({
        disposition: 'skipped',
        conversationId,
        reason: 'transcript-read-failed',
        detail: error instanceof Error ? error.message : String(error)
      })
    }
    if (!('messages' in readResult)) {
      return this.finish({
        disposition: 'skipped',
        conversationId,
        reason: readResult.notFound ? 'transcript-not-found' : 'transcript-read-failed',
        detail: readResult.error
      })
    }

    const createdRoundIds: string[] = []
    const upgradedRoundIds: string[] = []
    const unchangedRoundIds: string[] = []
    for (const fact of buildRoundTranscriptFacts(readResult.messages)) {
      const result = this.reconcileFact(conversationId, identity.identityFingerprint, fact)
      if (result.disposition === 'created') {
        createdRoundIds.push(result.round.id)
      } else if (result.disposition === 'upgraded') {
        upgradedRoundIds.push(result.round.id)
      } else {
        unchangedRoundIds.push(result.round.id)
      }
    }
    return this.finish({
      disposition: 'reconciled',
      conversationId,
      createdRoundIds,
      upgradedRoundIds,
      unchangedRoundIds
    })
  }

  private reconcileFact(
    conversationId: string,
    identityFingerprint: string,
    fact: RoundTranscriptFact
  ): { disposition: 'created' | 'upgraded' | 'unchanged'; round: RoundRecord } {
    const providerRef = fact.providerTurnId
      ? {
          kind: 'provider-turn',
          value: createProviderTurnRefValue(identityFingerprint, fact.providerTurnId),
          reachable: true
        }
      : null
    const transcriptRef = {
      kind: 'transcript-fact',
      value: scopedFactValue(identityFingerprint, fact.factKey),
      reachable: true
    }
    const existing = providerRef
      ? this.repository.rounds.findByRef(providerRef)
      : this.repository.rounds.findByRef(transcriptRef)
    const input: CreateRoundRecordInput = {
      conversationId,
      kind: 'completion',
      stateSource: existing?.stateSource ?? 'reconciled',
      occurredAt: existing?.occurredAt ?? fact.occurredAt,
      dedupeKey:
        existing?.dedupeKey ??
        `round:reconciled:v1:${scopedFactValue(identityFingerprint, fact.factKey)}`,
      executionChainId: existing?.executionChainId ?? null,
      supersedesRoundId: existing?.supersedesRoundId ?? null,
      userInput: fact.userInput ? { text: fact.userInput } : undefined,
      agentOutput: { text: fact.agentOutput },
      readAt: existing?.readAt ?? null,
      resolvedAt: existing?.resolvedAt ?? null,
      resolution: existing?.resolution ?? null,
      finalizedAt: existing?.finalizedAt ?? fact.finalizedAt,
      refs: providerRef ? [providerRef, transcriptRef] : [transcriptRef]
    }
    const beforeRevision = existing?.bodyRevision
    const round = this.repository.rounds.create({
      identity: {
        callerFingerprint: RECONCILIATION_CALLER_FINGERPRINT,
        mutationId: `round-reconcile:${hashValue(input)}`
      },
      input
    })
    return {
      disposition:
        !existing ? 'created' : round.bodyRevision === beforeRevision ? 'unchanged' : 'upgraded',
      round
    }
  }

  private finish(result: RoundRecordReconciliationResult): RoundRecordReconciliationResult {
    this.dependencies.onDiagnostic?.(result)
    return result
  }
}

function scopedFactValue(identityFingerprint: string, factKey: string): string {
  return `v1:${createHash('sha256')
    .update(JSON.stringify([identityFingerprint, factKey]))
    .digest('hex')}`
}

function hashValue(value: unknown): string {
  return createHash('sha256').update(JSON.stringify(value)).digest('hex')
}
