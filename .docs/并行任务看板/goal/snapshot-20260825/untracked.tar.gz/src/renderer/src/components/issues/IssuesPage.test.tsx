// @vitest-environment happy-dom

import '@testing-library/jest-dom/vitest'
import { act } from 'react'
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor
} from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  DEFAULT_ISSUE_CLIENT_PREFERENCES
} from '../../../../shared/issues/client-data'
import type {
  IssueClientPreferences,
  IssueClientSnapshot
} from '../../../../shared/issues/client-data'
import type { IssueDetail, RoundRecordPage } from '../../../../shared/issues/types'
import {
  createIssuesDomainStore,
  type IssuesDomainDependencies,
  type IssuesDomainPartition
} from '../../issues/issues-domain-store'
import IssuesPage from './IssuesPage'
import {
  makeIssueDetail,
  makeConversationSummary,
  makeIssueSummary,
  makeRoundPreview
} from './issue-detail-test-data'

const navigationMocks = vi.hoisted(() => ({
  openIssueConversation: vi.fn()
}))

vi.mock('../../issues/issue-conversation-navigation', () => navigationMocks)

globalThis.IS_REACT_ACT_ENVIRONMENT = true

const ISSUE_A = '11111111-1111-4111-8111-111111111111'
const ISSUE_B = '11111111-1111-4111-8111-111111111112'

afterEach(cleanup)

describe('IssuesPage', () => {
  it('loads detail and Round Records for the selected Issue', async () => {
    const detail = makeIssueDetail(
      makeIssueSummary(ISSUE_A, { localTitle: 'Loaded Issue' })
    )
    const harness = createHarness({
      loadDetail: createDetailLoader({ status: 'ready', value: detail }),
      loadRounds: createRoundLoader({
        status: 'ready',
        value: roundPage([
          makeRoundPreview('33333333-3333-4333-8333-333333333341')
        ])
      })
    })

    render(<IssuesPage store={harness.store} />)

    expect(await screen.findByRole('heading', { name: 'Loaded Issue' }))
      .toBeInTheDocument()
    expect(harness.dependencies.loadDetail).toHaveBeenCalledWith(
      'local',
      ISSUE_A
    )
    expect(harness.dependencies.loadRounds).toHaveBeenCalledWith(
      'local',
      { issueId: ISSUE_A }
    )
    expect(
      screen.getByText('Implemented the requested change.')
    ).toBeInTheDocument()
  })

  it('shows cached facts without presenting them as live data', async () => {
    const detail = makeIssueDetail(
      makeIssueSummary(ISSUE_A, { localTitle: 'Cached Issue' })
    )
    const harness = createHarness({
      loadDetail: createDetailLoader({
        status: 'cached',
        value: detail,
        error: 'Host is offline.'
      }),
      loadRounds: createRoundLoader({
        status: 'cached',
        value: roundPage([
          makeRoundPreview('33333333-3333-4333-8333-333333333342')
        ]),
        error: 'Round history is cached.'
      })
    })

    render(<IssuesPage store={harness.store} />)

    expect(
      await screen.findByText('Showing cached Issue facts. Host is offline.')
    ).toBeInTheDocument()
    expect(screen.getByText('Round history is cached.')).toBeInTheDocument()
  })

  it('distinguishes unsupported, failed, and deleted selections', async () => {
    const unsupported = createHarness({
      loadDetail: createDetailLoader({ status: 'unsupported' }),
      loadRounds: createRoundLoader({ status: 'unsupported' })
    })
    const unsupportedView = render(<IssuesPage store={unsupported.store} />)
    expect(
      await screen.findByRole('heading', { name: 'Update this Orca host' })
    ).toBeInTheDocument()
    unsupportedView.unmount()

    const failed = createHarness({
      loadDetail: createDetailLoader({
        status: 'error',
        error: 'Database unavailable.'
      })
    })
    const failedView = render(<IssuesPage store={failed.store} />)
    expect(
      await screen.findByRole('heading', { name: 'Could not load Issue' })
    ).toBeInTheDocument()
    expect(screen.getByText('Database unavailable.')).toBeInTheDocument()
    failedView.unmount()

    const deleted = createHarness({
      loadDetail: createDetailLoader({
        status: 'error',
        error: 'Issue not found.'
      }),
      partition: readyPartition([])
    })
    render(<IssuesPage store={deleted.store} />)
    expect(
      await screen.findByRole('heading', { name: 'Issue deleted' })
    ).toBeInTheDocument()
  })

  it('keeps a newer selection visible when an older request resolves last', async () => {
    const requests = new Map<string, ReturnType<typeof deferred<IssueDetail>>>()
    const harness = createHarness({
      loadDetail: vi
        .fn<IssuesDomainDependencies['loadDetail']>()
        .mockImplementation((_route, issueId) => {
          const request = deferred<IssueDetail>()
          requests.set(issueId, request)
          return request.promise.then((value) => ({
            status: 'ready' as const,
            value
          }))
        })
    })
    render(<IssuesPage store={harness.store} />)
    await waitFor(() => expect(requests.has(ISSUE_A)).toBe(true))

    await act(async () => {
      harness.store.getState().selectIssue('local', ISSUE_B)
    })
    await waitFor(() => expect(requests.has(ISSUE_B)).toBe(true))

    await act(async () => {
      requests.get(ISSUE_B)?.resolve(
        makeIssueDetail(
          makeIssueSummary(ISSUE_B, { localTitle: 'New selection' })
        )
      )
    })
    expect(
      await screen.findByRole('heading', { name: 'New selection' })
    ).toBeInTheDocument()

    await act(async () => {
      requests.get(ISSUE_A)?.resolve(
        makeIssueDetail(
          makeIssueSummary(ISSUE_A, { localTitle: 'Old selection' })
        )
      )
    })
    expect(screen.queryByText('Old selection')).toBeNull()
    expect(
      screen.getByRole('heading', { name: 'New selection' })
    ).toBeInTheDocument()
  })

  it('retries a failed detail request without changing the selected Issue', async () => {
    const loadDetail = vi
      .fn<IssuesDomainDependencies['loadDetail']>()
      .mockResolvedValueOnce({
        status: 'error',
        error: 'Temporary failure.'
      })
      .mockResolvedValueOnce({
        status: 'ready',
        value: makeIssueDetail(
          makeIssueSummary(ISSUE_A, { localTitle: 'Recovered Issue' })
        )
      })
    const harness = createHarness({ loadDetail })
    render(<IssuesPage store={harness.store} />)

    fireEvent.click(await screen.findByRole('button', { name: 'Retry' }))

    expect(
      await screen.findByRole('heading', { name: 'Recovered Issue' })
    ).toBeInTheDocument()
    expect(harness.store.getState().preferences.selectedIssueId).toBe(ISSUE_A)
    expect(loadDetail).toHaveBeenCalledTimes(2)
  })

  it('opens Direct work through the default precise Conversation navigation path', async () => {
    navigationMocks.openIssueConversation.mockReset()
    const conversation = makeConversationSummary(
      '22222222-2222-4222-8222-222222222229',
      { title: 'Open exact Conversation' }
    )
    const detail = makeIssueDetail(
      makeIssueSummary(ISSUE_A, { localTitle: 'Conversation Issue' }),
      {
        directConversations: [conversation],
        workspaceSnapshots: [conversation.workspaceSnapshot]
      }
    )
    const harness = createHarness({
      loadDetail: createDetailLoader({ status: 'ready', value: detail })
    })

    render(<IssuesPage store={harness.store} />)

    fireEvent.click(
      await screen.findByRole('button', {
        name: /Open exact Conversation/
      })
    )

    expect(navigationMocks.openIssueConversation).toHaveBeenCalledWith({
      routeExecutionHostId: 'local',
      conversation
    })
  })
})

function createHarness({
  loadDetail = createDetailLoader({
    status: 'error',
    error: 'Not configured.'
  }),
  loadRounds = createRoundLoader({
    status: 'ready',
    value: roundPage([])
  }),
  partition
}: {
  loadDetail?: IssuesDomainDependencies['loadDetail']
  loadRounds?: IssuesDomainDependencies['loadRounds']
  partition?: IssuesDomainPartition
} = {}) {
  const preferences = selectedPreferences()
  const dependencies: IssuesDomainDependencies = {
    readPreferences: vi
      .fn<IssuesDomainDependencies['readPreferences']>()
      .mockResolvedValue(preferences),
    writePreferences: vi
      .fn<IssuesDomainDependencies['writePreferences']>()
      .mockImplementation(async (value) => value),
    loadPartition: vi
      .fn<IssuesDomainDependencies['loadPartition']>()
      .mockResolvedValue({
        status: 'ready',
        value: snapshot()
      }),
    loadDetail,
    loadUnassigned: vi
      .fn<IssuesDomainDependencies['loadUnassigned']>()
      .mockResolvedValue({ status: 'ready', value: [] }),
    loadRounds
  }
  const store = createIssuesDomainStore(dependencies)
  store.setState({
    hydrationStatus: 'ready',
    preferences,
    ...(partition
      ? { partitionsByRoute: { local: partition } }
      : {})
  })
  return { dependencies, store }
}

function createDetailLoader(
  result: Awaited<ReturnType<IssuesDomainDependencies['loadDetail']>>
): ReturnType<typeof vi.fn<IssuesDomainDependencies['loadDetail']>> {
  return vi
    .fn<IssuesDomainDependencies['loadDetail']>()
    .mockResolvedValue(result)
}

function createRoundLoader(
  result: Awaited<ReturnType<IssuesDomainDependencies['loadRounds']>>
): ReturnType<typeof vi.fn<IssuesDomainDependencies['loadRounds']>> {
  return vi
    .fn<IssuesDomainDependencies['loadRounds']>()
    .mockResolvedValue(result)
}

function selectedPreferences(): IssueClientPreferences {
  return {
    ...DEFAULT_ISSUE_CLIENT_PREFERENCES,
    sidebarRootMode: 'issues',
    selectedRouteExecutionHostId: 'local',
    selectedIssueId: ISSUE_A
  }
}

function snapshot(): IssueClientSnapshot {
  return {
    authority: {
      authorityId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
      hostPartitionKey: 'local',
      routeExecutionHostId: 'local'
    },
    cachedAt: 1,
    factsRevision: 1,
    treeRevision: 1,
    searchRevision: 0,
    issues: [],
    details: [],
    unassignedConversations: [],
    rounds: []
  }
}

function roundPage(
  rounds: RoundRecordPage['rounds']
): RoundRecordPage {
  return {
    authority: snapshot().authority,
    snapshotFactsRevision: 1,
    rounds,
    nextCursor: null
  }
}

function readyPartition(
  issues: IssuesDomainPartition['issues']
): IssuesDomainPartition {
  return {
    routeExecutionHostId: 'local',
    status: 'ready',
    authority: snapshot().authority,
    issues,
    detailsByIssueId: {},
    unassignedConversations: [],
    error: null,
    cachedAt: 1,
    factsRevision: 1,
    treeRevision: 1
  }
}

function deferred<T>(): {
  promise: Promise<T>
  resolve: (value: T) => void
} {
  let resolve!: (value: T) => void
  const promise = new Promise<T>((resolver) => {
    resolve = resolver
  })
  return { promise, resolve }
}
