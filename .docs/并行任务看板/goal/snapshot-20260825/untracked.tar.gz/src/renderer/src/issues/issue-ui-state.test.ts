import { createStore, type StoreApi } from 'zustand/vanilla'
import { describe, expect, it } from 'vitest'
import type { AppState } from '../store/types'
import { createSettingsSearchState } from '../store/slices/settings-search-state'
import { createUISlice } from '../store/slices/ui'
import { createWorktreeNavHistorySlice } from '../store/slices/worktree-nav-history'

function createUIStore(): StoreApi<AppState> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return createStore<any>()((...args: any[]) => ({
    repos: [],
    worktreesByRepo: {},
    rightSidebarOpen: false,
    rightSidebarWidth: 280,
    markdownTocPanelWidth: 240,
    combinedDiffFileTreeWidth: 256,
    rightSidebarTab: 'explorer',
    rightSidebarExplorerView: 'files',
    ...createSettingsSearchState(args[0]),
    ...createWorktreeNavHistorySlice(
      ...(args as Parameters<typeof createWorktreeNavHistorySlice>)
    ),
    ...createUISlice(...(args as Parameters<typeof createUISlice>))
  })) as unknown as StoreApi<AppState>
}

describe('Issues page UI state', () => {
  it('returns to the originating top-level view when Issues closes', () => {
    const store = createUIStore()
    store.setState({ activeView: 'tasks' })

    store.getState().openIssuesPage()

    expect(store.getState().activeView).toBe('issues')
    expect(store.getState().previousViewBeforeIssues).toBe('tasks')

    store.getState().closeIssuesPage()

    expect(store.getState().activeView).toBe('tasks')
  })

  it('preserves the original return target when Issues is reopened while visible', () => {
    const store = createUIStore()
    store.setState({ activeView: 'activity' })

    store.getState().openIssuesPage()
    store.getState().openIssuesPage()

    expect(store.getState().previousViewBeforeIssues).toBe('activity')
  })
})
