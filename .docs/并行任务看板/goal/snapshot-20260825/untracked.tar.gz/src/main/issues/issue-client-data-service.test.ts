import { randomUUID } from 'node:crypto'
import { afterEach, describe, expect, it } from 'vitest'
import type {
  IssueClientPreferences,
  IssueClientSnapshot
} from '../../shared/issues/client-data'
import type { IssueAuthorityDescriptor } from '../../shared/issues/types'
import {
  createIssueTestUserDataPath,
  issueFileDatabaseTestsAvailable,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueClientDataService } from './issue-client-data-service'

function authority(
  routeExecutionHostId: IssueAuthorityDescriptor['routeExecutionHostId']
): IssueAuthorityDescriptor {
  return {
    authorityId: randomUUID(),
    hostPartitionKey: 'local',
    routeExecutionHostId
  }
}

function snapshot(
  descriptor: IssueAuthorityDescriptor,
  cachedAt: number
): IssueClientSnapshot {
  return {
    authority: descriptor,
    cachedAt,
    factsRevision: 7,
    treeRevision: 3,
    searchRevision: 2,
    issues: [],
    details: [],
    unassignedConversations: [],
    rounds: []
  }
}

function preferences(
  overrides: Partial<IssueClientPreferences> = {}
): IssueClientPreferences {
  return {
    version: 1,
    sidebarRootMode: 'issues',
    filter: 'needs-me',
    searchQuery: '',
    typeFilter: null,
    collapsedIssueIds: [randomUUID()],
    selectedRouteExecutionHostId: 'local',
    selectedIssueId: randomUUID(),
    sidebarScrollOffset: 42,
    ...overrides
  }
}

afterEach(removeIssueTestDirectories)

describe.skipIf(!issueFileDatabaseTestsAvailable)(
  'IssueClientDataService',
  () => {
    it('keeps cache and UI preferences isolated by active profile', () => {
      const userDataPath = createIssueTestUserDataPath(
        'orca-issue-client-profile'
      )
      const descriptor = authority('runtime:paired')
      const first = new IssueClientDataService('profile-a', userDataPath)
      const second = new IssueClientDataService('profile-b', userDataPath)

      first.replaceCache({
        routeExecutionHostId: 'runtime:paired',
        snapshot: snapshot(descriptor, 100)
      })
      const firstPreferences = first.writePreferences(preferences())

      expect(first.readCache({ routeExecutionHostId: 'runtime:paired' })).toEqual({
        status: 'hit',
        snapshot: snapshot(descriptor, 100)
      })
      expect(second.readCache({ routeExecutionHostId: 'runtime:paired' })).toEqual({
        status: 'miss'
      })
      expect(first.readPreferences()).toEqual(firstPreferences)
      expect(second.readPreferences()).toMatchObject({
        sidebarRootMode: 'workspaces',
        filter: 'all',
        selectedIssueId: null
      })
    })

    it('rejects a cache write whose route does not match the authority', () => {
      const userDataPath = createIssueTestUserDataPath(
        'orca-issue-client-route'
      )
      const service = new IssueClientDataService('profile-a', userDataPath)
      const descriptor = authority('runtime:first')

      expect(() =>
        service.replaceCache({
          routeExecutionHostId: 'runtime:second',
          snapshot: snapshot(descriptor, 100)
        })
      ).toThrow('route does not match')
      expect(
        service.readCache({ routeExecutionHostId: 'runtime:second' })
      ).toEqual({ status: 'miss' })
    })

    it('restamps a shared authority cache for the requested route', () => {
      const userDataPath = createIssueTestUserDataPath(
        'orca-issue-client-restamp'
      )
      const service = new IssueClientDataService('profile-a', userDataPath)
      const descriptor = authority('runtime:alias-a')

      service.replaceCache({
        routeExecutionHostId: 'runtime:alias-a',
        snapshot: snapshot(descriptor, 100)
      })

      expect(
        service.readCache({ routeExecutionHostId: 'runtime:alias-a' })
      ).toMatchObject({
        status: 'hit',
        snapshot: {
          authority: {
            authorityId: descriptor.authorityId,
            routeExecutionHostId: 'runtime:alias-a'
          },
          cachedAt: 100
        }
      })
    })
  }
)
