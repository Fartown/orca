import type {
  DeleteIssuePreparation,
  DeleteIssueWarning,
  IssueRecord
} from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { issueEventRef, IssueEventRepository } from './issue-event-repository'
import { assertIssueForest } from './issue-hierarchy-validation'
import { bumpIssueHostRevisions, getIssueHostRevisions } from './issue-host-state'
import { executeIssueMutation } from './issue-mutation-receipt'
import { getIssueRecord, requireIssueRecord } from './issue-record-queries'
import { IssueRepositoryError } from './issue-repository-error'
import {
  listIssueSiblingIds,
  writeIssueSiblingScope
} from './issue-sibling-order'
import type {
  CommitDeleteIssueInput,
  CommitDeleteIssueResult,
  IssueMutationParams
} from './issue-repository-types'

type DirectConversationRow = {
  id: string
  state: 'active' | 'closed'
}

export class IssueDeleteRepository {
  constructor(
    private readonly database: IssueDatabase,
    private readonly events: IssueEventRepository
  ) {}

  prepare(issueId: string): DeleteIssuePreparation {
    const issue = requireIssueRecord(this.database, issueId)
    const children = this.listDirectChildren(issue)
    const conversations = this.listDirectConversations(issue)
    const legalTargets = this.listLegalTargets(issue)
    const defaultParent = issue.parentId
    const defaultIndex = issue.siblingOrder
    return {
      plan: {
        issueId: issue.id,
        expectedFactsRevision: getIssueHostRevisions(
          this.database,
          issue.hostPartitionKey
        ).factsRevision,
        children: children.map((child, offset) => ({
          issueId: child.id,
          destination: defaultParent
            ? { kind: 'parent' as const, parentId: defaultParent }
            : { kind: 'root' as const },
          index: defaultIndex + offset
        })),
        conversations: conversations.map((conversation) => ({
          conversationId: conversation.id,
          destinationIssueId: null
        }))
      },
      legalParentTargetsByChild: Object.fromEntries(
        children.map((child) => [
          child.id,
          legalTargets
            .filter((targetId) =>
              isLegalPlannedParent(this.database, child.id, targetId, issue.id)
            )
        ])
      ),
      legalConversationTargets: legalTargets.filter((targetId) => {
        if (targetId === null) {
          return true
        }
        return getIssueRecord(this.database, targetId)?.state === 'active'
      }),
      warnings: this.listWarnings(issue, conversations)
    }
  }

  commit(
    params: IssueMutationParams<CommitDeleteIssueInput>
  ): CommitDeleteIssueResult {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.delete',
      payload: params.input,
      operation: () => this.commitWithinTransaction(params.input)
    })
  }

  private commitWithinTransaction(plan: CommitDeleteIssueInput): CommitDeleteIssueResult {
    const issue = requireIssueRecord(this.database, plan.issueId)
    const revisions = getIssueHostRevisions(this.database, issue.hostPartitionKey)
    if (revisions.factsRevision !== plan.expectedFactsRevision) {
      throw new IssueRepositoryError(
        'issue_facts_revision_stale',
        `Issue delete plan revision ${plan.expectedFactsRevision} is stale.`,
        {
          expectedFactsRevision: plan.expectedFactsRevision,
          currentFactsRevision: revisions.factsRevision
        }
      )
    }
    const children = this.listDirectChildren(issue)
    const conversations = this.listDirectConversations(issue)
    assertExactIds(
      children.map((child) => child.id),
      plan.children.map((child) => child.issueId),
      'child'
    )
    assertExactIds(
      conversations.map((conversation) => conversation.id),
      plan.conversations.map((conversation) => conversation.conversationId),
      'Conversation'
    )

    const parentChanges = new Map<string, string | null>()
    for (const childPlan of plan.children) {
      const parentId =
        childPlan.destination.kind === 'parent' ? childPlan.destination.parentId : null
      if (!Number.isSafeInteger(childPlan.index) || childPlan.index < 0) {
        throw new IssueRepositoryError(
          'issue_delete_plan_invalid',
          'Delete plan child index must be a non-negative integer.'
        )
      }
      parentChanges.set(childPlan.issueId, parentId)
    }
    assertIssueForest({
      database: this.database,
      hostPartitionKey: issue.hostPartitionKey,
      executionHostId: issue.executionHostId,
      deletedIssueId: issue.id,
      parentChanges
    })

    for (const binding of plan.conversations) {
      this.assertConversationDestination(issue, binding.destinationIssueId)
    }

    const now = Date.now()
    const affectedIssueIds = this.applyChildMoves(issue, plan.children, now)
    const updateConversation = this.database.prepare(
      `UPDATE conversations
       SET issue_id = ?, updated_at = ?
       WHERE id = ? AND issue_id = ?`
    )
    for (const binding of plan.conversations) {
      const result = updateConversation.run(
        binding.destinationIssueId,
        now,
        binding.conversationId,
        issue.id
      )
      if (result.changes !== 1) {
        throw new IssueRepositoryError(
          'issue_delete_plan_invalid',
          `Conversation ${binding.conversationId} changed during delete.`
        )
      }
    }
    this.assertEmpty(issue)
    this.database.prepare('DELETE FROM issues WHERE id = ?').run(issue.id)
    const nextRevisions = bumpIssueHostRevisions(
      this.database,
      issue.hostPartitionKey,
      { tree: true, searchable: true },
      now
    )
    this.events.appendWithinTransaction({
      hostPartitionKey: issue.hostPartitionKey,
      kind: 'deleted',
      issueRefs: [issueEventRef(issue, 'deleted-issue')],
      payload: {
        children: plan.children,
        conversations: plan.conversations
      },
      occurredAt: now,
      factsRevision: nextRevisions.factsRevision
    })
    return {
      deletedIssueId: issue.id,
      affectedIssueIds: [...new Set(affectedIssueIds.filter((id) => id !== issue.id))],
      affectedConversationIds: plan.conversations.map((binding) => binding.conversationId),
      factsRevision: nextRevisions.factsRevision,
      treeRevision: nextRevisions.treeRevision
    }
  }

  private listDirectChildren(issue: IssueRecord): IssueRecord[] {
    return (
      this.database
        .prepare(
          `SELECT id FROM issues
           WHERE host_partition_key = ? AND parent_id = ?
           ORDER BY sibling_order, id`
        )
        .all(issue.hostPartitionKey, issue.id) as { id: string }[]
    ).map((row) => requireIssueRecord(this.database, row.id))
  }

  private listDirectConversations(issue: IssueRecord): DirectConversationRow[] {
    return this.database
      .prepare(
        `SELECT id, state FROM conversations
         WHERE host_partition_key = ? AND issue_id = ?
         ORDER BY updated_at, id`
      )
      .all(issue.hostPartitionKey, issue.id) as DirectConversationRow[]
  }

  private listLegalTargets(issue: IssueRecord): (string | null)[] {
    const rows = this.database
      .prepare(
        `SELECT id FROM issues
         WHERE host_partition_key = ? AND id <> ? AND state = 'active'
         ORDER BY parent_id, sibling_order, id`
      )
      .all(issue.hostPartitionKey, issue.id) as { id: string }[]
    return [null, ...rows.map((row) => row.id)]
  }

  private listWarnings(
    issue: IssueRecord,
    conversations: readonly DirectConversationRow[]
  ): DeleteIssueWarning[] {
    const warnings: DeleteIssueWarning[] = conversations
      .filter((conversation) => conversation.state === 'active')
      .map((conversation) => ({
        conversationId: conversation.id,
        kind: 'active-conversation'
      }))
    const waiting = this.database
      .prepare(
        `SELECT round.conversation_id AS conversationId, round.id AS roundRecordId
         FROM round_record_effective_state round
         JOIN conversations conversation ON conversation.id = round.conversation_id
         WHERE conversation.issue_id = ?
           AND round.kind = 'waiting'
           AND round.effective_resolved_at IS NULL
         ORDER BY round.occurred_at, round.id`
      )
      .all(issue.id) as { conversationId: string; roundRecordId: string }[]
    warnings.push(
      ...waiting.map((row) => ({
        conversationId: row.conversationId,
        kind: 'unresolved-waiting' as const,
        roundRecordId: row.roundRecordId
      }))
    )
    return warnings
  }

  private assertConversationDestination(
    source: IssueRecord,
    destinationIssueId: string | null
  ): void {
    if (destinationIssueId === null) {
      return
    }
    const destination = requireIssueRecord(this.database, destinationIssueId)
    if (
      destination.id === source.id ||
      destination.hostPartitionKey !== source.hostPartitionKey ||
      destination.executionHostId !== source.executionHostId
    ) {
      throw new IssueRepositoryError(
        'issue_delete_plan_invalid',
        `Conversation destination ${destinationIssueId} is outside the Issue partition.`
      )
    }
    if (destination.state !== 'active') {
      throw new IssueRepositoryError(
        'issue_target_archived',
        `Conversation destination ${destinationIssueId} is archived.`
      )
    }
  }

  private applyChildMoves(
    issue: IssueRecord,
    plans: CommitDeleteIssueInput['children'],
    now: number
  ): string[] {
    const moved = new Set(plans.map((plan) => plan.issueId))
    const scopes = new Set<string | null>([issue.id])
    for (const plan of plans) {
      scopes.add(plan.destination.kind === 'parent' ? plan.destination.parentId : null)
    }
    const byScope = new Map<string | null, string[]>()
    for (const scope of scopes) {
      byScope.set(
        scope,
        listIssueSiblingIds({
          database: this.database,
          hostPartitionKey: issue.hostPartitionKey,
          parentId: scope
        }).filter((id) => id !== issue.id && !moved.has(id))
      )
    }
    for (const plan of plans) {
      const parentId =
        plan.destination.kind === 'parent' ? plan.destination.parentId : null
      const ids = byScope.get(parentId) ?? []
      ids.splice(Math.min(plan.index, ids.length), 0, plan.issueId)
      byScope.set(parentId, ids)
    }
    const affected: string[] = []
    for (const [parentId, issueIds] of byScope) {
      if (parentId === issue.id) {
        continue
      }
      writeIssueSiblingScope({
        database: this.database,
        hostPartitionKey: issue.hostPartitionKey,
        parentId,
        issueIds,
        now
      })
      affected.push(...issueIds)
    }
    return affected
  }

  private assertEmpty(issue: IssueRecord): void {
    const counts = this.database
      .prepare(
        `SELECT
           (SELECT COUNT(*) FROM issues WHERE parent_id = ?) AS children,
           (SELECT COUNT(*) FROM conversations WHERE issue_id = ?) AS conversations`
      )
      .get(issue.id, issue.id) as { children: number; conversations: number }
    if (counts.children !== 0 || counts.conversations !== 0) {
      throw new IssueRepositoryError(
        'issue_delete_plan_invalid',
        `Issue ${issue.id} still has direct dependents.`
      )
    }
  }
}

function assertExactIds(expected: string[], actual: string[], label: string): void {
  const normalizedExpected = [...expected].sort()
  const normalizedActual = [...new Set(actual)].sort()
  if (
    actual.length !== normalizedActual.length ||
    normalizedExpected.length !== normalizedActual.length ||
    normalizedExpected.some((id, index) => id !== normalizedActual[index])
  ) {
    throw new IssueRepositoryError(
      'issue_delete_plan_invalid',
      `Delete plan must include every direct ${label} exactly once.`
    )
  }
}

function isLegalPlannedParent(
  database: IssueDatabase,
  childId: string,
  parentId: string | null,
  deletedIssueId: string
): boolean {
  if (parentId === deletedIssueId) {
    return false
  }
  try {
    const child = requireIssueRecord(database, childId)
    assertIssueForest({
      database,
      hostPartitionKey: child.hostPartitionKey,
      executionHostId: child.executionHostId,
      deletedIssueId,
      parentChanges: new Map([[childId, parentId]])
    })
    return true
  } catch {
    return false
  }
}
