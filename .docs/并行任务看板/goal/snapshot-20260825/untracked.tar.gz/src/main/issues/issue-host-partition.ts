import { parseExecutionHostId, type ExecutionHostId } from '../../shared/execution-host'
import type { AuthorityHostPartitionKey } from '../../shared/issues/types'

export function hostPartitionForExecutionHost(
  executionHostId: ExecutionHostId
): AuthorityHostPartitionKey {
  const parsed = parseExecutionHostId(executionHostId)
  if (!parsed) {
    throw new Error(`Invalid execution host id: ${executionHostId}`)
  }
  return parsed.kind === 'ssh' ? parsed.id : 'local'
}
