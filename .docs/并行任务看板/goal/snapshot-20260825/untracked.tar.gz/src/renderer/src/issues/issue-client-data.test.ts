import { randomUUID } from 'node:crypto'
import { describe, expect, it, vi } from 'vitest'
import type { ExecutionHostId } from '../../../shared/execution-host'
import type {
  IssueClientCacheReadResult,
  IssueClientSnapshot
} from '../../../shared/issues/client-data'
import type {
  ConversationSummary,
  IssueAuthorityDescriptor,
  IssueDetail,
  IssueListResult,
  IssueSearchResult,
  IssueSummary,
  RoundRecordPreview
} from '../../../shared/issues/types'
import type {
  IssueDigestConfirmationResult,
  IssueDigestMutationResult,
  IssueDigestPreparation
} from '../../../shared/issues/digest-types'
import {
  confirmIssueDigest,
  generateIssueDigest,
  loadConversation,
  loadIssueDetail,
  loadIssuePartition,
  loadIssueRounds,
  loadUnassignedConversations,
  prepareIssueDigest,
  searchIssues,
  updateIssueDigestDraft,
  type IssueClientDataDependencies
} from './issue-client-data'

function authority(
  routeExecutionHostId: ExecutionHostId
): IssueAuthorityDescriptor {
  return {
    authorityId: randomUUID(),
    hostPartitionKey: 'local',
    routeExecutionHostId
  }
}

function issue(
  descriptor: IssueAuthorityDescriptor,
  state: IssueSummary['state'],
  title: string
): IssueSummary {
  return {
    id: randomUUID(),
    hostPartitionKey: descriptor.hostPartitionKey,
    executionHostId: descriptor.routeExecutionHostId,
    source: { kind: 'local', number: Math.floor(Math.random() * 10_000) + 1 },
    localTitle: title,
    typeLabel: null,
    note: null,
    state,
    parentId: null,
    siblingOrder: 0,
    createdAt: 1,
    updatedAt: 1,
    archivedAt: state === 'archived' ? 1 : null,
    ownUnresolvedCount: 0,
    descendantAttentionCount: 0,
    directConversationCount: 0,
    activeConversationCount: 0
  }
}

function snapshot(
  descriptor: IssueAuthorityDescriptor,
  issues: IssueSummary[]
): IssueClientSnapshot {
  return {
    authority: descriptor,
    cachedAt: 10,
    factsRevision: 1,
    treeRevision: 1,
    searchRevision: 0,
    issues,
    details: [],
    unassignedConversations: [],
    rounds: []
  }
}

function conversation(
  descriptor: IssueAuthorityDescriptor,
  title: string,
  options: Partial<ConversationSummary> = {}
): ConversationSummary {
  return {
    id: randomUUID(),
    hostPartitionKey: descriptor.hostPartitionKey,
    executionHostId: descriptor.routeExecutionHostId,
    workspaceRef: { type: 'worktree', worktreeId: randomUUID() },
    workspaceSnapshot: { name: 'Workspace', path: '/tmp/workspace' },
    agent: 'claude',
    title,
    titleSource: 'user',
    issueId: null,
    state: 'active',
    launchFailure: null,
    createdAt: 1,
    updatedAt: 1,
    unresolvedRoundCount: 0,
    latestRound: null,
    ...options
  }
}

function detail(
  descriptor: IssueAuthorityDescriptor,
  summary: IssueSummary,
  directConversations: ConversationSummary[] = []
): IssueDetail {
  return {
    authority: descriptor,
    issue: summary,
    directChildren: [],
    directConversations,
    workspaceSnapshots: directConversations.map(
      (item) => item.workspaceSnapshot
    )
  }
}

function round(
  conversationId: string,
  occurredAt: number,
  options: Partial<RoundRecordPreview> = {}
): RoundRecordPreview {
  const body = {
    completeness: 'preview-complete' as const,
    storage: 'preview' as const,
    bytes: 12,
    preview: 'bounded preview',
    previewBytes: 12
  }
  return {
    id: randomUUID(),
    conversationId,
    kind: 'completion',
    stateSource: 'hook',
    occurredAt,
    executionChainId: null,
    supersedesRoundId: null,
    userInput: body,
    agentOutput: body,
    pendingQuestion: {
      completeness: 'not-captured',
      storage: 'none',
      bytes: 0,
      preview: null,
      previewBytes: 0
    },
    readAt: null,
    resolvedAt: null,
    resolution: null,
    effectiveResolvedAt: null,
    effectiveResolution: null,
    finalizedAt: occurredAt,
    bodyEvictedAt: null,
    bodyDeletedAt: null,
    bodyRevision: 1,
    createdAt: occurredAt,
    ...options
  }
}

function page(
  descriptor: IssueAuthorityDescriptor,
  issues: IssueSummary[],
  revisions = { facts: 1, tree: 1 },
  nextCursor: string | null = null
): IssueListResult {
  return {
    status: 'snapshot-page',
    authority: descriptor,
    snapshotFactsRevision: revisions.facts,
    snapshotTreeRevision: revisions.tree,
    issues,
    nextCursor
  }
}

function dependencies(options: {
  cached?: IssueClientSnapshot
  supported?: boolean
  callRpc: IssueClientDataDependencies['callRpc']
}): {
  dependencies: IssueClientDataDependencies
  written: IssueClientSnapshot[]
} {
  const written: IssueClientSnapshot[] = []
  return {
    written,
    dependencies: {
      readCache: async (): Promise<IssueClientCacheReadResult> =>
        options.cached
          ? { status: 'hit', snapshot: options.cached }
          : { status: 'miss' },
      replaceCache: async (_route, next) => {
        written.push(next)
      },
      supportsCapability: async () => options.supported ?? true,
      callRpc: options.callRpc,
      now: () => 100
    }
  }
}

describe('Issue client data loading', () => {
  it('loads authoritative search results and Digest mutations through their bounded RPC contracts', async () => {
    const descriptor = authority('local')
    const searchResult: IssueSearchResult = {
      authority: descriptor,
      searchRevision: 4,
      indexedSearchRevision: 3,
      isStale: true,
      partial: true,
      groups: [
        {
          issue: {
            id: randomUUID(),
            title: 'Search result',
            typeLabel: null,
            state: 'active'
          },
          matches: [
            {
              entityKind: 'round',
              entityId: randomUUID(),
              issueId: null,
              title: 'Agent answer',
              preview: 'A bounded partial result',
              completeness: 'partial'
            }
          ]
        }
      ],
      nextCursor: null
    }
    const preparation: IssueDigestPreparation = {
      authority: descriptor,
      issueId: randomUUID(),
      coversUntil: 20,
      inputFingerprint: 'a'.repeat(64),
      inputs: [],
      coverage: {
        totalInputCount: 1,
        includedInputCount: 1,
        directRoundCount: 1,
        includedDirectRoundCount: 1,
        totalUtf8Bytes: 20,
        includedUtf8Bytes: 20,
        truncatedInputCount: 0,
        omittedInputCount: 0,
        complete: true,
        note: null
      }
    }
    const digest = {
      id: randomUUID(),
      issueId: preparation.issueId,
      version: 1,
      revision: 0,
      status: 'draft' as const,
      coversUntil: 20,
      problem: null,
      conclusion: 'Draft conclusion',
      keyArtifacts: null,
      openIssues: null,
      nextSteps: null,
      coverageNote: null,
      inputFingerprint: preparation.inputFingerprint,
      generatorAgent: 'codex' as const,
      generationId: randomUUID(),
      generationError: null,
      generationStartedAt: 10,
      generationFinishedAt: 20,
      createdAt: 10,
      updatedAt: 20,
      confirmedAt: null
    }
    const mutation: IssueDigestMutationResult = {
      authority: descriptor,
      digest
    }
    const confirmation: IssueDigestConfirmationResult = {
      status: 'confirmed',
      authority: descriptor,
      digest: { ...digest, status: 'confirmed', confirmedAt: 30 },
      currentInputFingerprint: preparation.inputFingerprint,
      stale: false
    }
    const callRpc = vi.fn<IssueClientDataDependencies['callRpc']>(
      async (_route, method) => {
        if (method === 'issues.search') {
          return searchResult
        }
        if (method === 'issues.prepareDigest') {
          return preparation
        }
        if (method === 'issues.confirmDigest') {
          return confirmation
        }
        return mutation
      }
    )
    const harness = dependencies({ callRpc })
    await expect(
      searchIssues('local', 'partial result', harness.dependencies)
    ).resolves.toEqual({ status: 'ready', value: searchResult })
    await expect(
      prepareIssueDigest('local', preparation.issueId, harness.dependencies)
    ).resolves.toEqual({ status: 'ready', value: preparation })
    await expect(
      generateIssueDigest(
        'local',
        {
          mutationId: 'generate-1',
          issueId: preparation.issueId,
          agent: 'codex',
          expectedInputFingerprint: preparation.inputFingerprint
        },
        harness.dependencies
      )
    ).resolves.toEqual({ status: 'ready', value: mutation })
    await expect(
      updateIssueDigestDraft(
        'local',
        {
          mutationId: 'edit-1',
          digestId: digest.id,
          expectedDigestRevision: 0,
          conclusion: 'Edited conclusion'
        },
        harness.dependencies
      )
    ).resolves.toEqual({ status: 'ready', value: mutation })
    await expect(
      confirmIssueDigest(
        'local',
        {
          mutationId: 'confirm-1',
          digestId: digest.id,
          expectedDigestRevision: 0,
          inputFingerprint: preparation.inputFingerprint
        },
        harness.dependencies
      )
    ).resolves.toEqual({ status: 'ready', value: confirmation })

    expect(callRpc.mock.calls.map(([, method]) => method)).toEqual([
      'issues.search',
      'issues.prepareDigest',
      'issues.generateDigest',
      'issues.updateDigestDraft',
      'issues.confirmDigest'
    ])
  })

  it('loads one authoritative Conversation and rejects a response stamped for another route', async () => {
    const descriptor = authority('runtime:paired')
    const expected = conversation(descriptor, 'Current binding')
    const success = dependencies({
      callRpc: async (_route, method, params) => {
        expect(method).toBe('conversations.get')
        expect(params).toEqual({
          executionHostId: 'runtime:paired',
          conversationId: expected.id
        })
        return expected
      }
    })

    await expect(
      loadConversation('runtime:paired', expected.id, success.dependencies)
    ).resolves.toEqual({ status: 'ready', value: expected })

    const wrongRoute = dependencies({
      callRpc: async () => ({ ...expected, executionHostId: 'local' })
    })
    await expect(
      loadConversation('runtime:paired', expected.id, wrongRoute.dependencies)
    ).resolves.toEqual({
      status: 'error',
      error: 'Conversation response was stamped for another route.'
    })
  })

  it('uses the cached Conversation only when the authority RPC is unavailable', async () => {
    const descriptor = authority('local')
    const selectedIssue = issue(descriptor, 'active', 'Cached Issue')
    const cachedConversation = conversation(descriptor, 'Cached Conversation', {
      issueId: selectedIssue.id
    })
    const cached = {
      ...snapshot(descriptor, [selectedIssue]),
      details: [detail(descriptor, selectedIssue, [cachedConversation])]
    }
    const harness = dependencies({
      cached,
      callRpc: async () => {
        throw new Error('host offline')
      }
    })

    await expect(
      loadConversation('local', cachedConversation.id, harness.dependencies)
    ).resolves.toEqual({
      status: 'cached',
      value: cachedConversation,
      error: 'host offline'
    })
  })

  it('atomically combines active and archived host snapshots before caching', async () => {
    const descriptor = authority('local')
    const active = issue(descriptor, 'active', 'Active')
    const archived = issue(descriptor, 'archived', 'Archived')
    const harness = dependencies({
      callRpc: async (_route, method, params) => {
        expect(method).toBe('issues.list')
        const filter = (params as { filter: string }).filter
        return (filter === 'all'
          ? page(descriptor, [active])
          : page(descriptor, [archived])) as never
      }
    })

    const result = await loadIssuePartition('local', harness.dependencies)

    expect(result).toMatchObject({
      status: 'ready',
      value: {
        cachedAt: 100,
        factsRevision: 1,
        issues: [{ localTitle: 'Active' }, { localTitle: 'Archived' }]
      }
    })
    expect(harness.written).toHaveLength(1)
    expect(harness.written[0].issues.map((item) => item.id)).toEqual([
      active.id,
      archived.id
    ])
  })

  it('shows cached facts instead of an empty list when a host is unreachable', async () => {
    const descriptor = authority('runtime:offline')
    const cachedIssue = issue(descriptor, 'active', 'Cached work')
    const harness = dependencies({
      cached: snapshot(descriptor, [cachedIssue]),
      callRpc: async () => {
        throw new Error('host offline')
      }
    })

    const result = await loadIssuePartition(
      'runtime:offline',
      harness.dependencies
    )

    expect(result).toMatchObject({
      status: 'cached',
      error: 'host offline',
      value: { issues: [{ id: cachedIssue.id }] }
    })
    expect(harness.written).toHaveLength(0)
  })

  it('keeps unsupported distinct from both cached and empty-ready states', async () => {
    const descriptor = authority('runtime:legacy')
    const rpc = vi.fn<IssueClientDataDependencies['callRpc']>()
    const harness = dependencies({
      cached: snapshot(descriptor, [issue(descriptor, 'active', 'Old')]),
      supported: false,
      callRpc: rpc
    })

    const result = await loadIssuePartition(
      'runtime:legacy',
      harness.dependencies
    )

    expect(result).toEqual({ status: 'unsupported' })
    expect(rpc).not.toHaveBeenCalled()
  })

  it('returns empty only after a successful live snapshot', async () => {
    const descriptor = authority('local')
    const harness = dependencies({
      callRpc: async () => page(descriptor, []) as never
    })

    const result = await loadIssuePartition('local', harness.dependencies)

    expect(result).toMatchObject({
      status: 'ready',
      value: { issues: [] }
    })
  })

  it('retries when active and archived filters observe different revisions', async () => {
    const descriptor = authority('local')
    let request = 0
    const harness = dependencies({
      callRpc: async () => {
        request += 1
        const firstAttempt = request <= 2
        const facts = firstAttempt ? request : 3
        return page(descriptor, [], { facts, tree: facts }) as never
      }
    })

    const result = await loadIssuePartition('local', harness.dependencies)

    expect(result).toMatchObject({
      status: 'ready',
      value: { factsRevision: 3, treeRevision: 3 }
    })
    expect(request).toBe(4)
    expect(harness.written).toHaveLength(1)
  })

  it('restarts a paged snapshot when the host marks a continuation stale', async () => {
    const descriptor = authority('local')
    const active = issue(descriptor, 'active', 'Active')
    const archived = issue(descriptor, 'archived', 'Archived')
    let request = 0
    const harness = dependencies({
      callRpc: async (_route, _method, params) => {
        request += 1
        if (request === 1) {
          return page(
            descriptor,
            [active],
            { facts: 1, tree: 1 },
            'continue-active'
          )
        }
        if (request === 2) {
          return {
            status: 'stale',
            authority: descriptor,
            factsRevision: 2,
            treeRevision: 2
          }
        }
        const filter = (params as { filter: string }).filter
        return filter === 'all'
          ? page(descriptor, [active], { facts: 2, tree: 2 })
          : page(descriptor, [archived], { facts: 2, tree: 2 })
      }
    })

    const result = await loadIssuePartition('local', harness.dependencies)

    expect(result).toMatchObject({
      status: 'ready',
      value: {
        factsRevision: 2,
        treeRevision: 2,
        issues: [{ id: active.id }, { id: archived.id }]
      }
    })
    expect(request).toBe(4)
    expect(harness.written).toHaveLength(1)
  })

  it('updates the cached detail without discarding other snapshot facts', async () => {
    const descriptor = authority('local')
    const firstIssue = issue(descriptor, 'active', 'First')
    const secondIssue = issue(descriptor, 'active', 'Second')
    const oldFirst = detail(descriptor, firstIssue)
    const secondDetail = detail(descriptor, secondIssue)
    const nextConversation = conversation(descriptor, 'New detail', {
      issueId: firstIssue.id
    })
    const nextFirst = detail(descriptor, firstIssue, [nextConversation])
    const cached = {
      ...snapshot(descriptor, [firstIssue, secondIssue]),
      details: [oldFirst, secondDetail]
    }
    const harness = dependencies({
      cached,
      callRpc: async (_route, method, params) => {
        expect(method).toBe('issues.get')
        expect(params).toEqual({
          executionHostId: 'local',
          issueId: firstIssue.id
        })
        return nextFirst
      }
    })

    const result = await loadIssueDetail(
      'local',
      firstIssue.id,
      harness.dependencies
    )

    expect(result).toEqual({ status: 'ready', value: nextFirst })
    expect(harness.written).toHaveLength(1)
    expect(harness.written[0].issues).toEqual([firstIssue, secondIssue])
    expect(harness.written[0].details).toEqual([secondDetail, nextFirst])
  })

  it('collects all unassigned Conversation pages before replacing the cache', async () => {
    const descriptor = authority('local')
    const first = conversation(descriptor, 'First')
    const second = conversation(descriptor, 'Second')
    const harness = dependencies({
      cached: snapshot(descriptor, []),
      callRpc: async (_route, method, params) => {
        expect(method).toBe('conversations.listUnassigned')
        const cursor = (params as { cursor?: string }).cursor
        return cursor
          ? {
              authority: descriptor,
              snapshotFactsRevision: 1,
              conversations: [second],
              nextCursor: null
            }
          : {
              authority: descriptor,
              snapshotFactsRevision: 1,
              conversations: [first],
              nextCursor: 'next-page'
            }
      }
    })

    const result = await loadUnassignedConversations(
      'local',
      harness.dependencies
    )

    expect(result).toEqual({ status: 'ready', value: [first, second] })
    expect(harness.written).toHaveLength(1)
    expect(harness.written[0].unassignedConversations).toEqual([first, second])
  })

  it('loads one bounded Round page through the existing RPC and merges it into a matching cache revision', async () => {
    const descriptor = authority('local')
    const selectedIssue = issue(descriptor, 'active', 'Selected')
    const selectedConversation = conversation(descriptor, 'Direct work', {
      issueId: selectedIssue.id
    })
    const preview = round(selectedConversation.id, 20)
    const cached = {
      ...snapshot(descriptor, [selectedIssue]),
      details: [detail(descriptor, selectedIssue, [selectedConversation])]
    }
    const harness = dependencies({
      cached,
      callRpc: async (_route, method, params) => {
        expect(method).toBe('issues.listRounds')
        expect(params).toEqual({
          executionHostId: 'local',
          issueId: selectedIssue.id,
          limit: 50
        })
        return {
          authority: descriptor,
          snapshotFactsRevision: 1,
          rounds: [preview],
          nextCursor: 'older'
        }
      }
    })

    const result = await loadIssueRounds(
      'local',
      { issueId: selectedIssue.id, limit: 50 },
      harness.dependencies
    )

    expect(result).toEqual({
      status: 'ready',
      value: {
        authority: descriptor,
        snapshotFactsRevision: 1,
        rounds: [preview],
        nextCursor: 'older'
      }
    })
    expect(result.status === 'ready' && result.value.rounds[0]?.agentOutput).toEqual({
      completeness: 'preview-complete',
      storage: 'preview',
      bytes: 12,
      preview: 'bounded preview',
      previewBytes: 12
    })
    expect(harness.written).toHaveLength(1)
    expect(harness.written[0].rounds).toEqual([preview])
  })

  it('does not mix a continuation page from a different facts revision', async () => {
    const descriptor = authority('local')
    const harness = dependencies({
      callRpc: async () => ({
        authority: descriptor,
        snapshotFactsRevision: 8,
        rounds: [],
        nextCursor: null
      })
    })

    const result = await loadIssueRounds(
      'local',
      {
        issueId: randomUUID(),
        cursor: 'older',
        expectedFactsRevision: 7
      },
      harness.dependencies
    )

    expect(result).toEqual({
      status: 'error',
      error: 'Round Record facts changed while loading the next page.'
    })
    expect(harness.written).toHaveLength(0)
  })

  it('uses only the selected Issue cached previews when its host is offline', async () => {
    const descriptor = authority('runtime:offline')
    const selectedIssue = issue(descriptor, 'active', 'Selected')
    const otherIssue = issue(descriptor, 'active', 'Other')
    const selectedConversation = conversation(descriptor, 'Selected work', {
      issueId: selectedIssue.id
    })
    const otherConversation = conversation(descriptor, 'Other work', {
      issueId: otherIssue.id
    })
    const selectedRound = round(selectedConversation.id, 20)
    const cached = {
      ...snapshot(descriptor, [selectedIssue, otherIssue]),
      details: [
        detail(descriptor, selectedIssue, [selectedConversation]),
        detail(descriptor, otherIssue, [otherConversation])
      ],
      rounds: [round(otherConversation.id, 30), selectedRound]
    }
    const harness = dependencies({
      cached,
      callRpc: async () => {
        throw new Error('host offline')
      }
    })

    const result = await loadIssueRounds(
      'runtime:offline',
      { issueId: selectedIssue.id },
      harness.dependencies
    )

    expect(result).toEqual({
      status: 'cached',
      error: 'host offline',
      value: {
        authority: descriptor,
        snapshotFactsRevision: 1,
        rounds: [selectedRound],
        nextCursor: null
      }
    })
  })

  it('keeps an unsupported remote host distinct from an empty Round page', async () => {
    const rpc = vi.fn<IssueClientDataDependencies['callRpc']>()
    const harness = dependencies({
      supported: false,
      callRpc: rpc
    })

    const result = await loadIssueRounds(
      'runtime:legacy',
      { issueId: randomUUID() },
      harness.dependencies
    )

    expect(result).toEqual({ status: 'unsupported' })
    expect(rpc).not.toHaveBeenCalled()
  })
})
