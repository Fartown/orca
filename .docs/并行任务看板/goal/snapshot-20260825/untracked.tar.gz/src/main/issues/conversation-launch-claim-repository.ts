import { createHash, randomUUID } from 'node:crypto'
import { hasUnsafeProviderSessionIdChars } from '../../shared/agent-session-resume'
import type {
  AuthorityHostPartitionKey,
  ConversationLaunchClaim
} from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { requireConversationRecord } from './conversation-record-queries'
import { IssueRepositoryError } from './issue-repository-error'

const MAX_LAUNCH_TOKEN_LENGTH = 4096

type ConversationLaunchClaimRow = {
  claim_id: string
  conversation_id: string
  host_partition_key: AuthorityHostPartitionKey
  pane_key: string | null
  launch_token_hash: string
  process_incarnation: string | null
  connection_id: string | null
  created_at: number
  expires_at: number
  consumed_at: number | null
}

export type CreateConversationLaunchClaimInput = {
  conversationId: string
  launchToken: string
  paneKey?: string | null
  processIncarnation?: string | null
  connectionId?: string | null
  createdAt?: number
  expiresAt: number
}

export type ResolveConversationLaunchClaimInput = {
  hostPartitionKey: AuthorityHostPartitionKey
  launchToken?: string | null
  paneKey?: string | null
  processIncarnation?: string | null
  connectionId?: string | null
  now?: number
}

export function hashConversationLaunchToken(launchToken: string): string {
  if (
    launchToken.length === 0 ||
    launchToken.length > MAX_LAUNCH_TOKEN_LENGTH ||
    hasUnsafeProviderSessionIdChars(launchToken)
  ) {
    throw new IssueRepositoryError(
      'conversation_launch_claim_invalid',
      'Conversation launch token is invalid.'
    )
  }
  return createHash('sha256').update(launchToken).digest('hex')
}

export class ConversationLaunchClaimRepository {
  constructor(private readonly database: IssueDatabase) {}

  create(input: CreateConversationLaunchClaimInput): ConversationLaunchClaim {
    return this.database.transaction(() => this.createWithinTransaction(input))
  }

  createWithinTransaction(
    input: CreateConversationLaunchClaimInput
  ): ConversationLaunchClaim {
    const conversation = requireConversationRecord(this.database, input.conversationId)
    const createdAt = input.createdAt ?? Date.now()
    if (input.expiresAt <= createdAt) {
      throw new IssueRepositoryError(
        'conversation_launch_claim_invalid',
        'Conversation launch claim must expire after it is created.'
      )
    }
    const launchTokenHash = hashConversationLaunchToken(input.launchToken)
    const existing = this.findByTokenHash(
      conversation.hostPartitionKey,
      launchTokenHash,
      false
    )
    if (existing) {
      if (existing.conversationId !== conversation.id) {
        throw new IssueRepositoryError(
          'conversation_launch_claim_invalid',
          'Conversation launch token is already assigned to another Conversation.'
        )
      }
      return existing
    }
    const claimId = randomUUID()
    this.database
      .prepare(
        `INSERT INTO conversation_launch_claims (
           claim_id, conversation_id, host_partition_key, pane_key, launch_token_hash,
           process_incarnation, connection_id, created_at, expires_at, consumed_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)`
      )
      .run(
        claimId,
        conversation.id,
        conversation.hostPartitionKey,
        input.paneKey ?? null,
        launchTokenHash,
        input.processIncarnation ?? null,
        input.connectionId ?? null,
        createdAt,
        input.expiresAt
      )
    return this.requireById(claimId)
  }

  findByToken(
    hostPartitionKey: AuthorityHostPartitionKey,
    launchToken: string,
    activeOnly = true
  ): ConversationLaunchClaim | undefined {
    return this.findByTokenHash(
      hostPartitionKey,
      hashConversationLaunchToken(launchToken),
      activeOnly
    )
  }

  resolveActive(input: ResolveConversationLaunchClaimInput): ConversationLaunchClaim {
    const now = input.now ?? Date.now()
    if (input.launchToken) {
      const claim = this.findByToken(input.hostPartitionKey, input.launchToken, false)
      if (!claim) {
        throw new IssueRepositoryError(
          'conversation_launch_claim_not_found',
          'Conversation launch claim was not found.'
        )
      }
      assertClaimActive(claim, now)
      return claim
    }
    const conditions = [
      'host_partition_key = ?',
      'consumed_at IS NULL',
      'expires_at > ?'
    ]
    const bindings: (string | number)[] = [input.hostPartitionKey, now]
    for (const [column, value] of [
      ['pane_key', input.paneKey],
      ['process_incarnation', input.processIncarnation],
      ['connection_id', input.connectionId]
    ] as const) {
      if (value) {
        conditions.push(`${column} = ?`)
        bindings.push(value)
      }
    }
    if (conditions.length === 3) {
      throw new IssueRepositoryError(
        'conversation_launch_claim_invalid',
        'Conversation launch claim resolution requires token or runtime evidence.'
      )
    }
    const rows = this.database
      .prepare(
        `SELECT * FROM conversation_launch_claims
         WHERE ${conditions.join(' AND ')}
         ORDER BY created_at DESC
         LIMIT 2`
      )
      .all(...bindings) as ConversationLaunchClaimRow[]
    if (rows.length === 0) {
      throw new IssueRepositoryError(
        'conversation_launch_claim_not_found',
        'Conversation launch claim was not found.'
      )
    }
    if (rows.length > 1) {
      throw new IssueRepositoryError(
        'conversation_launch_claim_ambiguous',
        'Conversation launch evidence matches more than one claim.'
      )
    }
    return launchClaimFromRow(rows[0])
  }

  consumeWithinTransaction(claimId: string, consumedAt = Date.now()): ConversationLaunchClaim {
    const current = this.requireById(claimId)
    if (current.consumedAt !== null) {
      return current
    }
    if (current.expiresAt <= consumedAt) {
      throw new IssueRepositoryError(
        'conversation_launch_claim_expired',
        `Conversation launch claim ${claimId} has expired.`
      )
    }
    this.database
      .prepare(
        `UPDATE conversation_launch_claims
         SET consumed_at = ?
         WHERE claim_id = ? AND consumed_at IS NULL`
      )
      .run(consumedAt, claimId)
    return this.requireById(claimId)
  }

  retireWithinTransaction(claimId: string, retiredAt = Date.now()): ConversationLaunchClaim {
    this.database
      .prepare(
        `UPDATE conversation_launch_claims
         SET consumed_at = COALESCE(consumed_at, ?)
         WHERE claim_id = ?`
      )
      .run(retiredAt, claimId)
    return this.requireById(claimId)
  }

  private findByTokenHash(
    hostPartitionKey: AuthorityHostPartitionKey,
    launchTokenHash: string,
    activeOnly: boolean
  ): ConversationLaunchClaim | undefined {
    const row = this.database
      .prepare(
        `SELECT * FROM conversation_launch_claims
         WHERE host_partition_key = ? AND launch_token_hash = ?
         ${activeOnly ? 'AND consumed_at IS NULL' : ''}
         ORDER BY created_at DESC
         LIMIT 1`
      )
      .get(hostPartitionKey, launchTokenHash) as ConversationLaunchClaimRow | undefined
    return row ? launchClaimFromRow(row) : undefined
  }

  private requireById(claimId: string): ConversationLaunchClaim {
    const row = this.database
      .prepare('SELECT * FROM conversation_launch_claims WHERE claim_id = ?')
      .get(claimId) as ConversationLaunchClaimRow | undefined
    if (!row) {
      throw new IssueRepositoryError(
        'conversation_launch_claim_not_found',
        `Conversation launch claim ${claimId} was not found.`
      )
    }
    return launchClaimFromRow(row)
  }
}

function assertClaimActive(claim: ConversationLaunchClaim, now: number): void {
  if (claim.consumedAt !== null) {
    throw new IssueRepositoryError(
      'conversation_launch_claim_invalid',
      `Conversation launch claim ${claim.claimId} was already consumed.`
    )
  }
  if (claim.expiresAt <= now) {
    throw new IssueRepositoryError(
      'conversation_launch_claim_expired',
      `Conversation launch claim ${claim.claimId} has expired.`
    )
  }
}

function launchClaimFromRow(row: ConversationLaunchClaimRow): ConversationLaunchClaim {
  return {
    claimId: row.claim_id,
    conversationId: row.conversation_id,
    hostPartitionKey: row.host_partition_key,
    paneKey: row.pane_key,
    processIncarnation: row.process_incarnation,
    connectionId: row.connection_id,
    createdAt: row.created_at,
    expiresAt: row.expires_at,
    consumedAt: row.consumed_at
  }
}
