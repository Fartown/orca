import { parseExecutionHostId, type ExecutionHostId } from '../../../shared/execution-host'
import type { IssueActivityEntry, IssueAuthorityDescriptor } from '../../../shared/issues/types'
import { createStore, type StoreApi } from 'zustand/vanilla'
import { loadIssueActivity, type IssueActivityLoadResult } from './issue-activity-client'
import {
  ISSUE_FACTS_CHANGED_EVENT,
  type IssueFactsChangedEventDetail
} from './issue-facts-changed-event'
import {
  legacyActivityMigrationSnapshotKey,
  migrateLegacyActivity,
  type LegacyActivityMigrationClientResult,
  type LegacyActivityMigrationSnapshot
} from './legacy-activity-migration'

export type IssueActivityPartitionState = {
  routeExecutionHostId: ExecutionHostId
  status: 'idle' | 'loading' | 'ready' | 'unsupported' | 'error'
  authority: IssueAuthorityDescriptor | null
  snapshotFactsRevision: number | null
  entries: readonly IssueActivityEntry[]
  nextCursor: string | null
  error: string | null
  legacyMigrationStatus:
    | 'idle'
    | 'migrating'
    | 'complete'
    | 'unsupported'
    | 'unresolved'
    | 'error'
  legacyMigrationSnapshotKey: string | null
  legacyMigrationAttemptFactsRevision: number | null
  legacyMigrationUnresolvedEventIds: readonly string[]
  legacyMigrationError: string | null
}

export type IssueActivityState = {
  visibleRouteExecutionHostIds: ExecutionHostId[]
  partitionsByRoute: Partial<Record<ExecutionHostId, IssueActivityPartitionState>>
  setVisibleRoutes: (routes: readonly ExecutionHostId[]) => Promise<void>
  refreshPartition: (routeExecutionHostId: ExecutionHostId) => Promise<void>
  refreshVisibleRoutes: () => Promise<void>
  syncLegacyMigration: (
    routes: readonly ExecutionHostId[],
    snapshot: LegacyActivityMigrationSnapshot
  ) => Promise<void>
  retryLegacyMigration: (
    routeExecutionHostId: ExecutionHostId
  ) => Promise<void>
  patchRoundsRead: (
    routeExecutionHostId: ExecutionHostId,
    roundRecordIds: readonly string[],
    readAt: number
  ) => void
}

export type IssueActivityStoreDependencies = {
  load: (routeExecutionHostId: ExecutionHostId) => Promise<IssueActivityLoadResult>
  migrateLegacy?: (
    routeExecutionHostId: ExecutionHostId,
    entries: NonNullable<LegacyActivityMigrationSnapshot[ExecutionHostId]>
  ) => Promise<LegacyActivityMigrationClientResult>
}

type RefreshEntry = {
  promise: Promise<void>
  rerun: boolean
}

type MigrationEntry = RefreshEntry

export function createIssueActivityStore(
  dependencies: IssueActivityStoreDependencies
): StoreApi<IssueActivityState> {
  const refreshes = new Map<ExecutionHostId, RefreshEntry>()
  const migrations = new Map<ExecutionHostId, MigrationEntry>()
  const migrationSnapshots = new Map<
    ExecutionHostId,
    {
      key: string
      entries: NonNullable<
        LegacyActivityMigrationSnapshot[ExecutionHostId]
      >
    }
  >()
  return createStore<IssueActivityState>()((set, get) => {
    const runRefresh = async (
      routeExecutionHostId: ExecutionHostId,
      entry: RefreshEntry
    ): Promise<void> => {
      do {
        entry.rerun = false
        const previous =
          get().partitionsByRoute[routeExecutionHostId] ?? emptyPartition(routeExecutionHostId)
        setPartition(set, routeExecutionHostId, {
          ...previous,
          status: 'loading',
          error: null
        })
        const result = await dependencies.load(routeExecutionHostId)
        const current =
          get().partitionsByRoute[routeExecutionHostId] ??
          emptyPartition(routeExecutionHostId)
        setPartition(
          set,
          routeExecutionHostId,
          partitionFromLoad(routeExecutionHostId, result, current)
        )
      } while (entry.rerun)
    }

    const refreshPartition = (routeExecutionHostId: ExecutionHostId): Promise<void> => {
      const route = parseExecutionHostId(routeExecutionHostId)
      if (!route) {
        return Promise.resolve()
      }
      const active = refreshes.get(route.id)
      if (active) {
        active.rerun = true
        return active.promise
      }
      const entry: RefreshEntry = {
        promise: Promise.resolve(),
        rerun: false
      }
      entry.promise = runRefresh(route.id, entry).finally(() => {
        if (refreshes.get(route.id) === entry) {
          refreshes.delete(route.id)
        }
      })
      refreshes.set(route.id, entry)
      return entry.promise
    }

    const runMigration = async (
      routeExecutionHostId: ExecutionHostId,
      entry: MigrationEntry
    ): Promise<void> => {
      do {
        entry.rerun = false
        const snapshot = migrationSnapshots.get(routeExecutionHostId)
        if (!snapshot || snapshot.entries.length === 0) {
          continue
        }
        const previous =
          get().partitionsByRoute[routeExecutionHostId] ??
          emptyPartition(routeExecutionHostId)
        setPartition(set, routeExecutionHostId, {
          ...previous,
          legacyMigrationStatus: 'migrating',
          legacyMigrationSnapshotKey: snapshot.key,
          legacyMigrationAttemptFactsRevision:
            previous.snapshotFactsRevision,
          legacyMigrationUnresolvedEventIds: [],
          legacyMigrationError: null
        })
        const result = dependencies.migrateLegacy
          ? await dependencies.migrateLegacy(
              routeExecutionHostId,
              snapshot.entries
            )
          : ({ status: 'unsupported' } as const)
        applyMigrationResult(
          set,
          get,
          routeExecutionHostId,
          snapshot.key,
          result
        )
        if (result.status === 'ready') {
          await refreshPartition(routeExecutionHostId)
        }
      } while (entry.rerun)
    }

    const startMigration = (
      routeExecutionHostId: ExecutionHostId
    ): Promise<void> => {
      const snapshot = migrationSnapshots.get(routeExecutionHostId)
      if (!snapshot || snapshot.entries.length === 0) {
        return Promise.resolve()
      }
      const active = migrations.get(routeExecutionHostId)
      if (active) {
        active.rerun = true
        return active.promise
      }
      const entry: MigrationEntry = {
        promise: Promise.resolve(),
        rerun: false
      }
      entry.promise = runMigration(routeExecutionHostId, entry).finally(() => {
        if (migrations.get(routeExecutionHostId) === entry) {
          migrations.delete(routeExecutionHostId)
        }
      })
      migrations.set(routeExecutionHostId, entry)
      return entry.promise
    }

    return {
      visibleRouteExecutionHostIds: [],
      partitionsByRoute: {},
      setVisibleRoutes: async (routes) => {
        const normalized = normalizeRoutes(routes)
        const previous = new Set(get().visibleRouteExecutionHostIds)
        set({ visibleRouteExecutionHostIds: normalized })
        await Promise.all(
          normalized
            .filter((route) => !previous.has(route) || !get().partitionsByRoute[route])
            .map(refreshPartition)
        )
      },
      refreshPartition,
      refreshVisibleRoutes: async () => {
        await Promise.all(get().visibleRouteExecutionHostIds.map(refreshPartition))
      },
      syncLegacyMigration: async (routes, snapshot) => {
        const normalized = normalizeRoutes(routes)
        const pending: Promise<void>[] = []
        for (const routeExecutionHostId of normalized) {
          const entries = snapshot[routeExecutionHostId] ?? []
          const key = legacyActivityMigrationSnapshotKey(entries)
          migrationSnapshots.set(routeExecutionHostId, { key, entries })
          const previous =
            get().partitionsByRoute[routeExecutionHostId] ??
            emptyPartition(routeExecutionHostId)
          if (entries.length === 0) {
            setPartition(set, routeExecutionHostId, {
              ...previous,
              legacyMigrationStatus: 'complete',
              legacyMigrationSnapshotKey: key,
              legacyMigrationAttemptFactsRevision:
                previous.snapshotFactsRevision,
              legacyMigrationUnresolvedEventIds: [],
              legacyMigrationError: null
            })
            const active = migrations.get(routeExecutionHostId)
            if (active) {
              active.rerun = true
            }
            continue
          }
          if (
            previous.legacyMigrationSnapshotKey === key &&
            (previous.legacyMigrationStatus === 'complete' ||
              previous.legacyMigrationStatus === 'migrating' ||
              previous.legacyMigrationStatus === 'unsupported')
          ) {
            continue
          }
          pending.push(startMigration(routeExecutionHostId))
        }
        await Promise.all(pending)
      },
      retryLegacyMigration: async (routeExecutionHostId) => {
        const partition =
          get().partitionsByRoute[routeExecutionHostId]
        if (
          !partition ||
          (partition.legacyMigrationStatus !== 'unresolved' &&
            partition.legacyMigrationStatus !== 'error') ||
          (partition.legacyMigrationStatus === 'unresolved' &&
            partition.snapshotFactsRevision ===
              partition.legacyMigrationAttemptFactsRevision)
        ) {
          return
        }
        await startMigration(routeExecutionHostId)
      },
      patchRoundsRead: (routeExecutionHostId, roundRecordIds, readAt) => {
        const ids = new Set(roundRecordIds)
        const partition = get().partitionsByRoute[routeExecutionHostId]
        if (!partition || ids.size === 0) {
          return
        }
        setPartition(set, routeExecutionHostId, {
          ...partition,
          entries: partition.entries.map((entry) =>
            entry.type === 'round' && ids.has(entry.round.id)
              ? { ...entry, round: { ...entry.round, readAt } }
              : entry
          )
        })
      }
    }
  })
}

function partitionFromLoad(
  routeExecutionHostId: ExecutionHostId,
  result: IssueActivityLoadResult,
  previous: IssueActivityPartitionState
): IssueActivityPartitionState {
  if (result.status === 'ready') {
    return {
      routeExecutionHostId,
      status: 'ready',
      authority: result.page.authority,
      snapshotFactsRevision: result.page.snapshotFactsRevision,
      entries: result.page.entries,
      nextCursor: result.page.nextCursor,
      error: null,
      legacyMigrationStatus: previous.legacyMigrationStatus,
      legacyMigrationSnapshotKey: previous.legacyMigrationSnapshotKey,
      legacyMigrationAttemptFactsRevision:
        previous.legacyMigrationAttemptFactsRevision,
      legacyMigrationUnresolvedEventIds:
        previous.legacyMigrationUnresolvedEventIds,
      legacyMigrationError: previous.legacyMigrationError
    }
  }
  if (result.status === 'unsupported') {
    return {
      ...emptyPartition(routeExecutionHostId),
      status: 'unsupported',
      legacyMigrationStatus: previous.legacyMigrationStatus,
      legacyMigrationSnapshotKey:
        previous.legacyMigrationSnapshotKey,
      legacyMigrationAttemptFactsRevision:
        previous.legacyMigrationAttemptFactsRevision,
      legacyMigrationUnresolvedEventIds:
        previous.legacyMigrationUnresolvedEventIds,
      legacyMigrationError: previous.legacyMigrationError
    }
  }
  return {
    ...previous,
    status: 'error',
    error: result.error
  }
}

function emptyPartition(routeExecutionHostId: ExecutionHostId): IssueActivityPartitionState {
  return {
    routeExecutionHostId,
    status: 'idle',
    authority: null,
    snapshotFactsRevision: null,
    entries: [],
    nextCursor: null,
    error: null,
    legacyMigrationStatus: 'idle',
    legacyMigrationSnapshotKey: null,
    legacyMigrationAttemptFactsRevision: null,
    legacyMigrationUnresolvedEventIds: [],
    legacyMigrationError: null
  }
}

function normalizeRoutes(routes: readonly ExecutionHostId[]): ExecutionHostId[] {
  const normalized: ExecutionHostId[] = []
  const seen = new Set<ExecutionHostId>()
  for (const route of routes) {
    const id = parseExecutionHostId(route)?.id
    if (!id || seen.has(id)) {
      continue
    }
    seen.add(id)
    normalized.push(id)
  }
  return normalized
}

function setPartition(
  set: StoreApi<IssueActivityState>['setState'],
  routeExecutionHostId: ExecutionHostId,
  partition: IssueActivityPartitionState
): void {
  set((state) => ({
    partitionsByRoute: {
      ...state.partitionsByRoute,
      [routeExecutionHostId]: partition
    }
  }))
}

export const issueActivityStore = createIssueActivityStore({
  load: (routeExecutionHostId) => loadIssueActivity(routeExecutionHostId),
  migrateLegacy: (routeExecutionHostId, entries) =>
    migrateLegacyActivity(routeExecutionHostId, entries)
})

export function connectIssueActivityEvents(
  store: StoreApi<IssueActivityState>,
  target: Pick<EventTarget, 'addEventListener' | 'removeEventListener'>
): () => void {
  const listener: EventListener = (event) => {
    const detail = (event as CustomEvent<IssueFactsChangedEventDetail>).detail
    const route = parseExecutionHostId(detail?.routeExecutionHostId)
    if (
      !route ||
      !store.getState().visibleRouteExecutionHostIds.includes(route.id)
    ) {
      return
    }
    void store
      .getState()
      .refreshPartition(route.id)
      .then(() => store.getState().retryLegacyMigration(route.id))
  }
  target.addEventListener(ISSUE_FACTS_CHANGED_EVENT, listener)
  return () => target.removeEventListener(ISSUE_FACTS_CHANGED_EVENT, listener)
}

function applyMigrationResult(
  set: StoreApi<IssueActivityState>['setState'],
  get: StoreApi<IssueActivityState>['getState'],
  routeExecutionHostId: ExecutionHostId,
  snapshotKey: string,
  result: LegacyActivityMigrationClientResult
): void {
  const partition = get().partitionsByRoute[routeExecutionHostId]
  if (
    !partition ||
    partition.legacyMigrationSnapshotKey !== snapshotKey
  ) {
    return
  }
  if (result.status === 'unsupported') {
    setPartition(set, routeExecutionHostId, {
      ...partition,
      legacyMigrationStatus: 'unsupported',
      legacyMigrationError: null
    })
    return
  }
  if (result.status === 'error') {
    setPartition(set, routeExecutionHostId, {
      ...partition,
      legacyMigrationStatus: 'error',
      legacyMigrationError: result.error
    })
    return
  }
  const unresolved = result.result.unresolvedLegacyEventIds
  setPartition(set, routeExecutionHostId, {
    ...partition,
    legacyMigrationStatus:
      unresolved.length === 0 ? 'complete' : 'unresolved',
    legacyMigrationUnresolvedEventIds: unresolved,
    legacyMigrationError: null
  })
}
