import { afterEach, describe, expect, it } from 'vitest'
import type { AgentProviderSessionMetadata } from '../../shared/agent-session-resume'
import type { ExecutionHostId } from '../../shared/execution-host'
import type { CreateConversationInput } from './issue-repository-types'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueRepository } from './issue-repository'
import { IssueRepositoryError, type IssueRepositoryErrorCode } from './issue-repository-error'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function openRepository(profileId: string): IssueRepository {
  const database = openIssueTestDatabase({
    profileId,
    userDataPath: createIssueTestUserDataPath(`orca-conversation-${profileId}`)
  })
  const repository = new IssueRepository(database)
  repositories.push(repository)
  return repository
}

function conversationInput(
  overrides: Partial<CreateConversationInput> = {}
): CreateConversationInput {
  const executionHostId = overrides.executionHostId ?? 'local'
  return {
    executionHostId,
    workspaceRef: {
      type: 'folder',
      folderWorkspaceId: `folder-${executionHostId}`
    },
    workspaceSnapshot: {
      name: `Workspace ${executionHostId}`,
      path: `/workspace/${executionHostId}`
    },
    agent: 'codex',
    title: 'Conversation',
    titleSource: 'user',
    issueId: null,
    ...overrides
  }
}

function session(id: string): AgentProviderSessionMetadata {
  return { key: 'session_id', id }
}

function expectRepositoryError(
  operation: () => unknown,
  code: IssueRepositoryErrorCode
): IssueRepositoryError {
  try {
    operation()
  } catch (error) {
    expect(error).toBeInstanceOf(IssueRepositoryError)
    expect((error as IssueRepositoryError).code).toBe(code)
    return error as IssueRepositoryError
  }
  throw new Error(`Expected IssueRepositoryError(${code}).`)
}

function createIssue(repository: IssueRepository, title: string, executionHostId: ExecutionHostId) {
  mutationSequence += 1
  return repository.issues.create({
    identity: {
      callerFingerprint: 'conversation-allocator-test',
      mutationId: `issue-${mutationSequence}`
    },
    input: { kind: 'local', executionHostId, title }
  })
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('ConversationAllocator fresh launches', () => {
  it('creates the Conversation and hashed launch claim atomically before spawn', () => {
    const repository = openRepository('fresh')
    const result = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput(),
      launchToken: 'launch-secret',
      paneKey: 'tab:leaf',
      processIncarnation: 'process-1',
      now: 1_000,
      claimTtlMs: 10_000
    })

    expect(result.disposition).toBe('created')
    expect(repository.conversations.get(result.conversation.id)).toEqual(result.conversation)
    expect(result.claim).toMatchObject({
      conversationId: result.conversation.id,
      paneKey: 'tab:leaf',
      processIncarnation: 'process-1',
      createdAt: 1_000,
      expiresAt: 11_000,
      consumedAt: null
    })
    const row = repository.database
      .prepare(
        `SELECT launch_token_hash, launch_token_hash = ? AS stored_plaintext
         FROM conversation_launch_claims WHERE claim_id = ?`
      )
      .get('launch-secret', result.claim.claimId) as {
      launch_token_hash: string
      stored_plaintext: number
    }
    expect(row.stored_plaintext).toBe(0)
    expect(row.launch_token_hash).toMatch(/^[0-9a-f]{64}$/)
  })

  it('replays one launch token without creating a second Conversation, even after consume', () => {
    const repository = openRepository('replay')
    const input = {
      ...conversationInput(),
      launchToken: 'stable-launch',
      now: 1_000,
      claimTtlMs: 10_000
    }
    const first = repository.conversationAllocator.allocateFreshLaunch(input)
    repository.conversationAllocator.attachProviderIdentity({
      executionHostId: 'local',
      agent: 'codex',
      providerSession: session('session-1'),
      launchToken: input.launchToken,
      observedAt: 2_000
    })
    const replay = repository.conversationAllocator.allocateFreshLaunch({
      ...input,
      now: 3_000
    })

    expect(replay).toMatchObject({
      disposition: 'replayed',
      conversation: { id: first.conversation.id },
      claim: { claimId: first.claim.claimId, consumedAt: 2_000 }
    })
    expect(repository.conversations.list()).toHaveLength(1)
    expect(
      repository.database.prepare('SELECT COUNT(*) AS count FROM conversation_launch_claims').get()
    ).toEqual({ count: 1 })
  })

  it('rolls back both rows when claim creation rejects invalid input', () => {
    const repository = openRepository('atomic-create')

    expectRepositoryError(
      () =>
        repository.conversationAllocator.allocateFreshLaunch({
          ...conversationInput(),
          launchToken: '',
          now: 1_000
        }),
      'conversation_launch_claim_invalid'
    )

    expect(repository.conversations.list()).toEqual([])
    expect(
      repository.database.prepare('SELECT COUNT(*) AS count FROM conversation_launch_claims').get()
    ).toEqual({ count: 0 })
  })

  it('rejects a launch-token replay with changed ownership input', () => {
    const repository = openRepository('replay-conflict')
    repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput(),
      launchToken: 'stable-launch',
      now: 1_000
    })

    expectRepositoryError(
      () =>
        repository.conversationAllocator.allocateFreshLaunch({
          ...conversationInput({
            workspaceRef: { type: 'folder', folderWorkspaceId: 'another-workspace' }
          }),
          launchToken: 'stable-launch',
          now: 2_000
        }),
      'conversation_launch_claim_invalid'
    )
    expect(repository.conversations.list()).toHaveLength(1)
  })

  it('keeps a failed launch as a closed diagnostic record and retires its claim', () => {
    const repository = openRepository('launch-failure')
    const allocated = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput(),
      launchToken: 'failed-launch',
      now: 1_000
    })

    const closed = repository.conversationAllocator.recordLaunchFailure({
      conversationId: allocated.conversation.id,
      claimId: allocated.claim.claimId,
      failure: 'spawn ENOENT',
      occurredAt: 2_000
    })

    expect(closed).toMatchObject({
      id: allocated.conversation.id,
      state: 'closed',
      launchFailure: 'spawn ENOENT'
    })
    expect(
      repository.conversationLaunchClaims.findByToken('local', 'failed-launch', false)
    ).toMatchObject({ consumedAt: 2_000 })
  })
})

describe('Conversation provider identities', () => {
  it('atomically attaches a late identity and consumes the launch claim once', () => {
    const repository = openRepository('late-identity')
    const allocated = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput(),
      launchToken: 'late-token',
      paneKey: 'tab:leaf',
      now: 1_000
    })

    const first = repository.conversationAllocator.attachProviderIdentity({
      executionHostId: 'local',
      agent: 'codex',
      providerSession: session('provider-1'),
      launchToken: 'late-token',
      paneKey: 'tab:leaf',
      observedAt: 2_000
    })
    const duplicate = repository.conversationAllocator.attachProviderIdentity({
      executionHostId: 'local',
      agent: 'codex',
      providerSession: session('provider-1'),
      launchToken: 'late-token',
      observedAt: 3_000
    })

    expect(first).toMatchObject({
      conversation: { id: allocated.conversation.id },
      claim: { claimId: allocated.claim.claimId, consumedAt: 2_000 }
    })
    expect(duplicate.conversation.id).toBe(allocated.conversation.id)
    expect(duplicate.identity.id).toBe(first.identity.id)
    expect(duplicate.claim).toBeNull()
    expect(repository.conversationIdentities.listForConversation(allocated.conversation.id)).toEqual([
      expect.objectContaining({
        id: first.identity.id,
        observedAt: 3_000,
        retiredAt: null
      })
    ])
  })

  it('does not consume a claim when its provider identity belongs to another Conversation', () => {
    const repository = openRepository('identity-conflict')
    const first = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput(),
      launchToken: 'first-token',
      now: 1_000
    })
    repository.conversationAllocator.attachProviderIdentity({
      executionHostId: 'local',
      agent: 'codex',
      providerSession: session('shared-session'),
      launchToken: 'first-token',
      observedAt: 2_000
    })
    const second = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput({
        workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-second' }
      }),
      launchToken: 'second-token',
      now: 3_000
    })

    expectRepositoryError(
      () =>
        repository.conversationAllocator.attachProviderIdentity({
          executionHostId: 'local',
          agent: 'codex',
          providerSession: session('shared-session'),
          launchToken: 'second-token',
          observedAt: 4_000
        }),
      'conversation_identity_conflict'
    )

    expect(first.conversation.id).not.toBe(second.conversation.id)
    expect(
      repository.conversationLaunchClaims.findByToken('local', 'second-token', false)
    ).toMatchObject({ consumedAt: null })
    expect(repository.conversationIdentities.listForConversation(second.conversation.id)).toEqual([])
  })

  it('retires a replaced provider session while preserving identity history', () => {
    const repository = openRepository('identity-rotation')
    const allocated = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput(),
      launchToken: 'rotation-token',
      now: 1_000
    })
    repository.conversationAllocator.attachProviderIdentity({
      executionHostId: 'local',
      agent: 'codex',
      providerSession: session('provider-old'),
      launchToken: 'rotation-token',
      observedAt: 2_000
    })

    const replacement = repository.conversationIdentities.attach({
      conversationId: allocated.conversation.id,
      agent: 'codex',
      providerSession: session('provider-new'),
      observedAt: 3_000
    })
    const identities = repository.conversationIdentities.listForConversation(
      allocated.conversation.id
    )

    expect(replacement).toMatchObject({
      session: session('provider-new'),
      retiredAt: null
    })
    expect(identities).toEqual([
      expect.objectContaining({ session: session('provider-new'), retiredAt: null }),
      expect.objectContaining({ session: session('provider-old'), retiredAt: 3_000 })
    ])
  })

  it('uses transcript path as the Pi-family identity discriminator', () => {
    const repository = openRepository('pi-paths')
    const first = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput({ agent: 'pi' }),
      launchToken: 'pi-one',
      now: 1_000
    })
    const second = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput({
        agent: 'pi',
        workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-pi-two' }
      }),
      launchToken: 'pi-two',
      now: 1_000
    })
    repository.conversationAllocator.attachProviderIdentity({
      executionHostId: 'local',
      agent: 'pi',
      providerSession: {
        key: 'session_id',
        id: 'same-id',
        transcriptPath: '/sessions/one.jsonl'
      },
      launchToken: 'pi-one',
      observedAt: 2_000
    })
    repository.conversationAllocator.attachProviderIdentity({
      executionHostId: 'local',
      agent: 'pi',
      providerSession: {
        key: 'session_id',
        id: 'same-id',
        transcriptPath: '/sessions/two.jsonl'
      },
      launchToken: 'pi-two',
      observedAt: 2_000
    })

    expect(repository.conversationIdentities.listForConversation(first.conversation.id)).toHaveLength(
      1
    )
    expect(repository.conversationIdentities.listForConversation(second.conversation.id)).toHaveLength(
      1
    )
    expect(
      repository.conversationIdentities.listForConversation(first.conversation.id)[0]
        ?.identityFingerprint
    ).not.toBe(
      repository.conversationIdentities.listForConversation(second.conversation.id)[0]
        ?.identityFingerprint
    )
  })

  it('rejects expired claims without partially attaching an identity', () => {
    const repository = openRepository('expired-claim')
    const allocated = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput(),
      launchToken: 'expired-token',
      now: 1_000,
      claimTtlMs: 10
    })

    expectRepositoryError(
      () =>
        repository.conversationAllocator.attachProviderIdentity({
          executionHostId: 'local',
          agent: 'codex',
          providerSession: session('too-late'),
          launchToken: 'expired-token',
          observedAt: 1_011
        }),
      'conversation_launch_claim_expired'
    )
    expect(repository.conversationIdentities.listForConversation(allocated.conversation.id)).toEqual(
      []
    )
  })
})

describe('Conversation resume resolution', () => {
  it('resumes the existing Conversation without changing its Issue binding', () => {
    const repository = openRepository('resume-existing')
    const issue = createIssue(repository, 'Bound Issue', 'local')
    const allocated = repository.conversationAllocator.allocateFreshLaunch({
      ...conversationInput({ issueId: issue.id }),
      launchToken: 'initial-token',
      now: 1_000
    })
    repository.conversationAllocator.attachProviderIdentity({
      executionHostId: 'local',
      agent: 'codex',
      providerSession: session('resume-me'),
      launchToken: 'initial-token',
      observedAt: 2_000
    })

    const resumed = repository.conversationAllocator.resolveResumeOrAllocate({
      ...conversationInput({ issueId: null }),
      providerSession: session('resume-me'),
      launchToken: 'resume-token',
      now: 3_000
    })

    expect(resumed).toMatchObject({
      disposition: 'replayed',
      conversation: {
        id: allocated.conversation.id,
        issueId: issue.id
      }
    })
    expect(repository.conversations.list()).toHaveLength(1)
  })

  it('creates an unassigned Conversation when resume identity has no owner', () => {
    const repository = openRepository('resume-unknown')
    const issue = createIssue(repository, 'Must not bind', 'local')

    const resumed = repository.conversationAllocator.resolveResumeOrAllocate({
      ...conversationInput({ issueId: issue.id }),
      providerSession: session('unknown-session'),
      launchToken: 'unknown-resume',
      now: 1_000
    })

    expect(resumed).toMatchObject({
      disposition: 'created',
      conversation: { issueId: null }
    })
    expect(
      repository.conversationIdentities.listForConversation(resumed.conversation.id)
    ).toEqual([expect.objectContaining({ session: session('unknown-session') })])
  })
})
