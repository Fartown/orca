import { StyleSheet } from 'react-native'
import { colors, radii, spacing, typography } from '../theme/mobile-theme'

export const mobileIssueScreenStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgBase
  },
  header: {
    minHeight: 48,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.borderSubtle
  },
  headerButton: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radii.button
  },
  headerTitleWrap: {
    flex: 1,
    minWidth: 0
  },
  headerTitle: {
    color: colors.textPrimary,
    fontSize: typography.titleSize,
    fontWeight: '600'
  },
  headerSubtitle: {
    color: colors.textMuted,
    fontSize: typography.metaSize,
    marginTop: 1
  },
  listContent: {
    padding: spacing.md,
    paddingBottom: spacing.xl
  },
  row: {
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    borderRadius: radii.card,
    backgroundColor: colors.bgPanel,
    marginBottom: spacing.sm
  },
  rowPressed: {
    backgroundColor: colors.bgRaised
  },
  rowTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm
  },
  rowTitle: {
    flex: 1,
    minWidth: 0,
    color: colors.textPrimary,
    fontSize: typography.bodySize,
    fontWeight: '600'
  },
  unreadDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: colors.statusAmber
  },
  rowMeta: {
    color: colors.textMuted,
    fontSize: typography.metaSize,
    marginTop: spacing.xs
  },
  preview: {
    color: colors.textSecondary,
    fontSize: typography.bodySize,
    lineHeight: 20,
    marginTop: spacing.sm
  },
  captureLabel: {
    alignSelf: 'flex-start',
    color: colors.textMuted,
    fontSize: typography.metaSize,
    marginTop: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radii.button,
    backgroundColor: colors.bgRaised
  },
  warning: {
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    padding: spacing.md,
    borderRadius: radii.card,
    borderWidth: 1,
    borderColor: colors.statusAmber,
    backgroundColor: colors.bgPanel
  },
  warningText: {
    color: colors.textSecondary,
    fontSize: typography.metaSize,
    lineHeight: 18
  },
  stateWrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl
  },
  stateCard: {
    width: '100%',
    maxWidth: 440,
    padding: spacing.xl,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    borderRadius: radii.card,
    backgroundColor: colors.bgPanel,
    alignItems: 'center'
  },
  stateIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: colors.bgRaised,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg
  },
  stateTitle: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center'
  },
  stateMessage: {
    color: colors.textSecondary,
    fontSize: typography.bodySize,
    lineHeight: 20,
    textAlign: 'center',
    marginTop: spacing.sm
  },
  detailContent: {
    flexGrow: 1,
    padding: spacing.md,
    paddingBottom: spacing.xl
  },
  detailCard: {
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.borderSubtle,
    borderRadius: radii.card,
    backgroundColor: colors.bgPanel
  },
  detailLabel: {
    color: colors.textMuted,
    fontSize: typography.metaSize,
    textTransform: 'uppercase',
    letterSpacing: 0.5
  },
  detailTitle: {
    color: colors.textPrimary,
    fontSize: 17,
    fontWeight: '600',
    marginTop: spacing.xs
  },
  detailMeta: {
    color: colors.textSecondary,
    fontSize: typography.metaSize,
    lineHeight: 18,
    marginTop: spacing.xs
  },
  detailDivider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.borderSubtle,
    marginVertical: spacing.lg
  },
  primaryButton: {
    minHeight: 44,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    borderRadius: radii.button,
    backgroundColor: colors.accentBlue,
    marginTop: spacing.lg,
    paddingHorizontal: spacing.lg
  },
  primaryButtonDisabled: {
    opacity: 0.6
  },
  primaryButtonText: {
    color: colors.onAccent,
    fontSize: typography.bodySize,
    fontWeight: '600'
  }
})
