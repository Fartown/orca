import type { IssueMobilePendingEntry, RoundRecordTextSummary } from '../../../src/shared/issues'
import { ORCA_ISSUES_RUNTIME_CAPABILITY } from '../../../src/shared/issues'
import type { ExecutionHostId } from '../../../src/shared/execution-host'
import type { MobileIssueDetailState } from './mobile-issue-data'

export type MobileIssuePendingRow = {
  executionHostId: ExecutionHostId
  issueTitle: string
  issueTypeLabel: string | null
  conversationTitle: string
  workspaceName: string
  preview: string | null
  captureLabel: string
  occurredAt: number
  isUnread: boolean
}

export type MobileIssueDetailPresentation = {
  tone: 'attention' | 'neutral' | 'warning' | 'danger'
  title: string
  message: string
  canOpenConversation: boolean
  preview: string | null
  captureLabel: string | null
}

export function supportsMobileIssues(capabilities: readonly string[]): boolean {
  return capabilities.includes(ORCA_ISSUES_RUNTIME_CAPABILITY)
}

function displayedRoundText(entry: IssueMobilePendingEntry): RoundRecordTextSummary {
  for (const value of [
    entry.round.pendingQuestion,
    entry.round.agentOutput,
    entry.round.userInput
  ]) {
    if (value.preview || value.completeness !== 'not-captured' || value.storage !== 'none') {
      return value
    }
  }
  return entry.round.pendingQuestion
}

function roundCaptureLabel(value: RoundRecordTextSummary): string {
  if (value.storage === 'deleted') {
    return 'Body deleted'
  }
  if (value.storage === 'evicted') {
    return 'Body removed'
  }
  if (value.storage === 'evicted-preview') {
    return 'Body removed · preview only'
  }
  if (value.completeness === 'truncated') {
    return 'Truncated preview'
  }
  if (value.completeness === 'not-captured' || value.storage === 'none') {
    return 'Not captured'
  }
  if (value.completeness === 'complete' && value.storage === 'full') {
    return 'Complete body'
  }
  return value.completeness === 'preview-complete' ? 'Captured preview' : 'Preview only'
}

export function buildMobileIssuePendingRow(
  executionHostId: ExecutionHostId,
  entry: IssueMobilePendingEntry
): MobileIssuePendingRow {
  const text = displayedRoundText(entry)
  return {
    executionHostId,
    issueTitle: entry.issue?.title ?? 'Unassigned',
    issueTypeLabel: entry.issue?.typeLabel ?? null,
    conversationTitle:
      entry.conversation.title?.trim() || entry.conversation.workspaceSnapshot.name,
    workspaceName: entry.conversation.workspaceSnapshot.name,
    preview: text.preview,
    captureLabel: roundCaptureLabel(text),
    occurredAt: entry.round.occurredAt,
    isUnread: entry.round.readAt === null
  }
}

export function buildMobileIssueDetailPresentation(
  state: MobileIssueDetailState
): MobileIssueDetailPresentation {
  if (state.status === 'ready') {
    const row = buildMobileIssuePendingRow(state.item.executionHostId, state.item.entry)
    return {
      tone: 'attention',
      title: 'Needs your input',
      message: 'Open the Conversation to answer or approve, then let the agent continue.',
      canOpenConversation: true,
      preview: row.preview,
      captureLabel: row.captureLabel
    }
  }
  if (state.status === 'handled-active') {
    return {
      tone: 'neutral',
      title: 'Already handled',
      message: 'This waiting item is no longer pending. The Conversation is still active.',
      canOpenConversation: true,
      preview: null,
      captureLabel: null
    }
  }
  if (state.status === 'closed') {
    return {
      tone: 'neutral',
      title: 'Conversation ended',
      message: 'This Conversation is no longer active on the host.',
      canOpenConversation: false,
      preview: null,
      captureLabel: null
    }
  }
  if (state.status === 'unsupported') {
    return {
      tone: 'warning',
      title: 'Host update required',
      message: 'This host does not support mobile Issue waiting yet.',
      canOpenConversation: false,
      preview: null,
      captureLabel: null
    }
  }
  if (state.status === 'unreachable') {
    return {
      tone: 'danger',
      title: 'Host unreachable',
      message: state.message || 'Reconnect to the host and try again.',
      canOpenConversation: false,
      preview: null,
      captureLabel: null
    }
  }
  return {
    tone: 'danger',
    title: 'Issue data unavailable',
    message: state.message || 'The host returned Issue data this app could not verify.',
    canOpenConversation: false,
    preview: null,
    captureLabel: null
  }
}
