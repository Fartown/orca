import { randomUUID } from 'node:crypto'
import { describe, expect, it, vi } from 'vitest'
import type { ExecutionHostId } from '../../../shared/execution-host'
import type { IssueAuthorityDescriptor } from '../../../shared/issues/types'
import {
  createLocalIssue,
  markIssueRoundsRead,
  type IssueMutationDependencies
} from './issue-mutations'

function authority(
  routeExecutionHostId: ExecutionHostId
): IssueAuthorityDescriptor {
  return {
    authorityId: randomUUID(),
    hostPartitionKey: 'local',
    routeExecutionHostId
  }
}

function dependencies(
  routeExecutionHostId: ExecutionHostId = 'local'
): IssueMutationDependencies & {
  callRpc: ReturnType<typeof vi.fn<IssueMutationDependencies['callRpc']>>
} {
  return {
    supportsCapability: vi.fn(async () => true),
    callRpc: vi.fn(async () => ({
      authority: authority(routeExecutionHostId),
      factsRevision: 2,
      treeRevision: 1,
      affectedIssueIds: [],
      affectedConversationIds: [],
      affectedRoundRecordIds: []
    }))
  }
}

describe('Issue mutation client', () => {
  it('preserves the mutation id and routes a local Issue creation through the existing runtime RPC', async () => {
    const deps = dependencies()

    await createLocalIssue(
      {
        executionHostId: 'local',
        mutationId: 'create-once',
        title: 'Renderer Issue',
        typeLabel: 'Feature'
      },
      deps
    )

    expect(deps.callRpc).toHaveBeenCalledWith('local', 'issues.create', {
      executionHostId: 'local',
      mutationId: 'create-once',
      source: { kind: 'local', title: 'Renderer Issue' },
      typeLabel: 'Feature'
    })
  })

  it('rejects an unsupported remote runtime before issuing a mutation', async () => {
    const deps = dependencies('runtime:legacy')
    deps.supportsCapability = vi.fn(async () => false)

    await expect(
      createLocalIssue(
        {
          executionHostId: 'runtime:legacy',
          mutationId: 'unsupported',
          title: 'Unavailable'
        },
        deps
      )
    ).rejects.toThrow('does not support Issues')
    expect(deps.callRpc).not.toHaveBeenCalled()
  })

  it('rejects a response restamped for a different host route', async () => {
    const deps = dependencies('local')

    await expect(
      createLocalIssue(
        {
          executionHostId: 'runtime:remote',
          mutationId: 'wrong-route',
          title: 'Wrong route'
        },
        deps
      )
    ).rejects.toThrow('stamped for another route')
  })

  it('keeps acknowledgement independent from resolution fields', async () => {
    const deps = dependencies()
    const roundRecordId = randomUUID()

    await markIssueRoundsRead(
      {
        executionHostId: 'local',
        mutationId: 'read-only',
        roundRecordIds: [roundRecordId],
        readAt: 123
      },
      deps
    )

    expect(deps.callRpc).toHaveBeenCalledWith('local', 'issues.markRead', {
      executionHostId: 'local',
      mutationId: 'read-only',
      roundRecordIds: [roundRecordId],
      readAt: 123
    })
    expect(deps.callRpc.mock.calls[0]?.[2]).not.toHaveProperty('resolvedAt')
  })
})
