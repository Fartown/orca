import { useEffect, useMemo } from 'react'
import { useStore } from 'zustand'
import type { ExecutionHostId } from '../../../shared/execution-host'
import {
  buildIssueActivityThreadProjections,
  type IssueActivityProjectionPartition,
  type IssueActivityThreadProjection
} from './issue-activity-projection'
import {
  connectIssueActivityEvents,
  issueActivityStore,
  type IssueActivityPartitionState
} from './issue-activity-store'
import {
  legacyActivityMigrationSnapshotKey,
  type LegacyActivityMigrationSnapshot
} from './legacy-activity-migration'
import { useLegacyActivityMigration } from './use-legacy-activity-migration'

export type IssueActivityTimeline = {
  authoritativeRoutes: ReadonlySet<ExecutionHostId>
  projections: IssueActivityThreadProjection[]
}

export function selectIssueActivityTimeline(
  routeExecutionHostIds: readonly ExecutionHostId[],
  partitionsByRoute: Partial<
    Record<ExecutionHostId, IssueActivityPartitionState>
  >,
  migrationSnapshot: LegacyActivityMigrationSnapshot = {}
): IssueActivityTimeline {
  const authoritativeRoutes = new Set<ExecutionHostId>()
  const partitions: IssueActivityProjectionPartition[] = []
  for (const routeExecutionHostId of routeExecutionHostIds) {
    const partition = partitionsByRoute[routeExecutionHostId]
    const expectedMigrationKey =
      legacyActivityMigrationSnapshotKey(
        migrationSnapshot[routeExecutionHostId] ?? []
      )
    const isAuthoritative =
      Boolean(partition?.authority) &&
      partition?.legacyMigrationStatus === 'complete' &&
      partition.legacyMigrationSnapshotKey === expectedMigrationKey
    if (isAuthoritative) {
      authoritativeRoutes.add(routeExecutionHostId)
    }
    if (!partition?.authority || !isAuthoritative) {
      continue
    }
    partitions.push({
      routeExecutionHostId,
      authority: partition.authority,
      entries: partition.entries
    })
  }
  return {
    authoritativeRoutes,
    projections: buildIssueActivityThreadProjections(partitions)
  }
}

export function useIssueActivityTimeline(
  routeExecutionHostIds: readonly ExecutionHostId[],
  enabled = true
): IssueActivityTimeline {
  const partitionsByRoute = useStore(
    issueActivityStore,
    (state) => state.partitionsByRoute
  )
  const routesKey = routeExecutionHostIds.join('\0')
  const stableRoutes = useMemo(
    () => [...routeExecutionHostIds],
    [routesKey]
  )
  const migrationSnapshot = useLegacyActivityMigration(
    stableRoutes,
    enabled
  )

  useEffect(() => {
    if (!enabled) {
      return
    }
    void issueActivityStore.getState().setVisibleRoutes(stableRoutes)
  }, [enabled, stableRoutes])

  useEffect(() => {
    if (!enabled) {
      return
    }
    return connectIssueActivityEvents(issueActivityStore, window)
  }, [enabled])

  return useMemo(
    () =>
      enabled
        ? selectIssueActivityTimeline(
            stableRoutes,
            partitionsByRoute,
            migrationSnapshot
          )
        : {
            authoritativeRoutes: new Set<ExecutionHostId>(),
            projections: []
          },
    [enabled, migrationSnapshot, partitionsByRoute, stableRoutes]
  )
}
