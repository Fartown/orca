import { afterEach, describe, expect, it, vi } from 'vitest'
import type {
  IssueDigestConfirmationResult,
  IssueDigestMutationResult,
  IssueDigestPreparation,
  IssueDigestSections
} from '../../shared/issues/digest-types'
import type { TuiAgent } from '../../shared/tui-agent'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import {
  IssueRuntimeService,
  type IssueRuntimeServiceOptions
} from './issue-runtime-service'

type DigestExecutor = {
  generate(input: {
    agent: TuiAgent
    digestId: string
    issueId: string
  }): Promise<IssueDigestSections>
  cancel(input: { digestId: string; issueId: string }): Promise<void>
}

type DigestRuntimeSurface = {
  prepareDigest(params: {
    executionHostId: 'local'
    issueId: string
    coversUntil: number
  }): IssueDigestPreparation
  generateDigest(
    params: {
      executionHostId: 'local'
      mutationId: string
      issueId: string
      coversUntil: number
      agent: TuiAgent
      expectedInputFingerprint: string
    },
    callerFingerprint: string
  ): Promise<IssueDigestMutationResult>
  cancelDigest(
    params: {
      executionHostId: 'local'
      mutationId: string
      digestId: string
    },
    callerFingerprint: string
  ): Promise<IssueDigestMutationResult>
  updateDigestDraft(
    params: {
      executionHostId: 'local'
      mutationId: string
      digestId: string
      expectedDigestRevision: number
      conclusion?: string | null
    },
    callerFingerprint: string
  ): IssueDigestMutationResult
  confirmDigest(
    params: {
      executionHostId: 'local'
      mutationId: string
      digestId: string
      expectedDigestRevision: number
      inputFingerprint: string
      confirmStaleAgainstFingerprint?: string
    },
    callerFingerprint: string
  ): IssueDigestConfirmationResult
}

const repositories: IssueRepository[] = []
let sequence = 0

function openRuntime(name: string, executor: DigestExecutor) {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-issue-digest-runtime-${name}`)
    })
  )
  repositories.push(repository)
  const options = { digestExecutor: executor } as unknown as IssueRuntimeServiceOptions
  return {
    repository,
    service: new IssueRuntimeService(repository, options) as unknown as DigestRuntimeSurface
  }
}

function identity(label: string) {
  sequence += 1
  return issueMutationIdentity('digest-runtime-seed', `${label}-${sequence}`)
}

function createIssue(repository: IssueRepository, title: string) {
  return repository.issues.create({
    identity: identity('issue'),
    input: {
      kind: 'local',
      executionHostId: 'local',
      title
    }
  })
}

function createConversation(repository: IssueRepository, issueId: string) {
  return repository.conversations.create({
    identity: identity('conversation'),
    input: {
      executionHostId: 'local',
      workspaceRef: {
        type: 'folder',
        folderWorkspaceId: `digest-folder-${sequence}`
      },
      workspaceSnapshot: {
        name: 'Digest workspace',
        path: '/workspace/digest'
      },
      agent: 'codex',
      issueId
    }
  })
}

function createRound(
  repository: IssueRepository,
  conversationId: string,
  occurredAt: number,
  text: string
) {
  return repository.rounds.create({
    identity: identity('round'),
    input: {
      conversationId,
      kind: 'completion',
      stateSource: 'hook',
      occurredAt,
      dedupeKey: `digest-round:${sequence}`,
      agentOutput: { text }
    }
  })
}

function createExecutor() {
  return {
    generate: vi.fn<DigestExecutor['generate']>(async () => ({
      problem: 'Generated problem',
      conclusion: 'Generated conclusion',
      keyArtifacts: null,
      openIssues: null,
      nextSteps: 'Continue'
    })),
    cancel: vi.fn<DigestExecutor['cancel']>(async () => {})
  }
}

function deferredSections() {
  let resolve!: (sections: IssueDigestSections) => void
  const promise = new Promise<IssueDigestSections>((resolver) => {
    resolve = resolver
  })
  return { promise, resolve }
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  sequence = 0
})

describe('Issue Digest runtime coordination', () => {
  it('rejects a changed input fingerprint before allocating or starting generation', async () => {
    const executor = createExecutor()
    const { repository, service } = openRuntime('fingerprint-fence', executor)
    const issue = createIssue(repository, 'Fingerprint fence')
    const conversation = createConversation(repository, issue.id)
    const preparation = service.prepareDigest({
      executionHostId: 'local',
      issueId: issue.id,
      coversUntil: 100
    })
    createRound(repository, conversation.id, 50, 'Arrived after prepare')

    expect(() =>
      service.generateDigest(
        {
          executionHostId: 'local',
          mutationId: 'generate-stale',
          issueId: issue.id,
          coversUntil: 100,
          agent: 'codex',
          expectedInputFingerprint: preparation.inputFingerprint
        },
        'desktop-profile'
      )
    ).toThrowError(expect.objectContaining({ code: 'digest_input_stale' }))
    expect(repository.digests.listForIssue(issue.id)).toEqual([])
    expect(executor.generate).not.toHaveBeenCalled()
  })

  it('replays a generation receipt without starting the agent twice', async () => {
    const executor = createExecutor()
    const pending = deferredSections()
    executor.generate.mockReturnValue(pending.promise)
    const { repository, service } = openRuntime('generation-replay', executor)
    const issue = createIssue(repository, 'Generate once')
    const preparation = service.prepareDigest({
      executionHostId: 'local',
      issueId: issue.id,
      coversUntil: 100
    })
    const params = {
      executionHostId: 'local' as const,
      mutationId: 'generate-once',
      issueId: issue.id,
      coversUntil: 100,
      agent: 'codex' as const,
      expectedInputFingerprint: preparation.inputFingerprint
    }

    const first = await service.generateDigest(params, 'desktop-profile')
    const replay = await service.generateDigest(params, 'desktop-profile')

    expect(replay).toEqual(first)
    expect(first.digest.status).toBe('generating')
    expect(repository.digests.listForIssue(issue.id)).toHaveLength(1)
    expect(executor.generate).toHaveBeenCalledTimes(1)

    pending.resolve({
      problem: null,
      conclusion: 'Settled',
      keyArtifacts: null,
      openIssues: null,
      nextSteps: null
    })
    await vi.waitFor(() => {
      expect(repository.digests.require(first.digest.id).status).toBe('draft')
    })
  })

  it('replays cancellation once and ignores a late generation result', async () => {
    const executor = createExecutor()
    const pending = deferredSections()
    executor.generate.mockReturnValue(pending.promise)
    const { repository, service } = openRuntime('cancel-race', executor)
    const issue = createIssue(repository, 'Cancel once')
    const preparation = service.prepareDigest({
      executionHostId: 'local',
      issueId: issue.id,
      coversUntil: 100
    })
    const generated = await service.generateDigest(
      {
        executionHostId: 'local',
        mutationId: 'generate-for-cancel',
        issueId: issue.id,
        coversUntil: 100,
        agent: 'claude',
        expectedInputFingerprint: preparation.inputFingerprint
      },
      'desktop-profile'
    )
    const cancelParams = {
      executionHostId: 'local' as const,
      mutationId: 'cancel-once',
      digestId: generated.digest.id
    }

    const first = await service.cancelDigest(cancelParams, 'desktop-profile')
    const replay = await service.cancelDigest(cancelParams, 'desktop-profile')

    expect(replay).toEqual(first)
    expect(first.digest.status).toBe('canceled')
    expect(executor.cancel).toHaveBeenCalledTimes(1)

    pending.resolve({
      problem: 'Late',
      conclusion: 'Must not win',
      keyArtifacts: null,
      openIssues: null,
      nextSteps: null
    })
    await vi.waitFor(() => {
      expect(repository.digests.require(generated.digest.id)).toMatchObject({
        status: 'canceled',
        problem: null,
        conclusion: null
      })
    })
  })

  it('updates one draft revision and replays the edit receipt', () => {
    const executor = createExecutor()
    const { repository, service } = openRuntime('draft-edit', executor)
    const issue = createIssue(repository, 'Edit draft')
    const preparation = service.prepareDigest({
      executionHostId: 'local',
      issueId: issue.id,
      coversUntil: 100
    })
    const generating = repository.digests.createGenerating({
      identity: identity('generate'),
      issue,
      agent: 'codex',
      coversUntil: 100,
      inputFingerprint: preparation.inputFingerprint,
      coverageNote: preparation.coverage.note,
      inputs: preparation.inputs
    }).digest
    const draft = repository.digests.completeGeneration(generating.id, {
      problem: 'Original',
      conclusion: null,
      keyArtifacts: null,
      openIssues: null,
      nextSteps: null
    })
    const params = {
      executionHostId: 'local' as const,
      mutationId: 'edit-once',
      digestId: draft.id,
      expectedDigestRevision: 0,
      conclusion: 'Edited'
    }

    const first = service.updateDigestDraft(params, 'desktop-profile')
    const replay = service.updateDigestDraft(params, 'desktop-profile')

    expect(replay).toEqual(first)
    expect(first.digest).toMatchObject({
      status: 'draft',
      revision: 1,
      problem: 'Original',
      conclusion: 'Edited'
    })
  })

  it('requires a fresh second confirmation before accepting a stale draft', () => {
    const executor = createExecutor()
    const { repository, service } = openRuntime('stale-confirm', executor)
    const issue = createIssue(repository, 'Stale confirmation')
    const conversation = createConversation(repository, issue.id)
    const preparation = service.prepareDigest({
      executionHostId: 'local',
      issueId: issue.id,
      coversUntil: 100
    })
    const generating = repository.digests.createGenerating({
      identity: identity('generate'),
      issue,
      agent: 'codex',
      coversUntil: 100,
      inputFingerprint: preparation.inputFingerprint,
      coverageNote: preparation.coverage.note,
      inputs: preparation.inputs
    }).digest
    const draft = repository.digests.completeGeneration(generating.id, {
      problem: 'Old coverage',
      conclusion: null,
      keyArtifacts: null,
      openIssues: null,
      nextSteps: null
    })
    createRound(repository, conversation.id, 50, 'First change')

    const first = service.confirmDigest(
      {
        executionHostId: 'local',
        mutationId: 'confirm-first',
        digestId: draft.id,
        expectedDigestRevision: 0,
        inputFingerprint: draft.inputFingerprint
      },
      'desktop-profile'
    )
    expect(first).toMatchObject({
      status: 'stale',
      digest: { id: draft.id, status: 'draft' },
      currentInputFingerprint: expect.not.stringMatching(draft.inputFingerprint)
    })
    if (first.status !== 'stale') {
      throw new Error('Expected the first confirmation to report stale input.')
    }

    createRound(repository, conversation.id, 60, 'Second change')
    const second = service.confirmDigest(
      {
        executionHostId: 'local',
        mutationId: 'confirm-second',
        digestId: draft.id,
        expectedDigestRevision: 0,
        inputFingerprint: draft.inputFingerprint,
        confirmStaleAgainstFingerprint: first.currentInputFingerprint
      },
      'desktop-profile'
    )
    expect(second).toMatchObject({
      status: 'stale',
      digest: { status: 'draft' },
      currentInputFingerprint: expect.not.stringMatching(first.currentInputFingerprint)
    })
    if (second.status !== 'stale') {
      throw new Error('Expected the second confirmation to observe the newer input.')
    }

    const confirmed = service.confirmDigest(
      {
        executionHostId: 'local',
        mutationId: 'confirm-third',
        digestId: draft.id,
        expectedDigestRevision: 0,
        inputFingerprint: draft.inputFingerprint,
        confirmStaleAgainstFingerprint: second.currentInputFingerprint
      },
      'desktop-profile'
    )

    expect(confirmed).toMatchObject({
      status: 'confirmed',
      stale: true,
      currentInputFingerprint: second.currentInputFingerprint,
      digest: {
        status: 'confirmed',
        inputFingerprint: draft.inputFingerprint
      }
    })
  })
})
