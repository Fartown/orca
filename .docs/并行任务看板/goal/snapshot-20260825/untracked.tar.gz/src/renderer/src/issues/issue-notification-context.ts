import type { ExecutionHostId } from '../../../shared/execution-host'
import type {
  IssueDashboardPaneProjection,
  RoundRecordKind
} from '../../../shared/issues/types'
import {
  loadIssueDashboardProjection,
  type IssueDashboardLoadResult
} from './issue-dashboard-client'
import { issueDashboardStore } from './issue-dashboard-store'

export type IssueNotificationContext = {
  executionHostId: ExecutionHostId
  conversationId?: string
  issueId?: string
  roundRecordId?: string
  isVisibleRoundRecord?: boolean
}

export type ExpectedNotificationRound = {
  kind: Extract<RoundRecordKind, 'completion' | 'waiting'>
  occurredAt?: number
}

export type IssueNotificationContextInput = {
  executionHostId: ExecutionHostId
  paneKey: string
  expectedRound?: ExpectedNotificationRound
}

export type IssueNotificationContextDependencies = {
  readCachedPane: (
    executionHostId: ExecutionHostId,
    paneKey: string
  ) => IssueDashboardPaneProjection | null
  loadProjection: (
    executionHostId: ExecutionHostId,
    paneKeys: readonly string[]
  ) => Promise<IssueDashboardLoadResult>
  isRoundRecordVisible: (roundRecordId: string) => boolean
}

type Rect = {
  top: number
  right: number
  bottom: number
  left: number
  width: number
  height: number
}

type RectVisibilityContext = {
  foreground: boolean
  viewportWidth: number
  viewportHeight: number
}

export async function loadIssueNotificationContext(
  { executionHostId, paneKey, expectedRound }: IssueNotificationContextInput,
  dependencies: IssueNotificationContextDependencies = defaultDependencies
): Promise<IssueNotificationContext> {
  const cached = dependencies.readCachedPane(executionHostId, paneKey)
  if (cached && roundMatches(cached, expectedRound)) {
    return contextFromPane(executionHostId, cached, expectedRound, dependencies)
  }

  const loaded = await dependencies.loadProjection(executionHostId, [paneKey])
  if (loaded.status === 'ready') {
    const current = loaded.projection.panes.find(
      (candidate) => candidate.paneKey === paneKey
    )
    if (current) {
      return contextFromPane(
        executionHostId,
        current,
        expectedRound,
        dependencies
      )
    }
  }

  return cached
    ? contextFromPane(executionHostId, cached, expectedRound, dependencies)
    : { executionHostId }
}

export function readCachedIssueNotificationContext(
  { executionHostId, paneKey, expectedRound }: IssueNotificationContextInput,
  dependencies: Pick<
    IssueNotificationContextDependencies,
    'readCachedPane' | 'isRoundRecordVisible'
  > = defaultDependencies
): IssueNotificationContext | null {
  const cached = dependencies.readCachedPane(executionHostId, paneKey)
  return cached && roundMatches(cached, expectedRound)
    ? contextFromPane(executionHostId, cached, expectedRound, dependencies)
    : null
}

export function roundRecordRectIsVisible(
  rect: Rect,
  context: RectVisibilityContext
): boolean {
  return Boolean(
    context.foreground &&
      rect.width > 0 &&
      rect.height > 0 &&
      rect.bottom > 0 &&
      rect.right > 0 &&
      rect.top < context.viewportHeight &&
      rect.left < context.viewportWidth
  )
}

export function isRoundRecordVisible(roundRecordId: string): boolean {
  if (
    typeof document === 'undefined' ||
    document.visibilityState !== 'visible' ||
    !document.hasFocus()
  ) {
    return false
  }
  const element = [...document.querySelectorAll<HTMLElement>('[data-round-record-id]')].find(
    (candidate) => candidate.dataset.roundRecordId === roundRecordId
  )
  if (!element) {
    return false
  }
  const rect = element.getBoundingClientRect()
  return roundRecordRectIsVisible(rect, {
    foreground: true,
    viewportWidth:
      document.documentElement.clientWidth ||
      (typeof window === 'undefined' ? 0 : window.innerWidth),
    viewportHeight:
      document.documentElement.clientHeight ||
      (typeof window === 'undefined' ? 0 : window.innerHeight)
  })
}

function contextFromPane(
  executionHostId: ExecutionHostId,
  pane: IssueDashboardPaneProjection,
  expectedRound: ExpectedNotificationRound | undefined,
  dependencies: Pick<IssueNotificationContextDependencies, 'isRoundRecordVisible'>
): IssueNotificationContext {
  const round = roundMatches(pane, expectedRound) ? pane.latestRound : null
  return {
    executionHostId,
    conversationId: pane.conversationId,
    ...(pane.issue ? { issueId: pane.issue.id } : {}),
    ...(round
      ? {
          roundRecordId: round.id,
          isVisibleRoundRecord: dependencies.isRoundRecordVisible(round.id)
        }
      : {})
  }
}

function roundMatches(
  pane: IssueDashboardPaneProjection,
  expectedRound: ExpectedNotificationRound | undefined
): boolean {
  const round = pane.latestRound
  if (!round) {
    return false
  }
  return Boolean(
    !expectedRound ||
      (round.kind === expectedRound.kind &&
        (expectedRound.occurredAt === undefined ||
          round.occurredAt === expectedRound.occurredAt))
  )
}

const defaultDependencies: IssueNotificationContextDependencies = {
  readCachedPane: (executionHostId, paneKey) =>
    issueDashboardStore
      .getState()
      .partitionsByRoute[executionHostId]?.projection?.panes.find(
        (candidate) => candidate.paneKey === paneKey
      ) ?? null,
  loadProjection: loadIssueDashboardProjection,
  isRoundRecordVisible
}
