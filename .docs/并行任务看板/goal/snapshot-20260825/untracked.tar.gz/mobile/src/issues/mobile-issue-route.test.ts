import { describe, expect, it, vi } from 'vitest'
import type { ConversationNavigationTarget } from '../../../src/shared/issues'
import type { RpcClient } from '../transport/rpc-client'
import type { RpcResponse } from '../transport/types'
import {
  activateMobileIssueConversation,
  mobileIssueConversationSessionTarget,
  mobileIssueRouteTarget,
  mobileIssueWorkspaceId
} from './mobile-issue-route'

const CONVERSATION_ID = '33333333-3333-4333-8333-333333333333'
const LEAF_ID = '11111111-1111-4111-8111-111111111111'

function conversation(
  overrides: Partial<ConversationNavigationTarget> = {}
): ConversationNavigationTarget {
  return {
    id: CONVERSATION_ID,
    hostPartitionKey: 'local',
    executionHostId: 'local',
    workspaceRef: { type: 'worktree', worktreeId: 'worktree-1' },
    workspaceSnapshot: { name: 'Feature', path: '/tmp/feature' },
    agent: 'codex',
    title: 'Fix the build',
    titleSource: 'user',
    issueId: null,
    state: 'active',
    launchFailure: null,
    createdAt: 1,
    updatedAt: 2,
    navigation: {
      paneKey: `tab-1:${LEAF_ID}`,
      providerSession: null,
      resumeLocator: null
    },
    ...overrides
  }
}

function response(ok: boolean): RpcResponse {
  return ok
    ? { id: 'rpc-1', ok: true, result: {}, _meta: { runtimeId: 'runtime-1' } }
    : {
        id: 'rpc-1',
        ok: false,
        error: { code: 'not_found', message: 'pane missing' },
        _meta: { runtimeId: 'runtime-1' }
      }
}

describe('mobile Issue routing', () => {
  it('keeps the exact Issue locator and drops malformed optional ids', () => {
    expect(
      mobileIssueRouteTarget({
        hostId: 'host-1',
        executionHostId: 'ssh:docs',
        conversationId: CONVERSATION_ID,
        issueId: 'not-an-id',
        roundRecordId: '44444444-4444-4444-8444-444444444444',
        worktreeId: 'repo::/tmp/worktree'
      })
    ).toEqual({
      name: '[hostId]/issues/[conversationId]',
      params: {
        hostId: 'host-1',
        executionHostId: 'ssh:docs',
        conversationId: CONVERSATION_ID,
        roundRecordId: '44444444-4444-4444-8444-444444444444',
        worktreeId: 'repo::/tmp/worktree'
      }
    })
    expect(
      mobileIssueRouteTarget({
        hostId: 'host-1',
        executionHostId: 'invalid',
        conversationId: CONVERSATION_ID
      })
    ).toBeNull()
  })

  it('maps managed worktrees and folder workspaces onto existing session routes', () => {
    expect(mobileIssueWorkspaceId(conversation())).toBe('worktree-1')
    const folderConversation = conversation({
      workspaceRef: {
        type: 'folder',
        folderWorkspaceId: 'folder-1'
      }
    })
    expect(mobileIssueWorkspaceId(folderConversation)).toBe('folder:folder-1')
    expect(mobileIssueConversationSessionTarget('host-1', folderConversation)).toEqual({
      name: '[hostId]/session/[worktreeId]',
      params: {
        hostId: 'host-1',
        worktreeId: 'folder:folder-1',
        name: 'Feature'
      }
    })
  })

  it('activates the stable pane before opening the existing session screen', async () => {
    const sendRequest = vi.fn<RpcClient['sendRequest']>().mockResolvedValue(response(true))

    await expect(
      activateMobileIssueConversation({ sendRequest }, 'host-1', conversation())
    ).resolves.toEqual({
      precision: 'pane',
      target: {
        name: '[hostId]/session/[worktreeId]',
        params: {
          hostId: 'host-1',
          worktreeId: 'worktree-1',
          name: 'Feature'
        }
      }
    })
    expect(sendRequest).toHaveBeenCalledWith('session.tabs.activate', {
      worktree: 'id:worktree-1',
      tabId: 'tab-1',
      leafId: LEAF_ID,
      notifyClients: false,
      navigation: 'caller',
      intent: 'user'
    })
  })

  it('falls back to the Workspace when the pane is legacy or no longer available', async () => {
    const legacySend = vi.fn<RpcClient['sendRequest']>()
    await expect(
      activateMobileIssueConversation(
        { sendRequest: legacySend },
        'host-1',
        conversation({
          navigation: {
            paneKey: 'tab-1:42',
            providerSession: null,
            resumeLocator: null
          }
        })
      )
    ).resolves.toMatchObject({ precision: 'workspace' })
    expect(legacySend).not.toHaveBeenCalled()

    const missingSend = vi.fn<RpcClient['sendRequest']>().mockResolvedValue(response(false))
    await expect(
      activateMobileIssueConversation({ sendRequest: missingSend }, 'host-1', conversation())
    ).resolves.toMatchObject({ precision: 'workspace' })
  })
})
