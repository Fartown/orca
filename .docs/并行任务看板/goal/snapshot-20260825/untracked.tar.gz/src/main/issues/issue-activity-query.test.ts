import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueActivityQuery } from './issue-activity-query'
import { resolveIssueAuthorityRoute } from './issue-authority-route'
import { readHostRevisions } from './issue-query-projections'
import { IssueRepository, issueMutationIdentity } from './issue-repository'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-activity-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  mutationSequence += 1
  return issueMutationIdentity('activity-test', `${label}-${mutationSequence}`)
}

function createIssue(
  repository: IssueRepository,
  title: string,
  executionHostId: ExecutionHostId = 'local'
) {
  return repository.issues.create({
    identity: identity(`issue-${title}`),
    input: { kind: 'local', title, executionHostId }
  })
}

function createConversation(
  repository: IssueRepository,
  label: string,
  issueId: string | null = null,
  executionHostId: ExecutionHostId = 'local'
) {
  return repository.conversations.create({
    identity: identity(`conversation-${label}`),
    input: {
      executionHostId,
      workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${label}` },
      workspaceSnapshot: { name: label, path: `/workspace/${label}` },
      agent: 'codex',
      title: label,
      titleSource: 'user',
      issueId
    }
  })
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('IssueActivityQuery', () => {
  it('merges Round Records and lifecycle events without losing unassigned Conversations', () => {
    const repository = openRepository('merged')
    const query = new IssueActivityQuery(repository.database)
    const route = resolveIssueAuthorityRoute('local')
    const issue = createIssue(repository, 'Assigned work')
    const assigned = createConversation(repository, 'assigned', issue.id)
    const unassigned = createConversation(repository, 'unassigned')
    repository.conversationLaunchClaims.create({
      conversationId: assigned.id,
      launchToken: 'activity-assigned',
      paneKey: 'tab-assigned:leaf-assigned',
      createdAt: 1,
      expiresAt: 100_000
    })
    repository.conversationIdentities.attach({
      conversationId: assigned.id,
      agent: 'codex',
      providerSession: {
        key: 'session_id',
        id: 'activity-provider-session',
        transcriptPath: '/sessions/activity-provider-session.jsonl'
      },
      resumeLocator: '/sessions/activity-provider-session.jsonl',
      observedAt: 2
    })
    const base = Date.now() + 10_000
    const assignedRound = repository.rounds.create({
      identity: identity('assigned-round'),
      input: {
        conversationId: assigned.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: base + 30,
        dedupeKey: 'activity:assigned',
        pendingQuestion: { text: 'Review this?' },
        readAt: base + 31
      }
    })
    const revisions = readHostRevisions(repository.database, 'local')
    const event = repository.issueEvents.appendWithinTransaction({
      hostPartitionKey: 'local',
      kind: 'metadata-updated',
      issueRefs: [{ issueId: issue.id, role: 'issue', titleSnapshot: 'Assigned work' }],
      payload: { fields: ['note'] },
      occurredAt: base + 50,
      factsRevision: revisions.factsRevision
    })
    const unassignedRound = repository.rounds.create({
      identity: identity('unassigned-round'),
      input: {
        conversationId: unassigned.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: base + 50,
        dedupeKey: 'activity:unassigned',
        agentOutput: { text: 'Finished' },
        resolvedAt: base + 60,
        resolution: 'explicit'
      }
    })

    const first = query.list(route, { limit: 2 })
    expect(first.entries).toHaveLength(2)
    expect(new Set(first.entries.map((entry) => `${entry.type}:${entry.id}`))).toEqual(
      new Set([`round:${unassignedRound.id}`, `issue-event:${event.id}`])
    )
    expect(first.nextCursor).not.toBeNull()
    if (!first.nextCursor) {
      throw new Error('Expected a second Activity page.')
    }

    const second = query.list(route, { cursor: first.nextCursor, limit: 20 })
    const assignedEntry = second.entries.find(
      (entry) => entry.type === 'round' && entry.id === assignedRound.id
    )
    expect(assignedEntry).toMatchObject({
      type: 'round',
      round: {
        readAt: base + 31,
        resolvedAt: null,
        effectiveResolvedAt: null
      },
      conversation: {
        id: assigned.id,
        issueId: issue.id,
        navigation: {
          paneKey: 'tab-assigned:leaf-assigned',
          providerSession: {
            key: 'session_id',
            id: 'activity-provider-session',
            transcriptPath: '/sessions/activity-provider-session.jsonl'
          },
          resumeLocator: '/sessions/activity-provider-session.jsonl'
        }
      },
      issue: { id: issue.id, title: 'Assigned work' }
    })
    const unassignedEntry = first.entries.find(
      (entry) => entry.type === 'round' && entry.id === unassignedRound.id
    )
    expect(unassignedEntry).toMatchObject({
      type: 'round',
      round: {
        readAt: null,
        resolvedAt: base + 60,
        effectiveResolvedAt: base + 60
      },
      conversation: { id: unassigned.id, issueId: null },
      issue: null
    })
    expect(second.entries.some((entry) => entry.id === event.id)).toBe(false)
  })

  it('pins cursors to the host facts revision and isolates host partitions', () => {
    const repository = openRepository('partitioned')
    const query = new IssueActivityQuery(repository.database)
    const localConversation = createConversation(repository, 'local')
    const remoteConversation = createConversation(repository, 'remote', null, 'ssh:builder')
    repository.rounds.create({
      identity: identity('local-round'),
      input: {
        conversationId: localConversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'activity:local'
      }
    })
    repository.rounds.create({
      identity: identity('older-local-round'),
      input: {
        conversationId: localConversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 5,
        dedupeKey: 'activity:older-local'
      }
    })
    const remoteRound = repository.rounds.create({
      identity: identity('remote-round'),
      input: {
        conversationId: remoteConversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 20,
        dedupeKey: 'activity:remote'
      }
    })

    const remoteRoute = resolveIssueAuthorityRoute('ssh:builder', {
      isManagedSshTarget: (targetId) => targetId === 'builder'
    })
    const remotePage = query.list(remoteRoute, { limit: 1 })
    expect(remotePage.entries).toEqual([
      expect.objectContaining({
        type: 'round',
        id: remoteRound.id,
        conversation: expect.objectContaining({
          id: remoteConversation.id,
          executionHostId: 'ssh:builder'
        })
      })
    ])
    expect(remotePage.nextCursor).toBeNull()

    const localRoute = resolveIssueAuthorityRoute('local')
    const localPage = query.list(localRoute, { limit: 1 })
    expect(localPage.nextCursor).not.toBeNull()
    if (!localPage.nextCursor) {
      throw new Error('Expected the local Activity cursor.')
    }
    repository.rounds.create({
      identity: identity('concurrent-round'),
      input: {
        conversationId: localConversation.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 30,
        dedupeKey: 'activity:concurrent'
      }
    })
    expect(() =>
      query.list(localRoute, { cursor: localPage.nextCursor ?? undefined, limit: 20 })
    ).toThrowError(expect.objectContaining({ code: 'issue_cursor_invalid' }))
  })

  it('restamps event Conversations to the client runtime route', () => {
    const repository = openRepository('runtime-route')
    const query = new IssueActivityQuery(repository.database)
    const conversation = createConversation(repository, 'remote-runtime-view')
    repository.conversationLaunchClaims.create({
      conversationId: conversation.id,
      launchToken: 'activity-runtime-route',
      paneKey: 'tab-runtime:leaf-runtime',
      createdAt: 1,
      expiresAt: 1_000
    })
    const revisions = readHostRevisions(repository.database, 'local')
    const event = repository.issueEvents.appendWithinTransaction({
      hostPartitionKey: 'local',
      kind: 'conversation-unbound',
      conversationId: conversation.id,
      issueRefs: [],
      payload: {},
      occurredAt: 100,
      factsRevision: revisions.factsRevision
    })

    const page = query.list(resolveIssueAuthorityRoute('runtime:paired'), {
      limit: 20
    })

    expect(page.entries).toEqual([
      expect.objectContaining({
        type: 'issue-event',
        id: event.id,
        event: expect.objectContaining({
          executionHostId: 'runtime:paired'
        }),
        conversation: expect.objectContaining({
          id: conversation.id,
          executionHostId: 'runtime:paired',
          navigation: {
            paneKey: 'tab-runtime:leaf-runtime',
            providerSession: null,
            resumeLocator: null
          }
        })
      })
    ])
  })
})
