import { createHash, randomUUID } from 'node:crypto'
import {
  normalizeAgentProviderSession,
  type AgentProviderSessionMetadata
} from '../../shared/agent-session-resume'
import type {
  AuthorityHostPartitionKey,
  ConversationProviderIdentity
} from '../../shared/issues/types'
import type { TuiAgent } from '../../shared/tui-agent'
import type { IssueDatabase } from './issue-database'
import { requireConversationRecord } from './conversation-record-queries'
import { hostPartitionForExecutionHost } from './issue-host-partition'
import { IssueRepositoryError } from './issue-repository-error'

type ConversationProviderIdentityRow = {
  id: string
  conversation_id: string
  host_partition_key: AuthorityHostPartitionKey
  agent: TuiAgent
  provider_session_key: AgentProviderSessionMetadata['key']
  provider_session_id: string
  identity_fingerprint: string
  transcript_path: string | null
  resume_locator: string | null
  observed_at: number
  retired_at: number | null
}

export type AttachConversationProviderIdentityInput = {
  conversationId: string
  agent: TuiAgent
  providerSession: AgentProviderSessionMetadata
  resumeLocator?: string | null
  observedAt?: number
}

export type FindConversationProviderIdentityInput = {
  hostPartitionKey: AuthorityHostPartitionKey
  agent: TuiAgent
  providerSession: AgentProviderSessionMetadata
}

function encodeFingerprintFields(fields: readonly string[]): Buffer {
  const chunks: Buffer[] = []
  for (const field of fields) {
    const value = Buffer.from(field, 'utf8')
    const length = Buffer.allocUnsafe(4)
    length.writeUInt32BE(value.length)
    chunks.push(length, value)
  }
  return Buffer.concat(chunks)
}

export function getConversationIdentityFingerprint(input: {
  hostPartitionKey: AuthorityHostPartitionKey
  agent: TuiAgent
  providerSession: AgentProviderSessionMetadata
}): string {
  const providerSession = normalizeAgentProviderSession(input.providerSession)
  if (!providerSession) {
    throw new IssueRepositoryError(
      'conversation_identity_invalid',
      'Provider session identity is invalid.'
    )
  }
  const transcriptDiscriminator =
    input.agent === 'pi' || input.agent === 'prime-agent'
      ? providerSession.transcriptPath?.trim()
      : ''
  if (
    (input.agent === 'pi' || input.agent === 'prime-agent') &&
    !transcriptDiscriminator
  ) {
    throw new IssueRepositoryError(
      'conversation_identity_invalid',
      `${input.agent} identity requires a canonical transcript path.`
    )
  }
  return createHash('sha256')
    .update(
      encodeFingerprintFields([
        'orca-conversation-provider-identity-v1',
        input.hostPartitionKey,
        input.agent,
        providerSession.key,
        providerSession.id,
        transcriptDiscriminator ?? ''
      ])
    )
    .digest('hex')
}

export class ConversationIdentityRepository {
  constructor(private readonly database: IssueDatabase) {}

  findActive(input: FindConversationProviderIdentityInput): ConversationProviderIdentity | undefined {
    const fingerprint = getConversationIdentityFingerprint(input)
    return this.findActiveByFingerprint(input.hostPartitionKey, fingerprint)
  }

  findActiveForExecutionHost(input: {
    executionHostId: Parameters<typeof hostPartitionForExecutionHost>[0]
    agent: TuiAgent
    providerSession: AgentProviderSessionMetadata
  }): ConversationProviderIdentity | undefined {
    return this.findActive({
      hostPartitionKey: hostPartitionForExecutionHost(input.executionHostId),
      agent: input.agent,
      providerSession: input.providerSession
    })
  }

  findActiveByFingerprint(
    hostPartitionKey: AuthorityHostPartitionKey,
    fingerprint: string
  ): ConversationProviderIdentity | undefined {
    const row = this.database
      .prepare(
        `SELECT * FROM conversation_provider_identities
         WHERE host_partition_key = ? AND identity_fingerprint = ? AND retired_at IS NULL`
      )
      .get(hostPartitionKey, fingerprint) as ConversationProviderIdentityRow | undefined
    return row ? providerIdentityFromRow(row) : undefined
  }

  listForConversation(conversationId: string): ConversationProviderIdentity[] {
    return (
      this.database
        .prepare(
          `SELECT * FROM conversation_provider_identities
           WHERE conversation_id = ?
           ORDER BY observed_at DESC, id`
        )
        .all(conversationId) as ConversationProviderIdentityRow[]
    ).map(providerIdentityFromRow)
  }

  attach(input: AttachConversationProviderIdentityInput): ConversationProviderIdentity {
    return this.database.transaction(() => this.attachWithinTransaction(input))
  }

  attachWithinTransaction(
    input: AttachConversationProviderIdentityInput
  ): ConversationProviderIdentity {
    const conversation = requireConversationRecord(this.database, input.conversationId)
    if (conversation.agent !== input.agent) {
      throw new IssueRepositoryError(
        'conversation_identity_invalid',
        `Conversation ${conversation.id} belongs to agent ${conversation.agent}.`
      )
    }
    const providerSession = normalizeAgentProviderSession(input.providerSession)
    if (!providerSession) {
      throw new IssueRepositoryError(
        'conversation_identity_invalid',
        'Provider session identity is invalid.'
      )
    }
    const fingerprint = getConversationIdentityFingerprint({
      hostPartitionKey: conversation.hostPartitionKey,
      agent: input.agent,
      providerSession
    })
    const observedAt = input.observedAt ?? Date.now()
    const matchingRows = this.database
      .prepare(
        `SELECT * FROM conversation_provider_identities
         WHERE host_partition_key = ? AND identity_fingerprint = ?
         ORDER BY retired_at IS NULL DESC, observed_at DESC`
      )
      .all(conversation.hostPartitionKey, fingerprint) as ConversationProviderIdentityRow[]
    const foreignOwner = matchingRows.find((row) => row.conversation_id !== conversation.id)
    if (foreignOwner) {
      throw new IssueRepositoryError(
        'conversation_identity_conflict',
        `Provider identity is already owned by Conversation ${foreignOwner.conversation_id}.`
      )
    }

    const matching = matchingRows[0]
    const active = this.database
      .prepare(
        `SELECT * FROM conversation_provider_identities
         WHERE conversation_id = ? AND retired_at IS NULL`
      )
      .get(conversation.id) as ConversationProviderIdentityRow | undefined
    if (active && active.identity_fingerprint !== fingerprint) {
      this.database
        .prepare(
          `UPDATE conversation_provider_identities
           SET retired_at = MAX(observed_at, ?)
           WHERE id = ? AND retired_at IS NULL`
        )
        .run(observedAt, active.id)
    }

    if (matching) {
      this.database
        .prepare(
          `UPDATE conversation_provider_identities
           SET provider_session_key = ?, provider_session_id = ?, transcript_path = ?,
               resume_locator = ?, observed_at = MAX(observed_at, ?), retired_at = NULL
           WHERE id = ?`
        )
        .run(
          providerSession.key,
          providerSession.id,
          providerSession.transcriptPath ?? null,
          input.resumeLocator ?? matching.resume_locator,
          observedAt,
          matching.id
        )
      return this.requireById(matching.id)
    }

    const id = randomUUID()
    this.database
      .prepare(
        `INSERT INTO conversation_provider_identities (
           id, conversation_id, host_partition_key, agent, provider_session_key,
           provider_session_id, identity_fingerprint, transcript_path, resume_locator,
           observed_at, retired_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)`
      )
      .run(
        id,
        conversation.id,
        conversation.hostPartitionKey,
        input.agent,
        providerSession.key,
        providerSession.id,
        fingerprint,
        providerSession.transcriptPath ?? null,
        input.resumeLocator ?? null,
        observedAt
      )
    return this.requireById(id)
  }

  private requireById(id: string): ConversationProviderIdentity {
    const row = this.database
      .prepare('SELECT * FROM conversation_provider_identities WHERE id = ?')
      .get(id) as ConversationProviderIdentityRow | undefined
    if (!row) {
      throw new Error(`Conversation provider identity ${id} was not persisted.`)
    }
    return providerIdentityFromRow(row)
  }
}

function providerIdentityFromRow(
  row: ConversationProviderIdentityRow
): ConversationProviderIdentity {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    hostPartitionKey: row.host_partition_key,
    agent: row.agent,
    session: {
      key: row.provider_session_key,
      id: row.provider_session_id,
      ...(row.transcript_path ? { transcriptPath: row.transcript_path } : {})
    },
    identityFingerprint: row.identity_fingerprint,
    ...(row.resume_locator ? { resumeLocator: row.resume_locator } : {}),
    observedAt: row.observed_at,
    retiredAt: row.retired_at
  }
}
