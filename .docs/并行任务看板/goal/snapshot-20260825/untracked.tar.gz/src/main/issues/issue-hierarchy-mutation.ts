import type { IssueRecord } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { issueEventRef, IssueEventRepository } from './issue-event-repository'
import { assertIssueParent } from './issue-hierarchy-validation'
import { bumpIssueHostRevisions, getIssueHostRevisions } from './issue-host-state'
import { executeIssueMutation } from './issue-mutation-receipt'
import { requireIssueRecord } from './issue-record-queries'
import { IssueRepositoryError } from './issue-repository-error'
import {
  boundedIndex,
  listIssueSiblingIds,
  writeIssueSiblingScope
} from './issue-sibling-order'
import type {
  IssueMutationParams,
  ReparentIssueInput,
  ReparentIssueResult
} from './issue-repository-types'

export class IssueHierarchyMutation {
  constructor(
    private readonly database: IssueDatabase,
    private readonly events: IssueEventRepository
  ) {}

  reparent(params: IssueMutationParams<ReparentIssueInput>): ReparentIssueResult {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.reparent',
      payload: params.input,
      operation: () => this.reparentWithinTransaction(params.input)
    })
  }

  reparentWithinTransaction(input: ReparentIssueInput): ReparentIssueResult {
    const issue = requireIssueRecord(this.database, input.issueId)
    const revisions = getIssueHostRevisions(this.database, issue.hostPartitionKey)
    if (revisions.treeRevision !== input.expectedTreeRevision) {
      throw new IssueRepositoryError(
        'issue_tree_revision_stale',
        `Issue tree revision ${input.expectedTreeRevision} is stale.`,
        {
          expectedTreeRevision: input.expectedTreeRevision,
          currentTreeRevision: revisions.treeRevision,
          conflictScopes: [scopeKey(issue.parentId), scopeKey(input.parentId)]
        }
      )
    }
    if (!Number.isSafeInteger(input.index) || input.index < 0) {
      throw new IssueRepositoryError(
        'issue_delete_plan_invalid',
        'Issue sibling index must be a non-negative integer.'
      )
    }
    assertIssueParent({
      database: this.database,
      parentId: input.parentId,
      hostPartitionKey: issue.hostPartitionKey,
      executionHostId: issue.executionHostId,
      issueId: issue.id
    })

    const oldParentId = issue.parentId
    if (oldParentId === input.parentId) {
      this.reorderScope(issue, input.index)
    } else {
      const oldScope = this.listScope(issue, oldParentId).filter((id) => id !== issue.id)
      const newScope = this.listScope(issue, input.parentId)
      this.writeScope(issue, oldParentId, oldScope)
      newScope.splice(boundedIndex(input.index, newScope.length), 0, issue.id)
      this.writeScope(issue, input.parentId, newScope)
    }

    const now = Date.now()
    const nextRevisions = bumpIssueHostRevisions(
      this.database,
      issue.hostPartitionKey,
      { tree: true },
      now
    )
    const updated = requireIssueRecord(this.database, issue.id)
    this.events.appendWithinTransaction({
      hostPartitionKey: issue.hostPartitionKey,
      kind: 'reparented',
      issueRefs: [
        issueEventRef(updated, 'issue'),
        ...(input.parentId
          ? [issueEventRef(requireIssueRecord(this.database, input.parentId), 'new-parent')]
          : [])
      ],
      payload: {
        previousParentId: oldParentId,
        parentId: input.parentId,
        index: updated.siblingOrder
      },
      occurredAt: now,
      factsRevision: nextRevisions.factsRevision
    })
    return {
      issue: updated,
      affectedIssueIds: uniqueIds([
        ...this.listScope(updated, oldParentId),
        ...this.listScope(updated, input.parentId)
      ]),
      factsRevision: nextRevisions.factsRevision,
      treeRevision: nextRevisions.treeRevision
    }
  }

  reorderScopesWithinTransaction(params: {
    issue: IssueRecord
    destinations: { issueId: string; parentId: string | null; index: number }[]
  }): string[] {
    const scopes = new Set<string | null>([params.issue.parentId])
    for (const destination of params.destinations) {
      const child = requireIssueRecord(this.database, destination.issueId)
      scopes.add(child.parentId)
      scopes.add(destination.parentId)
    }
    const movedIds = new Set(params.destinations.map((destination) => destination.issueId))
    const byScope = new Map<string | null, string[]>()
    for (const scope of scopes) {
      byScope.set(
        scope,
        this.listScope(params.issue, scope).filter((id) => !movedIds.has(id))
      )
    }
    for (const destination of params.destinations) {
      const target = byScope.get(destination.parentId) ?? []
      target.splice(boundedIndex(destination.index, target.length), 0, destination.issueId)
      byScope.set(destination.parentId, target)
    }
    const affected: string[] = []
    for (const [parentId, ids] of byScope) {
      this.writeScope(params.issue, parentId, ids)
      affected.push(...ids)
    }
    return uniqueIds(affected)
  }

  private reorderScope(issue: IssueRecord, index: number): void {
    const ids = this.listScope(issue, issue.parentId).filter((id) => id !== issue.id)
    ids.splice(boundedIndex(index, ids.length), 0, issue.id)
    this.writeScope(issue, issue.parentId, ids)
  }

  private listScope(issue: IssueRecord, parentId: string | null): string[] {
    return listIssueSiblingIds({
      database: this.database,
      hostPartitionKey: issue.hostPartitionKey,
      parentId
    })
  }

  private writeScope(issue: IssueRecord, parentId: string | null, ids: readonly string[]): void {
    writeIssueSiblingScope({
      database: this.database,
      hostPartitionKey: issue.hostPartitionKey,
      parentId,
      issueIds: ids,
      now: Date.now()
    })
  }
}

function scopeKey(parentId: string | null): string {
  return parentId ?? 'root'
}

function uniqueIds(ids: readonly string[]): string[] {
  return [...new Set(ids)]
}
