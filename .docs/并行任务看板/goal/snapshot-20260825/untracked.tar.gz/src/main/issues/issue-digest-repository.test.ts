import { randomUUID } from 'node:crypto'
import { afterEach, describe, expect, it } from 'vitest'
import { ISSUE_DIGEST_GENERATION_ERROR_MAX_BYTES } from '../../shared/issues/digest-constants'
import type { IssueDigestInputSummary } from '../../shared/issues/digest-types'
import { getUtf8ByteLength } from '../../shared/utf8-byte-limits'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueDigestRepository } from './issue-digest-repository'
import { IssueRepository, issueMutationIdentity } from './issue-repository'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-issue-digest-repository-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  mutationSequence += 1
  return issueMutationIdentity('digest-repository-test', `${label}-${mutationSequence}`)
}

function createIssue(repository: IssueRepository, title: string) {
  return repository.issues.create({
    identity: identity('issue'),
    input: {
      kind: 'local',
      executionHostId: 'local',
      title
    }
  })
}

function digestInput(id: string): IssueDigestInputSummary {
  return {
    kind: 'direct-round',
    inputId: id,
    inputVersion: 1,
    titleSnapshot: 'Round',
    occurredAt: 10,
    originalBytes: 20,
    includedBytes: 20,
    completeness: 'complete',
    omissionReason: null
  }
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('IssueDigestRepository', () => {
  it('replays one generation mutation without allocating a second digest', () => {
    const repository = openRepository('generation-idempotency')
    const digests = new IssueDigestRepository(
      repository.database,
      repository.issueEvents
    )
    const issue = createIssue(repository, 'Idempotent Digest')
    const generationIdentity = issueMutationIdentity(
      'stable-digest-caller',
      'stable-generation'
    )
    const params = {
      identity: generationIdentity,
      issue,
      agent: 'codex' as const,
      coversUntil: 100,
      inputFingerprint: 'a'.repeat(64),
      coverageNote: null,
      inputs: [digestInput(randomUUID())]
    }

    const first = digests.createGenerating(params)
    const replay = digests.createGenerating(params)

    expect(first.replayed).toBe(false)
    expect(replay).toEqual({ digest: first.digest, replayed: true })
    expect(digests.listForIssue(issue.id)).toEqual([first.digest])
    expect(
      repository.database
        .prepare('SELECT COUNT(*) AS count FROM issue_digest_inputs')
        .get()
    ).toEqual({ count: 1 })
  })

  it('rejects a second in-flight generation with a domain error', () => {
    const repository = openRepository('one-generating')
    const digests = new IssueDigestRepository(
      repository.database,
      repository.issueEvents
    )
    const issue = createIssue(repository, 'Single generation')
    digests.createGenerating({
      identity: identity('first-generation'),
      issue,
      agent: 'codex',
      coversUntil: 100,
      inputFingerprint: 'b'.repeat(64),
      coverageNote: null,
      inputs: []
    })

    expect(() =>
      digests.createGenerating({
        identity: identity('second-generation'),
        issue,
        agent: 'claude',
        coversUntil: 101,
        inputFingerprint: 'c'.repeat(64),
        coverageNote: null,
        inputs: []
      })
    ).toThrowError(
      expect.objectContaining({
        code: 'digest_generation_in_progress'
      })
    )
    expect(digests.listForIssue(issue.id)).toHaveLength(1)
  })

  it('keeps cancellation authoritative over a late generation result', () => {
    const repository = openRepository('cancel-race')
    const digests = new IssueDigestRepository(
      repository.database,
      repository.issueEvents
    )
    const issue = createIssue(repository, 'Cancel race')
    const generated = digests.createGenerating({
      identity: identity('generation'),
      issue,
      agent: 'codex',
      coversUntil: 100,
      inputFingerprint: 'd'.repeat(64),
      coverageNote: null,
      inputs: []
    }).digest

    const canceled = digests.cancel({
      identity: identity('cancel'),
      digestId: generated.id
    })
    const lateResult = digests.completeGeneration(generated.id, {
      problem: 'Late problem',
      conclusion: 'Late conclusion',
      keyArtifacts: null,
      openIssues: null,
      nextSteps: null
    })

    expect(canceled).toMatchObject({
      changed: true,
      digest: { status: 'canceled' }
    })
    expect(lateResult).toMatchObject({
      status: 'canceled',
      problem: null,
      conclusion: null
    })
  })

  it('replays cancellation without exposing a second runtime side effect', () => {
    const repository = openRepository('cancel-idempotency')
    const digests = new IssueDigestRepository(
      repository.database,
      repository.issueEvents
    )
    const issue = createIssue(repository, 'Cancel once')
    const generated = digests.createGenerating({
      identity: identity('generation'),
      issue,
      agent: 'codex',
      coversUntil: 100,
      inputFingerprint: '7'.repeat(64),
      coverageNote: null,
      inputs: []
    }).digest
    const cancelIdentity = issueMutationIdentity(
      'stable-digest-caller',
      'stable-cancel'
    )
    const params = {
      identity: cancelIdentity,
      digestId: generated.id
    }

    const first = digests.cancel(params)
    const replay = digests.cancel(params)

    expect(first).toMatchObject({
      changed: true,
      replayed: false,
      digest: { id: generated.id, status: 'canceled' }
    })
    expect(replay).toEqual({
      digest: first.digest,
      changed: true,
      replayed: true
    })
  })

  it('bounds persisted generation failures by UTF-8 bytes', () => {
    const repository = openRepository('bounded-generation-error')
    const digests = new IssueDigestRepository(
      repository.database,
      repository.issueEvents
    )
    const issue = createIssue(repository, 'Bounded failure')
    const generated = digests.createGenerating({
      identity: identity('generation'),
      issue,
      agent: 'codex',
      coversUntil: 100,
      inputFingerprint: '8'.repeat(64),
      coverageNote: null,
      inputs: []
    }).digest

    const failed = digests.failGeneration(
      generated.id,
      '生成失败：'.repeat(ISSUE_DIGEST_GENERATION_ERROR_MAX_BYTES)
    )

    expect(failed.status).toBe('failed')
    expect(failed.generationError).not.toBeNull()
    expect(getUtf8ByteLength(failed.generationError ?? '')).toBeLessThanOrEqual(
      ISSUE_DIGEST_GENERATION_ERROR_MAX_BYTES
    )
  })

  it('edits one draft revision and confirms it exactly once', () => {
    const repository = openRepository('draft-confirm')
    const digests = new IssueDigestRepository(
      repository.database,
      repository.issueEvents
    )
    const issue = createIssue(repository, 'Confirm Digest')
    const generating = digests.createGenerating({
      identity: identity('generation'),
      issue,
      agent: 'claude',
      coversUntil: 100,
      inputFingerprint: 'e'.repeat(64),
      coverageNote: 'Partial source.',
      inputs: []
    }).digest
    const draft = digests.completeGeneration(generating.id, {
      problem: 'Original',
      conclusion: null,
      keyArtifacts: null,
      openIssues: null,
      nextSteps: null
    })
    const edited = digests.updateDraft({
      identity: identity('edit'),
      digestId: draft.id,
      expectedRevision: 0,
      patch: { conclusion: 'Confirmed conclusion' }
    })
    const confirmIdentity = issueMutationIdentity(
      'stable-digest-caller',
      'stable-confirm'
    )
    const confirmParams = {
      identity: confirmIdentity,
      digestId: draft.id,
      expectedRevision: 1,
      stale: false,
      currentInputFingerprint: draft.inputFingerprint
    }

    const confirmed = digests.confirm(confirmParams)
    const replay = digests.confirm(confirmParams)

    expect(edited).toMatchObject({
      revision: 1,
      conclusion: 'Confirmed conclusion'
    })
    expect(replay).toEqual(confirmed)
    expect(confirmed).toMatchObject({
      status: 'confirmed',
      revision: 1,
      confirmedAt: expect.any(Number)
    })
    expect(
      repository.issueEvents.list({ issueId: issue.id }).filter(
        (event) => event.kind === 'digest-confirmed'
      )
    ).toHaveLength(1)
  })

  it('recovers interrupted generations without changing confirmed digests', () => {
    const repository = openRepository('restart-recovery')
    const digests = new IssueDigestRepository(
      repository.database,
      repository.issueEvents
    )
    const interruptedIssue = createIssue(repository, 'Interrupted')
    const confirmedIssue = createIssue(repository, 'Already confirmed')
    const interrupted = digests.createGenerating({
      identity: identity('interrupted-generation'),
      issue: interruptedIssue,
      agent: 'codex',
      coversUntil: 100,
      inputFingerprint: 'f'.repeat(64),
      coverageNote: null,
      inputs: []
    }).digest
    const confirmedGenerating = digests.createGenerating({
      identity: identity('confirmed-generation'),
      issue: confirmedIssue,
      agent: 'claude',
      coversUntil: 100,
      inputFingerprint: '1'.repeat(64),
      coverageNote: null,
      inputs: []
    }).digest
    digests.completeGeneration(confirmedGenerating.id, {
      problem: null,
      conclusion: 'Stable',
      keyArtifacts: null,
      openIssues: null,
      nextSteps: null
    })
    digests.confirm({
      identity: identity('confirm'),
      digestId: confirmedGenerating.id,
      expectedRevision: 0,
      stale: false,
      currentInputFingerprint: confirmedGenerating.inputFingerprint
    })

    expect(digests.recoverInterrupted()).toEqual([interrupted.id])
    expect(digests.require(interrupted.id)).toMatchObject({
      status: 'failed',
      generationError: 'runtime-restarted'
    })
    expect(digests.require(confirmedGenerating.id)).toMatchObject({
      status: 'confirmed',
      conclusion: 'Stable'
    })
  })

  it('recovers interrupted generations when the repository opens', () => {
    const userDataPath = createIssueTestUserDataPath(
      'orca-issue-digest-open-recovery'
    )
    const first = new IssueRepository(
      openIssueTestDatabase({
        profileId: 'open-recovery',
        userDataPath
      })
    )
    repositories.push(first)
    const issue = createIssue(first, 'Interrupted before restart')
    const interrupted = new IssueDigestRepository(
      first.database,
      first.issueEvents
    ).createGenerating({
      identity: identity('generation'),
      issue,
      agent: 'claude',
      coversUntil: 100,
      inputFingerprint: '9'.repeat(64),
      coverageNote: null,
      inputs: []
    }).digest
    first.close()
    repositories.splice(repositories.indexOf(first), 1)

    const reopened = new IssueRepository(
      openIssueTestDatabase({
        profileId: 'open-recovery',
        userDataPath
      })
    )
    repositories.push(reopened)
    const recovered = new IssueDigestRepository(
      reopened.database,
      reopened.issueEvents
    ).require(interrupted.id)

    expect(recovered).toMatchObject({
      status: 'failed',
      generationError: 'runtime-restarted'
    })
  })
})
