import type {
  DashboardAckAgentArgs,
  DashboardCard,
  DashboardCardIssueContext
} from '../../../shared/dashboard-snapshot'
import type { ExecutionHostId } from '../../../shared/execution-host'
import type { IssueMutationResult } from '../../../shared/issues/types'
import { createBrowserUuid } from '../lib/browser-uuid'
import { useAppStore } from '../store'
import { markIssueRoundsRead } from './issue-mutations'
import { issueDashboardStore } from './issue-dashboard-store'

export type IssueDashboardAckTarget = DashboardAckAgentArgs & {
  issueContext?: DashboardCardIssueContext
}

export type IssueDashboardAckDependencies = {
  markRead: (input: {
    executionHostId: ExecutionHostId
    mutationId: string
    roundRecordIds: string[]
    readAt: number
  }) => Promise<IssueMutationResult | void>
  patchRead: (
    routeExecutionHostId: ExecutionHostId,
    roundRecordId: string,
    readAt: number
  ) => void
  ackPane: (paneKey: string) => void
  createMutationId: () => string
  now: () => number
}

export function createIssueDashboardAcknowledger(
  dependencies: IssueDashboardAckDependencies
): (target: IssueDashboardAckTarget) => Promise<void> {
  const pending = new Map<string, Promise<void>>()
  return async (target) => {
    const context = target.issueContext
    if (
      !context ||
      context.status === 'unsupported' ||
      context.status === 'unmapped'
    ) {
      dependencies.ackPane(target.paneKey)
      return
    }
    if (
      context.status !== 'mapped' ||
      !context.latestRound ||
      context.latestRound.readAt !== null
    ) {
      return
    }
    const roundRecordId = context.latestRound.id
    const routeExecutionHostId = context.authority.routeExecutionHostId
    const key = `${routeExecutionHostId}\0${roundRecordId}`
    const active = pending.get(key)
    if (active) {
      await active
      return
    }
    const readAt = dependencies.now()
    const promise = dependencies
      .markRead({
        executionHostId: routeExecutionHostId,
        mutationId: dependencies.createMutationId(),
        roundRecordIds: [roundRecordId],
        readAt
      })
      .then(() => {
        dependencies.patchRead(
          routeExecutionHostId,
          roundRecordId,
          readAt
        )
      })
      .finally(() => {
        pending.delete(key)
      })
    pending.set(key, promise)
    await promise
  }
}

const acknowledge = createIssueDashboardAcknowledger({
  markRead: markIssueRoundsRead,
  patchRead: (routeExecutionHostId, roundRecordId, readAt) =>
    issueDashboardStore
      .getState()
      .patchRoundRead(routeExecutionHostId, roundRecordId, readAt),
  ackPane: (paneKey) => useAppStore.getState().acknowledgeAgents([paneKey]),
  createMutationId: createBrowserUuid,
  now: () => Date.now()
})

export function issueDashboardAckTargetForCard(
  card: DashboardCard
): IssueDashboardAckTarget {
  return {
    paneKey: card.paneKey,
    ...(card.executionHostId
      ? { executionHostId: card.executionHostId }
      : {}),
    ...(card.issueContext ? { issueContext: card.issueContext } : {})
  }
}

export function issueDashboardAckTargetForArgs(
  args: DashboardAckAgentArgs
): IssueDashboardAckTarget {
  if (!args.executionHostId) {
    return args
  }
  const partition =
    issueDashboardStore.getState().partitionsByRoute[args.executionHostId]
  const pane = partition?.projection?.panes.find(
    (candidate) => candidate.paneKey === args.paneKey
  )
  if (!partition || partition.status === 'idle' || partition.status === 'loading') {
    return { ...args, issueContext: { status: 'unavailable' } }
  }
  if (partition.status === 'unsupported') {
    return { ...args, issueContext: { status: 'unsupported' } }
  }
  if (partition.status !== 'ready' || !partition.projection) {
    return { ...args, issueContext: { status: 'unavailable' } }
  }
  if (!pane) {
    return { ...args, issueContext: { status: 'unmapped' } }
  }
  return {
    ...args,
    issueContext: {
      status: 'mapped',
      authority: partition.projection.authority,
      conversationId: pane.conversationId,
      issue: pane.issue,
      latestRound: pane.latestRound
        ? { id: pane.latestRound.id, readAt: pane.latestRound.readAt }
        : null
    }
  }
}

export function acknowledgeIssueDashboardCard(
  target: IssueDashboardAckTarget
): Promise<void> {
  return acknowledge(target)
}
