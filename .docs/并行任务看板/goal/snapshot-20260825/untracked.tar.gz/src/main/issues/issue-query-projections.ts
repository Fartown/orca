import type {
  AuthorityHostPartitionKey,
  ConversationNavigationHint,
  ConversationNavigationTarget,
  ConversationRecord,
  ConversationSummary,
  IssueRecord,
  RoundRecord,
  RoundRecordPreview,
  UnassignedConversationSummary
} from '../../shared/issues/types'
import { getUtf8ByteLengthForCodePoint, readUtf8CodePointAt } from '../../shared/utf8-byte-limits'
import type { IssueAuthorityRoute } from './issue-authority-route'
import type { IssueDatabase } from './issue-database'
import type { IssueHostRevisions } from './issue-host-state'
import { conversationFromRow, roundRecordFromRow } from './issue-row-mappers'
import type { ConversationRow, RoundRecordRow } from './issue-row-mappers'
import { IssueRepositoryError } from './issue-repository-error'

type IssueSummaryCounts = {
  ownUnresolvedCount: number
  directConversationCount: number
  activeConversationCount: number
}

type ConversationNavigationRow = {
  pane_key: string | null
  provider_session_key: 'session_id' | 'conversation_id' | null
  provider_session_id: string | null
  transcript_path: string | null
  resume_locator: string | null
}

export function readHostRevisions(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): IssueHostRevisions {
  return (
    (database
      .prepare(
        `SELECT
           facts_revision AS factsRevision,
           tree_revision AS treeRevision,
           search_revision AS searchRevision,
           indexed_search_revision AS indexedSearchRevision
         FROM issue_host_state
         WHERE host_partition_key = ?`
      )
      .get(hostPartitionKey) as IssueHostRevisions | undefined) ?? {
      factsRevision: 0,
      treeRevision: 0,
      searchRevision: 0,
      indexedSearchRevision: 0
    }
  )
}

export function readIssueSummaryCounts(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): Map<string, IssueSummaryCounts> {
  const rows = database
    .prepare(
      `SELECT
         conversation.issue_id AS issueId,
         COUNT(DISTINCT conversation.id) AS directConversationCount,
         COUNT(DISTINCT CASE WHEN conversation.state = 'active' THEN conversation.id END)
           AS activeConversationCount,
         COALESCE(SUM(
           CASE WHEN round.effective_resolved_at IS NULL AND round.id IS NOT NULL
             THEN 1 ELSE 0 END
         ), 0) AS ownUnresolvedCount
       FROM conversations conversation
       LEFT JOIN round_record_effective_state round
         ON round.conversation_id = conversation.id
       WHERE conversation.host_partition_key = ?
         AND conversation.issue_id IS NOT NULL
       GROUP BY conversation.issue_id`
    )
    .all(hostPartitionKey) as Array<IssueSummaryCounts & { issueId: string }>
  return new Map(rows.map(({ issueId, ...counts }) => [issueId, counts]))
}

export function readConversationSummaries(
  database: IssueDatabase,
  route: IssueAuthorityRoute,
  where: string,
  bindings: readonly (string | number | null)[]
): ConversationSummary[] {
  const rows = database
    .prepare(
      `SELECT conversation.*
       FROM conversations conversation
       ${where}
       ORDER BY conversation.updated_at DESC, conversation.id DESC`
    )
    .all(...bindings) as ConversationRow[]
  return rows.map((row) => {
    const conversation = conversationFromRow(row)
    const rounds = database
      .prepare(
        `SELECT *
         FROM round_record_effective_state
         WHERE conversation_id = ?
         ORDER BY occurred_at DESC, id DESC`
      )
      .all(conversation.id) as RoundRecordRow[]
    return {
      ...conversation,
      executionHostId: route.routeExecutionHostId,
      unresolvedRoundCount: rounds.reduce(
        (count, round) => count + (round.effective_resolved_at === null ? 1 : 0),
        0
      ),
      latestRound: rounds[0] ? toRoundRecordPreview(roundRecordFromRow(rounds[0])) : null,
      ...readConversationNavigation(database, conversation.id)
    }
  })
}

export function readConversationNavigation(
  database: IssueDatabase,
  conversationId: string
): { navigation?: ConversationNavigationHint } {
  const row = database
    .prepare(
      `SELECT
         (
           SELECT claim.pane_key
           FROM conversation_launch_claims claim
           WHERE claim.conversation_id = conversation.id
             AND claim.pane_key IS NOT NULL
           ORDER BY claim.created_at DESC, claim.claim_id DESC
           LIMIT 1
         ) AS pane_key,
         identity.provider_session_key,
         identity.provider_session_id,
         identity.transcript_path,
         identity.resume_locator
       FROM conversations conversation
       LEFT JOIN conversation_provider_identities identity
         ON identity.conversation_id = conversation.id
        AND identity.retired_at IS NULL
       WHERE conversation.id = ?`
    )
    .get(conversationId) as ConversationNavigationRow | undefined
  if (!row || (!row.pane_key && !row.provider_session_id)) {
    return {}
  }
  const providerSession =
    row.provider_session_key && row.provider_session_id
      ? {
          key: row.provider_session_key,
          id: row.provider_session_id,
          ...(row.transcript_path ? { transcriptPath: row.transcript_path } : {})
        }
      : null
  return {
    navigation: {
      paneKey: row.pane_key,
      providerSession,
      resumeLocator: row.resume_locator
    }
  }
}

export function readConversationNavigationTargets(
  database: IssueDatabase,
  route: IssueAuthorityRoute,
  conversationIds: readonly string[]
): Map<string, ConversationNavigationTarget> {
  const uniqueIds = [...new Set(conversationIds)]
  if (uniqueIds.length === 0) {
    return new Map()
  }
  const placeholders = uniqueIds.map(() => '?').join(', ')
  const rows = database
    .prepare(`SELECT * FROM conversations WHERE id IN (${placeholders})`)
    .all(...uniqueIds) as ConversationRow[]
  return new Map(
    rows.map((row) => {
      const conversation = conversationFromRow(row)
      return [
        conversation.id,
        {
          ...conversation,
          executionHostId: route.routeExecutionHostId,
          ...readConversationNavigation(database, conversation.id)
        }
      ]
    })
  )
}

export function readUnassignedSummary(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): UnassignedConversationSummary {
  return database
    .prepare(
      `SELECT
         COUNT(DISTINCT conversation.id) AS conversationCount,
         COALESCE(SUM(
           CASE WHEN round.effective_resolved_at IS NULL AND round.id IS NOT NULL
             THEN 1 ELSE 0 END
         ), 0) AS unresolvedCount
       FROM conversations conversation
       LEFT JOIN round_record_effective_state round
         ON round.conversation_id = conversation.id
       WHERE conversation.host_partition_key = ?
         AND conversation.issue_id IS NULL`
    )
    .get(hostPartitionKey) as UnassignedConversationSummary
}

export function toRoundRecordPreview(round: RoundRecord): RoundRecordPreview {
  const { dedupeKey: _dedupeKey, userInput, agentOutput, pendingQuestion, ...metadata } = round
  return {
    ...metadata,
    userInput: withoutRoundText(userInput),
    agentOutput: withoutRoundText(agentOutput),
    pendingQuestion: withoutRoundText(pendingQuestion)
  }
}

export function uniqueWorkspaceSnapshots(
  conversations: readonly ConversationRecord[]
): ConversationRecord['workspaceSnapshot'][] {
  const snapshots = new Map<string, ConversationRecord['workspaceSnapshot']>()
  for (const conversation of conversations) {
    snapshots.set(JSON.stringify(conversation.workspaceSnapshot), conversation.workspaceSnapshot)
  }
  return [...snapshots.values()].sort(
    (left, right) => left.name.localeCompare(right.name) || left.path.localeCompare(right.path)
  )
}

export function compareIssueSummaryOrder(left: IssueRecord, right: IssueRecord): number {
  return left.siblingOrder - right.siblingOrder || left.id.localeCompare(right.id)
}

export function utf8IndexAtByteOffset(text: string, byteOffset: number): number {
  let bytes = 0
  let index = 0
  while (index < text.length && bytes < byteOffset) {
    const codePoint = readUtf8CodePointAt(text, index)
    bytes += getUtf8ByteLengthForCodePoint(codePoint)
    index += codePoint > 0xffff ? 2 : 1
  }
  if (bytes !== byteOffset) {
    throw new IssueRepositoryError(
      'issue_body_offset_invalid',
      'Round body offset is not on a UTF-8 code point boundary.'
    )
  }
  return index
}

export function getRoundForRoute(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey,
  roundRecordId: string
): RoundRecord {
  const row = database
    .prepare(
      `SELECT round.*
       FROM round_record_effective_state round
       JOIN conversations conversation ON conversation.id = round.conversation_id
       WHERE round.id = ? AND conversation.host_partition_key = ?`
    )
    .get(roundRecordId, hostPartitionKey) as RoundRecordRow | undefined
  if (!row) {
    throw new IssueRepositoryError(
      'round_not_found',
      `Round Record ${roundRecordId} was not found.`
    )
  }
  return roundRecordFromRow(row)
}

function withoutRoundText(value: RoundRecord['userInput']): Omit<RoundRecord['userInput'], 'text'> {
  const { text: _text, ...summary } = value
  return summary
}
