import {
  ROUND_TEXT_PREVIEW_MAX_BYTES,
  type ROUND_AGENT_OUTPUT_MAX_BYTES,
  type ROUND_PENDING_QUESTION_MAX_BYTES,
  type ROUND_USER_INPUT_MAX_BYTES
} from '../../shared/issues/constants'
import type { RoundRecordText } from '../../shared/issues/types'
import {
  clampUtf8TextPrefix,
  clampUtf8TextTail,
  getUtf8ByteLength
} from '../../shared/utf8-byte-limits'
import { IssueRepositoryError } from './issue-repository-error'
import type { RoundTextInput } from './issue-repository-types'

type RoundTextLimit =
  | typeof ROUND_USER_INPUT_MAX_BYTES
  | typeof ROUND_AGENT_OUTPUT_MAX_BYTES
  | typeof ROUND_PENDING_QUESTION_MAX_BYTES

export function normalizeRoundRecordText(
  input: RoundTextInput | undefined,
  maxBytes: RoundTextLimit,
  label: string
): RoundRecordText {
  const sourceText = input?.text ?? null
  const normalizedText = truncateRoundText(sourceText, maxBytes)
  const text = normalizedText.text
  const textBytes = normalizedText.bytes

  const defaultPreview =
    text === null ? null : clampUtf8TextPrefix(text, ROUND_TEXT_PREVIEW_MAX_BYTES)
  const previewSource = input?.preview ?? defaultPreview
  const preview =
    previewSource === null
      ? null
      : clampUtf8TextPrefix(previewSource, ROUND_TEXT_PREVIEW_MAX_BYTES)
  const previewBytes = preview === null ? 0 : getUtf8ByteLength(preview)

  const storage = input?.storage ?? (text !== null ? 'full' : preview !== null ? 'preview' : 'none')
  const completeness =
    normalizedText.truncated
      ? 'truncated'
      : (input?.completeness ??
        (text !== null ? 'complete' : preview !== null ? 'preview-complete' : 'not-captured'))
  assertTextStorage(storage, text, preview, label)
  return {
    text,
    completeness,
    storage,
    bytes: textBytes,
    preview,
    previewBytes
  }
}

export function retainedRoundTextBytes(text: RoundRecordText): number {
  return text.bytes + text.previewBytes
}

export function evictRoundRecordTextToPreview(text: RoundRecordText): RoundRecordText {
  if (text.storage === 'deleted' || text.storage === 'evicted' || text.storage === 'none') {
    return text
  }
  if (text.text === null) {
    return text
  }
  return {
    ...text,
    text: null,
    bytes: 0,
    storage: text.preview === null ? 'evicted' : 'evicted-preview'
  }
}

export function evictRoundRecordTextCompletely(text: RoundRecordText): RoundRecordText {
  if (text.storage === 'deleted' || text.storage === 'evicted' || text.storage === 'none') {
    return text
  }
  return {
    ...text,
    text: null,
    bytes: 0,
    preview: null,
    previewBytes: 0,
    storage: 'evicted'
  }
}

export function deleteRoundRecordText(text: RoundRecordText): RoundRecordText {
  return {
    ...text,
    text: null,
    bytes: 0,
    preview: null,
    previewBytes: 0,
    storage: 'deleted'
  }
}

export function isRoundRecordTextTombstoned(text: RoundRecordText): boolean {
  return (
    text.storage === 'deleted' ||
    text.storage === 'evicted' ||
    text.storage === 'evicted-preview'
  )
}

export function preferMoreCompleteRoundRecordText(
  current: RoundRecordText,
  incoming: RoundRecordText
): RoundRecordText {
  if (isRoundRecordTextTombstoned(current)) {
    return current
  }
  const currentRank = completenessRank(current.completeness)
  const incomingRank = completenessRank(incoming.completeness)
  if (incomingRank < currentRank) {
    return current
  }
  if (incomingRank === currentRank && retainedRoundTextBytes(incoming) <= retainedRoundTextBytes(current)) {
    return current
  }
  return incoming
}

export function fitRoundRecordTextWithinBytes(
  text: RoundRecordText,
  maxRetainedBytes: number
): RoundRecordText {
  if (retainedRoundTextBytes(text) <= maxRetainedBytes) {
    return text
  }
  const previewOnly = evictRoundRecordTextToPreview(text)
  if (retainedRoundTextBytes(previewOnly) <= maxRetainedBytes) {
    return previewOnly
  }
  if (maxRetainedBytes <= 0 || previewOnly.preview === null) {
    return evictRoundRecordTextCompletely(previewOnly)
  }
  const preview = clampUtf8TextPrefix(previewOnly.preview, maxRetainedBytes)
  return {
    ...previewOnly,
    preview: preview || null,
    previewBytes: getUtf8ByteLength(preview),
    storage: preview ? 'evicted-preview' : 'evicted'
  }
}

function truncateRoundText(
  text: string | null,
  maxBytes: number
): { text: string | null; bytes: number; truncated: boolean } {
  if (text === null) {
    return { text: null, bytes: 0, truncated: false }
  }
  const bytes = getUtf8ByteLength(text)
  if (bytes <= maxBytes) {
    return { text, bytes, truncated: false }
  }
  const prefixBytes = Math.floor(maxBytes / 2)
  const prefix = clampUtf8TextPrefix(text, prefixBytes)
  const prefixLength = getUtf8ByteLength(prefix)
  const tail = clampUtf8TextTail(text, maxBytes - prefixLength)
  const truncated = `${prefix}${tail.text}`
  return { text: truncated, bytes: prefixLength + tail.bytes, truncated: true }
}

function completenessRank(completeness: RoundRecordText['completeness']): number {
  switch (completeness) {
    case 'not-captured':
      return 0
    case 'preview-complete':
      return 1
    case 'truncated':
      return 2
    case 'complete':
      return 3
  }
}

function assertTextStorage(
  storage: RoundRecordText['storage'],
  text: string | null,
  preview: string | null,
  label: string
): void {
  const hasBody = text !== null || preview !== null
  if (storage === 'none' && hasBody) {
    throw new IssueRepositoryError('round_text_invalid', `${label} has body data with no storage.`)
  }
  if (storage === 'full' && text === null) {
    throw new IssueRepositoryError('round_text_invalid', `${label} full storage has no text.`)
  }
  if (storage === 'preview' && preview === null) {
    throw new IssueRepositoryError('round_text_invalid', `${label} preview storage has no preview.`)
  }
  if (storage === 'evicted-preview' && (text !== null || preview === null)) {
    throw new IssueRepositoryError(
      'round_text_invalid',
      `${label} evicted-preview storage must retain only a preview.`
    )
  }
  if ((storage === 'evicted' || storage === 'deleted') && hasBody) {
    throw new IssueRepositoryError(
      'round_text_invalid',
      `${label} ${storage} storage cannot retain body data.`
    )
  }
}
