import React, { useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import type { ExecutionHostId } from '../../../../../shared/execution-host'
import type { IssueMutationResult } from '../../../../../shared/issues/types'
import type { IssueAuthorityDescriptor } from '../../../../../shared/issues/types'
import { createLocalIssue } from '../../../issues/issue-mutations'
import type { SidebarHostOption } from '../sidebar-host-options'

type CreateLocalIssueDialogProps = {
  open: boolean
  hostOptions: readonly SidebarHostOption[]
  defaultExecutionHostId?: ExecutionHostId | null
  onOpenChange: (open: boolean) => void
  onCreated: (
    authority: IssueAuthorityDescriptor,
    issueId: string
  ) => void
  createIssue?: typeof createLocalIssue
}

export default function CreateLocalIssueDialog({
  open,
  hostOptions,
  defaultExecutionHostId,
  onOpenChange,
  onCreated,
  createIssue = createLocalIssue
}: CreateLocalIssueDialogProps): React.JSX.Element {
  const [executionHostId, setExecutionHostId] =
    useState<ExecutionHostId>('local')
  const [title, setTitle] = useState('')
  const [typeLabel, setTypeLabel] = useState('')
  const [note, setNote] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const mutationIdRef = useRef<string | null>(null)

  useEffect(() => {
    if (!open) {
      return
    }
    const preferred =
      defaultExecutionHostId &&
      hostOptions.some((host) => host.id === defaultExecutionHostId)
        ? defaultExecutionHostId
        : hostOptions[0]?.id ?? 'local'
    setExecutionHostId(preferred)
    setTitle('')
    setTypeLabel('')
    setNote('')
    setSubmitting(false)
    setError(null)
    mutationIdRef.current = null
  }, [defaultExecutionHostId, hostOptions, open])

  const resetMutation = (): void => {
    mutationIdRef.current = null
    setError(null)
  }

  const submit = async (event: React.FormEvent): Promise<void> => {
    event.preventDefault()
    if (submitting || !title.trim()) {
      return
    }
    const mutationId = mutationIdRef.current ?? crypto.randomUUID()
    mutationIdRef.current = mutationId
    setSubmitting(true)
    setError(null)
    try {
      const result: IssueMutationResult = await createIssue({
        executionHostId,
        mutationId,
        title,
        typeLabel: typeLabel.trim() || null,
        note: note.trim() || null
      })
      const issueId = result.affectedIssueIds[0]
      if (!issueId) {
        throw new Error('Issue creation returned no Issue id.')
      }
      mutationIdRef.current = null
      onCreated(result.authority, issueId)
      onOpenChange(false)
    } catch (cause) {
      setError(
        cause instanceof Error && cause.message.trim()
          ? cause.message
          : 'Unable to create Issue.'
      )
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <form className="grid gap-4" onSubmit={(event) => void submit(event)}>
          <DialogHeader>
            <DialogTitle>New Issue</DialogTitle>
            <DialogDescription>
              Create a local Issue on the host that owns its Conversations.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-2">
            <Label htmlFor="new-issue-title">Title</Label>
            <Input
              id="new-issue-title"
              autoFocus
              maxLength={512}
              value={title}
              onChange={(event) => {
                setTitle(event.target.value)
                resetMutation()
              }}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="new-issue-host">Execution host</Label>
            <Select
              value={executionHostId}
              onValueChange={(value) => {
                setExecutionHostId(value as ExecutionHostId)
                resetMutation()
              }}
            >
              <SelectTrigger id="new-issue-host" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent align="start">
                {hostOptions.map((host) => (
                  <SelectItem key={host.id} value={host.id}>
                    {host.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="new-issue-type">Type</Label>
            <Input
              id="new-issue-type"
              maxLength={128}
              placeholder="Optional"
              value={typeLabel}
              onChange={(event) => {
                setTypeLabel(event.target.value)
                resetMutation()
              }}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="new-issue-note">Note</Label>
            <Textarea
              id="new-issue-note"
              maxLength={32_768}
              placeholder="Optional"
              value={note}
              onChange={(event) => {
                setNote(event.target.value)
                resetMutation()
              }}
            />
          </div>
          {error ? (
            <p role="alert" className="text-xs text-destructive">
              {error}
            </p>
          ) : null}
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              disabled={submitting}
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={submitting || !title.trim()}>
              {submitting ? 'Creating…' : 'Create Issue'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
