import {
  parseExecutionHostId,
  type ExecutionHostId
} from '../../../shared/execution-host'
import {
  ConversationBindingMutationResultSchema,
  IssueArchiveMutationResultSchema,
  IssueDeletePreparationResultSchema,
  IssueMutationResultSchema,
  IssuesCreateParams,
  IssuesDeleteParams,
  IssuesLifecycleParams,
  IssuesMarkReadParams,
  IssuesPrepareDeleteParams,
  IssuesReparentParams,
  IssuesResolveRoundParams,
  IssuesUpdateParams
} from '../../../shared/issues/schemas'
import type {
  ConversationBindingMutationResult,
  DeleteIssuePlan,
  IssueArchiveMutationResult,
  IssueDeletePreparationResult,
  IssueMutationResult
} from '../../../shared/issues/types'
import { ORCA_ISSUES_RUNTIME_CAPABILITY } from '../../../shared/protocol-version'
import {
  callRuntimeRpc,
  runtimeEnvironmentSupportsCapability,
  type RuntimeClientTarget
} from '../runtime/runtime-rpc-client'

export type IssueMutationDependencies = {
  supportsCapability: (environmentId: string) => Promise<boolean>
  callRpc: (
    routeExecutionHostId: ExecutionHostId,
    method: string,
    params: unknown
  ) => Promise<unknown>
}

type MutationEnvelope = {
  executionHostId: ExecutionHostId
  mutationId: string
}

export async function createLocalIssue(
  input: MutationEnvelope & {
    title: string
    parentId?: string | null
    index?: number
    typeLabel?: string | null
    note?: string | null
  },
  dependencies: IssueMutationDependencies = defaultDependencies
): Promise<IssueMutationResult> {
  const params = IssuesCreateParams.parse({
    executionHostId: input.executionHostId,
    mutationId: input.mutationId,
    source: { kind: 'local', title: input.title },
    parentId: input.parentId,
    index: input.index,
    typeLabel: input.typeLabel,
    note: input.note
  })
  return mutate(
    input.executionHostId,
    'issues.create',
    params,
    IssueMutationResultSchema.parse,
    dependencies
  )
}

export async function updateIssue(
  input: MutationEnvelope & {
    issueId: string
    localTitle?: string | null
    typeLabel?: string | null
    note?: string | null
  },
  dependencies: IssueMutationDependencies = defaultDependencies
): Promise<IssueMutationResult> {
  const params = IssuesUpdateParams.parse(input)
  return mutate(
    input.executionHostId,
    'issues.update',
    params,
    IssueMutationResultSchema.parse,
    dependencies
  )
}

export async function setIssueArchived(
  input: MutationEnvelope & {
    issueId: string
    archived: boolean
    expectedFactsRevision?: number
  },
  dependencies: IssueMutationDependencies = defaultDependencies
): Promise<IssueArchiveMutationResult | IssueMutationResult> {
  const params = IssuesLifecycleParams.parse(input)
  if (input.archived) {
    return mutate(
      input.executionHostId,
      'issues.archive',
      params,
      IssueArchiveMutationResultSchema.parse,
      dependencies
    )
  }
  return mutate(
    input.executionHostId,
    'issues.reopen',
    params,
    IssueMutationResultSchema.parse,
    dependencies
  )
}

export async function reparentIssue(
  input: MutationEnvelope & {
    issueId: string
    parentId: string | null
    index: number
    expectedTreeRevision: number
  },
  dependencies: IssueMutationDependencies = defaultDependencies
): Promise<IssueMutationResult> {
  const params = IssuesReparentParams.parse(input)
  return mutate(
    input.executionHostId,
    'issues.reparent',
    params,
    IssueMutationResultSchema.parse,
    dependencies
  )
}

export async function prepareIssueDelete(
  input: { executionHostId: ExecutionHostId; issueId: string },
  dependencies: IssueMutationDependencies = defaultDependencies
): Promise<IssueDeletePreparationResult> {
  const params = IssuesPrepareDeleteParams.parse(input)
  return mutate(
    input.executionHostId,
    'issues.prepareDelete',
    params,
    IssueDeletePreparationResultSchema.parse,
    dependencies
  )
}

export async function deleteIssue(
  input: MutationEnvelope & { plan: DeleteIssuePlan },
  dependencies: IssueMutationDependencies = defaultDependencies
): Promise<IssueMutationResult> {
  const params = IssuesDeleteParams.parse(input)
  return mutate(
    input.executionHostId,
    'issues.delete',
    params,
    IssueMutationResultSchema.parse,
    dependencies
  )
}

export async function bindConversationToIssue(
  input: MutationEnvelope & {
    conversationId: string
    issueId: string | null
    expectedFactsRevision: number
  },
  dependencies: IssueMutationDependencies = defaultDependencies
): Promise<ConversationBindingMutationResult> {
  const params = {
    executionHostId: input.executionHostId,
    mutationId: input.mutationId,
    conversationId: input.conversationId,
    issueId: input.issueId,
    expectedFactsRevision: input.expectedFactsRevision
  }
  return mutate(
    input.executionHostId,
    'conversations.bindIssue',
    params,
    ConversationBindingMutationResultSchema.parse,
    dependencies
  )
}

export async function markIssueRoundsRead(
  input: MutationEnvelope & {
    roundRecordIds: string[]
    readAt: number
  },
  dependencies: IssueMutationDependencies = defaultDependencies
): Promise<IssueMutationResult> {
  const params = IssuesMarkReadParams.parse(input)
  return mutate(
    input.executionHostId,
    'issues.markRead',
    params,
    IssueMutationResultSchema.parse,
    dependencies
  )
}

export async function resolveIssueRound(
  input: MutationEnvelope & {
    roundRecordId: string
    resolvedAt: number
  },
  dependencies: IssueMutationDependencies = defaultDependencies
): Promise<IssueMutationResult> {
  const params = IssuesResolveRoundParams.parse(input)
  return mutate(
    input.executionHostId,
    'issues.resolveRound',
    params,
    IssueMutationResultSchema.parse,
    dependencies
  )
}

async function mutate<T>(
  routeExecutionHostId: ExecutionHostId,
  method: string,
  params: unknown,
  parse: (value: unknown) => T,
  dependencies: IssueMutationDependencies
): Promise<T> {
  const route = parseExecutionHostId(routeExecutionHostId)
  if (!route) {
    throw new Error('Invalid Issue host route.')
  }
  if (
    route.kind === 'runtime' &&
    !(await dependencies.supportsCapability(route.environmentId))
  ) {
    throw new Error('This Orca runtime does not support Issues.')
  }
  const result = parse(
    await dependencies.callRpc(route.id, method, params)
  )
  assertResultRoute(result, route.id)
  return result
}

function assertResultRoute(
  result: unknown,
  routeExecutionHostId: ExecutionHostId
): void {
  const authority =
    typeof result === 'object' && result !== null && 'authority' in result
      ? result.authority
      : typeof result === 'object' &&
          result !== null &&
          'mutation' in result &&
          typeof result.mutation === 'object' &&
          result.mutation !== null &&
          'authority' in result.mutation
        ? result.mutation.authority
        : null
  if (
    typeof authority !== 'object' ||
    authority === null ||
    !('routeExecutionHostId' in authority) ||
    authority.routeExecutionHostId !== routeExecutionHostId
  ) {
    throw new Error('Issue mutation response was stamped for another route.')
  }
}

function runtimeTargetForRoute(
  routeExecutionHostId: ExecutionHostId
): RuntimeClientTarget {
  const route = parseExecutionHostId(routeExecutionHostId)
  return route?.kind === 'runtime'
    ? { kind: 'environment', environmentId: route.environmentId }
    : { kind: 'local' }
}

const defaultDependencies: IssueMutationDependencies = {
  supportsCapability: (environmentId) =>
    runtimeEnvironmentSupportsCapability(
      environmentId,
      ORCA_ISSUES_RUNTIME_CAPABILITY
    ),
  callRpc: (routeExecutionHostId, method, params) =>
    callRuntimeRpc(
      runtimeTargetForRoute(routeExecutionHostId),
      method,
      params,
      { reuseRecentCompatibilityFailure: true }
    )
}
