import type { ExecutionHostId } from '../../../shared/execution-host'
import type { IssueSearchResult } from '../../../shared/issues/types'
import type { StoreApi } from 'zustand/vanilla'
import type { IssueClientLoadResult } from './issue-client-data'

export type IssueSearchLoadState =
  | {
      status: 'idle'
      query: string
      result: null
      error: null
    }
  | {
      status: 'loading'
      query: string
      result: IssueSearchResult | null
      error: null
    }
  | {
      status: 'ready'
      query: string
      result: IssueSearchResult
      error: null
    }
  | {
      status: 'unsupported'
      query: string
      result: null
      error: null
    }
  | {
      status: 'error'
      query: string
      result: IssueSearchResult | null
      error: string
    }

export type IssueSearchDomainFields = {
  searchLoadsByRoute: Partial<Record<ExecutionHostId, IssueSearchLoadState>>
}

export type IssueSearchDomainActions = {
  search: (
    routeExecutionHostId: ExecutionHostId,
    query: string
  ) => Promise<void>
  clearSearch: (routeExecutionHostId?: ExecutionHostId) => void
}

export type IssueSearchDomainDependencies = {
  searchIssues: (
    routeExecutionHostId: ExecutionHostId,
    query: string
  ) => Promise<IssueClientLoadResult<IssueSearchResult>>
}

export function createIssueSearchDomain<
  State extends IssueSearchDomainFields
>(
  dependencies: IssueSearchDomainDependencies,
  set: StoreApi<State>['setState'],
  get: StoreApi<State>['getState']
): IssueSearchDomainActions {
  const generations = new Map<ExecutionHostId, number>()
  return {
    search: async (routeExecutionHostId, rawQuery) => {
      const query = rawQuery.trim()
      if (!query) {
        clearRouteSearch(set, routeExecutionHostId)
        return
      }
      const generation = (generations.get(routeExecutionHostId) ?? 0) + 1
      generations.set(routeExecutionHostId, generation)
      const previous = get().searchLoadsByRoute[routeExecutionHostId]
      setSearchState(set, routeExecutionHostId, {
        status: 'loading',
        query,
        result: previous?.query === query ? previous.result : null,
        error: null
      })
      const result = await dependencies.searchIssues(
        routeExecutionHostId,
        query
      )
      if (generations.get(routeExecutionHostId) !== generation) {
        return
      }
      setSearchState(
        set,
        routeExecutionHostId,
        searchStateFromLoad(query, result)
      )
    },
    clearSearch: (routeExecutionHostId) => {
      if (routeExecutionHostId) {
        generations.set(
          routeExecutionHostId,
          (generations.get(routeExecutionHostId) ?? 0) + 1
        )
        clearRouteSearch(set, routeExecutionHostId)
        return
      }
      for (const route of Object.keys(
        get().searchLoadsByRoute
      ) as ExecutionHostId[]) {
        generations.set(route, (generations.get(route) ?? 0) + 1)
      }
      set({ searchLoadsByRoute: {} } as Partial<State>)
    }
  }
}

function searchStateFromLoad(
  query: string,
  result: IssueClientLoadResult<IssueSearchResult>
): IssueSearchLoadState {
  switch (result.status) {
    case 'ready':
    case 'cached':
      return {
        status: 'ready',
        query,
        result: result.value,
        error: null
      }
    case 'unsupported':
      return {
        status: 'unsupported',
        query,
        result: null,
        error: null
      }
    case 'error':
      return {
        status: 'error',
        query,
        result: null,
        error: result.error
      }
  }
}

function clearRouteSearch<State extends IssueSearchDomainFields>(
  set: StoreApi<State>['setState'],
  routeExecutionHostId: ExecutionHostId
): void {
  set((state) => {
    const next = { ...state.searchLoadsByRoute }
    delete next[routeExecutionHostId]
    return { searchLoadsByRoute: next } as Partial<State>
  })
}

function setSearchState<State extends IssueSearchDomainFields>(
  set: StoreApi<State>['setState'],
  routeExecutionHostId: ExecutionHostId,
  value: IssueSearchLoadState
): void {
  set((state) => ({
    searchLoadsByRoute: {
      ...state.searchLoadsByRoute,
      [routeExecutionHostId]: value
    }
  }) as Partial<State>)
}
