import type {
  ConversationSummary,
  WorkspaceSnapshot
} from '../../../shared/issues/types'

export type IssueConversationWorkspaceGroup = {
  key: string
  workspace: WorkspaceSnapshot
  conversations: ConversationSummary[]
}

export function groupIssueConversationsByWorkspace(
  conversations: readonly ConversationSummary[]
): IssueConversationWorkspaceGroup[] {
  const groups = new Map<string, ConversationSummary[]>()
  for (const conversation of conversations) {
    const key = `${conversation.workspaceRef.type}:${workspaceRefId(conversation)}`
    const group = groups.get(key) ?? []
    group.push(conversation)
    groups.set(key, group)
  }
  return [...groups].map(([key, group]) => {
    group.sort(
      (left, right) =>
        right.updatedAt - left.updatedAt || left.id.localeCompare(right.id)
    )
    return {
      key,
      workspace: group[0].workspaceSnapshot,
      conversations: group
    }
  })
}

function workspaceRefId(conversation: ConversationSummary): string {
  return conversation.workspaceRef.type === 'worktree'
    ? conversation.workspaceRef.worktreeId
    : conversation.workspaceRef.folderWorkspaceId
}
