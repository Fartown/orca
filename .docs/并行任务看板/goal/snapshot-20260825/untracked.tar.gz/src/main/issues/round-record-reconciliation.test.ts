import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import type { NativeChatMessage } from '../../shared/native-chat-types'
import type { ConversationRecord, RoundRecord } from '../../shared/issues/types'
import type { TuiAgent } from '../../shared/tui-agent'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import { createProviderTurnRefValue } from './round-record-provider-turn-ref'
import {
  RoundRecordReconciler,
  type RoundRecordReconcilerDependencies
} from './round-record-reconciliation'
import { RoundRecordRetention } from './round-record-retention'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function openRepository(profileId: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId,
      userDataPath: createIssueTestUserDataPath(`orca-round-reconcile-${profileId}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  mutationSequence += 1
  return issueMutationIdentity('reconciliation-test', `${label}-${mutationSequence}`)
}

function createConversation(
  repository: IssueRepository,
  agent: TuiAgent = 'codex',
  executionHostId: ExecutionHostId = 'local'
): ConversationRecord {
  return repository.conversations.create({
    identity: identity('conversation'),
    input: {
      executionHostId,
      workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${mutationSequence}` },
      workspaceSnapshot: { name: 'Workspace', path: '/workspace' },
      agent,
      title: 'Conversation',
      titleSource: 'user',
      issueId: null
    }
  })
}

function attachIdentity(
  repository: IssueRepository,
  conversation: ConversationRecord,
  sessionId: string
) {
  return repository.conversationIdentities.attach({
    conversationId: conversation.id,
    agent: conversation.agent,
    providerSession: { key: 'session_id', id: sessionId },
    observedAt: 100
  })
}

function message(
  id: string,
  role: 'user' | 'assistant',
  text: string,
  timestamp: number,
  turnId?: string
): NativeChatMessage {
  return {
    id,
    role,
    blocks: [{ type: 'text', text }],
    timestamp,
    source: 'transcript',
    ...(turnId ? { turnId } : {})
  }
}

function transcript(
  messages: NativeChatMessage[]
): NonNullable<RoundRecordReconcilerDependencies['readTranscript']> {
  return async () => ({ messages })
}

function createProviderRound(
  repository: IssueRepository,
  conversation: ConversationRecord,
  identityFingerprint: string,
  providerTurnId: string,
  output: { text?: string; preview?: string; completeness?: 'complete' | 'preview-complete' }
): RoundRecord {
  return repository.rounds.create({
    identity: identity('round'),
    input: {
      conversationId: conversation.id,
      kind: 'completion',
      stateSource: 'hook',
      occurredAt: 1_000,
      dedupeKey: `hook:${conversation.id}:${providerTurnId}`,
      userInput: {
        preview: 'Preview prompt',
        completeness: 'preview-complete',
        storage: 'preview'
      },
      agentOutput: {
        ...output,
        storage: output.text ? 'full' : 'preview'
      },
      refs: [
        {
          kind: 'provider-turn',
          value: createProviderTurnRefValue(identityFingerprint, providerTurnId),
          reachable: true
        }
      ]
    }
  })
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('RoundRecordReconciler', () => {
  it('upgrades a hook preview in place from an explicit Codex turn and stays idempotent', async () => {
    const repository = openRepository('strong-upgrade')
    const conversation = createConversation(repository)
    const providerIdentity = attachIdentity(repository, conversation, 'session-1')
    const hookRound = createProviderRound(
      repository,
      conversation,
      providerIdentity.identityFingerprint,
      'turn-1',
      { preview: 'Preview result', completeness: 'preview-complete' }
    )
    const reconciler = new RoundRecordReconciler(repository, {
      readTranscript: transcript([
        message('user-1', 'user', 'Complete prompt', 1_000, 'turn-1'),
        message('assistant-1', 'assistant', 'Complete result', 1_100, 'turn-1')
      ])
    })

    const first = await reconciler.reconcile(conversation.id)
    const replay = await reconciler.reconcile(conversation.id)
    const rounds = repository.rounds.list({ conversationId: conversation.id })

    expect(first).toEqual({
      disposition: 'reconciled',
      conversationId: conversation.id,
      createdRoundIds: [],
      upgradedRoundIds: [hookRound.id],
      unchangedRoundIds: []
    })
    expect(replay).toEqual({
      disposition: 'reconciled',
      conversationId: conversation.id,
      createdRoundIds: [],
      upgradedRoundIds: [],
      unchangedRoundIds: [hookRound.id]
    })
    expect(rounds).toHaveLength(1)
    expect(rounds[0]).toMatchObject({
      id: hookRound.id,
      stateSource: 'hook',
      resolvedAt: null,
      userInput: {
        text: 'Complete prompt',
        completeness: 'complete',
        storage: 'full'
      },
      agentOutput: {
        text: 'Complete result',
        completeness: 'complete',
        storage: 'full'
      }
    })
    expect(repository.rounds.listRefs(hookRound.id)).toHaveLength(2)
  })

  it('creates a reconciled Round when a transcript turn has no hook fact', async () => {
    const repository = openRepository('missing-hook')
    const conversation = createConversation(repository)
    attachIdentity(repository, conversation, 'session-1')
    const reconciler = new RoundRecordReconciler(repository, {
      readTranscript: transcript([
        message('user-1', 'user', 'Prompt', 1_000, 'turn-1'),
        message('assistant-1', 'assistant', 'Result', 1_100, 'turn-1')
      ])
    })

    const first = await reconciler.reconcile(conversation.id)
    const replay = await reconciler.reconcile(conversation.id)
    const rounds = repository.rounds.list({ conversationId: conversation.id })

    expect(first).toMatchObject({
      disposition: 'reconciled',
      createdRoundIds: [rounds[0]?.id],
      upgradedRoundIds: [],
      unchangedRoundIds: []
    })
    expect(replay).toMatchObject({
      disposition: 'reconciled',
      createdRoundIds: [],
      upgradedRoundIds: [],
      unchangedRoundIds: [rounds[0]?.id]
    })
    expect(rounds).toEqual([
      expect.objectContaining({
        stateSource: 'reconciled',
        resolvedAt: null,
        agentOutput: expect.objectContaining({
          text: 'Result',
          completeness: 'complete',
          storage: 'full'
        })
      })
    ])
  })

  it.each([
    { tombstone: 'deleted', targetBytes: null },
    { tombstone: 'evicted-preview', targetBytes: 27 },
    { tombstone: 'evicted', targetBytes: 0 }
  ] as const)(
    'does not restore $tombstone bodies during background reconciliation',
    async ({ tombstone, targetBytes }) => {
      const repository = openRepository(`tombstone-${tombstone}`)
      const conversation = createConversation(repository)
      const providerIdentity = attachIdentity(repository, conversation, 'session-1')
      const round = createProviderRound(
        repository,
        conversation,
        providerIdentity.identityFingerprint,
        'turn-1',
        { text: 'Stored result', completeness: 'complete' }
      )
      if (tombstone === 'deleted') {
        repository.rounds.delete({
          identity: identity('delete'),
          input: { id: round.id }
        })
      } else {
        new RoundRecordRetention(repository.database, {
          softLimitBytes: targetBytes ?? 0,
          hardLimitBytes: 1_000
        }).enforceSoftLimit()
      }
      expect(repository.rounds.get(round.id)?.agentOutput.storage).toBe(tombstone)

      const result = await new RoundRecordReconciler(repository, {
        readTranscript: transcript([
          message('assistant-1', 'assistant', 'Restored result', 1_100, 'turn-1')
        ])
      }).reconcile(conversation.id)

      expect(result).toMatchObject({
        disposition: 'reconciled',
        createdRoundIds: [],
        upgradedRoundIds: [],
        unchangedRoundIds: [round.id]
      })
      expect(repository.rounds.get(round.id)).toMatchObject({
        resolvedAt: null,
        effectiveResolvedAt: null,
        agentOutput: {
          text: null,
          storage: tombstone,
          completeness: 'complete'
        }
      })
    }
  )

  it('keeps a weak Claude transcript fact separate from an existing hook Round', async () => {
    const repository = openRepository('weak-fact')
    const conversation = createConversation(repository, 'claude')
    attachIdentity(repository, conversation, 'session-1')
    const hookRound = repository.rounds.create({
      identity: identity('hook-round'),
      input: {
        conversationId: conversation.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 1_000,
        dedupeKey: 'hook:weak-fact',
        agentOutput: {
          preview: 'Hook preview',
          completeness: 'preview-complete',
          storage: 'preview'
        }
      }
    })
    const reconciler = new RoundRecordReconciler(repository, {
      readTranscript: transcript([
        message('user-1', 'user', 'Transcript prompt', 1_000),
        message('assistant-1', 'assistant', 'Transcript result', 1_100)
      ])
    })

    const result = await reconciler.reconcile(conversation.id)
    const rounds = repository.rounds.list({ conversationId: conversation.id })

    expect(result).toMatchObject({
      disposition: 'reconciled',
      createdRoundIds: [expect.any(String)],
      upgradedRoundIds: []
    })
    expect(rounds).toHaveLength(2)
    expect(repository.rounds.get(hookRound.id)?.agentOutput).toMatchObject({
      text: null,
      preview: 'Hook preview',
      completeness: 'preview-complete'
    })
    expect(rounds.find((round) => round.id !== hookRound.id)).toMatchObject({
      stateSource: 'reconciled',
      agentOutput: {
        text: 'Transcript result',
        completeness: 'complete',
        storage: 'full'
      }
    })
  })

  it('returns explicit reasons for unsupported, remote, missing, and unreadable transcripts', async () => {
    const repository = openRepository('skip-reasons')
    const unsupported = createConversation(repository, 'cursor')
    const identityMissing = createConversation(repository)
    const remote = createConversation(repository, 'codex', 'ssh:remote')
    attachIdentity(repository, remote, 'remote-session')
    const missing = createConversation(repository)
    attachIdentity(repository, missing, 'missing-session')
    const unreadable = createConversation(repository)
    attachIdentity(repository, unreadable, 'unreadable-session')
    const thrown = createConversation(repository)
    attachIdentity(repository, thrown, 'thrown-session')

    await expect(new RoundRecordReconciler(repository).reconcile(unsupported.id)).resolves.toEqual({
      disposition: 'skipped',
      conversationId: unsupported.id,
      reason: 'provider-unsupported'
    })
    await expect(
      new RoundRecordReconciler(repository).reconcile(identityMissing.id)
    ).resolves.toEqual({
      disposition: 'skipped',
      conversationId: identityMissing.id,
      reason: 'identity-missing'
    })
    await expect(new RoundRecordReconciler(repository).reconcile(remote.id)).resolves.toEqual({
      disposition: 'skipped',
      conversationId: remote.id,
      reason: 'remote-transcript-unavailable'
    })
    await expect(
      new RoundRecordReconciler(repository, {
        readTranscript: async () => ({ error: 'not flushed', notFound: true })
      }).reconcile(missing.id)
    ).resolves.toEqual({
      disposition: 'skipped',
      conversationId: missing.id,
      reason: 'transcript-not-found',
      detail: 'not flushed'
    })
    await expect(
      new RoundRecordReconciler(repository, {
        readTranscript: async () => ({ error: 'permission denied' })
      }).reconcile(unreadable.id)
    ).resolves.toEqual({
      disposition: 'skipped',
      conversationId: unreadable.id,
      reason: 'transcript-read-failed',
      detail: 'permission denied'
    })
    await expect(
      new RoundRecordReconciler(repository, {
        readTranscript: async () => {
          throw new Error('reader crashed')
        }
      }).reconcile(thrown.id)
    ).resolves.toEqual({
      disposition: 'skipped',
      conversationId: thrown.id,
      reason: 'transcript-read-failed',
      detail: 'reader crashed'
    })
  })

  it('coalesces concurrent scheduling for one Conversation', async () => {
    const repository = openRepository('schedule')
    const conversation = createConversation(repository)
    attachIdentity(repository, conversation, 'session-1')
    let release!: () => void
    let reads = 0
    const gate = new Promise<void>((resolve) => {
      release = resolve
    })
    const reconciler = new RoundRecordReconciler(repository, {
      readTranscript: async () => {
        reads += 1
        await gate
        return { messages: [] }
      }
    })

    const first = reconciler.schedule(conversation.id)
    const second = reconciler.schedule(conversation.id)
    release()

    expect(second).toBe(first)
    await expect(Promise.all([first, second])).resolves.toEqual([
      expect.objectContaining({ disposition: 'reconciled' }),
      expect.objectContaining({ disposition: 'reconciled' })
    ])
    expect(reads).toBe(1)
  })
})
