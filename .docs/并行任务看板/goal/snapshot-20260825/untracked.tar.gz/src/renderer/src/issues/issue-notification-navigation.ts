import type { ExecutionHostId } from '../../../shared/execution-host'
import type { IssueNotificationNavigationTarget } from '../../../shared/issues/notification-types'
import type {
  ConversationSummary,
  IssueAuthorityDescriptor,
  IssueDetail,
  RoundRecordPage
} from '../../../shared/issues/types'
import {
  activateAndRevealFolderWorkspace,
  activateAndRevealWorktree
} from '../lib/worktree-activation'
import { parseWorkspaceKey } from '../../../shared/workspace-scope'
import {
  loadConversation,
  loadIssueDetail,
  loadIssueRounds,
  type IssueClientLoadResult
} from './issue-client-data'
import {
  openIssueConversation,
  type IssueConversationNavigationResult
} from './issue-conversation-navigation'
import { openIssueDetail } from './issue-navigation'

export type IssueNotificationNavigationResult =
  | { status: 'round'; issueId: string; roundRecordId: string }
  | { status: 'conversation'; conversationId: string }
  | { status: 'workspace' }
  | { status: 'unavailable' }

export type IssueNotificationNavigationDependencies = {
  loadConversation: (
    routeExecutionHostId: ExecutionHostId,
    conversationId: string
  ) => Promise<IssueClientLoadResult<ConversationSummary>>
  loadIssueDetail: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string
  ) => Promise<IssueClientLoadResult<IssueDetail>>
  loadIssueRounds: (
    routeExecutionHostId: ExecutionHostId,
    scope: { issueId: string }
  ) => Promise<IssueClientLoadResult<RoundRecordPage>>
  openIssue: (
    authority: IssueAuthorityDescriptor,
    issueId: string
  ) => void
  revealRound: (roundRecordId: string) => void
  openConversation: (
    routeExecutionHostId: ExecutionHostId,
    conversation: ConversationSummary
  ) => Promise<IssueConversationNavigationResult>
  openWorkspace: (
    routeExecutionHostId: ExecutionHostId,
    conversation: ConversationSummary | null,
    workspaceId?: string
  ) => boolean
}

export async function openIssueNotification(
  target: IssueNotificationNavigationTarget,
  dependencies: IssueNotificationNavigationDependencies = defaultDependencies
): Promise<IssueNotificationNavigationResult> {
  const conversation = target.conversationId
    ? await loadCurrentConversation(target, dependencies)
    : null
  if (conversation && target.roundRecordId && conversation.issueId) {
    const opened = await openCurrentRound(
      target.executionHostId,
      conversation,
      conversation.issueId,
      target.roundRecordId,
      dependencies
    )
    if (opened) {
      return opened
    }
  }
  if (!conversation && !target.conversationId && target.issueId && target.roundRecordId) {
    const opened = await openRoundWithoutConversation(
      target.executionHostId,
      target.issueId,
      target.roundRecordId,
      dependencies
    )
    if (opened) {
      return opened
    }
  }
  if (conversation) {
    const opened = await dependencies.openConversation(
      target.executionHostId,
      conversation
    )
    if (opened.status !== 'unavailable') {
      return { status: 'conversation', conversationId: conversation.id }
    }
  }
  return dependencies.openWorkspace(
    target.executionHostId,
    conversation,
    target.worktreeId
  )
    ? { status: 'workspace' }
    : { status: 'unavailable' }
}

async function loadCurrentConversation(
  target: IssueNotificationNavigationTarget,
  dependencies: IssueNotificationNavigationDependencies
): Promise<ConversationSummary | null> {
  if (!target.conversationId) {
    return null
  }
  const result = await dependencies.loadConversation(
    target.executionHostId,
    target.conversationId
  )
  return result.status === 'ready' || result.status === 'cached'
    ? result.value
    : null
}

async function openCurrentRound(
  routeExecutionHostId: ExecutionHostId,
  conversation: ConversationSummary,
  issueId: string,
  roundRecordId: string,
  dependencies: IssueNotificationNavigationDependencies
): Promise<Extract<IssueNotificationNavigationResult, { status: 'round' }> | null> {
  const [detail, rounds] = await Promise.all([
    dependencies.loadIssueDetail(routeExecutionHostId, issueId),
    dependencies.loadIssueRounds(routeExecutionHostId, { issueId })
  ])
  if (
    !isAvailable(detail) ||
    !isAvailable(rounds) ||
    !detail.value.directConversations.some(
      (candidate) => candidate.id === conversation.id
    ) ||
    !rounds.value.rounds.some(
      (round) =>
        round.id === roundRecordId &&
        round.conversationId === conversation.id
    )
  ) {
    return null
  }
  dependencies.openIssue(detail.value.authority, issueId)
  dependencies.revealRound(roundRecordId)
  return { status: 'round', issueId, roundRecordId }
}

async function openRoundWithoutConversation(
  routeExecutionHostId: ExecutionHostId,
  issueId: string,
  roundRecordId: string,
  dependencies: IssueNotificationNavigationDependencies
): Promise<Extract<IssueNotificationNavigationResult, { status: 'round' }> | null> {
  const [detail, rounds] = await Promise.all([
    dependencies.loadIssueDetail(routeExecutionHostId, issueId),
    dependencies.loadIssueRounds(routeExecutionHostId, { issueId })
  ])
  if (
    !isAvailable(detail) ||
    !isAvailable(rounds) ||
    !rounds.value.rounds.some((round) => round.id === roundRecordId)
  ) {
    return null
  }
  dependencies.openIssue(detail.value.authority, issueId)
  dependencies.revealRound(roundRecordId)
  return { status: 'round', issueId, roundRecordId }
}

function isAvailable<T>(
  result: IssueClientLoadResult<T>
): result is Extract<IssueClientLoadResult<T>, { status: 'ready' | 'cached' }> {
  return result.status === 'ready' || result.status === 'cached'
}

function revealRoundRecord(roundRecordId: string): void {
  let attempts = 0
  const reveal = (): void => {
    const element = [...document.querySelectorAll<HTMLElement>('[data-round-record-id]')]
      .find((candidate) => candidate.dataset.roundRecordId === roundRecordId)
    if (element) {
      element.scrollIntoView({ block: 'center' })
      return
    }
    attempts += 1
    if (attempts < 300) {
      requestAnimationFrame(reveal)
    }
  }
  requestAnimationFrame(reveal)
}

function openWorkspace(
  routeExecutionHostId: ExecutionHostId,
  conversation: ConversationSummary | null,
  workspaceId?: string
): boolean {
  const scope = conversation?.workspaceRef ?? (
    workspaceId ? parseWorkspaceKey(workspaceId) : null
  )
  if (scope?.type === 'folder') {
    return Boolean(
      activateAndRevealFolderWorkspace(scope.folderWorkspaceId, {
        executionHostId: routeExecutionHostId
      })
    )
  }
  const worktreeId =
    scope?.type === 'worktree'
      ? scope.worktreeId
      : workspaceId
  return worktreeId
    ? Boolean(
        activateAndRevealWorktree(worktreeId, {
          executionHostId: routeExecutionHostId
        })
      )
    : false
}

const defaultDependencies: IssueNotificationNavigationDependencies = {
  loadConversation,
  loadIssueDetail,
  loadIssueRounds,
  openIssue: (authority, issueId) => {
    openIssueDetail({ authority, issueId })
  },
  revealRound: revealRoundRecord,
  openConversation: (routeExecutionHostId, conversation) =>
    openIssueConversation({ routeExecutionHostId, conversation }),
  openWorkspace
}
