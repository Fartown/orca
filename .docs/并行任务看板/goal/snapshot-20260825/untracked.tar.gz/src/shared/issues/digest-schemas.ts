import { z } from 'zod'
import { parseExecutionHostId } from '../execution-host'
import type { TuiAgent } from '../tui-agent'
import { ALL_TUI_AGENTS } from '../tui-agent-display-names'
import { getUtf8ByteLength } from '../utf8-byte-limits'
import {
  ISSUE_DIGEST_DRAFT_MAX_BYTES,
  ISSUE_DIGEST_GENERATION_ERROR_MAX_BYTES,
  ISSUE_DIGEST_INPUT_COMPLETENESS,
  ISSUE_DIGEST_INPUT_KINDS,
  ISSUE_DIGEST_OMISSION_REASONS,
  ISSUE_DIGEST_STATUSES
} from './digest-constants'
import { IssueAuthorityDescriptorSchema } from './authority-schemas'

const DigestEntityId = z.string().uuid()
const DigestMutationId = z.string().min(1).max(128)
const DigestTimestamp = z.number().int().nonnegative()
const DigestFingerprint = z.string().regex(/^[a-f0-9]{64}$/)
const DigestAgentSchema = z.custom<TuiAgent>(
  (value) => typeof value === 'string' && ALL_TUI_AGENTS.includes(value as TuiAgent),
  'Unknown agent preset'
)
const DigestExecutionHostId = z.string().transform((value, context) => {
  const parsed = parseExecutionHostId(value)
  if (parsed) {
    return parsed.id
  }
  context.addIssue({ code: 'custom', message: 'Invalid execution host id' })
  return z.NEVER
})
const NullableDigestText = z.string().nullable()

const DigestSectionsSchema = z
  .object({
    problem: NullableDigestText,
    conclusion: NullableDigestText,
    keyArtifacts: NullableDigestText,
    openIssues: NullableDigestText,
    nextSteps: NullableDigestText
  })
  .refine(
    (sections) =>
      getUtf8ByteLength(
        [
          sections.problem,
          sections.conclusion,
          sections.keyArtifacts,
          sections.openIssues,
          sections.nextSteps
        ]
          .filter((value): value is string => value !== null)
          .join('')
      ) <= ISSUE_DIGEST_DRAFT_MAX_BYTES,
    'Digest draft exceeds the UTF-8 byte limit'
  )

export const IssueDigestRecordSchema = DigestSectionsSchema.extend({
  id: DigestEntityId,
  issueId: DigestEntityId,
  version: z.number().int().positive(),
  revision: z.number().int().nonnegative(),
  status: z.enum(ISSUE_DIGEST_STATUSES),
  coversUntil: DigestTimestamp,
  coverageNote: z.string().max(64 * 1024).nullable(),
  inputFingerprint: DigestFingerprint,
  generatorAgent: DigestAgentSchema.nullable(),
  generationId: DigestEntityId.nullable(),
  generationError: z
    .string()
    .refine(
      (value) => getUtf8ByteLength(value) <= ISSUE_DIGEST_GENERATION_ERROR_MAX_BYTES,
      'Digest generation error exceeds the UTF-8 byte limit'
    )
    .nullable(),
  generationStartedAt: DigestTimestamp.nullable(),
  generationFinishedAt: DigestTimestamp.nullable(),
  createdAt: DigestTimestamp,
  updatedAt: DigestTimestamp,
  confirmedAt: DigestTimestamp.nullable()
})

export const IssueDigestInputSummarySchema = z.object({
  kind: z.enum(ISSUE_DIGEST_INPUT_KINDS),
  inputId: DigestEntityId,
  inputVersion: z.number().int().nonnegative(),
  titleSnapshot: z.string().max(8 * 1024).nullable(),
  occurredAt: DigestTimestamp.nullable(),
  originalBytes: z.number().int().nonnegative(),
  includedBytes: z.number().int().nonnegative(),
  completeness: z.enum(ISSUE_DIGEST_INPUT_COMPLETENESS),
  omissionReason: z.enum(ISSUE_DIGEST_OMISSION_REASONS).nullable()
})

export const IssueDigestCoverageSchema = z.object({
  totalInputCount: z.number().int().nonnegative(),
  includedInputCount: z.number().int().nonnegative(),
  directRoundCount: z.number().int().nonnegative(),
  includedDirectRoundCount: z.number().int().nonnegative(),
  totalUtf8Bytes: z.number().int().nonnegative(),
  includedUtf8Bytes: z.number().int().nonnegative(),
  truncatedInputCount: z.number().int().nonnegative(),
  omittedInputCount: z.number().int().nonnegative(),
  complete: z.boolean(),
  note: z.string().max(64 * 1024).nullable()
})

export const IssueDigestPreparationSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  issueId: DigestEntityId,
  coversUntil: DigestTimestamp,
  inputFingerprint: DigestFingerprint,
  inputs: z.array(IssueDigestInputSummarySchema).max(10_000),
  coverage: IssueDigestCoverageSchema
})

export const IssuesPrepareDigestParams = z.object({
  executionHostId: DigestExecutionHostId,
  issueId: DigestEntityId,
  coversUntil: DigestTimestamp.optional()
})

export const IssuesGenerateDigestParams = z.object({
  executionHostId: DigestExecutionHostId,
  mutationId: DigestMutationId,
  issueId: DigestEntityId,
  coversUntil: DigestTimestamp.optional(),
  agent: DigestAgentSchema,
  expectedInputFingerprint: DigestFingerprint
})

export const IssuesCancelDigestParams = z.object({
  executionHostId: DigestExecutionHostId,
  mutationId: DigestMutationId,
  digestId: DigestEntityId
})

export const IssuesUpdateDigestDraftParams = z
  .object({
    executionHostId: DigestExecutionHostId,
    mutationId: DigestMutationId,
    digestId: DigestEntityId,
    expectedDigestRevision: z.number().int().nonnegative(),
    problem: NullableDigestText.optional(),
    conclusion: NullableDigestText.optional(),
    keyArtifacts: NullableDigestText.optional(),
    openIssues: NullableDigestText.optional(),
    nextSteps: NullableDigestText.optional()
  })
  .refine(
    (value) =>
      getUtf8ByteLength(
        [
          value.problem,
          value.conclusion,
          value.keyArtifacts,
          value.openIssues,
          value.nextSteps
        ]
          .filter((field): field is string => typeof field === 'string')
          .join('')
      ) <= ISSUE_DIGEST_DRAFT_MAX_BYTES,
    'Digest draft exceeds the UTF-8 byte limit'
  )

export const IssuesConfirmDigestParams = z.object({
  executionHostId: DigestExecutionHostId,
  mutationId: DigestMutationId,
  digestId: DigestEntityId,
  expectedDigestRevision: z.number().int().nonnegative(),
  inputFingerprint: DigestFingerprint,
  confirmStaleAgainstFingerprint: DigestFingerprint.optional()
})

export const IssueDigestMutationResultSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  digest: IssueDigestRecordSchema
})

export const IssueDigestProjectionSchema = z.object({
  latestConfirmed: IssueDigestRecordSchema.nullable(),
  latestAttempt: IssueDigestRecordSchema.nullable(),
  currentInputFingerprint: DigestFingerprint,
  latestConfirmedIsStale: z.boolean()
})

export const IssueDigestConfirmationResultSchema = z.discriminatedUnion('status', [
  z.object({
    status: z.literal('confirmed'),
    authority: IssueAuthorityDescriptorSchema,
    digest: IssueDigestRecordSchema,
    currentInputFingerprint: DigestFingerprint,
    stale: z.boolean()
  }),
  z.object({
    status: z.literal('stale'),
    authority: IssueAuthorityDescriptorSchema,
    digest: IssueDigestRecordSchema,
    currentInputFingerprint: DigestFingerprint,
    changeSummary: z.string().max(64 * 1024)
  })
])
