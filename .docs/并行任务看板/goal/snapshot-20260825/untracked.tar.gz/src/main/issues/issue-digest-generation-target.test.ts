import { describe, expect, it, vi } from 'vitest'
import type { FolderWorkspace } from '../../shared/folder-workspace-types'
import type { ConversationRecord, IssueRecord } from '../../shared/issues/types'
import type { ProjectGroup } from '../../shared/project-group-types'
import type { Repo } from '../../shared/repo-types'
import type { WorktreeMeta } from '../../shared/worktree/meta-types'
import { hostPartitionForExecutionHost } from './issue-host-partition'
import {
  resolveIssueDigestGenerationTarget,
  type IssueDigestGenerationTargetStore
} from './issue-digest-generation-target'

function makeIssue(executionHostId: IssueRecord['executionHostId'] = 'local'): IssueRecord {
  return {
    id: 'issue-1',
    hostPartitionKey: hostPartitionForExecutionHost(executionHostId),
    executionHostId,
    source: { kind: 'local', number: 1 },
    localTitle: 'Digest target',
    typeLabel: null,
    note: null,
    state: 'active',
    parentId: null,
    siblingOrder: 0,
    createdAt: 1,
    updatedAt: 1,
    archivedAt: null
  }
}

function makeConversation(
  workspaceRef: ConversationRecord['workspaceRef'],
  overrides: Partial<ConversationRecord> = {}
): ConversationRecord {
  return {
    id: `conversation-${overrides.updatedAt ?? 1}`,
    hostPartitionKey: 'local',
    executionHostId: 'local',
    workspaceRef,
    workspaceSnapshot: { name: 'Stale', path: '/stale/snapshot' },
    agent: 'codex',
    title: null,
    titleSource: null,
    issueId: 'issue-1',
    state: 'active',
    launchFailure: null,
    createdAt: 1,
    updatedAt: 1,
    ...overrides
  }
}

function makeRepo(overrides: Partial<Repo> = {}): Repo {
  return {
    id: 'repo-1',
    path: '/current/repo',
    displayName: 'Repo',
    badgeColor: '#000000',
    addedAt: 1,
    ...overrides
  }
}

function store(input: {
  repos?: Repo[]
  folders?: FolderWorkspace[]
  groups?: ProjectGroup[]
  meta?: Record<string, WorktreeMeta>
} = {}): IssueDigestGenerationTargetStore {
  return {
    getRepos: () => input.repos ?? [],
    getFolderWorkspaces: () => input.folders ?? [],
    getProjectGroups: () => input.groups ?? [],
    getWorktreeMeta: (id) => input.meta?.[id]
  }
}

describe('resolveIssueDigestGenerationTarget', () => {
  it('uses the newest executable direct Conversation and current worktree facts', async () => {
    const archivedId = 'repo-1::/current/archived'
    const usableId = 'repo-1::/current/usable'
    const prepareAgentEnv = vi.fn(async () => ({ ok: true as const, env: { TOKEN: 'ready' } }))

    const target = await resolveIssueDigestGenerationTarget(
      {
        issue: makeIssue(),
        agent: 'codex',
        conversations: [
          makeConversation({ type: 'worktree', worktreeId: usableId }, { updatedAt: 10 }),
          makeConversation({ type: 'worktree', worktreeId: archivedId }, { updatedAt: 20 })
        ]
      },
      {
        store: store({
          repos: [makeRepo()],
          meta: {
            [archivedId]: { isArchived: true } as WorktreeMeta,
            [usableId]: { isArchived: false } as WorktreeMeta
          }
        }),
        prepareAgentEnv,
        resolveLocalRuntimeOptions: () => ({})
      }
    )

    expect(target).toEqual({
      kind: 'local',
      cwd: '/current/usable',
      env: { TOKEN: 'ready' }
    })
    expect(prepareAgentEnv).toHaveBeenCalledWith('codex', { runtime: 'host' })
  })

  it('routes direct SSH folders through the existing provider execution and cancellation lanes', async () => {
    const executeCommitMessagePlan = vi.fn(async () => ({
      stdout: '{}',
      stderr: '',
      exitCode: 0,
      timedOut: false
    }))
    const cancelGenerateCommitMessage = vi.fn(async () => {})
    const target = await resolveIssueDigestGenerationTarget(
      {
        issue: makeIssue('ssh:server-a'),
        agent: 'claude',
        conversations: [
          makeConversation(
            { type: 'folder', folderWorkspaceId: 'folder-1' },
            {
              executionHostId: 'ssh:server-a',
              hostPartitionKey: 'ssh:server-a'
            }
          )
        ]
      },
      {
        store: store({
          folders: [
            {
              id: 'folder-1',
              projectGroupId: 'group-1',
              name: 'Remote folder',
              folderPath: '/srv/current',
              connectionId: 'server-a',
              linkedTask: null,
              comment: '',
              isArchived: false,
              isUnread: false,
              isPinned: false,
              sortOrder: 0,
              lastActivityAt: 1,
              createdAt: 1,
              updatedAt: 1
            }
          ]
        }),
        getSshProvider: () => ({
          executeCommitMessagePlan,
          cancelGenerateCommitMessage
        }),
        prepareAgentEnv: vi.fn(),
        resolveLocalRuntimeOptions: () => ({})
      }
    )
    if (target.kind !== 'remote') {
      throw new Error('Expected a remote target.')
    }

    await target.execute(
      { binary: 'claude', args: [], stdinPayload: '{}', label: 'Claude' },
      target.cwd,
      60_000,
      'issue-digest'
    )
    await target.cancel?.(target.cwd, 'issue-digest')

    expect(executeCommitMessagePlan).toHaveBeenCalledWith(
      expect.any(Object),
      '/srv/current',
      60_000,
      'issue-digest'
    )
    expect(cancelGenerateCommitMessage).toHaveBeenCalledWith(
      '/srv/current',
      'issue-digest'
    )
  })

  it('prepares local WSL execution from the current project runtime', async () => {
    const prepareAgentEnv = vi.fn(async () => ({ ok: true as const, env: { CODEX_HOME: '/home/me/.codex' } }))
    const target = await resolveIssueDigestGenerationTarget(
      {
        issue: makeIssue(),
        agent: 'codex',
        conversations: [
          makeConversation({
            type: 'worktree',
            worktreeId: 'repo-1::C:\\projects\\orca-work'
          })
        ]
      },
      {
        store: store({ repos: [makeRepo({ path: 'C:\\projects\\orca' })] }),
        prepareAgentEnv,
        resolveLocalRuntimeOptions: () => ({ wslDistro: 'Ubuntu' })
      }
    )

    expect(target).toEqual({
      kind: 'local',
      cwd: 'C:\\projects\\orca-work',
      wslDistro: 'Ubuntu',
      env: { CODEX_HOME: '/home/me/.codex' }
    })
    expect(prepareAgentEnv).toHaveBeenCalledWith('codex', {
      runtime: 'wsl',
      wslDistro: 'Ubuntu'
    })
  })

  it('rejects host mismatches instead of trusting the Conversation path snapshot', async () => {
    await expect(
      resolveIssueDigestGenerationTarget(
        {
          issue: makeIssue(),
          agent: 'codex',
          conversations: [
            makeConversation({
              type: 'worktree',
              worktreeId: 'repo-1::/remote/repo'
            })
          ]
        },
        {
          store: store({
            repos: [makeRepo({ path: '/remote/repo', connectionId: 'server-a' })]
          }),
          prepareAgentEnv: vi.fn(),
          resolveLocalRuntimeOptions: () => ({})
        }
      )
    ).rejects.toMatchObject({ code: 'digest_target_unavailable' })
  })

  it('rejects ambiguous folder ownership and missing current workspace records', async () => {
    const folder: FolderWorkspace = {
      id: 'folder-1',
      projectGroupId: 'group-1',
      name: 'Ambiguous',
      folderPath: '/workspace',
      linkedTask: null,
      comment: '',
      isArchived: false,
      isUnread: false,
      isPinned: false,
      sortOrder: 0,
      lastActivityAt: 1,
      createdAt: 1,
      updatedAt: 1
    }
    const conversation = makeConversation({
      type: 'folder',
      folderWorkspaceId: folder.id
    })
    const dependencies = {
      store: store({
        folders: [folder],
        repos: [
          makeRepo({ id: 'local', path: '/workspace/local' }),
          makeRepo({ id: 'remote', path: '/workspace/remote', connectionId: 'server-a' })
        ]
      }),
      prepareAgentEnv: vi.fn(),
      resolveLocalRuntimeOptions: () => ({})
    }

    await expect(
      resolveIssueDigestGenerationTarget(
        { issue: makeIssue(), agent: 'codex', conversations: [conversation] },
        dependencies
      )
    ).rejects.toMatchObject({ code: 'digest_target_unavailable' })

    await expect(
      resolveIssueDigestGenerationTarget(
        {
          issue: makeIssue(),
          agent: 'codex',
          conversations: [
            makeConversation({ type: 'folder', folderWorkspaceId: 'deleted-folder' })
          ]
        },
        dependencies
      )
    ).rejects.toMatchObject({ code: 'digest_target_unavailable' })
  })
})
