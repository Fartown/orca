export const ISSUE_DATABASE_CORE_SCHEMA = `
CREATE TABLE issue_authority_meta (
  singleton                 INTEGER PRIMARY KEY CHECK(singleton = 1),
  authority_id              TEXT NOT NULL UNIQUE,
  retained_round_text_bytes INTEGER NOT NULL DEFAULT 0
                              CHECK(retained_round_text_bytes >= 0),
  created_at                INTEGER NOT NULL
);

CREATE TABLE issue_host_state (
  host_partition_key      TEXT PRIMARY KEY,
  next_local_issue_number INTEGER NOT NULL DEFAULT 1
                          CHECK(next_local_issue_number >= 1),
  facts_revision          INTEGER NOT NULL DEFAULT 0 CHECK(facts_revision >= 0),
  tree_revision           INTEGER NOT NULL DEFAULT 0 CHECK(tree_revision >= 0),
  search_revision         INTEGER NOT NULL DEFAULT 0 CHECK(search_revision >= 0),
  indexed_search_revision INTEGER NOT NULL DEFAULT 0
                          CHECK(indexed_search_revision >= 0),
  search_index_dirty      INTEGER NOT NULL DEFAULT 0
                          CHECK(search_index_dirty IN (0, 1)),
  updated_at              INTEGER NOT NULL
);

CREATE TABLE issues (
  id                  TEXT PRIMARY KEY,
  host_partition_key  TEXT NOT NULL,
  execution_host_id   TEXT NOT NULL,
  source_kind         TEXT NOT NULL CHECK(source_kind IN ('local', 'external')),
  source_provider     TEXT,
  source_scope_key    TEXT,
  source_external_id  TEXT,
  source_number       INTEGER,
  source_identifier   TEXT,
  source_url          TEXT,
  source_title        TEXT,
  source_state        TEXT,
  source_synced_at    INTEGER,
  source_refresh_attempted_at INTEGER,
  source_refresh_error TEXT,
  source_availability TEXT CHECK(
                        source_availability IS NULL OR
                        source_availability IN ('available', 'unavailable')
                      ),
  source_context_json TEXT,
  native_parent_json  TEXT,
  local_title         TEXT,
  type_label          TEXT,
  note                TEXT,
  state               TEXT NOT NULL CHECK(state IN ('active', 'archived')),
  parent_id           TEXT REFERENCES issues(id) ON DELETE RESTRICT,
  sibling_order       INTEGER NOT NULL,
  created_at          INTEGER NOT NULL,
  updated_at          INTEGER NOT NULL,
  archived_at         INTEGER,
  CHECK (
    (source_kind = 'local' AND local_title IS NOT NULL
                           AND source_number IS NOT NULL
                           AND source_provider IS NULL
                           AND source_scope_key IS NULL
                           AND source_external_id IS NULL) OR
    (source_kind = 'external' AND source_provider IS NOT NULL
                              AND source_scope_key IS NOT NULL
                              AND source_external_id IS NOT NULL)
  )
);

CREATE UNIQUE INDEX idx_issues_local_number
  ON issues(host_partition_key, source_number)
  WHERE source_kind = 'local';
CREATE UNIQUE INDEX idx_issues_external_source
  ON issues(
    host_partition_key, source_provider, source_scope_key, source_external_id
  )
  WHERE source_kind = 'external';
CREATE INDEX idx_issues_parent_order
  ON issues(host_partition_key, parent_id, sibling_order);
CREATE INDEX idx_issues_state
  ON issues(host_partition_key, state, updated_at DESC);

CREATE TRIGGER issues_execution_host_immutable
BEFORE UPDATE OF execution_host_id, host_partition_key ON issues
WHEN NEW.execution_host_id <> OLD.execution_host_id
  OR NEW.host_partition_key <> OLD.host_partition_key
BEGIN
  SELECT RAISE(ABORT, 'issue_execution_host_immutable');
END;

CREATE TRIGGER issues_parent_same_host_insert
BEFORE INSERT ON issues
WHEN NEW.parent_id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM issues parent
    WHERE parent.id = NEW.parent_id
      AND parent.host_partition_key = NEW.host_partition_key
      AND parent.execution_host_id = NEW.execution_host_id
  )
BEGIN
  SELECT RAISE(ABORT, 'issue_parent_host_mismatch');
END;

CREATE TRIGGER issues_parent_same_host_update
BEFORE UPDATE OF parent_id ON issues
WHEN NEW.parent_id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM issues parent
    WHERE parent.id = NEW.parent_id
      AND parent.host_partition_key = NEW.host_partition_key
      AND parent.execution_host_id = NEW.execution_host_id
  )
BEGIN
  SELECT RAISE(ABORT, 'issue_parent_host_mismatch');
END;

CREATE TABLE issue_links (
  issue_id                  TEXT NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  target_authority_id       TEXT NOT NULL,
  target_host_partition_key TEXT NOT NULL,
  target_issue_id           TEXT NOT NULL,
  target_title_snapshot     TEXT NOT NULL,
  created_at                INTEGER NOT NULL,
  updated_at                INTEGER NOT NULL,
  PRIMARY KEY(
    issue_id, target_authority_id, target_host_partition_key, target_issue_id
  )
);

CREATE TABLE conversations (
  id                      TEXT PRIMARY KEY,
  host_partition_key      TEXT NOT NULL,
  execution_host_id       TEXT NOT NULL,
  workspace_kind          TEXT NOT NULL CHECK(workspace_kind IN ('worktree', 'folder')),
  workspace_id            TEXT NOT NULL,
  workspace_name_snapshot TEXT NOT NULL,
  workspace_path_snapshot TEXT NOT NULL,
  agent                   TEXT NOT NULL,
  title                   TEXT,
  title_source            TEXT CHECK(
                            title_source IS NULL OR
                            title_source IN ('user', 'provider', 'generated', 'terminal')
                          ),
  issue_id                TEXT REFERENCES issues(id) ON DELETE RESTRICT,
  state                   TEXT NOT NULL CHECK(state IN ('active', 'closed')),
  launch_failure          TEXT,
  created_at              INTEGER NOT NULL,
  updated_at              INTEGER NOT NULL
);
CREATE INDEX idx_conversations_issue
  ON conversations(issue_id, updated_at DESC);
CREATE INDEX idx_conversations_workspace
  ON conversations(host_partition_key, workspace_kind, workspace_id, updated_at DESC);

CREATE TRIGGER conversations_execution_host_immutable
BEFORE UPDATE OF execution_host_id, host_partition_key ON conversations
WHEN NEW.execution_host_id <> OLD.execution_host_id
  OR NEW.host_partition_key <> OLD.host_partition_key
BEGIN
  SELECT RAISE(ABORT, 'conversation_execution_host_immutable');
END;

CREATE TRIGGER conversations_issue_same_host_insert
BEFORE INSERT ON conversations
WHEN NEW.issue_id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM issues issue
    WHERE issue.id = NEW.issue_id
      AND issue.host_partition_key = NEW.host_partition_key
      AND issue.execution_host_id = NEW.execution_host_id
  )
BEGIN
  SELECT RAISE(ABORT, 'conversation_issue_host_mismatch');
END;

CREATE TRIGGER conversations_issue_same_host_update
BEFORE UPDATE OF issue_id ON conversations
WHEN NEW.issue_id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM issues issue
    WHERE issue.id = NEW.issue_id
      AND issue.host_partition_key = NEW.host_partition_key
      AND issue.execution_host_id = NEW.execution_host_id
  )
BEGIN
  SELECT RAISE(ABORT, 'conversation_issue_host_mismatch');
END;

CREATE TABLE conversation_provider_identities (
  id                    TEXT PRIMARY KEY,
  conversation_id       TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  host_partition_key    TEXT NOT NULL,
  agent                 TEXT NOT NULL,
  provider_session_key  TEXT NOT NULL,
  provider_session_id   TEXT NOT NULL,
  identity_fingerprint  TEXT NOT NULL,
  transcript_path       TEXT,
  resume_locator        TEXT,
  observed_at           INTEGER NOT NULL,
  retired_at            INTEGER
);
CREATE INDEX idx_provider_identity_lookup
  ON conversation_provider_identities(
    host_partition_key, agent, provider_session_key, provider_session_id, retired_at
  );
CREATE UNIQUE INDEX idx_provider_identity_active_owner
  ON conversation_provider_identities(host_partition_key, identity_fingerprint)
  WHERE retired_at IS NULL;
CREATE UNIQUE INDEX idx_provider_identity_one_active_per_conversation
  ON conversation_provider_identities(conversation_id)
  WHERE retired_at IS NULL;

CREATE TABLE conversation_launch_claims (
  claim_id            TEXT PRIMARY KEY,
  conversation_id     TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  host_partition_key  TEXT NOT NULL,
  pane_key            TEXT,
  launch_token_hash   TEXT NOT NULL,
  process_incarnation TEXT,
  connection_id       TEXT,
  created_at          INTEGER NOT NULL,
  expires_at          INTEGER NOT NULL,
  consumed_at         INTEGER
);
CREATE UNIQUE INDEX idx_launch_claim_active_token
  ON conversation_launch_claims(host_partition_key, launch_token_hash)
  WHERE consumed_at IS NULL;
CREATE INDEX idx_launch_claim_pane
  ON conversation_launch_claims(host_partition_key, pane_key, consumed_at, expires_at);
`
