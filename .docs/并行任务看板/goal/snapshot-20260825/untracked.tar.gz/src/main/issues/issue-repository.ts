import type { IssueMutationIdentity } from '../../shared/issues/types'
import { ConversationAllocator } from './conversation-allocator'
import { ConversationIdentityRepository } from './conversation-identity-repository'
import { ConversationLaunchClaimRepository } from './conversation-launch-claim-repository'
import { ConversationRecordRepository } from './conversation-record-repository'
import { ExternalIssueRepository } from './external-issue-repository'
import { IssueDatabase, type OpenIssueDatabaseOptions } from './issue-database'
import { IssueDeleteRepository } from './issue-delete-repository'
import { IssueDigestRepository } from './issue-digest-repository'
import { IssueEventRepository } from './issue-event-repository'
import { IssueHierarchyMutation } from './issue-hierarchy-mutation'
import { IssueLifecycleRepository } from './issue-lifecycle-repository'
import { IssueLinkRepository } from './issue-link-repository'
import { IssueRecordRepository } from './issue-record-repository'
import { IssueSearchIndex, IssueSearchIndexWorker } from './issue-search-index'
import { RoundRecordRepository } from './round-record-repository'
import {
  RoundRecordRetention,
  RoundRecordRetentionWorker,
  type RoundRecordRetentionLimits
} from './round-record-retention'

export class IssueRepository {
  readonly issues: IssueRecordRepository
  readonly conversations: ConversationRecordRepository
  readonly conversationIdentities: ConversationIdentityRepository
  readonly conversationLaunchClaims: ConversationLaunchClaimRepository
  readonly conversationAllocator: ConversationAllocator
  readonly rounds: RoundRecordRepository
  readonly issueEvents: IssueEventRepository
  readonly digests: IssueDigestRepository
  readonly issueLinks: IssueLinkRepository
  readonly searchIndex: IssueSearchIndex
  private readonly roundRetentionWorker: RoundRecordRetentionWorker
  private readonly searchIndexWorker: IssueSearchIndexWorker
  private readonly stopSearchIndexListener: () => void

  constructor(
    readonly database: IssueDatabase,
    roundRetentionLimits?: Partial<RoundRecordRetentionLimits>
  ) {
    this.issueEvents = new IssueEventRepository(database)
    this.digests = new IssueDigestRepository(database, this.issueEvents)
    this.digests.recoverInterrupted()
    const hierarchy = new IssueHierarchyMutation(database, this.issueEvents)
    const lifecycle = new IssueLifecycleRepository(database, this.issueEvents)
    this.issues = new IssueRecordRepository(database, {
      events: this.issueEvents,
      hierarchy,
      lifecycle,
      deletion: new IssueDeleteRepository(database, this.issueEvents),
      external: new ExternalIssueRepository(database, this.issueEvents)
    })
    this.issueLinks = new IssueLinkRepository(database)
    this.searchIndex = new IssueSearchIndex(database)
    this.searchIndexWorker = new IssueSearchIndexWorker(this.searchIndex)
    this.stopSearchIndexListener = database.onFactsChanged((change) => {
      if (change.searchRevision !== change.indexedSearchRevision) {
        this.searchIndexWorker.schedule(change.hostPartitionKey)
      }
    })
    this.conversations = new ConversationRecordRepository(database, this.issueEvents)
    this.conversationIdentities = new ConversationIdentityRepository(database)
    this.conversationLaunchClaims = new ConversationLaunchClaimRepository(database)
    this.conversationAllocator = new ConversationAllocator(
      database,
      this.conversations,
      this.conversationIdentities,
      this.conversationLaunchClaims
    )
    const roundRetention = new RoundRecordRetention(database, roundRetentionLimits)
    this.roundRetentionWorker = new RoundRecordRetentionWorker(roundRetention)
    this.rounds = new RoundRecordRepository(
      database,
      roundRetention,
      () => this.roundRetentionWorker.scheduleIfNeeded(),
      lifecycle
    )
    for (const row of database
      .prepare(
        `SELECT host_partition_key
         FROM issue_host_state
         WHERE search_index_dirty = 1
            OR search_revision <> indexed_search_revision`
      )
      .all() as Array<{ host_partition_key: Parameters<IssueSearchIndexWorker['schedule']>[0] }>) {
      this.searchIndexWorker.schedule(row.host_partition_key)
    }
  }

  static open(options: OpenIssueDatabaseOptions): IssueRepository {
    return new IssueRepository(
      IssueDatabase.open(options),
      options.roundRetentionLimits
    )
  }

  close(): void {
    this.stopSearchIndexListener()
    this.searchIndexWorker.close()
    this.roundRetentionWorker.close()
    this.database.close()
  }
}

export function issueMutationIdentity(
  callerFingerprint: string,
  mutationId: string
): IssueMutationIdentity {
  return { callerFingerprint, mutationId }
}
