import type { IssueNotificationNavigationTarget } from '../../shared/issues/notification-types'
import type { NotificationDispatchRequest } from '../../shared/notification-settings-types'

export function issueNotificationClickTarget(
  request: NotificationDispatchRequest
): IssueNotificationNavigationTarget | null {
  if (
    !request.executionHostId ||
    (!request.conversationId && !request.issueId && !request.roundRecordId)
  ) {
    return null
  }
  return {
    executionHostId: request.executionHostId,
    ...(request.conversationId
      ? { conversationId: request.conversationId }
      : {}),
    ...(request.issueId ? { issueId: request.issueId } : {}),
    ...(request.roundRecordId
      ? { roundRecordId: request.roundRecordId }
      : {}),
    ...(request.worktreeId ? { worktreeId: request.worktreeId } : {}),
    ...(request.paneKey ? { paneKey: request.paneKey } : {})
  }
}
