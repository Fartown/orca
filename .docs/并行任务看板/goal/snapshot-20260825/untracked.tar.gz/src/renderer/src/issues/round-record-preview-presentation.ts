import type {
  RoundRecordPreview,
  RoundRecordTextSummary
} from '../../../shared/issues/types'

export type RoundPreviewFieldKey =
  | 'pendingQuestion'
  | 'agentOutput'
  | 'userInput'

export type RoundPreviewField = {
  key: RoundPreviewFieldKey
  label: string
  value: RoundRecordTextSummary
}

const FIELD_DEFINITIONS: readonly Pick<
  RoundPreviewField,
  'key' | 'label'
>[] = [
  { key: 'pendingQuestion', label: 'Pending question' },
  { key: 'agentOutput', label: 'Agent output' },
  { key: 'userInput', label: 'User input' }
]

export function getRoundPreviewFields(
  round: RoundRecordPreview
): RoundPreviewField[] {
  return FIELD_DEFINITIONS.map(({ key, label }) => ({
    key,
    label,
    value: round[key]
  }))
}

export function getPrimaryRoundPreviewField(
  round: RoundRecordPreview
): RoundPreviewField {
  const fields = getRoundPreviewFields(round)
  return (
    fields.find(({ value }) => value.preview !== null) ??
    fields.find(
      ({ value }) =>
        value.completeness !== 'not-captured' || value.storage !== 'none'
    ) ??
    fields[1]
  )
}
