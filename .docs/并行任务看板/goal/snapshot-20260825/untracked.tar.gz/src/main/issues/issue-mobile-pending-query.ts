import type {
  IssueMobilePendingEntry,
  IssueMobilePendingPage
} from '../../shared/issues/mobile-types'
import type { IssueRecord } from '../../shared/issues/types'
import type { IssueAuthorityRoute } from './issue-authority-route'
import { issueAuthorityDescriptor } from './issue-authority-route'
import type { IssueDatabase } from './issue-database'
import { encodeIssueQueryCursor, readTimelineCursor } from './issue-query-cursor'
import {
  readConversationNavigationTargets,
  readHostRevisions,
  toRoundRecordPreview
} from './issue-query-projections'
import {
  issueFromRow,
  roundRecordFromRow,
  type IssueRow,
  type RoundRecordRow
} from './issue-row-mappers'

export class IssueMobilePendingQuery {
  constructor(private readonly database: IssueDatabase) {}

  list(
    route: IssueAuthorityRoute,
    params: { cursor?: string; limit: number }
  ): IssueMobilePendingPage {
    return this.database.readTransaction(() => {
      const revisions = readHostRevisions(this.database, route.hostPartitionKey)
      const cursor = params.cursor
        ? readTimelineCursor(params.cursor, 'mobile-pending', revisions.factsRevision)
        : null
      const limit = Math.max(1, params.limit)
      const rows = this.database
        .prepare(
          `SELECT round.*
           FROM round_record_effective_state round
           JOIN conversations conversation ON conversation.id = round.conversation_id
           WHERE conversation.host_partition_key = ?
             AND round.kind = 'waiting'
             AND round.effective_resolved_at IS NULL
             AND (
               ? IS NULL OR round.occurred_at < ? OR
               (round.occurred_at = ? AND round.id < ?)
             )
           ORDER BY round.occurred_at DESC, round.id DESC
           LIMIT ?`
        )
        .all(
          route.hostPartitionKey,
          cursor?.occurredAt ?? null,
          cursor?.occurredAt ?? null,
          cursor?.occurredAt ?? null,
          cursor?.id ?? null,
          limit + 1
        ) as RoundRecordRow[]
      const pageRows = rows.slice(0, limit)
      const last = pageRows.at(-1)
      return {
        authority: issueAuthorityDescriptor(this.database, route),
        snapshotFactsRevision: revisions.factsRevision,
        entries: this.readEntries(route, pageRows),
        nextCursor:
          rows.length > pageRows.length && last
            ? encodeIssueQueryCursor({
                v: 1,
                kind: 'mobile-pending',
                factsRevision: revisions.factsRevision,
                occurredAt: last.occurred_at,
                id: last.id
              })
            : null
      }
    })
  }

  private readEntries(
    route: IssueAuthorityRoute,
    rows: readonly RoundRecordRow[]
  ): IssueMobilePendingEntry[] {
    const conversations = readConversationNavigationTargets(
      this.database,
      route,
      rows.map((row) => row.conversation_id)
    )
    const issues = this.readIssues(
      [...conversations.values()].flatMap((conversation) =>
        conversation.issueId ? [conversation.issueId] : []
      )
    )
    return rows.flatMap((row) => {
      const conversation = conversations.get(row.conversation_id)
      if (!conversation) {
        return []
      }
      const issue = conversation.issueId
        ? (issues.get(conversation.issueId) ?? null)
        : null
      return [
        {
          round: toRoundRecordPreview(roundRecordFromRow(row)),
          conversation,
          issue: issue ? toIssueDisplayProjection(issue) : null
        }
      ]
    })
  }

  private readIssues(ids: readonly string[]): Map<string, IssueRecord> {
    const uniqueIds = [...new Set(ids)]
    if (uniqueIds.length === 0) {
      return new Map()
    }
    const placeholders = uniqueIds.map(() => '?').join(', ')
    const rows = this.database
      .prepare(`SELECT * FROM issues WHERE id IN (${placeholders})`)
      .all(...uniqueIds) as IssueRow[]
    return new Map(rows.map((row) => [row.id, issueFromRow(row)]))
  }
}

function toIssueDisplayProjection(issue: IssueRecord) {
  return {
    id: issue.id,
    title:
      issue.source.kind === 'local'
        ? (issue.localTitle ?? '')
        : issue.source.titleSnapshot,
    typeLabel: issue.typeLabel,
    state: issue.state
  }
}
