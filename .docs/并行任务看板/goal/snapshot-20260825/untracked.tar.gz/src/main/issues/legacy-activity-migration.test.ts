import { afterEach, describe, expect, it } from 'vitest'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { LegacyActivityMigration } from './legacy-activity-migration'
import { IssueRepository, issueMutationIdentity } from './issue-repository'

const repositories: IssueRepository[] = []
let sequence = 0

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-legacy-activity-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function identity(label: string) {
  sequence += 1
  return issueMutationIdentity('legacy-activity-test', `${label}-${sequence}`)
}

function seedConversation(
  repository: IssueRepository,
  label: string,
  executionHostId: 'local' | `ssh:${string}`,
  paneKey: string
) {
  const conversation = repository.conversations.create({
    identity: identity(`conversation-${label}`),
    input: {
      executionHostId,
      workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${label}` },
      workspaceSnapshot: { name: label, path: `/workspace/${label}` },
      agent: 'codex'
    }
  })
  repository.conversationLaunchClaims.create({
    conversationId: conversation.id,
    launchToken: `launch-${label}`,
    paneKey,
    createdAt: 10,
    expiresAt: 10_000
  })
  return conversation
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  sequence = 0
})

describe('LegacyActivityMigration', () => {
  it('creates one truncated Round Record and maps pane acknowledgement only to readAt', () => {
    const repository = openRepository('read')
    const conversation = seedConversation(
      repository,
      'local',
      'local',
      'tab:local-pane'
    )
    const migration = new LegacyActivityMigration(repository)
    const input = {
      executionHostId: 'local' as const,
      mutationId: 'legacy-read-once',
      entries: [
        {
          legacyEventId: 'agent:tab:local-pane:done:100',
          paneKey: 'tab:local-pane',
          state: 'done' as const,
          occurredAt: 100,
          acknowledgedAt: 120,
          userInputPreview: 'Implement the fix',
          agentOutputPreview: 'Finished the implementation'
        }
      ]
    }

    const first = migration.migrate(input, 'desktop-profile')
    const replay = migration.migrate(input, 'desktop-profile')
    const rounds = repository.rounds.list({
      conversationId: conversation.id
    })

    expect(replay).toEqual(first)
    expect(first.unresolvedLegacyEventIds).toEqual([])
    expect(rounds).toHaveLength(1)
    expect(rounds[0]).toMatchObject({
      kind: 'completion',
      stateSource: 'reconciled',
      occurredAt: 100,
      readAt: 120,
      resolvedAt: null,
      resolution: null,
      userInput: {
        completeness: 'truncated',
        storage: 'preview',
        preview: 'Implement the fix'
      },
      agentOutput: {
        completeness: 'truncated',
        storage: 'preview',
        preview: 'Finished the implementation'
      }
    })
  })

  it('applies acknowledgement that arrives after the legacy Round was created', () => {
    const repository = openRepository('late-read')
    const conversation = seedConversation(
      repository,
      'late-read',
      'local',
      'tab:late-read-pane'
    )
    const migration = new LegacyActivityMigration(repository)
    const entry = {
      legacyEventId: 'agent:tab:late-read-pane:done:100',
      paneKey: 'tab:late-read-pane',
      state: 'done' as const,
      occurredAt: 100,
      acknowledgedAt: null,
      agentOutputPreview: 'Finished'
    }

    migration.migrate(
      {
        executionHostId: 'local',
        mutationId: 'legacy-late-read-first',
        entries: [entry]
      },
      'desktop-profile'
    )
    migration.migrate(
      {
        executionHostId: 'local',
        mutationId: 'legacy-late-read-second',
        entries: [{ ...entry, acknowledgedAt: 150 }]
      },
      'desktop-profile'
    )

    const rounds = repository.rounds.list({
      conversationId: conversation.id
    })
    expect(rounds).toHaveLength(1)
    expect(rounds[0]).toMatchObject({
      readAt: 150,
      resolvedAt: null,
      resolution: null
    })
  })

  it('upgrades the same legacy event when a later snapshot carries a longer preview', () => {
    const repository = openRepository('preview-upgrade')
    const conversation = seedConversation(
      repository,
      'preview-upgrade',
      'local',
      'tab:preview-upgrade-pane'
    )
    const migration = new LegacyActivityMigration(repository)
    const entry = {
      legacyEventId: 'agent:tab:preview-upgrade-pane:done:100',
      paneKey: 'tab:preview-upgrade-pane',
      state: 'done' as const,
      occurredAt: 100,
      acknowledgedAt: null
    }

    migration.migrate(
      {
        executionHostId: 'local',
        mutationId: 'legacy-preview-upgrade-first',
        entries: [{ ...entry, agentOutputPreview: 'Finished' }]
      },
      'desktop-profile'
    )
    migration.migrate(
      {
        executionHostId: 'local',
        mutationId: 'legacy-preview-upgrade-second',
        entries: [
          {
            ...entry,
            agentOutputPreview: 'Finished with the complete migration summary'
          }
        ]
      },
      'desktop-profile'
    )

    const rounds = repository.rounds.list({
      conversationId: conversation.id
    })
    expect(rounds).toHaveLength(1)
    expect(rounds[0]?.agentOutput).toMatchObject({
      completeness: 'truncated',
      storage: 'preview',
      preview: 'Finished with the complete migration summary'
    })
  })

  it('keeps unresolved panes retryable and never maps a claim from another host', () => {
    const repository = openRepository('partition')
    seedConversation(
      repository,
      'remote',
      'ssh:builder',
      'tab:shared-pane'
    )
    const migration = new LegacyActivityMigration(repository)
    const first = migration.migrate(
      {
        executionHostId: 'local',
        mutationId: 'legacy-unresolved-first',
        entries: [
          {
            legacyEventId: 'agent:tab:shared-pane:waiting:200',
            paneKey: 'tab:shared-pane',
            state: 'waiting',
            occurredAt: 200,
            acknowledgedAt: null,
            pendingQuestionPreview: 'Approve the command?'
          }
        ]
      },
      'desktop-profile'
    )

    expect(first.migrated).toEqual([])
    expect(first.unresolvedLegacyEventIds).toEqual([
      'agent:tab:shared-pane:waiting:200'
    ])

    const localConversation = seedConversation(
      repository,
      'local',
      'local',
      'tab:shared-pane'
    )
    const retried = migration.migrate(
      {
        executionHostId: 'local',
        mutationId: 'legacy-unresolved-retry',
        entries: first.unresolvedLegacyEventIds.map((legacyEventId) => ({
          legacyEventId,
          paneKey: 'tab:shared-pane',
          state: 'waiting' as const,
          occurredAt: 200,
          acknowledgedAt: null,
          pendingQuestionPreview: 'Approve the command?'
        }))
      },
      'desktop-profile'
    )
    const round = repository.rounds.list({
      conversationId: localConversation.id
    })[0]

    expect(retried.unresolvedLegacyEventIds).toEqual([])
    expect(retried.migrated).toEqual([
      expect.objectContaining({
        legacyEventId: 'agent:tab:shared-pane:waiting:200',
        conversationId: localConversation.id,
        roundRecordId: round.id
      })
    ])
    expect(round).toMatchObject({
      kind: 'waiting',
      readAt: null,
      resolvedAt: null,
      pendingQuestion: {
        completeness: 'truncated',
        storage: 'preview',
        preview: 'Approve the command?'
      }
    })
  })
})
