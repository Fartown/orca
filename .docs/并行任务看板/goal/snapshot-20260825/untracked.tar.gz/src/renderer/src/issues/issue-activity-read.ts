import type { ExecutionHostId } from '../../../shared/execution-host'
import type { IssueMutationResult } from '../../../shared/issues/types'
import { createBrowserUuid } from '../lib/browser-uuid'
import { markIssueRoundsRead } from './issue-mutations'

export type IssueActivityReadTarget = {
  routeExecutionHostId: ExecutionHostId
  roundRecordIds: readonly string[]
}

export type IssueActivityReadDependencies = {
  markRead: (input: {
    executionHostId: ExecutionHostId
    mutationId: string
    roundRecordIds: string[]
    readAt: number
  }) => Promise<IssueMutationResult>
  patchRead: (
    routeExecutionHostId: ExecutionHostId,
    roundRecordIds: readonly string[],
    readAt: number
  ) => void
  createMutationId: () => string
}

export async function markIssueActivityRead(
  targets: readonly IssueActivityReadTarget[],
  readAt: number,
  dependencies: IssueActivityReadDependencies
): Promise<void> {
  const grouped = groupReadTargets(targets)
  await Promise.all(
    [...grouped].map(async ([routeExecutionHostId, ids]) => {
      const roundRecordIds = [...ids]
      await dependencies.markRead({
        executionHostId: routeExecutionHostId,
        mutationId: dependencies.createMutationId(),
        roundRecordIds,
        readAt
      })
      dependencies.patchRead(routeExecutionHostId, roundRecordIds, readAt)
    })
  )
}

export function createIssueActivityReadDependencies(
  patchRead: IssueActivityReadDependencies['patchRead']
): IssueActivityReadDependencies {
  return {
    markRead: markIssueRoundsRead,
    patchRead,
    createMutationId: createBrowserUuid
  }
}

function groupReadTargets(
  targets: readonly IssueActivityReadTarget[]
): Map<ExecutionHostId, Set<string>> {
  const grouped = new Map<ExecutionHostId, Set<string>>()
  for (const target of targets) {
    if (target.roundRecordIds.length === 0) {
      continue
    }
    const ids = grouped.get(target.routeExecutionHostId) ?? new Set<string>()
    for (const id of target.roundRecordIds) {
      ids.add(id)
    }
    grouped.set(target.routeExecutionHostId, ids)
  }
  return grouped
}
