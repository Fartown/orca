import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef
} from 'react'
import { Search } from 'lucide-react'
import { useVirtualizer } from '@tanstack/react-virtual'
import { useStore, type StoreApi } from 'zustand'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { useSidebarHostScopeOptions } from '../use-sidebar-host-scope-options'
import type { ExecutionHostId } from '../../../../../shared/execution-host'
import type {
  ConversationSummary,
  IssueListFilter
} from '../../../../../shared/issues/types'
import type { IssueAuthorityDescriptor } from '../../../../../shared/issues/types'
import {
  connectIssuesDomainEvents,
  issuesDomainStore,
  type IssuesDomainPartition,
  type IssuesDomainState
} from '../../../issues/issues-domain-store'
import { buildIssueRows } from './build-issue-rows'
import { buildIssueSearchRows } from './build-issue-search-rows'
import type {
  IssueSidebarPartition,
  IssueSidebarRow
} from './issue-row-types'
import { IssueVirtualRow } from './issue-virtual-row'
import type { SidebarHostOption } from '../sidebar-host-options'
import { openIssueDetail } from '../../../issues/issue-navigation'
import { openIssueConversation } from '../../../issues/issue-conversation-navigation'

type IssueSidebarProps = {
  onOpenIssue?: (
    authority: IssueAuthorityDescriptor,
    issueId: string
  ) => void
  onOpenConversation?: (
    routeExecutionHostId: ExecutionHostId,
    conversation: ConversationSummary
  ) => void
}

export default function IssueSidebar(
  props: IssueSidebarProps
): React.JSX.Element {
  const { hostOptions } = useSidebarHostScopeOptions()
  const onOpenIssue =
    props.onOpenIssue ??
    ((authority: IssueAuthorityDescriptor, issueId: string) =>
      openIssueDetail({ authority, issueId }))
  const onOpenConversation =
    props.onOpenConversation ??
    ((routeExecutionHostId: ExecutionHostId, conversation: ConversationSummary) => {
      void openIssueConversation({ routeExecutionHostId, conversation })
    })
  return (
    <IssueSidebarView
      {...props}
      onOpenIssue={onOpenIssue}
      onOpenConversation={onOpenConversation}
      hostOptions={hostOptions}
      store={issuesDomainStore}
    />
  )
}

export function IssueSidebarView({
  hostOptions,
  store,
  onOpenIssue,
  onOpenConversation,
  eventTarget = window
}: IssueSidebarProps & {
  onOpenIssue: NonNullable<IssueSidebarProps['onOpenIssue']>
  hostOptions: readonly SidebarHostOption[]
  store: StoreApi<IssuesDomainState>
  eventTarget?: Pick<EventTarget, 'addEventListener' | 'removeEventListener'>
}): React.JSX.Element {
  const preferences = useStore(store, (state) => state.preferences)
  const partitionsByRoute = useStore(
    store,
    (state) => state.partitionsByRoute
  )
  const detailLoadsByKey = useStore(
    store,
    (state) => state.detailLoadsByKey
  )
  const searchLoadsByRoute = useStore(
    store,
    (state) => state.searchLoadsByRoute
  )
  const scrollRef = useRef<HTMLDivElement>(null)
  const scrollWriteTimerRef = useRef<number | null>(null)
  const hostIds = useMemo(
    () => hostOptions.map((host) => host.id),
    [hostOptions]
  )
  const hostLabelById = useMemo(
    () => new Map(hostOptions.map((host) => [host.id, host.label])),
    [hostOptions]
  )
  const partitions = useMemo(
    () =>
      hostIds.map(
        (routeExecutionHostId) =>
          partitionsByRoute[routeExecutionHostId] ??
          emptySidebarPartition(routeExecutionHostId)
      ),
    [hostIds, partitionsByRoute]
  )
  const searchedHostIds = useMemo(
    () =>
      preferences.selectedRouteExecutionHostId
        ? [preferences.selectedRouteExecutionHostId]
        : hostIds,
    [hostIds, preferences.selectedRouteExecutionHostId]
  )
  const rows = useMemo(() => {
    if (preferences.searchQuery.trim()) {
      return buildIssueSearchRows({
        routeExecutionHostIds: searchedHostIds,
        partitionsByRoute,
        searchLoadsByRoute,
        typeFilter: preferences.typeFilter
      })
    }
    return buildIssueRows({
      partitions,
      filter: preferences.filter,
      collapsedIssueIds: new Set(preferences.collapsedIssueIds),
      selectedRouteExecutionHostId:
        preferences.selectedRouteExecutionHostId,
      typeFilter: preferences.typeFilter
    })
  }, [
    partitions,
    partitionsByRoute,
    preferences,
    searchLoadsByRoute,
    searchedHostIds
  ])
  const typeLabels = useMemo(
    () =>
      [...new Set(
        partitions.flatMap((partition) =>
          partition.issues.flatMap((issue) =>
            issue.typeLabel ? [issue.typeLabel] : []
          )
        )
      )].sort((left, right) => left.localeCompare(right)),
    [partitions]
  )
  const virtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: (index) => estimateIssueRowSize(rows[index]),
    getItemKey: (index) => rows[index]?.id ?? index,
    overscan: 8,
    initialOffset: () => preferences.sidebarScrollOffset,
    initialRect: { width: 300, height: 500 }
  })

  useEffect(() => {
    void store.getState().hydrate()
    return connectIssuesDomainEvents(store, eventTarget)
  }, [eventTarget, store])

  useEffect(() => {
    void store.getState().setVisibleRoutes(hostIds)
  }, [hostIds, store])

  useEffect(() => {
    const query = preferences.searchQuery.trim()
    if (!query) {
      store.getState().clearSearch()
      return
    }
    for (const routeExecutionHostId of searchedHostIds) {
      void store.getState().search(routeExecutionHostId, query)
    }
  }, [preferences.searchQuery, searchedHostIds, store])

  useEffect(
    () => () => {
      if (scrollWriteTimerRef.current !== null) {
        window.clearTimeout(scrollWriteTimerRef.current)
      }
      const scrollOffset = scrollRef.current?.scrollTop
      if (scrollOffset !== undefined) {
        store.getState().setSidebarScrollOffset(scrollOffset)
      }
    },
    [store]
  )

  const handleScroll = useCallback(() => {
    if (scrollWriteTimerRef.current !== null) {
      window.clearTimeout(scrollWriteTimerRef.current)
    }
    scrollWriteTimerRef.current = window.setTimeout(() => {
      scrollWriteTimerRef.current = null
      store
        .getState()
        .setSidebarScrollOffset(scrollRef.current?.scrollTop ?? 0)
    }, 150)
  }, [store])

  const toggleIssue = useCallback(
    (row: Extract<IssueSidebarRow, { type: 'issue' }>) => {
      const state = store.getState()
      const partition = state.partitionsByRoute[row.routeExecutionHostId]
      const detailLoaded =
        partition !== undefined &&
        Object.hasOwn(partition.detailsByIssueId, row.issue.id)
      if (row.issue.directConversationCount > 0 && !detailLoaded) {
        if (!row.expanded) {
          state.toggleCollapsedIssue(row.issue.id)
        }
        void state.loadDetail(row.routeExecutionHostId, row.issue.id)
        return
      }
      state.toggleCollapsedIssue(row.issue.id)
    },
    [store]
  )

  const selectIssue = useCallback(
    (row: Extract<IssueSidebarRow, { type: 'issue' }>) => {
      const state = store.getState()
      state.selectIssue(row.routeExecutionHostId, row.issue.id)
      const key = `${row.routeExecutionHostId}\0${row.issue.id}`
      if (!detailLoadsByKey[key]) {
        void state.loadDetail(row.routeExecutionHostId, row.issue.id)
      }
      onOpenIssue(row.authority, row.issue.id)
    },
    [detailLoadsByKey, onOpenIssue, store]
  )

  const toggleUnassigned = useCallback(
    (row: Extract<IssueSidebarRow, { type: 'unassigned-summary' }>) => {
      const state = store.getState()
      const partition = state.partitionsByRoute[row.routeExecutionHostId]
      if (!hasLoadedUnassigned(partition)) {
        void state.loadUnassigned(row.routeExecutionHostId)
        return
      }
      state.toggleCollapsedIssue(row.id)
    },
    [store]
  )

  const selectConversation = useCallback(
    (row: Extract<IssueSidebarRow, { type: 'conversation' }>) => {
      if (row.issueId) {
        store.getState().selectIssue(row.routeExecutionHostId, row.issueId)
      }
      const openConversation =
        onOpenConversation ??
        ((routeExecutionHostId: ExecutionHostId, conversation: ConversationSummary) => {
          void openIssueConversation({ routeExecutionHostId, conversation })
        })
      openConversation(row.routeExecutionHostId, row.conversation)
    },
    [onOpenConversation, store]
  )
  const selectSearchResult = useCallback(
    (row: Extract<IssueSidebarRow, { type: 'search-result' }>) => {
      const issueId = row.match.issueId ?? row.issue?.id
      if (!issueId) {
        return
      }
      store.getState().selectIssue(row.routeExecutionHostId, issueId)
      onOpenIssue(row.authority, issueId)
    },
    [onOpenIssue, store]
  )

  return (
    <div className="flex min-h-0 flex-1 flex-col" data-issue-sidebar="">
      <IssueSidebarFilters
        filter={preferences.filter}
        searchQuery={preferences.searchQuery}
        typeFilter={preferences.typeFilter}
        selectedRouteExecutionHostId={
          preferences.selectedRouteExecutionHostId
        }
        hostOptions={hostOptions}
        typeLabels={typeLabels}
        onFilterChange={(filter) => store.getState().setFilter(filter)}
        onSearchChange={(query) => store.getState().setSearchQuery(query)}
        onTypeFilterChange={(typeLabel) =>
          store.getState().setTypeFilter(typeLabel)
        }
        onHostChange={(hostId) =>
          store
            .getState()
            .selectIssue(hostId === 'all' ? null : hostId, null)
        }
      />
      <div
        ref={scrollRef}
        className="scrollbar-sleek min-h-0 flex-1 overflow-y-auto px-1"
        onScroll={handleScroll}
      >
        <div
          className="relative w-full"
          style={{ height: `${virtualizer.getTotalSize()}px` }}
        >
          {virtualizer.getVirtualItems().map((virtualRow) => {
            const row = rows[virtualRow.index]
            if (!row) {
              return null
            }
            const partition = partitionsByRoute[row.routeExecutionHostId]
            return (
              <div
                key={row.id}
                ref={virtualizer.measureElement}
                data-index={virtualRow.index}
                className="absolute left-0 top-0 w-full"
                style={{
                  transform: `translateY(${virtualRow.start}px)`
                }}
              >
                <IssueVirtualRow
                  row={row}
                  hostLabelById={hostLabelById}
                  selectedIssueId={preferences.selectedIssueId}
                  unassignedLoaded={hasLoadedUnassigned(partition)}
                  onToggleIssue={toggleIssue}
                  onSelectIssue={selectIssue}
                  onToggleUnassigned={toggleUnassigned}
                  onSelectConversation={selectConversation}
                  onSelectSearchResult={selectSearchResult}
                />
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function IssueSidebarFilters({
  filter,
  searchQuery,
  typeFilter,
  selectedRouteExecutionHostId,
  hostOptions,
  typeLabels,
  onFilterChange,
  onSearchChange,
  onTypeFilterChange,
  onHostChange
}: {
  filter: IssueListFilter
  searchQuery: string
  typeFilter: string | null
  selectedRouteExecutionHostId: ExecutionHostId | null
  hostOptions: readonly SidebarHostOption[]
  typeLabels: readonly string[]
  onFilterChange: (filter: IssueListFilter) => void
  onSearchChange: (query: string) => void
  onTypeFilterChange: (typeLabel: string | null) => void
  onHostChange: (hostId: ExecutionHostId | 'all') => void
}): React.JSX.Element {
  return (
    <div className="grid shrink-0 gap-1.5 border-b border-border/60 px-2 pb-2">
      <div className="grid grid-cols-3 gap-1">
        {(
          [
            ['all', 'All'],
            ['needs-me', 'Needs me'],
            ['archived', 'Archived']
          ] as const
        ).map(([value, label]) => (
          <Button
            key={value}
            type="button"
            size="xs"
            variant={filter === value ? 'secondary' : 'ghost'}
            aria-pressed={filter === value}
            onClick={() => onFilterChange(value)}
          >
            {label}
          </Button>
        ))}
      </div>
      <div className="relative">
        <Search className="pointer-events-none absolute left-2 top-2 size-3 text-muted-foreground" />
        <Input
          type="search"
          className="h-7 pl-7 text-xs"
          value={searchQuery}
          aria-label="Search Issues"
          placeholder="Search Issues"
          onChange={(event) => onSearchChange(event.target.value)}
        />
      </div>
      {(hostOptions.length > 1 || typeLabels.length > 0) && (
        <div className="flex gap-1.5">
          {hostOptions.length > 1 ? (
            <Select
              value={selectedRouteExecutionHostId ?? 'all'}
              onValueChange={(value) =>
                onHostChange(value as ExecutionHostId | 'all')
              }
            >
              <SelectTrigger
                size="sm"
                className="h-7 min-w-0 flex-1 text-xs"
                aria-label="Filter Issues by host"
              >
                <SelectValue placeholder="All hosts" />
              </SelectTrigger>
              <SelectContent align="start">
                <SelectItem value="all">All hosts</SelectItem>
                {hostOptions.map((host) => (
                  <SelectItem key={host.id} value={host.id}>
                    {host.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : null}
          {typeLabels.length > 0 ? (
            <Select
              value={typeFilter ?? 'all'}
              onValueChange={(value) =>
                onTypeFilterChange(value === 'all' ? null : value)
              }
            >
              <SelectTrigger
                size="sm"
                className="h-7 min-w-0 flex-1 text-xs"
                aria-label="Filter Issues by type"
              >
                <SelectValue placeholder="All types" />
              </SelectTrigger>
              <SelectContent align="start">
                <SelectItem value="all">All types</SelectItem>
                {typeLabels.map((typeLabel) => (
                  <SelectItem key={typeLabel} value={typeLabel}>
                    {typeLabel}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : null}
        </div>
      )}
    </div>
  )
}

function emptySidebarPartition(
  routeExecutionHostId: ExecutionHostId
): IssueSidebarPartition {
  return {
    routeExecutionHostId,
    status: 'idle',
    authority: null,
    issues: [],
    detailsByIssueId: {},
    unassignedConversations: [],
    error: null
  }
}

function hasLoadedUnassigned(
  partition: IssuesDomainPartition | undefined
): boolean {
  if (!partition?.unassignedSummary?.conversationCount) {
    return false
  }
  return partition.unassignedConversations.length > 0
}

function estimateIssueRowSize(row: IssueSidebarRow | undefined): number {
  switch (row?.type) {
    case 'empty':
      return 80
    case 'search-empty':
      return 80
    case 'search-result':
      return 56
    case 'unassigned-summary':
    case 'issue':
      return 32
    case 'host-state':
    case 'conversation':
    case 'search-status':
    case 'search-group':
      return 28
    case 'workspace-header':
      return 24
    case undefined:
      return 28
  }
}
