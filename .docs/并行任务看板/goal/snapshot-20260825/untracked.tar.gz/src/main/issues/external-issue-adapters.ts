import type { IssueRecord } from '../../shared/issues/types'
import type { TaskProvider } from '../../shared/task-providers'
import type { TaskSourceContext } from '../../shared/task-source-context'
import type { IssueInfo } from '../../shared/github/pull-request-types'
import type { GitLabIssueInfo } from '../../shared/gitlab-types'
import type { JiraIssue } from '../../shared/jira-types'
import type { LinearIssue } from '../../shared/linear/issue-types'
import { getIssue as getGitHubIssue } from '../github/issues'
import { getIssue as getGitLabIssue } from '../gitlab/issues'
import { getIssue as getJiraIssue } from '../jira/issues'
import { getIssue as getLinearIssue } from '../linear/issues'
import {
  externalIssueSourceScopeKey,
  normalizeExternalIssueSourceContext
} from './external-issue-source-identity'
import { hostPartitionForExecutionHost } from './issue-host-partition'
import type { IssueRecordRepository } from './issue-record-repository'
import { IssueRepositoryError } from './issue-repository-error'
import type {
  ExternalIssueSnapshot,
  IssueMutationParams,
  TrackExternalIssueInput
} from './issue-repository-types'

export type ExternalIssueReference = {
  provider: TaskProvider
  sourceContext: TaskSourceContext
  hostPartitionKey: IssueRecord['hostPartitionKey']
  externalId: string
  number?: number
  identifier?: string
}

export type ExternalIssueAdapter = {
  provider: TaskProvider
  resolveSelection(
    input: unknown,
    sourceContext: TaskSourceContext
  ): Promise<ExternalIssueSnapshot | null>
  refresh(reference: ExternalIssueReference): Promise<ExternalIssueSnapshot | null>
}

export type ResolvedExternalIssueSelection = {
  provider: TaskProvider
  sourceContext: TaskSourceContext
  sourceScopeKey: string
  snapshot: ExternalIssueSnapshot
}

export type ExternalIssueRepositoryExecution = {
  repoPath: string
  connectionId?: string | null
}

export type ExternalIssueRepositoryExecutionResolver = (
  sourceContext: TaskSourceContext
) => Promise<ExternalIssueRepositoryExecution | null>

export type ExternalIssueProviderClients = {
  github: (
    repoPath: string,
    issueNumber: number,
    connectionId?: string | null
  ) => Promise<IssueInfo | null>
  gitlab: (
    repoPath: string,
    issueNumber: number,
    connectionId?: string | null
  ) => Promise<GitLabIssueInfo | null>
  linear: (id: string, workspaceId?: string | null) => Promise<LinearIssue | null>
  jira: (key: string, siteId?: string | null) => Promise<JiraIssue | null>
}

export type TrackExternalIssueSelectionInput = Omit<
  TrackExternalIssueInput,
  'provider' | 'snapshot'
> & {
  selection: unknown
}

export class ExternalIssueAdapterRegistry {
  private readonly adapters = new Map<TaskProvider, ExternalIssueAdapter>()

  constructor(adapters: readonly ExternalIssueAdapter[]) {
    for (const adapter of adapters) {
      if (this.adapters.has(adapter.provider)) {
        throw new Error(`Duplicate External Issue adapter for ${adapter.provider}.`)
      }
      this.adapters.set(adapter.provider, adapter)
    }
  }

  async resolveSelection(params: {
    executionHostId: TrackExternalIssueInput['executionHostId']
    sourceContext: TaskSourceContext
    selection: unknown
  }): Promise<ResolvedExternalIssueSelection> {
    const hostPartitionKey = hostPartitionForExecutionHost(params.executionHostId)
    const sourceContext = normalizeExternalIssueSourceContext({
      provider: params.sourceContext.provider,
      sourceContext: params.sourceContext,
      hostPartitionKey
    })
    const adapter = this.require(sourceContext.provider)
    const snapshot = await adapter.resolveSelection(params.selection, sourceContext)
    if (!snapshot) {
      throw unavailableError(sourceContext.provider)
    }
    return {
      provider: sourceContext.provider,
      sourceContext,
      sourceScopeKey: externalIssueSourceScopeKey({
        provider: sourceContext.provider,
        sourceContext,
        hostPartitionKey
      }),
      snapshot
    }
  }

  refresh(reference: ExternalIssueReference): Promise<ExternalIssueSnapshot | null> {
    return this.require(reference.provider).refresh(reference)
  }

  private require(provider: TaskProvider): ExternalIssueAdapter {
    const adapter = this.adapters.get(provider)
    if (!adapter) {
      throw new IssueRepositoryError(
        'external_issue_source_invalid',
        `No External Issue adapter is registered for ${provider}.`
      )
    }
    return adapter
  }
}

export class ExternalIssueTrackingService {
  constructor(
    private readonly issues: IssueRecordRepository,
    private readonly adapters: ExternalIssueAdapterRegistry
  ) {}

  async track(params: IssueMutationParams<TrackExternalIssueSelectionInput>): Promise<IssueRecord> {
    let resolved: ResolvedExternalIssueSelection
    try {
      resolved = await this.adapters.resolveSelection(params.input)
    } catch (error) {
      if (error instanceof IssueRepositoryError) {
        throw error
      }
      throw unavailableError(params.input.sourceContext.provider, error)
    }
    return this.issues.trackExternal({
      identity: params.identity,
      input: {
        executionHostId: params.input.executionHostId,
        provider: resolved.provider,
        sourceContext: resolved.sourceContext,
        snapshot: resolved.snapshot,
        ...(params.input.refreshAttemptedAt === undefined
          ? {}
          : { refreshAttemptedAt: params.input.refreshAttemptedAt }),
        ...(params.input.parentId === undefined ? {} : { parentId: params.input.parentId }),
        ...(params.input.typeLabel === undefined ? {} : { typeLabel: params.input.typeLabel }),
        ...(params.input.note === undefined ? {} : { note: params.input.note })
      }
    })
  }

  async refresh(params: {
    identity: IssueMutationParams<never>['identity']
    issueId: string
    attemptedAt: number
  }): Promise<IssueRecord> {
    const issue = this.issues.get(params.issueId)
    if (!issue) {
      throw new IssueRepositoryError('issue_not_found', `Issue ${params.issueId} was not found.`)
    }
    if (issue.source.kind !== 'external' || !issue.source.sourceContext) {
      throw new IssueRepositoryError(
        'external_issue_source_invalid',
        `Issue ${params.issueId} is missing an external source context.`
      )
    }
    try {
      const snapshot = await this.adapters.refresh({
        provider: issue.source.provider,
        sourceContext: issue.source.sourceContext,
        hostPartitionKey: issue.hostPartitionKey,
        externalId: issue.source.externalId,
        ...(issue.source.number === undefined ? {} : { number: issue.source.number }),
        ...(issue.source.identifier === undefined ? {} : { identifier: issue.source.identifier })
      })
      if (!snapshot) {
        return this.recordUnavailable(params, 'Provider Issue was not found.')
      }
      return this.issues.refreshExternal({
        identity: params.identity,
        input: {
          id: issue.id,
          snapshot,
          attemptedAt: params.attemptedAt
        }
      })
    } catch (error) {
      if (error instanceof IssueRepositoryError) {
        throw error
      }
      return this.recordUnavailable(params, errorMessage(error))
    }
  }

  private recordUnavailable(
    params: {
      identity: IssueMutationParams<never>['identity']
      issueId: string
      attemptedAt: number
    },
    error: string
  ): IssueRecord {
    return this.issues.failExternalRefresh({
      identity: params.identity,
      input: {
        id: params.issueId,
        attemptedAt: params.attemptedAt,
        error,
        availability: 'unavailable'
      }
    })
  }
}

export function createExternalIssueAdapterRegistry(options: {
  resolveRepositoryExecution: ExternalIssueRepositoryExecutionResolver
  clients?: Partial<ExternalIssueProviderClients>
}): ExternalIssueAdapterRegistry {
  const clients: ExternalIssueProviderClients = {
    github: getGitHubIssue,
    gitlab: getGitLabIssue,
    linear: getLinearIssue,
    jira: getJiraIssue,
    ...options.clients
  }
  return new ExternalIssueAdapterRegistry([
    gitAdapter('github', options.resolveRepositoryExecution, clients.github),
    gitAdapter('gitlab', options.resolveRepositoryExecution, clients.gitlab),
    linearAdapter(clients.linear),
    jiraAdapter(clients.jira)
  ])
}

function gitAdapter(
  provider: 'github' | 'gitlab',
  resolveRepositoryExecution: ExternalIssueRepositoryExecutionResolver,
  getIssue: ExternalIssueProviderClients['github'] | ExternalIssueProviderClients['gitlab']
): ExternalIssueAdapter {
  const resolve = async (
    selection: unknown,
    sourceContext: TaskSourceContext
  ): Promise<ExternalIssueSnapshot | null> => {
    const issueNumber = selectedIssueNumber(selection)
    const execution = await resolveRepositoryExecution(sourceContext)
    if (!execution) {
      throw new IssueRepositoryError(
        'external_issue_source_invalid',
        `No repository execution is available for ${provider}.`
      )
    }
    const issue = await getIssue(execution.repoPath, issueNumber, execution.connectionId)
    return issue
      ? {
          externalId: String(issue.number),
          number: issue.number,
          url: issue.url,
          title: issue.title,
          state: issue.state
        }
      : null
  }
  return {
    provider,
    resolveSelection: resolve,
    refresh: (reference) =>
      resolve(
        { issueNumber: reference.number ?? Number(reference.externalId) },
        reference.sourceContext
      )
  }
}

function linearAdapter(getIssue: ExternalIssueProviderClients['linear']): ExternalIssueAdapter {
  const resolve = async (
    selection: unknown,
    sourceContext: TaskSourceContext
  ): Promise<ExternalIssueSnapshot | null> => {
    const issue = await getIssue(
      selectedString(selection, 'issueId'),
      linearWorkspaceId(sourceContext)
    )
    return issue
      ? {
          externalId: issue.id,
          identifier: issue.identifier,
          url: issue.url,
          title: issue.title,
          state: issue.state.name
        }
      : null
  }
  return {
    provider: 'linear',
    resolveSelection: resolve,
    refresh: (reference) => resolve({ issueId: reference.externalId }, reference.sourceContext)
  }
}

function jiraAdapter(getIssue: ExternalIssueProviderClients['jira']): ExternalIssueAdapter {
  const resolve = async (
    selection: unknown,
    sourceContext: TaskSourceContext
  ): Promise<ExternalIssueSnapshot | null> => {
    const issue = await getIssue(selectedString(selection, 'issueKey'), jiraSiteId(sourceContext))
    return issue
      ? {
          externalId: issue.id,
          identifier: issue.key,
          url: issue.url,
          title: issue.title,
          state: issue.status.name
        }
      : null
  }
  return {
    provider: 'jira',
    resolveSelection: resolve,
    refresh: (reference) =>
      resolve({ issueKey: reference.identifier ?? reference.externalId }, reference.sourceContext)
  }
}

function selectedIssueNumber(input: unknown): number {
  const value = readSelectionValue(input, 'issueNumber')
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value <= 0) {
    throw new IssueRepositoryError(
      'external_issue_source_invalid',
      'External Issue selection requires a positive issue number.'
    )
  }
  return value
}

function selectedString(input: unknown, key: 'issueId' | 'issueKey'): string {
  const value = readSelectionValue(input, key)
  const trimmed = typeof value === 'string' ? value.trim() : ''
  if (!trimmed) {
    throw new IssueRepositoryError(
      'external_issue_source_invalid',
      `External Issue selection requires ${key}.`
    )
  }
  return trimmed
}

function readSelectionValue(input: unknown, key: string): unknown {
  return input && typeof input === 'object' ? (input as Record<string, unknown>)[key] : undefined
}

function linearWorkspaceId(sourceContext: TaskSourceContext): string | null {
  const identity = sourceContext.providerIdentity
  const value = identity?.provider === 'linear' ? identity.workspaceId : null
  return typeof value === 'string' && value.trim() ? value.trim() : null
}

function jiraSiteId(sourceContext: TaskSourceContext): string | null {
  const identity = sourceContext.providerIdentity
  const value = identity?.provider === 'jira' ? identity.siteId : null
  return typeof value === 'string' && value.trim() ? value.trim() : null
}

function unavailableError(provider: TaskProvider, cause?: unknown): IssueRepositoryError {
  return new IssueRepositoryError(
    'external_issue_unavailable',
    `The ${provider} Issue could not be loaded.`,
    cause === undefined ? undefined : { cause: errorMessage(cause) }
  )
}

function errorMessage(error: unknown): string {
  return error instanceof Error && error.message.trim()
    ? error.message.trim()
    : 'External Issue provider request failed.'
}
