import React from 'react'
import {
  Archive,
  ChevronRight,
  CircleDot,
  ExternalLink,
  Server
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import type {
  ConversationSummary,
  IssueDetail as IssueDetailRecord,
  IssueSummary,
  RoundRecordPreview
} from '../../../../shared/issues/types'
import type {
  IssueDigestConfirmationResult,
  IssueDigestPreparation,
  IssueDigestRecord,
  IssueDigestSections
} from '../../../../shared/issues/digest-types'
import type { TuiAgent } from '../../../../shared/tui-agent'
import {
  getIssueDisplayTitle,
  getIssueSourceLabel
} from '../../issues/issue-display'
import { IssueChildren } from './IssueChildren'
import { IssueConversationList } from './IssueConversationList'
import {
  IssueTimeline,
  type IssueTimelineStatus
} from './IssueTimeline'
import { IssueDigest } from './IssueDigest'

type IssueDetailProps = {
  detail: IssueDetailRecord
  ancestors?: readonly IssueSummary[]
  rounds: readonly RoundRecordPreview[]
  roundStatus: IssueTimelineStatus
  roundError?: string | null
  roundHasMore?: boolean
  roundLoadingMore?: boolean
  cachedError?: string | null
  onOpenIssue?: (issue: IssueSummary) => void
  onOpenConversation?: (conversation: ConversationSummary) => void
  onLoadMoreRounds?: () => void
  onOpenExternalSource?: (url: string) => void
  digestPreparation?: IssueDigestPreparation | null
  digestAttempt?: IssueDigestRecord | null
  digestConfirmation?: IssueDigestConfirmationResult | null
  digestStatus?: 'idle' | 'loading' | 'ready' | 'unsupported' | 'error'
  digestError?: string | null
  onPrepareDigest?: () => void
  onGenerateDigest?: (agent: TuiAgent) => void
  onUpdateDigestDraft?: (patch: IssueDigestSections) => void
  onConfirmDigest?: (confirmStaleAgainstFingerprint?: string) => void
  onCancelDigest?: () => void
}

export function IssueDetail({
  detail,
  ancestors = [],
  rounds,
  roundStatus,
  roundError = null,
  roundHasMore = false,
  roundLoadingMore = false,
  cachedError = null,
  onOpenIssue,
  onOpenConversation,
  onLoadMoreRounds,
  onOpenExternalSource,
  digestPreparation,
  digestAttempt,
  digestConfirmation,
  digestStatus,
  digestError,
  onPrepareDigest,
  onGenerateDigest,
  onUpdateDigestDraft,
  onConfirmDigest,
  onCancelDigest
}: IssueDetailProps): React.JSX.Element {
  const { issue } = detail
  const source = issue.source
  return (
    <article className="mx-auto w-full max-w-5xl px-5 pb-12 pt-4 md:px-8">
      {cachedError ? (
        <div
          role="status"
          className="mb-3 rounded-md border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground"
        >
          Showing cached Issue facts. {cachedError}
        </div>
      ) : null}
      <nav
        aria-label="Issue hierarchy"
        className="mb-2 flex min-w-0 items-center gap-1 text-xs text-muted-foreground"
      >
        {ancestors.map((ancestor) => (
          <React.Fragment key={ancestor.id}>
            <button
              type="button"
              className="max-w-48 truncate rounded-sm px-1 py-0.5 hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              onClick={() => onOpenIssue?.(ancestor)}
            >
              {getIssueDisplayTitle(ancestor)}
            </button>
            <ChevronRight className="size-3 shrink-0" />
          </React.Fragment>
        ))}
        <span className="truncate text-foreground">
          {getIssueDisplayTitle(issue)}
        </span>
      </nav>
      <header className="border-b border-border/60 pb-4">
        <div className="flex min-w-0 items-start gap-3">
          {issue.state === 'archived' ? (
            <Archive className="mt-1 size-4 shrink-0 text-muted-foreground" />
          ) : (
            <CircleDot className="mt-1 size-4 shrink-0 text-muted-foreground" />
          )}
          <div className="min-w-0 flex-1">
            <h1 className="break-words text-xl font-semibold tracking-tight">
              {getIssueDisplayTitle(issue)}
            </h1>
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <Badge variant="outline">{getIssueSourceLabel(issue)}</Badge>
              <Badge variant="ghost">
                <Server className="size-3" />
                {detail.authority.routeExecutionHostId}
              </Badge>
              <Badge variant={issue.state === 'active' ? 'secondary' : 'outline'}>
                {issue.state}
              </Badge>
              {issue.typeLabel ? (
                <Badge variant="outline">{issue.typeLabel}</Badge>
              ) : null}
              {issue.ownUnresolvedCount > 0 ? (
                <Badge>{issue.ownUnresolvedCount} own attention</Badge>
              ) : null}
              {issue.descendantAttentionCount > 0 ? (
                <Badge variant="outline">
                  {issue.descendantAttentionCount} descendant attention
                </Badge>
              ) : null}
            </div>
          </div>
          {source.kind === 'external' && onOpenExternalSource ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onOpenExternalSource(source.url)}
            >
              <ExternalLink className="size-3.5" />
              Open source
            </Button>
          ) : null}
        </div>
        {issue.note ? (
          <p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-muted-foreground">
            {issue.note}
          </p>
        ) : null}
        {detail.workspaceSnapshots.length > 0 ? (
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <span className="text-xs text-muted-foreground">Workspaces</span>
            {detail.workspaceSnapshots.map((workspace) => (
              <Badge
                key={`${workspace.path}\0${workspace.name}`}
                variant="outline"
                title={workspace.path}
              >
                {workspace.name}
              </Badge>
            ))}
          </div>
        ) : null}
      </header>
      <div className="mt-5 space-y-7">
        <IssueDigest
          projection={detail.digest}
          preparation={digestPreparation}
          activeAttempt={digestAttempt}
          confirmation={digestConfirmation}
          status={digestStatus}
          error={digestError}
          onPrepare={onPrepareDigest}
          onGenerate={onGenerateDigest}
          onUpdateDraft={onUpdateDigestDraft}
          onConfirm={onConfirmDigest}
          onCancel={onCancelDigest}
        />
        <IssueConversationList
          conversations={detail.directConversations}
          onOpenConversation={onOpenConversation}
        />
        <IssueChildren
          children={detail.directChildren}
          onOpenIssue={onOpenIssue}
        />
        <IssueTimeline
          rounds={rounds}
          status={roundStatus}
          error={roundError}
          hasMore={roundHasMore}
          loadingMore={roundLoadingMore}
          onLoadMore={onLoadMoreRounds}
        />
      </div>
    </article>
  )
}
