import {
  connectIssueDashboardEvents,
  issueDashboardStore
} from './issue-dashboard-store'

export type IssueDashboardEventLease = {
  acquire: () => () => void
}

export function createIssueDashboardEventLease(
  connect: () => () => void
): IssueDashboardEventLease {
  let subscriberCount = 0
  let disconnect: (() => void) | null = null

  return {
    acquire: () => {
      subscriberCount += 1
      disconnect ??= connect()
      let released = false
      return () => {
        if (released) {
          return
        }
        released = true
        subscriberCount -= 1
        if (subscriberCount === 0) {
          disconnect?.()
          disconnect = null
        }
      }
    }
  }
}

const dashboardEventLease = createIssueDashboardEventLease(() =>
  connectIssueDashboardEvents(issueDashboardStore, window)
)

export function acquireIssueDashboardEvents(): () => void {
  return dashboardEventLease.acquire()
}
