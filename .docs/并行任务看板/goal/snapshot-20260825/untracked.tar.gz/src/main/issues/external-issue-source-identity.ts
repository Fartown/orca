import { createHash } from 'node:crypto'
import type { AuthorityHostPartitionKey } from '../../shared/issues/types'
import type { TaskProvider } from '../../shared/task-providers'
import {
  normalizeTaskSourceContext,
  type TaskSourceContext
} from '../../shared/task-source-context'
import { IssueRepositoryError } from './issue-repository-error'

export function normalizeExternalIssueSourceContext(params: {
  provider: TaskProvider
  sourceContext: TaskSourceContext
  hostPartitionKey: AuthorityHostPartitionKey
}): TaskSourceContext {
  if (params.sourceContext.provider !== params.provider) {
    throw new IssueRepositoryError(
      'external_issue_source_invalid',
      'External Issue provider does not match its source context.'
    )
  }
  const normalized = normalizeTaskSourceContext({
    ...params.sourceContext,
    provider: params.provider,
    hostId: params.hostPartitionKey
  })
  if (!normalized) {
    throw new IssueRepositoryError(
      'external_issue_source_invalid',
      'External Issue source context is invalid.'
    )
  }
  return normalized
}

export function externalIssueSourceScopeKey(params: {
  provider: TaskProvider
  sourceContext: TaskSourceContext
  hostPartitionKey: AuthorityHostPartitionKey
}): string {
  const context = normalizeExternalIssueSourceContext(params)
  const identity = {
    provider: context.provider,
    hostPartitionKey: params.hostPartitionKey,
    projectId: context.projectId,
    projectHostSetupId: context.projectHostSetupId ?? null,
    repoId: context.repoId ?? null,
    providerIdentity: context.providerIdentity ?? null
  }
  return createHash('sha256').update(JSON.stringify(canonicalize(identity))).digest('hex')
}

function canonicalize(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(canonicalize)
  }
  if (!value || typeof value !== 'object') {
    return value
  }
  return Object.fromEntries(
    Object.entries(value as Record<string, unknown>)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([key, nested]) => [key, canonicalize(nested)])
  )
}
