import { describe, expect, it } from 'vitest'
import type { IssueActivityPartitionState } from './issue-activity-store'
import { selectIssueActivityTimeline } from './use-issue-activity-timeline'

function partition(
  status: IssueActivityPartitionState['status'],
  withAuthority: boolean
): IssueActivityPartitionState {
  return {
    routeExecutionHostId: 'local',
    status,
    authority: withAuthority
      ? {
          authorityId: 'authority-local',
          hostPartitionKey: 'local',
          routeExecutionHostId: 'local'
        }
      : null,
    snapshotFactsRevision: withAuthority ? 1 : null,
    entries: [],
    nextCursor: null,
    error: status === 'error' ? 'offline' : null,
    legacyMigrationStatus: withAuthority ? 'complete' : 'idle',
    legacyMigrationSnapshotKey: withAuthority ? '[]' : null,
    legacyMigrationAttemptFactsRevision: null,
    legacyMigrationUnresolvedEventIds: [],
    legacyMigrationError: null
  }
}

describe('selectIssueActivityTimeline', () => {
  it('treats a previously loaded partition as authoritative while it refreshes or errors', () => {
    for (const status of ['loading', 'error'] as const) {
      const timeline = selectIssueActivityTimeline(
        ['local'],
        { local: partition(status, true) },
        { local: [] }
      )
      expect(timeline.authoritativeRoutes).toEqual(new Set(['local']))
    }
  })

  it('keeps routes on the legacy fallback until persistent Activity establishes authority', () => {
    const timeline = selectIssueActivityTimeline(
      ['local', 'runtime:legacy'],
      {
        local: partition('idle', false),
        'runtime:legacy': {
          ...partition('unsupported', false),
          routeExecutionHostId: 'runtime:legacy'
        }
      },
      { local: [], 'runtime:legacy': [] }
    )

    expect(timeline.authoritativeRoutes).toEqual(new Set())
    expect(timeline.projections).toEqual([])
  })
})
