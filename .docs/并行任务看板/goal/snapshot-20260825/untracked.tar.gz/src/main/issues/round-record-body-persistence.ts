import type { RoundRecord, RoundRecordText } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { retainedRoundTextBytes } from './round-record-text'

export type RoundRecordBodies = Pick<
  RoundRecord,
  'userInput' | 'agentOutput' | 'pendingQuestion'
>

export function retainedRoundRecordBytes(round: RoundRecordBodies): number {
  return (
    retainedRoundTextBytes(round.userInput) +
    retainedRoundTextBytes(round.agentOutput) +
    retainedRoundTextBytes(round.pendingQuestion)
  )
}

export function roundRecordBodiesEqual(
  left: RoundRecordBodies,
  right: RoundRecordBodies
): boolean {
  return (
    roundRecordTextEqual(left.userInput, right.userInput) &&
    roundRecordTextEqual(left.agentOutput, right.agentOutput) &&
    roundRecordTextEqual(left.pendingQuestion, right.pendingQuestion)
  )
}

export function writeRoundRecordBodies(
  database: IssueDatabase,
  roundId: string,
  bodies: RoundRecordBodies,
  options: { evictedAt?: number; deletedAt?: number } = {}
): void {
  database
    .prepare(
      `UPDATE round_records
       SET user_input = ?,
           user_input_completeness = ?,
           user_input_storage = ?,
           user_input_bytes = ?,
           user_input_preview = ?,
           user_input_preview_bytes = ?,
           agent_output = ?,
           output_completeness = ?,
           output_storage = ?,
           output_bytes = ?,
           output_preview = ?,
           output_preview_bytes = ?,
           pending_question = ?,
           question_completeness = ?,
           question_storage = ?,
           question_bytes = ?,
           question_preview = ?,
           question_preview_bytes = ?,
           body_evicted_at = COALESCE(?, body_evicted_at),
           body_deleted_at = COALESCE(?, body_deleted_at),
           body_revision = body_revision + 1
       WHERE id = ?`
    )
    .run(
      bodies.userInput.text,
      bodies.userInput.completeness,
      bodies.userInput.storage,
      bodies.userInput.bytes,
      bodies.userInput.preview,
      bodies.userInput.previewBytes,
      bodies.agentOutput.text,
      bodies.agentOutput.completeness,
      bodies.agentOutput.storage,
      bodies.agentOutput.bytes,
      bodies.agentOutput.preview,
      bodies.agentOutput.previewBytes,
      bodies.pendingQuestion.text,
      bodies.pendingQuestion.completeness,
      bodies.pendingQuestion.storage,
      bodies.pendingQuestion.bytes,
      bodies.pendingQuestion.preview,
      bodies.pendingQuestion.previewBytes,
      options.evictedAt ?? null,
      options.deletedAt ?? null,
      roundId
    )
}

function roundRecordTextEqual(left: RoundRecordText, right: RoundRecordText): boolean {
  return (
    left.text === right.text &&
    left.completeness === right.completeness &&
    left.storage === right.storage &&
    left.bytes === right.bytes &&
    left.preview === right.preview &&
    left.previewBytes === right.previewBytes
  )
}
