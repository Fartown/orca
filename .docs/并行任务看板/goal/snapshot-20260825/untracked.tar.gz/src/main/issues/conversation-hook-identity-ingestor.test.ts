import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import type { WorkspaceScope } from '../../shared/folder-workspace-types'
import type { WorkspaceSnapshot } from '../../shared/issues/types'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import {
  ConversationHookIdentityIngestor,
  type ConversationHookIdentityContext
} from './conversation-hook-identity-ingestor'
import { IssueRepository } from './issue-repository'

const repositories: IssueRepository[] = []

function openRepository(profileId: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId,
      userDataPath: createIssueTestUserDataPath(`orca-hook-identity-${profileId}`)
    })
  )
  repositories.push(repository)
  return repository
}

function context(
  overrides: Partial<ConversationHookIdentityContext> = {}
): ConversationHookIdentityContext {
  const executionHostId: ExecutionHostId = overrides.executionHostId ?? 'local'
  const workspaceRef: WorkspaceScope =
    overrides.workspaceRef ?? { type: 'folder', folderWorkspaceId: 'folder-1' }
  const workspaceSnapshot: WorkspaceSnapshot = overrides.workspaceSnapshot ?? {
    name: 'Folder 1',
    path: '/workspace/folder-1'
  }
  return {
    executionHostId,
    workspaceRef,
    workspaceSnapshot,
    processIncarnation: 'pty-1:incarnation-1',
    connectionId: null,
    hostPlatform: 'darwin',
    ...overrides
  }
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
})

describe('ConversationHookIdentityIngestor', () => {
  it('atomically attaches a late hook identity to the preallocated launch claim', async () => {
    const repository = openRepository('claimed')
    const allocated = repository.conversationAllocator.allocateFreshLaunch({
      ...context(),
      agent: 'codex',
      issueId: null,
      launchToken: 'managed-launch',
      paneKey: 'tab-1:leaf-1',
      processIncarnation: 'pty-1:incarnation-1',
      now: 1_000
    })
    const ingestor = new ConversationHookIdentityIngestor(repository, {
      resolveContext: async () => context()
    })

    const result = await ingestor.ingest({
      paneKey: 'tab-1:leaf-1',
      worktreeId: 'folder-1',
      connectionId: null,
      launchToken: 'managed-launch',
      providerSession: { key: 'session_id', id: 'provider-session-1' },
      payload: { agentType: 'codex' },
      receivedAt: 2_000
    })

    expect(result).toEqual({
      disposition: 'attached',
      conversationId: allocated.conversation.id
    })
    expect(
      repository.conversationIdentities.listForConversation(allocated.conversation.id)
    ).toEqual([
      expect.objectContaining({
        session: { key: 'session_id', id: 'provider-session-1' },
        observedAt: 2_000,
        retiredAt: null
      })
    ])
    expect(
      repository.conversationLaunchClaims.findByToken('local', 'managed-launch', false)
    ).toMatchObject({ consumedAt: 2_000 })
  })

  it('creates one unassigned Conversation for a strong manual-shell identity', async () => {
    const repository = openRepository('manual')
    const ingestor = new ConversationHookIdentityIngestor(repository, {
      resolveContext: async () => context()
    })
    const event = {
      paneKey: 'tab-1:leaf-1',
      worktreeId: 'folder-1',
      connectionId: null,
      providerSession: { key: 'session_id' as const, id: 'manual-session-1' },
      payload: { agentType: 'codex' },
      receivedAt: 2_000
    }

    const first = await ingestor.ingest(event)
    const replay = await ingestor.ingest({ ...event, receivedAt: 3_000 })

    expect(first.disposition).toBe('created')
    if (first.disposition === 'ignored') {
      throw new Error(`Unexpected ignored identity: ${first.reason}`)
    }
    expect(replay).toEqual({
      disposition: 'replayed',
      conversationId: first.conversationId
    })
    expect(repository.conversations.list()).toEqual([
      expect.objectContaining({
        id: first.conversationId,
        issueId: null,
        workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-1' }
      })
    ])
    expect(
      repository.conversationIdentities.listForConversation(first.conversationId!)
    ).toHaveLength(1)
  })

  it('does not guess a Conversation when pane ownership is unavailable', async () => {
    const repository = openRepository('ambiguous')
    const ingestor = new ConversationHookIdentityIngestor(repository, {
      resolveContext: async () => null
    })

    await expect(
      ingestor.ingest({
        paneKey: 'unknown:leaf',
        providerSession: { key: 'session_id', id: 'provider-session-1' },
        payload: { agentType: 'codex' },
        receivedAt: 2_000
      })
    ).resolves.toEqual({ disposition: 'ignored', reason: 'workspace-unresolved' })
    expect(repository.conversations.list()).toEqual([])
  })

  it('canonicalizes Pi identity through the remote execution owner before persistence', async () => {
    const repository = openRepository('remote-pi')
    const remoteContext = context({
      executionHostId: 'ssh:connection-1',
      connectionId: 'connection-1',
      hostPlatform: 'linux',
      workspaceRef: { type: 'worktree', worktreeId: 'remote-worktree' },
      workspaceSnapshot: { name: 'Remote', path: '/remote/worktree' }
    })
    const ingestor = new ConversationHookIdentityIngestor(repository, {
      resolveContext: async () => remoteContext,
      resolvePathAccess: () => ({
        platform: 'linux',
        realpath: async () => '/remote/canonical/session.jsonl',
        stat: async () => ({ type: 'file' })
      })
    })

    const result = await ingestor.ingest({
      paneKey: 'tab-remote:leaf-remote',
      worktreeId: 'remote-worktree',
      connectionId: 'connection-1',
      providerSession: {
        key: 'session_id',
        id: 'pi-session-1',
        transcriptPath: '/remote/link/session.jsonl'
      },
      payload: { agentType: 'pi' },
      receivedAt: 2_000
    })

    expect(result.disposition).toBe('created')
    if (result.disposition === 'ignored') {
      throw new Error(`Unexpected ignored identity: ${result.reason}`)
    }
    expect(
      repository.conversationIdentities.listForConversation(result.conversationId)
    ).toEqual([
      expect.objectContaining({
        session: {
          key: 'session_id',
          id: 'pi-session-1',
          transcriptPath: '/remote/canonical/session.jsonl'
        }
      })
    ])
  })

  it('does not replace a missing managed claim with an unassigned Conversation', async () => {
    const repository = openRepository('missing-claim')
    const ingestor = new ConversationHookIdentityIngestor(repository, {
      resolveContext: async () => context()
    })

    await expect(
      ingestor.ingest({
        paneKey: 'tab-1:leaf-1',
        launchToken: 'missing-managed-launch',
        providerSession: { key: 'session_id', id: 'provider-session-1' },
        payload: { agentType: 'codex' },
        receivedAt: 2_000
      })
    ).resolves.toEqual({ disposition: 'ignored', reason: 'claim-unresolved' })
    expect(repository.conversations.list()).toEqual([])
  })
})
