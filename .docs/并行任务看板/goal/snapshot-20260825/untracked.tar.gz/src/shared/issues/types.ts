import type { AgentProviderSessionMetadata } from '../agent-session-resume'
import type { ExecutionHostId } from '../execution-host'
import type { WorkspaceScope } from '../folder-workspace-types'
import type { TaskProvider } from '../task-providers'
import type { TaskSourceContext } from '../task-source-context'
import type { TuiAgent } from '../tui-agent'
import type { IssueDigestProjection } from './digest-types'
import type {
  CONVERSATION_STATES,
  EFFECTIVE_ROUND_RESOLUTIONS,
  ISSUE_EVENT_KINDS,
  ISSUE_STATES,
  ROUND_RECORD_KINDS,
  ROUND_RECORD_STATE_SOURCES,
  ROUND_RESOLUTIONS,
  ROUND_TEXT_COMPLETENESS,
  ROUND_TEXT_STORAGE
} from './constants'

export type AuthorityHostPartitionKey = 'local' | `ssh:${string}`
export type IssueState = (typeof ISSUE_STATES)[number]
export type ConversationState = (typeof CONVERSATION_STATES)[number]
export type RoundRecordKind = (typeof ROUND_RECORD_KINDS)[number]
export type RoundRecordStateSource = (typeof ROUND_RECORD_STATE_SOURCES)[number]
export type RoundTextCompleteness = (typeof ROUND_TEXT_COMPLETENESS)[number]
export type RoundTextStorage = (typeof ROUND_TEXT_STORAGE)[number]
export type RoundResolution = (typeof ROUND_RESOLUTIONS)[number]
export type EffectiveRoundResolution = (typeof EFFECTIVE_ROUND_RESOLUTIONS)[number]
export type IssueEventKind = (typeof ISSUE_EVENT_KINDS)[number]
export type ExternalIssueAvailability = 'available' | 'unavailable'

export type LocalIssueSource = {
  kind: 'local'
  number: number
}

export type ExternalIssueSource = {
  kind: 'external'
  provider: TaskProvider
  sourceScopeKey: string
  externalId: string
  number?: number
  identifier?: string
  url: string
  titleSnapshot: string
  stateSnapshot?: string
  syncedAt: number
  refreshAttemptedAt: number
  refreshError: string | null
  availability: ExternalIssueAvailability
  sourceContext?: TaskSourceContext
  nativeParentSnapshot?: {
    sourceScopeKey: string
    externalId: string
    title: string
  } | null
}

export type IssueSource = LocalIssueSource | ExternalIssueSource

export type WorkspaceSnapshot = {
  name: string
  path: string
}

export type IssueRecord = {
  id: string
  hostPartitionKey: AuthorityHostPartitionKey
  executionHostId: ExecutionHostId
  source: IssueSource
  localTitle: string | null
  typeLabel: string | null
  note: string | null
  state: IssueState
  parentId: string | null
  siblingOrder: number
  createdAt: number
  updatedAt: number
  archivedAt: number | null
}

export type ConversationRecord = {
  id: string
  hostPartitionKey: AuthorityHostPartitionKey
  executionHostId: ExecutionHostId
  workspaceRef: WorkspaceScope
  workspaceSnapshot: WorkspaceSnapshot
  agent: TuiAgent
  title: string | null
  titleSource: 'user' | 'provider' | 'generated' | 'terminal' | null
  issueId: string | null
  state: ConversationState
  launchFailure: string | null
  createdAt: number
  updatedAt: number
}

export type ConversationProviderIdentity = {
  id: string
  conversationId: string
  hostPartitionKey: AuthorityHostPartitionKey
  agent: TuiAgent
  session: AgentProviderSessionMetadata
  identityFingerprint: string
  resumeLocator?: string
  observedAt: number
  retiredAt: number | null
}

export type ConversationLaunchClaim = {
  claimId: string
  conversationId: string
  hostPartitionKey: AuthorityHostPartitionKey
  paneKey: string | null
  processIncarnation: string | null
  connectionId: string | null
  createdAt: number
  expiresAt: number
  consumedAt: number | null
}

export type RoundRecordText = {
  text: string | null
  completeness: RoundTextCompleteness
  storage: RoundTextStorage
  bytes: number
  preview: string | null
  previewBytes: number
}

export type RoundRecordRef = {
  kind: string
  value: string
  reachable: boolean | null
}

export type RoundRecord = {
  id: string
  conversationId: string
  kind: RoundRecordKind
  stateSource: RoundRecordStateSource
  occurredAt: number
  dedupeKey: string
  executionChainId: string | null
  supersedesRoundId: string | null
  userInput: RoundRecordText
  agentOutput: RoundRecordText
  pendingQuestion: RoundRecordText
  readAt: number | null
  resolvedAt: number | null
  resolution: RoundResolution | null
  effectiveResolvedAt: number | null
  effectiveResolution: EffectiveRoundResolution | null
  finalizedAt: number | null
  bodyEvictedAt: number | null
  bodyDeletedAt: number | null
  bodyRevision: number
  createdAt: number
}

export type RoundRecordSummary = Pick<
  RoundRecord,
  | 'id'
  | 'conversationId'
  | 'kind'
  | 'occurredAt'
  | 'readAt'
  | 'resolvedAt'
  | 'resolution'
  | 'supersedesRoundId'
  | 'effectiveResolvedAt'
  | 'effectiveResolution'
>

export type IssueAuthorityDescriptor = {
  authorityId: string
  hostPartitionKey: AuthorityHostPartitionKey
  routeExecutionHostId: ExecutionHostId
}

export type RoundRecordTextSummary = Omit<RoundRecordText, 'text'>

export type RoundRecordPreview = Omit<
  RoundRecord,
  'userInput' | 'agentOutput' | 'pendingQuestion' | 'dedupeKey'
> & {
  userInput: RoundRecordTextSummary
  agentOutput: RoundRecordTextSummary
  pendingQuestion: RoundRecordTextSummary
}

export type ConversationNavigationHint = {
  paneKey: string | null
  providerSession: AgentProviderSessionMetadata | null
  resumeLocator: string | null
}

export type ConversationNavigationTarget = ConversationRecord & {
  navigation?: ConversationNavigationHint
}

export type ConversationSummary = ConversationNavigationTarget & {
  unresolvedRoundCount: number
  latestRound: RoundRecordPreview | null
}

export type IssueSummary = IssueRecord & {
  ownUnresolvedCount: number
  descendantAttentionCount: number
  directConversationCount: number
  activeConversationCount: number
}

export type UnassignedConversationSummary = {
  conversationCount: number
  unresolvedCount: number
}

export type IssueDetail = {
  authority: IssueAuthorityDescriptor
  issue: IssueSummary
  directChildren: IssueSummary[]
  directConversations: ConversationSummary[]
  workspaceSnapshots: WorkspaceSnapshot[]
  digest?: IssueDigestProjection
}

export type IssueListFilter = 'all' | 'needs-me' | 'archived'

export type IssueListResult =
  | {
      status: 'not-modified'
      authority: IssueAuthorityDescriptor
      factsRevision: number
      treeRevision: number
    }
  | {
      status: 'stale'
      authority: IssueAuthorityDescriptor
      factsRevision: number
      treeRevision: number
    }
  | {
      status: 'snapshot-page'
      authority: IssueAuthorityDescriptor
      snapshotFactsRevision: number
      snapshotTreeRevision: number
      issues: IssueSummary[]
      unassigned?: UnassignedConversationSummary
      nextCursor: string | null
    }

export type RoundRecordBodyField = 'userInput' | 'agentOutput' | 'pendingQuestion'

export type RoundRecordBodyReadResult =
  | {
      status: 'body-chunk'
      roundRecordId: string
      field: RoundRecordBodyField
      bodyRevision: number
      storage: RoundTextStorage
      completeness: RoundTextCompleteness
      offset: number
      nextOffset: number
      eof: boolean
      text: string
    }
  | {
      status: 'stale'
      roundRecordId: string
      field: RoundRecordBodyField
      bodyRevision: number
      storage: RoundTextStorage
      completeness: RoundTextCompleteness
    }
  | {
      status: 'unavailable'
      roundRecordId: string
      field: RoundRecordBodyField
      bodyRevision: number
      storage: RoundTextStorage
      completeness: RoundTextCompleteness
    }

export type RoundRecordPage = {
  authority: IssueAuthorityDescriptor
  snapshotFactsRevision: number
  rounds: RoundRecordPreview[]
  nextCursor: string | null
}

export type ConversationPage = {
  authority: IssueAuthorityDescriptor
  snapshotFactsRevision: number
  conversations: ConversationSummary[]
  nextCursor: string | null
}

export type IssueLocator = {
  authorityId: string
  hostPartitionKey: AuthorityHostPartitionKey
  issueId: string
  titleSnapshot: string
}

export type IssueLink = {
  issueId: string
  target: IssueLocator
  createdAt: number
  updatedAt: number
}

export type DeleteIssueChildDestination = { kind: 'root' } | { kind: 'parent'; parentId: string }

export type DeleteIssuePlan = {
  issueId: string
  expectedFactsRevision: number
  children: {
    issueId: string
    destination: DeleteIssueChildDestination
    index: number
  }[]
  conversations: {
    conversationId: string
    destinationIssueId: string | null
  }[]
}

export type DeleteIssueWarning = {
  conversationId: string
  kind: 'active-conversation' | 'unresolved-waiting'
  roundRecordId?: string
}

export type DeleteIssuePreparation = {
  plan: DeleteIssuePlan
  legalParentTargetsByChild: Record<string, (string | null)[]>
  legalConversationTargets: (string | null)[]
  warnings: DeleteIssueWarning[]
}

export type ArchiveIssueBlocker = {
  conversationId: string
  kind: 'unresolved-waiting' | 'runtime-waiting'
  roundRecordId: string | null
  dedupeKey: string | null
}

export type IssueEvent = {
  id: string
  hostPartitionKey: AuthorityHostPartitionKey
  executionHostId: ExecutionHostId
  kind: IssueEventKind
  conversationId: string | null
  issueRefs: { issueId: string; role: string; titleSnapshot: string }[]
  payload: Record<string, unknown>
  occurredAt: number
  factsRevision: number
}

export type IssueDisplayProjection = {
  id: string
  title: string
  typeLabel: string | null
  state: IssueState
}

export type IssueActivityEntry =
  | {
      type: 'round'
      id: string
      occurredAt: number
      round: RoundRecordPreview
      conversation: ConversationNavigationTarget
      issue: IssueDisplayProjection | null
    }
  | {
      type: 'issue-event'
      id: string
      occurredAt: number
      event: IssueEvent
      conversation: ConversationNavigationTarget | null
    }

export type IssueActivityPage = {
  authority: IssueAuthorityDescriptor
  snapshotFactsRevision: number
  entries: IssueActivityEntry[]
  nextCursor: string | null
}

export type LegacyActivityState = 'done' | 'waiting' | 'blocked'

export type LegacyActivityMigrationEntry = {
  legacyEventId: string
  paneKey: string
  state: LegacyActivityState
  occurredAt: number
  acknowledgedAt: number | null
  userInputPreview?: string | null
  agentOutputPreview?: string | null
  pendingQuestionPreview?: string | null
}

export type LegacyActivityMigrationResult = {
  authority: IssueAuthorityDescriptor
  migrated: {
    legacyEventId: string
    conversationId: string
    roundRecordId: string
  }[]
  unresolvedLegacyEventIds: string[]
}

export type IssueDashboardPaneProjection = {
  paneKey: string
  conversationId: string
  issue: IssueDisplayProjection | null
  latestRound: RoundRecordPreview | null
}

export type IssueDashboardProjection = {
  authority: IssueAuthorityDescriptor
  snapshotFactsRevision: number
  panes: IssueDashboardPaneProjection[]
}

export type IssueMutationIdentity = {
  callerFingerprint: string
  mutationId: string
}

export type IssueMutationResult = {
  authority: IssueAuthorityDescriptor
  factsRevision: number
  treeRevision: number
  affectedIssueIds: string[]
  affectedConversationIds: string[]
  affectedRoundRecordIds: string[]
}

export type IssueArchiveMutationResult =
  | {
      status: 'blocked'
      authority: IssueAuthorityDescriptor
      issueId: string
      blockers: ArchiveIssueBlocker[]
    }
  | {
      status: 'archived'
      archivedAt: number
      resolvedCompletionIds: string[]
      mutation: IssueMutationResult
    }

export type IssueDeletePreparationResult = DeleteIssuePreparation & {
  authority: IssueAuthorityDescriptor
}

export type ConversationBindingMutationResult = IssueMutationResult & {
  conversationId: string
  previousIssueId: string | null
  issueId: string | null
}

export type IssueFactsChangedEvent = {
  type: 'issueFactsChanged'
  authorityId: string
  hostPartitionKey: AuthorityHostPartitionKey
  factsRevision: number
  treeRevision: number
  issueIds?: string[]
}

export type IssueSearchEntityKind =
  | 'issue'
  | 'conversation'
  | 'round'
  | 'digest'
  | 'artifact'

export type IssueSearchCompleteness = 'complete' | 'partial' | 'unavailable'

export type IssueSearchMatch = {
  entityKind: IssueSearchEntityKind
  entityId: string
  issueId: string | null
  title: string
  preview: string
  completeness: IssueSearchCompleteness | null
}

export type IssueSearchGroup = {
  issue: IssueDisplayProjection | null
  matches: IssueSearchMatch[]
}

export type IssueSearchResult = {
  authority: IssueAuthorityDescriptor
  searchRevision: number
  indexedSearchRevision: number
  isStale: boolean
  partial: boolean
  groups: IssueSearchGroup[]
  nextCursor: string | null
}
