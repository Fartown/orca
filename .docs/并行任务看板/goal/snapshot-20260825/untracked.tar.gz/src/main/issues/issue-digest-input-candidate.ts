import type {
  IssueDigestInputCompleteness,
  IssueDigestInputKind
} from '../../shared/issues/digest-types'

export type IssueDigestInputCandidate = {
  kind: IssueDigestInputKind
  inputId: string
  inputVersion: number
  titleSnapshot: string | null
  occurredAt: number | null
  content: string
  sourceCompleteness: IssueDigestInputCompleteness
  sourceFingerprint: unknown
}
