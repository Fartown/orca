import { describe, expect, it, vi } from 'vitest'
import type { DashboardCard } from '../../../shared/dashboard-snapshot'
import {
  connectIssueDashboardEvents,
  createIssueDashboardStore,
  type IssueDashboardStoreDependencies
} from './issue-dashboard-store'
import { createIssueDashboardEventLease } from './issue-dashboard-event-lease'
import {
  ISSUE_FACTS_CHANGED_EVENT,
  type IssueFactsChangedEventDetail
} from './issue-facts-changed-event'

function card(
  paneKey: string,
  executionHostId: DashboardCard['executionHostId']
): DashboardCard {
  return {
    paneKey,
    ptyId: null,
    agentType: 'codex',
    bucket: 'working',
    dotState: 'working',
    task: '',
    repoId: 'repo-1',
    worktreeId: 'worktree-1',
    tabId: 'tab-1',
    leafId: null,
    repoName: 'Orca',
    worktreeName: 'issues',
    executionHostId,
    startedAt: 0,
    finishedAt: null,
    stateChangedAt: 0,
    unseen: false
  }
}

describe('createIssueDashboardStore', () => {
  it('groups pane projection requests by host and does not reload an unchanged card set', async () => {
    const load = vi.fn<IssueDashboardStoreDependencies['load']>(
      async (routeExecutionHostId, paneKeys) => ({
        status: 'ready',
        projection: {
          authority: {
            authorityId:
              routeExecutionHostId === 'local'
                ? '11111111-1111-4111-8111-111111111111'
                : '22222222-2222-4222-8222-222222222222',
            hostPartitionKey:
              routeExecutionHostId === 'local' ? 'local' : 'ssh:build',
            routeExecutionHostId
          },
          snapshotFactsRevision: 1,
          panes: paneKeys.map((paneKey) => ({
            paneKey,
            conversationId: '33333333-3333-4333-8333-333333333333',
            issue: null,
            latestRound: null
          }))
        }
      })
    )
    const store = createIssueDashboardStore({ load, now: () => 1 })
    const cards = [
      card('pane-2', 'local'),
      card('pane-1', 'local'),
      card('pane-3', 'ssh:build')
    ]

    await store.getState().syncCards(cards)
    await store.getState().syncCards([...cards].reverse())

    expect(load).toHaveBeenCalledTimes(2)
    expect(load).toHaveBeenCalledWith('local', ['pane-1', 'pane-2'])
    expect(load).toHaveBeenCalledWith('ssh:build', ['pane-3'])
  })

  it('ignores stale results after the requested pane set changes', async () => {
    let release!: () => void
    const load = vi.fn<IssueDashboardStoreDependencies['load']>(
      async (routeExecutionHostId, paneKeys) => {
        if (paneKeys[0] === 'old') {
          await new Promise<void>((resolve) => {
            release = resolve
          })
        }
        return {
          status: 'ready',
          projection: {
            authority: {
              authorityId: '11111111-1111-4111-8111-111111111111',
              hostPartitionKey: 'local',
              routeExecutionHostId
            },
            snapshotFactsRevision: paneKeys[0] === 'old' ? 1 : 2,
            panes: []
          }
        }
      }
    )
    const store = createIssueDashboardStore({ load, now: () => 1 })

    const oldRequest = store.getState().syncCards([card('old', 'local')])
    await Promise.resolve()
    const newRequest = store.getState().syncCards([card('new', 'local')])
    release()
    await Promise.all([oldRequest, newRequest])

    expect(
      store.getState().partitionsByRoute.local?.requestedPaneKeys
    ).toEqual(['new'])
    expect(
      store.getState().partitionsByRoute.local?.projection
        ?.snapshotFactsRevision
    ).toBe(2)
  })

  it('refreshes an unchanged pane set when a dashboard surface reopens', async () => {
    let revision = 0
    const load = vi.fn<IssueDashboardStoreDependencies['load']>(
      async (routeExecutionHostId) => ({
        status: 'ready',
        projection: {
          authority: {
            authorityId: '11111111-1111-4111-8111-111111111111',
            hostPartitionKey: 'local',
            routeExecutionHostId
          },
          snapshotFactsRevision: ++revision,
          panes: []
        }
      })
    )
    const store = createIssueDashboardStore({ load, now: () => 1 })
    const cards = [card('pane-1', 'local')]

    await store.getState().syncCards(cards)
    await store.getState().syncCards(cards)
    expect(load).toHaveBeenCalledTimes(1)

    await store.getState().syncCards(cards, { forceRefresh: true })

    expect(load).toHaveBeenCalledTimes(2)
    expect(
      store.getState().partitionsByRoute.local?.projection
        ?.snapshotFactsRevision
    ).toBe(2)
  })

  it('shares one facts listener across dashboard surfaces until the last release', async () => {
    const load = vi.fn<IssueDashboardStoreDependencies['load']>(
      async (routeExecutionHostId) => ({
        status: 'ready',
        projection: {
          authority: {
            authorityId: '11111111-1111-4111-8111-111111111111',
            hostPartitionKey: 'local',
            routeExecutionHostId
          },
          snapshotFactsRevision: load.mock.calls.length,
          panes: []
        }
      })
    )
    const store = createIssueDashboardStore({ load, now: () => 1 })
    const listeners = new Set<EventListener>()
    const target = {
      addEventListener: (
        type: string,
        listener: EventListenerOrEventListenerObject
      ) => {
        if (type === ISSUE_FACTS_CHANGED_EVENT) {
          listeners.add(listener as EventListener)
        }
      },
      removeEventListener: (
        type: string,
        listener: EventListenerOrEventListenerObject
      ) => {
        if (type === ISSUE_FACTS_CHANGED_EVENT) {
          listeners.delete(listener as EventListener)
        }
      }
    }
    const lease = createIssueDashboardEventLease(() =>
      connectIssueDashboardEvents(store, target)
    )
    await store.getState().syncCards([card('pane-1', 'local')])
    const releaseDrawer = lease.acquire()
    const releasePopout = lease.acquire()
    expect(listeners).toHaveLength(1)

    dispatchFactsChanged(listeners, {
      type: 'issueFactsChanged',
      routeExecutionHostId: 'local',
      authorityId: '11111111-1111-4111-8111-111111111111',
      hostPartitionKey: 'local',
      factsRevision: 2,
      treeRevision: 1
    })
    await vi.waitFor(() => expect(load).toHaveBeenCalledTimes(2))

    releaseDrawer()
    expect(listeners).toHaveLength(1)
    releasePopout()
    expect(listeners).toHaveLength(0)

    dispatchFactsChanged(listeners, {
      type: 'issueFactsChanged',
      routeExecutionHostId: 'local',
      authorityId: '11111111-1111-4111-8111-111111111111',
      hostPartitionKey: 'local',
      factsRevision: 3,
      treeRevision: 1
    })
    await Promise.resolve()
    expect(load).toHaveBeenCalledTimes(2)
  })
})

function dispatchFactsChanged(
  listeners: ReadonlySet<EventListener>,
  detail: IssueFactsChangedEventDetail
): void {
  const event = new Event(ISSUE_FACTS_CHANGED_EVENT)
  Object.defineProperty(event, 'detail', { value: detail })
  for (const listener of listeners) {
    listener(event)
  }
}
