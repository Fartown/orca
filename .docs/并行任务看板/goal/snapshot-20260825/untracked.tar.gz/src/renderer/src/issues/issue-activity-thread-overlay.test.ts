import { describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../../shared/execution-host'
import type { Worktree } from '../../../shared/worktree/types'
import type { IssueActivityThreadProjection } from './issue-activity-projection'
import {
  overlayIssueActivityThreads,
  type ActivityTimelineThreadView
} from './issue-activity-thread-overlay'

const paneKey = 'tab-a:11111111-1111-4111-8111-111111111111'

function worktree(
  id: string,
  hostId: ExecutionHostId
): Worktree {
  return {
    id,
    repoId: 'repo-a',
    path: `/workspace/${id}`,
    head: 'abc',
    branch: 'feature',
    isBare: false,
    isMainWorktree: false,
    displayName: id,
    comment: '',
    linkedIssue: null,
    linkedPR: null,
    linkedLinearIssue: null,
    isArchived: false,
    isUnread: false,
    isPinned: false,
    sortOrder: 0,
    lastActivityAt: 1,
    hostId
  }
}

function legacyThread(
  routeExecutionHostId: ExecutionHostId,
  options: { current?: boolean; timestamp?: number } = {}
): ActivityTimelineThreadView {
  const workspace = worktree(`workspace-${routeExecutionHostId}`, routeExecutionHostId)
  const timestamp = options.timestamp ?? 50
  const entry = {
    state: options.current ? ('working' as const) : ('done' as const),
    prompt: 'Legacy prompt',
    updatedAt: timestamp,
    stateStartedAt: timestamp,
    paneKey,
    stateHistory: [],
    agentType: 'codex' as const
  }
  return {
    threadKey: paneKey,
    paneKey,
    paneTitle: 'Legacy prompt',
    worktree: workspace,
    repo: null,
    tab: {
      id: 'tab-a',
      ptyId: 'pty-a',
      worktreeId: workspace.id,
      title: 'Codex',
      customTitle: null,
      color: null,
      sortOrder: 0,
      createdAt: 1
    },
    agentType: 'codex',
    currentAgentState: options.current ? 'working' : null,
    currentAgentEntry: options.current ? entry : null,
    responsePreview: options.current ? 'Running tests' : 'Legacy result',
    latestTimestamp: timestamp,
    latestEvent: null,
    events: [],
    unread: true
  }
}

function projection(
  routeExecutionHostId: ExecutionHostId,
  options: { pane?: string | null; timestamp?: number } = {}
): IssueActivityThreadProjection {
  const timestamp = options.timestamp ?? 100
  const conversationId = `conversation-${routeExecutionHostId}`
  const roundId = `round-${routeExecutionHostId}`
  return {
    key: `${routeExecutionHostId}\0conversation:${conversationId}`,
    routeExecutionHostId,
    authority: {
      authorityId: `authority-${routeExecutionHostId}`,
      hostPartitionKey: 'local',
      routeExecutionHostId
    },
    conversation: {
      id: conversationId,
      hostPartitionKey: 'local',
      executionHostId: routeExecutionHostId,
      workspaceRef: {
        type: 'worktree',
        worktreeId: `workspace-${routeExecutionHostId}`
      },
      workspaceSnapshot: {
        name: `Workspace ${routeExecutionHostId}`,
        path: `/workspace/${routeExecutionHostId}`
      },
      agent: 'codex',
      title: 'Persisted task',
      titleSource: 'user',
      issueId: 'issue-a',
      state: 'active',
      launchFailure: null,
      createdAt: 1,
      updatedAt: timestamp,
      navigation: {
        paneKey: options.pane === undefined ? paneKey : options.pane,
        providerSession: null,
        resumeLocator: null
      }
    },
    issue: {
      id: 'issue-a',
      title: 'Persisted Issue',
      typeLabel: 'Feature',
      state: 'active'
    },
    paneKey: options.pane === undefined ? paneKey : options.pane ?? null,
    agentType: 'codex',
    state: 'done',
    title: 'Persisted Issue',
    preview: 'Persisted result',
    workspaceName: `Workspace ${routeExecutionHostId}`,
    workspacePath: `/workspace/${routeExecutionHostId}`,
    latestOccurredAt: timestamp,
    unread: true,
    roundRecordIds: [roundId],
    unreadRoundRecordIds: [roundId],
    entries: [
      {
        type: 'round',
        id: roundId,
        occurredAt: timestamp,
        conversation: {
          id: conversationId,
          hostPartitionKey: 'local',
          executionHostId: routeExecutionHostId,
          workspaceRef: {
            type: 'worktree',
            worktreeId: `workspace-${routeExecutionHostId}`
          },
          workspaceSnapshot: {
            name: `Workspace ${routeExecutionHostId}`,
            path: `/workspace/${routeExecutionHostId}`
          },
          agent: 'codex',
          title: 'Persisted task',
          titleSource: 'user',
          issueId: 'issue-a',
          state: 'active',
          launchFailure: null,
          createdAt: 1,
          updatedAt: timestamp,
          navigation: {
            paneKey: options.pane === undefined ? paneKey : options.pane,
            providerSession: null,
            resumeLocator: null
          }
        },
        issue: {
          id: 'issue-a',
          title: 'Persisted Issue',
          typeLabel: 'Feature',
          state: 'active'
        },
        round: {
          id: roundId,
          conversationId,
          kind: 'completion',
          stateSource: 'hook',
          occurredAt: timestamp,
          executionChainId: null,
          supersedesRoundId: null,
          userInput: {
            completeness: 'preview-complete',
            storage: 'preview',
            bytes: 4,
            preview: 'Task',
            previewBytes: 4
          },
          agentOutput: {
            completeness: 'preview-complete',
            storage: 'preview',
            bytes: 16,
            preview: 'Persisted result',
            previewBytes: 16
          },
          pendingQuestion: {
            completeness: 'not-captured',
            storage: 'none',
            bytes: 0,
            preview: null,
            previewBytes: 0
          },
          readAt: null,
          resolvedAt: null,
          resolution: null,
          effectiveResolvedAt: null,
          effectiveResolution: null,
          finalizedAt: timestamp,
          bodyEvictedAt: null,
          bodyDeletedAt: null,
          bodyRevision: 1,
          createdAt: timestamp
        }
      }
    ]
  }
}

describe('Issue Activity thread overlay', () => {
  it('removes legacy history on authoritative routes but keeps unsupported routes intact', () => {
    const authoritativeDone = legacyThread('local')
    const authoritativeLive = legacyThread('local', {
      current: true,
      timestamp: 80
    })
    authoritativeLive.paneKey =
      'tab-live:22222222-2222-4222-8222-222222222222'
    authoritativeLive.threadKey = authoritativeLive.paneKey
    authoritativeLive.currentAgentEntry = {
      ...authoritativeLive.currentAgentEntry!,
      paneKey: authoritativeLive.paneKey
    }
    const unsupported = legacyThread('runtime:legacy')

    const threads = overlayIssueActivityThreads({
      legacyThreads: [authoritativeDone, authoritativeLive, unsupported],
      projections: [],
      authoritativeRoutes: new Set<ExecutionHostId>(['local']),
      routeForLegacyThread: (thread) => thread.worktree.hostId ?? 'local',
      resolveWorkspace: () => null
    })

    expect(threads.map((thread) => thread.threadKey)).toEqual([
      authoritativeLive.threadKey,
      unsupported.threadKey
    ])
    expect(threads[0]).toMatchObject({
      currentAgentState: 'working',
      latestEvent: null,
      events: [],
      unread: false
    })
    expect(threads[1]).toBe(unsupported)
  })

  it('reuses a same-host live pane while replacing its historical read truth', () => {
    const live = legacyThread('local', { current: true, timestamp: 120 })

    const [thread] = overlayIssueActivityThreads({
      legacyThreads: [live],
      projections: [projection('local')],
      authoritativeRoutes: new Set<ExecutionHostId>(['local']),
      routeForLegacyThread: (entry) => entry.worktree.hostId ?? 'local',
      resolveWorkspace: () => null
    })

    expect(thread).toMatchObject({
      threadKey: 'issue:local\u0000conversation:conversation-local',
      paneKey,
      paneTitle: 'Persisted Issue',
      currentAgentState: 'working',
      responsePreview: 'Running tests',
      latestTimestamp: 120,
      unread: true
    })
    expect(thread.issueActivity?.unreadRoundRecordIds).toEqual(['round-local'])
    expect(thread.events[0]).toMatchObject({
      id: 'round:round-local',
      unread: true
    })
  })

  it('does not bind the same pane key across different execution hosts', () => {
    const remoteLive = legacyThread('runtime:remote', {
      current: true,
      timestamp: 120
    })

    const threads = overlayIssueActivityThreads({
      legacyThreads: [remoteLive],
      projections: [projection('local')],
      authoritativeRoutes: new Set<ExecutionHostId>(['local']),
      routeForLegacyThread: (entry) => entry.worktree.hostId ?? 'local',
      resolveWorkspace: () => null
    })

    expect(threads).toHaveLength(2)
    expect(threads.find((thread) => thread.issueActivity)?.currentAgentState).toBeNull()
    expect(
      threads.find((thread) => thread.threadKey === paneKey)?.currentAgentState
    ).toBe('working')
  })

  it('keeps a closed Conversation visible with persisted navigation and read state', () => {
    const persisted = projection('local', { pane: null })

    const [thread] = overlayIssueActivityThreads({
      legacyThreads: [],
      projections: [persisted],
      authoritativeRoutes: new Set<ExecutionHostId>(['local']),
      routeForLegacyThread: () => 'local',
      resolveWorkspace: () => null
    })

    expect(thread).toMatchObject({
      paneTitle: 'Persisted Issue',
      currentAgentState: null,
      unread: true,
      worktree: {
        id: 'workspace-local',
        path: '/workspace/local',
        hostId: 'local'
      },
      tab: {
        id: 'conversation-local',
        ptyId: null
      }
    })
    expect(thread.issueActivity?.conversation?.id).toBe('conversation-local')
    expect(thread.issueActivity?.roundRecordIds).toEqual(['round-local'])
  })
})
