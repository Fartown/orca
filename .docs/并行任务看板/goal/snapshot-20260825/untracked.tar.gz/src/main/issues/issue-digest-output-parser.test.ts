import { describe, expect, it } from 'vitest'
import { ISSUE_DIGEST_DRAFT_MAX_BYTES } from '../../shared/issues/digest-constants'
import { parseIssueDigestOutput } from './issue-digest-output-parser'

describe('parseIssueDigestOutput', () => {
  it('accepts exactly the five Digest sections as strings or null', () => {
    expect(
      parseIssueDigestOutput(
        JSON.stringify({
          problem: 'The problem',
          conclusion: 'The conclusion',
          keyArtifacts: null,
          openIssues: 'One unresolved question',
          nextSteps: 'Run the verification'
        })
      )
    ).toEqual({
      problem: 'The problem',
      conclusion: 'The conclusion',
      keyArtifacts: null,
      openIssues: 'One unresolved question',
      nextSteps: 'Run the verification'
    })
  })

  it.each([
    ['missing section', '{"problem":null,"conclusion":null,"keyArtifacts":null,"openIssues":null}'],
    [
      'extra section',
      '{"problem":null,"conclusion":null,"keyArtifacts":null,"openIssues":null,"nextSteps":null,"extra":"no"}'
    ],
    [
      'wrong section type',
      '{"problem":[],"conclusion":null,"keyArtifacts":null,"openIssues":null,"nextSteps":null}'
    ],
    ['non-object', '[]'],
    ['invalid JSON', '{"problem"'],
    [
      'markdown fence',
      '```json\n{"problem":null,"conclusion":null,"keyArtifacts":null,"openIssues":null,"nextSteps":null}\n```'
    ]
  ])('rejects %s', (_label, output) => {
    expect(() => parseIssueDigestOutput(output)).toThrowError(
      expect.objectContaining({ code: 'digest_output_invalid' })
    )
  })

  it('rejects structurally abusive JSON before accepting its fields', () => {
    const nested = `[${'['.repeat(40)}null${']'.repeat(40)}]`
    expect(() => parseIssueDigestOutput(nested)).toThrowError(
      expect.objectContaining({ code: 'digest_output_invalid' })
    )
  })

  it('rejects five-section content whose aggregate UTF-8 size exceeds the draft budget', () => {
    const oversized = 'a'.repeat(ISSUE_DIGEST_DRAFT_MAX_BYTES + 1)
    expect(() =>
      parseIssueDigestOutput(
        JSON.stringify({
          problem: oversized,
          conclusion: null,
          keyArtifacts: null,
          openIssues: null,
          nextSteps: null
        })
      )
    ).toThrowError(expect.objectContaining({ code: 'digest_output_invalid' }))
  })
})
