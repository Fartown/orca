import {
  DASHBOARD_MAX_LABEL_LENGTH,
  type DashboardCard,
  type DashboardCardIssueContext,
  type DashboardSnapshot
} from '../../../shared/dashboard-snapshot'
import type { ExecutionHostId } from '../../../shared/execution-host'
import type { IssueDashboardPartitionState } from './issue-dashboard-store'

export function overlayIssueDashboardSnapshot(
  snapshot: DashboardSnapshot,
  partitionsByRoute: Partial<
    Record<ExecutionHostId, IssueDashboardPartitionState>
  >
): DashboardSnapshot {
  return {
    ...snapshot,
    cards: snapshot.cards.map((card) =>
      overlayIssueDashboardCard(card, partitionsByRoute)
    )
  }
}

function overlayIssueDashboardCard(
  card: DashboardCard,
  partitionsByRoute: Partial<
    Record<ExecutionHostId, IssueDashboardPartitionState>
  >
): DashboardCard {
  if (!card.executionHostId) {
    return card
  }
  const partition = partitionsByRoute[card.executionHostId]
  const issueContext = issueContextForCard(card, partition)
  if (issueContext.status !== 'mapped') {
    return { ...card, issueContext }
  }
  const unseen = issueContext.latestRound?.readAt === null
  return {
    ...card,
    unseen,
    bucket:
      card.dotState === 'done' ? (unseen ? 'done' : 'idle') : card.bucket,
    issueContext
  }
}

function issueContextForCard(
  card: DashboardCard,
  partition: IssueDashboardPartitionState | undefined
): DashboardCardIssueContext {
  if (!partition || partition.status === 'idle' || partition.status === 'loading') {
    return { status: 'unavailable' }
  }
  if (partition.status === 'unsupported') {
    return { status: 'unsupported' }
  }
  if (partition.status === 'error' || !partition.projection) {
    return { status: 'unavailable' }
  }
  const pane = partition.projection.panes.find(
    (candidate) => candidate.paneKey === card.paneKey
  )
  if (!pane) {
    return { status: 'unmapped' }
  }
  return {
    status: 'mapped',
    authority: partition.projection.authority,
    conversationId: pane.conversationId,
    issue: pane.issue
      ? {
          ...pane.issue,
          title: pane.issue.title.slice(0, DASHBOARD_MAX_LABEL_LENGTH)
        }
      : null,
    latestRound: pane.latestRound
      ? { id: pane.latestRound.id, readAt: pane.latestRound.readAt }
      : null
  }
}
