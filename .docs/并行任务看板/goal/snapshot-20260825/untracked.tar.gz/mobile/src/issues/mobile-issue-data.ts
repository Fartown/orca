import type {
  ConversationSummary,
  IssueMobilePendingEntry
} from '../../../src/shared/issues'
import {
  ConversationSummarySchema,
  IssueMobilePendingPageSchema
} from '../../../src/shared/issues'
import {
  normalizeExecutionHostId,
  type ExecutionHostId
} from '../../../src/shared/execution-host'
import type { RpcClient } from '../transport/rpc-client'

const MOBILE_PENDING_PAGE_LIMIT = 200

type MobileIssueFailureStatus = 'unsupported' | 'unreachable' | 'invalid'

export type MobileIssuePendingItem = {
  executionHostId: ExecutionHostId
  entry: IssueMobilePendingEntry
}

export type MobileIssuePendingPartition = {
  executionHostId: ExecutionHostId
  status: 'ready' | MobileIssueFailureStatus
  message?: string
}

export type MobileIssuePendingLoadResult = {
  status: 'ready' | MobileIssueFailureStatus
  items: MobileIssuePendingItem[]
  partitions: MobileIssuePendingPartition[]
}

export type MobileIssueConversationLoadResult =
  | { status: 'ready'; conversation: ConversationSummary }
  | { status: 'closed' }
  | { status: MobileIssueFailureStatus; message: string }

export type MobileIssueDetailState =
  | { status: 'ready'; item: MobileIssuePendingItem }
  | { status: 'handled-active'; conversation: ConversationSummary }
  | { status: 'closed'; conversation?: ConversationSummary }
  | { status: MobileIssueFailureStatus; message: string }

type IssueReadClient = Pick<RpcClient, 'sendRequest'>

function failureMessage(value: unknown, fallback: string): string {
  return value instanceof Error && value.message ? value.message : fallback
}

function unavailableStatus(code: string, message: string): MobileIssueFailureStatus {
  return code === 'method_not_found' || message.includes('not available to mobile clients')
    ? 'unsupported'
    : 'unreachable'
}

async function loadPendingPartition(
  client: IssueReadClient,
  executionHostId: ExecutionHostId
): Promise<{
  partition: MobileIssuePendingPartition
  items: MobileIssuePendingItem[]
}> {
  const items: MobileIssuePendingItem[] = []
  const seenCursors = new Set<string>()
  let cursor: string | undefined

  try {
    do {
      const response = await client.sendRequest('issues.pendingForMobile', {
        executionHostId,
        ...(cursor ? { cursor } : {}),
        limit: MOBILE_PENDING_PAGE_LIMIT
      })
      if (!response.ok) {
        return {
          partition: {
            executionHostId,
            status: unavailableStatus(response.error.code, response.error.message),
            message: response.error.message
          },
          items: []
        }
      }

      const parsed = IssueMobilePendingPageSchema.safeParse(response.result)
      if (
        !parsed.success ||
        parsed.data.authority.routeExecutionHostId !== executionHostId
      ) {
        return {
          partition: {
            executionHostId,
            status: 'invalid',
            message: 'The host returned an invalid Issue waiting response.'
          },
          items: []
        }
      }

      items.push(
        ...parsed.data.entries.map((entry) => ({
          executionHostId,
          entry
        }))
      )
      cursor = parsed.data.nextCursor ?? undefined
      if (cursor && seenCursors.has(cursor)) {
        return {
          partition: {
            executionHostId,
            status: 'invalid',
            message: 'The host repeated an Issue waiting cursor.'
          },
          items: []
        }
      }
      if (cursor) {
        seenCursors.add(cursor)
      }
    } while (cursor)

    return {
      partition: { executionHostId, status: 'ready' },
      items
    }
  } catch (error) {
    return {
      partition: {
        executionHostId,
        status: 'unreachable',
        message: failureMessage(error, 'The host is unreachable.')
      },
      items: []
    }
  }
}

function aggregatePendingStatus(
  partitions: readonly MobileIssuePendingPartition[]
): MobileIssuePendingLoadResult['status'] {
  if (partitions.some((partition) => partition.status === 'ready')) {
    return 'ready'
  }
  if (partitions.some((partition) => partition.status === 'invalid')) {
    return 'invalid'
  }
  if (partitions.some((partition) => partition.status === 'unreachable')) {
    return 'unreachable'
  }
  return partitions.length === 0 ? 'ready' : 'unsupported'
}

export async function loadMobileIssuePending(
  client: IssueReadClient,
  executionHostIds: readonly string[]
): Promise<MobileIssuePendingLoadResult> {
  const uniqueHostIds = [
    ...new Set(
      executionHostIds.flatMap((value) => {
        const normalized = normalizeExecutionHostId(value)
        return normalized ? [normalized] : []
      })
    )
  ]
  const results = await Promise.all(
    uniqueHostIds.map((executionHostId) => loadPendingPartition(client, executionHostId))
  )
  const partitions = results.map((result) => result.partition)
  const items = results
    .flatMap((result) => result.items)
    .sort(
      (left, right) =>
        right.entry.round.occurredAt - left.entry.round.occurredAt ||
        right.entry.round.id.localeCompare(left.entry.round.id)
    )
  return {
    status: aggregatePendingStatus(partitions),
    items,
    partitions
  }
}

export async function loadMobileIssueConversation(
  client: IssueReadClient,
  executionHostId: ExecutionHostId,
  conversationId: string
): Promise<MobileIssueConversationLoadResult> {
  try {
    const response = await client.sendRequest('conversations.get', {
      executionHostId,
      conversationId
    })
    if (!response.ok) {
      if (response.error.code === 'conversation_not_found') {
        return { status: 'closed' }
      }
      return {
        status: unavailableStatus(response.error.code, response.error.message),
        message: response.error.message
      }
    }

    const parsed = ConversationSummarySchema.safeParse(response.result)
    if (
      !parsed.success ||
      parsed.data.id !== conversationId ||
      parsed.data.executionHostId !== executionHostId
    ) {
      return {
        status: 'invalid',
        message: 'The host returned an invalid Conversation response.'
      }
    }
    return { status: 'ready', conversation: parsed.data }
  } catch (error) {
    return {
      status: 'unreachable',
      message: failureMessage(error, 'The host is unreachable.')
    }
  }
}

export function resolveMobileIssueDetailState(args: {
  executionHostId: ExecutionHostId
  conversationId: string
  roundRecordId?: string | null
  pending: MobileIssuePendingLoadResult
  conversation: MobileIssueConversationLoadResult
}): MobileIssueDetailState {
  const item = args.pending.items.find(
    (candidate) =>
      candidate.executionHostId === args.executionHostId &&
      candidate.entry.conversation.id === args.conversationId &&
      (!args.roundRecordId || candidate.entry.round.id === args.roundRecordId)
  )
  if (item) {
    return { status: 'ready', item }
  }

  const partition = args.pending.partitions.find(
    (candidate) => candidate.executionHostId === args.executionHostId
  )
  if (partition && partition.status !== 'ready') {
    return {
      status: partition.status,
      message: partition.message ?? 'Issue waiting status is unavailable.'
    }
  }

  if (args.conversation.status === 'ready') {
    return args.conversation.conversation.state === 'closed'
      ? { status: 'closed', conversation: args.conversation.conversation }
      : {
          status: 'handled-active',
          conversation: args.conversation.conversation
        }
  }
  if (args.conversation.status === 'closed') {
    return { status: 'closed' }
  }
  return args.conversation
}
