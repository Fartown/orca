import type { ExecutionHostId } from '../../../../../shared/execution-host'
import type { IssueSearchLoadState } from '../../../issues/issue-search-domain'
import type {
  IssueSidebarPartition,
  IssueSidebarRow
} from './issue-row-types'

export type BuildIssueSearchRowsInput = {
  routeExecutionHostIds: readonly ExecutionHostId[]
  partitionsByRoute: Partial<Record<ExecutionHostId, IssueSidebarPartition>>
  searchLoadsByRoute: Partial<Record<ExecutionHostId, IssueSearchLoadState>>
  typeFilter: string | null
}

export function buildIssueSearchRows(
  input: BuildIssueSearchRowsInput
): IssueSidebarRow[] {
  const rows: IssueSidebarRow[] = []
  for (const routeExecutionHostId of input.routeExecutionHostIds) {
    const partition = input.partitionsByRoute[routeExecutionHostId]
    const search = input.searchLoadsByRoute[routeExecutionHostId]
    rows.push({
      id: `host:${routeExecutionHostId}`,
      type: 'host-state',
      routeExecutionHostId,
      status: search?.status === 'loading'
        ? 'loading'
        : search?.status === 'unsupported'
          ? 'unsupported'
          : search?.status === 'error'
            ? 'error'
            : partition?.status ?? 'idle',
      error: search?.status === 'error' ? search.error : partition?.error ?? null
    })
    if (!search || search.status === 'loading' || search.status === 'idle') {
      continue
    }
    if (search.status === 'unsupported' || search.status === 'error') {
      continue
    }
    if (search.result.isStale || search.result.partial) {
      rows.push({
        id: `search-status:${routeExecutionHostId}`,
        type: 'search-status',
        routeExecutionHostId,
        isStale: search.result.isStale,
        partial: search.result.partial
      })
    }
    const groups = search.result.groups.filter(
      (group) =>
        !input.typeFilter || group.issue?.typeLabel === input.typeFilter
    )
    for (const [groupIndex, group] of groups.entries()) {
      rows.push({
        id: `search-group:${routeExecutionHostId}:${group.issue?.id ?? `unassigned-${groupIndex}`}`,
        type: 'search-group',
        routeExecutionHostId,
        issue: group.issue
      })
      for (const match of group.matches) {
        rows.push({
          id: `search-result:${routeExecutionHostId}:${match.entityKind}:${match.entityId}`,
          type: 'search-result',
          routeExecutionHostId,
          authority: search.result.authority,
          issue: group.issue,
          match
        })
      }
    }
    if (groups.length === 0) {
      rows.push({
        id: `search-empty:${routeExecutionHostId}`,
        type: 'search-empty',
        routeExecutionHostId
      })
    }
  }
  return rows
}
