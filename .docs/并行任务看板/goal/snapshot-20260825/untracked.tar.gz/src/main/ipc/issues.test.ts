import { describe, expect, it, vi } from 'vitest'
import type { IssueFactsChangedEvent } from '../../shared/issues/types'

const { getAllWindowsMock, handleMock, removeHandlerMock } = vi.hoisted(() => ({
  getAllWindowsMock: vi.fn(),
  handleMock: vi.fn(),
  removeHandlerMock: vi.fn()
}))

vi.mock('electron', () => ({
  BrowserWindow: {
    getAllWindows: getAllWindowsMock
  },
  ipcMain: {
    handle: handleMock,
    removeHandler: removeHandlerMock
  }
}))

import { registerIssueClientDataHandlers } from './issues'

describe('registerIssueClientDataHandlers', () => {
  it('broadcasts authoritative Issue facts to each live renderer', () => {
    const factsListeners: Array<(event: IssueFactsChangedEvent) => void> = []
    const onFactsChanged = vi.fn((listener: (event: IssueFactsChangedEvent) => void) => {
      factsListeners.push(listener)
      return vi.fn()
    })
    const liveSend = vi.fn()
    const destroyedWindowSend = vi.fn()
    const destroyedContentsSend = vi.fn()
    getAllWindowsMock.mockReturnValue([
      {
        isDestroyed: () => false,
        webContents: {
          isDestroyed: () => false,
          send: liveSend
        }
      },
      {
        isDestroyed: () => true,
        webContents: {
          isDestroyed: () => false,
          send: destroyedWindowSend
        }
      },
      {
        isDestroyed: () => false,
        webContents: {
          isDestroyed: () => true,
          send: destroyedContentsSend
        }
      }
    ])
    const stop = registerIssueClientDataHandlers(
      {
        readCache: vi.fn(),
        replaceCache: vi.fn(),
        readPreferences: vi.fn(),
        writePreferences: vi.fn()
      } as never,
      { onFactsChanged }
    )
    const event: IssueFactsChangedEvent = {
      type: 'issueFactsChanged',
      authorityId: 'authority-local',
      hostPartitionKey: 'local',
      factsRevision: 2,
      treeRevision: 1,
      issueIds: ['issue-1']
    }

    expect(onFactsChanged).toHaveBeenCalledTimes(1)
    factsListeners[0]?.(event)

    expect(liveSend).toHaveBeenCalledWith('issues:factsChanged', event)
    expect(destroyedWindowSend).not.toHaveBeenCalled()
    expect(destroyedContentsSend).not.toHaveBeenCalled()

    stop()
    expect(onFactsChanged.mock.results[0]?.value).toHaveBeenCalledTimes(1)
  })
})
