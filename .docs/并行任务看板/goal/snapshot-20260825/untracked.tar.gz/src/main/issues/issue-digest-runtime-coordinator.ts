import type {
  IssueDigestConfirmationResult,
  IssueDigestMutationResult,
  IssueDigestPreparation,
  IssueDigestSections
} from '../../shared/issues/digest-types'
import type { IssueMutationIdentity, IssueRecord } from '../../shared/issues/types'
import type { TuiAgent } from '../../shared/tui-agent'
import { issueAuthorityDescriptor, type IssueAuthorityRoute } from './issue-authority-route'
import { buildIssueDigestSnapshot } from './issue-digest-snapshot'
import type { IssueRepository } from './issue-repository'
import { IssueRepositoryError } from './issue-repository-error'

export type IssueDigestGenerationExecutor = {
  generate(input: {
    agent: TuiAgent
    digestId: string
    issue: IssueRecord
    snapshot: ReturnType<typeof buildIssueDigestSnapshot>
  }): Promise<IssueDigestSections>
  cancel(input: { digestId: string; issue: IssueRecord }): Promise<void>
}

export class IssueDigestRuntimeCoordinator {
  constructor(
    private readonly repository: IssueRepository,
    private readonly executor?: IssueDigestGenerationExecutor
  ) {}

  prepare(
    route: IssueAuthorityRoute,
    issue: IssueRecord,
    coversUntil = Date.now()
  ): IssueDigestPreparation {
    const snapshot = this.repository.database.readTransaction(() =>
      buildIssueDigestSnapshot(this.repository.database, issue, coversUntil)
    )
    return {
      authority: issueAuthorityDescriptor(this.repository.database, route),
      issueId: issue.id,
      coversUntil: snapshot.coversUntil,
      inputFingerprint: snapshot.inputFingerprint,
      inputs: snapshot.inputs,
      coverage: snapshot.coverage
    }
  }

  generate(
    route: IssueAuthorityRoute,
    issue: IssueRecord,
    params: {
      identity: IssueMutationIdentity
      coversUntil?: number
      agent: TuiAgent
      expectedInputFingerprint: string
    }
  ): IssueDigestMutationResult {
    const executor = this.requireExecutor()
    const coversUntil = params.coversUntil ?? Date.now()
    const created = this.repository.digests.createGeneratingChecked({
      identity: params.identity,
      issue,
      agent: params.agent,
      coversUntil,
      expectedInputFingerprint: params.expectedInputFingerprint,
      resolveSnapshot: () => {
        const snapshot = buildIssueDigestSnapshot(
          this.repository.database,
          issue,
          coversUntil
        )
        return {
          ...snapshot,
          coverageNote: snapshot.coverage.note
        }
      }
    })
    if (!created.replayed && created.snapshot) {
      void this.settleGeneration(executor, issue, created.digest.id, params.agent, created.snapshot)
    }
    return {
      authority: issueAuthorityDescriptor(this.repository.database, route),
      digest: created.digest
    }
  }

  async cancel(
    route: IssueAuthorityRoute,
    issue: IssueRecord,
    params: {
      identity: IssueMutationIdentity
      digestId: string
    }
  ): Promise<IssueDigestMutationResult> {
    const canceled = this.repository.digests.cancel(params)
    if (canceled.changed && !canceled.replayed && this.executor) {
      try {
        await this.executor.cancel({ digestId: canceled.digest.id, issue })
      } catch (error) {
        console.error('[issues] Failed to cancel Digest generation:', error)
      }
    }
    return {
      authority: issueAuthorityDescriptor(this.repository.database, route),
      digest: canceled.digest
    }
  }

  updateDraft(
    route: IssueAuthorityRoute,
    params: {
      identity: IssueMutationIdentity
      digestId: string
      expectedRevision: number
      patch: Partial<IssueDigestSections>
    }
  ): IssueDigestMutationResult {
    return {
      authority: issueAuthorityDescriptor(this.repository.database, route),
      digest: this.repository.digests.updateDraft(params)
    }
  }

  confirm(
    route: IssueAuthorityRoute,
    issue: IssueRecord,
    params: {
      identity: IssueMutationIdentity
      digestId: string
      expectedRevision: number
      inputFingerprint: string
      confirmStaleAgainstFingerprint?: string
    }
  ): IssueDigestConfirmationResult {
    const result = this.repository.digests.confirmChecked({
      ...params,
      resolveCurrentInputFingerprint: () =>
        buildIssueDigestSnapshot(this.repository.database, issue, Date.now())
          .inputFingerprint
    })
    return {
      ...result,
      authority: issueAuthorityDescriptor(this.repository.database, route)
    }
  }

  private requireExecutor(): IssueDigestGenerationExecutor {
    if (!this.executor) {
      throw new IssueRepositoryError(
        'digest_target_unavailable',
        'Digest generation is not available on this runtime.'
      )
    }
    return this.executor
  }

  private async settleGeneration(
    executor: IssueDigestGenerationExecutor,
    issue: IssueRecord,
    digestId: string,
    agent: TuiAgent,
    snapshot: ReturnType<typeof buildIssueDigestSnapshot>
  ): Promise<void> {
    try {
      const sections = await executor.generate({
        agent,
        digestId,
        issue,
        snapshot
      })
      this.repository.digests.completeGeneration(digestId, sections)
    } catch (error) {
      this.repository.digests.failGeneration(digestId, errorMessage(error))
    }
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
