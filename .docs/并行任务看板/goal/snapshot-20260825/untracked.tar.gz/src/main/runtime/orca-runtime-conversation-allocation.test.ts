import { afterEach, describe, expect, it, vi } from 'vitest'
import type { RuntimeCreateAgentSessionRequest } from '../../shared/agent-session-host-authority'
import type { FolderWorkspace } from '../../shared/folder-workspace-types'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from '../issues/issue-database.test-environment'
import { IssueRepository } from '../issues/issue-repository'
import { OrcaRuntimeService } from './orca-runtime'

const repositories: IssueRepository[] = []
let operationSequence = 0

function operationId(): string {
  operationSequence += 1
  return `${Date.now()}-${operationSequence.toString(16).padStart(32, '0')}`
}

function terminal() {
  return {
    handle: 'term_conversation',
    tabId: '11111111-1111-4111-8111-111111111111',
    paneKey: '11111111-1111-4111-8111-111111111111:22222222-2222-4222-8222-222222222222',
    ptyId: 'pty-conversation',
    worktreeId: 'worktree-1',
    title: null,
    surface: 'background' as const
  }
}

function openRepository(name: string): IssueRepository {
  const repository = new IssueRepository(
    openIssueTestDatabase({
      profileId: name,
      userDataPath: createIssueTestUserDataPath(`orca-runtime-conversation-${name}`)
    })
  )
  repositories.push(repository)
  return repository
}

function worktreeScope() {
  return {
    id: 'worktree-1',
    path: '/tmp/worktree-1',
    connectionId: null,
    repo: null,
    folderWorkspace: null,
    managedWorktree: {
      id: 'worktree-1',
      displayName: 'Worktree One',
      path: '/tmp/worktree-1',
      hostId: 'local'
    }
  }
}

function folderScope() {
  const folderWorkspace = {
    id: 'folder-1',
    name: 'Folder One',
    folderPath: '/tmp/folder-1',
    executionHostId: 'local'
  } as FolderWorkspace
  return {
    id: 'folder:folder-1',
    path: folderWorkspace.folderPath,
    connectionId: null,
    repo: null,
    folderWorkspace,
    managedWorktree: {
      id: 'folder:folder-1',
      displayName: folderWorkspace.name,
      path: folderWorkspace.folderPath,
      hostId: 'local'
    }
  }
}

function createRuntime(
  repository: IssueRepository,
  scope: ReturnType<typeof worktreeScope> | ReturnType<typeof folderScope> = worktreeScope()
): OrcaRuntimeService {
  const runtime = new OrcaRuntimeService(
    {
      getSettings: () => ({
        disabledTuiAgents: [],
        agentCmdOverrides: {},
        agentDefaultArgs: {},
        agentDefaultEnv: {}
      })
    } as never,
    undefined,
    { conversationAllocator: repository.conversationAllocator }
  )
  const internal = runtime as unknown as {
    resolveTerminalWorkspaceLaunchScope: ReturnType<typeof vi.fn>
    markLocalWorkspaceTrustedForAgent: ReturnType<typeof vi.fn>
    markRemoteWorkspaceTrustedForAgent: ReturnType<typeof vi.fn>
  }
  internal.resolveTerminalWorkspaceLaunchScope = vi.fn(async () => scope)
  internal.markLocalWorkspaceTrustedForAgent = vi.fn()
  internal.markRemoteWorkspaceTrustedForAgent = vi.fn()
  return runtime
}

function setPtySpawn(
  runtime: OrcaRuntimeService,
  spawn: NonNullable<Parameters<OrcaRuntimeService['setPtyController']>[0]>['spawn']
): void {
  runtime.setPtyController({
    spawn,
    write: () => true,
    kill: () => true,
    getForegroundProcess: async () => null
  })
}

function managedLaunchOptions() {
  return {
    command: 'codex',
    launchAgent: 'codex' as const,
    launchConfig: {
      agentCommand: 'codex',
      agentArgs: '',
      agentEnv: {}
    },
    launchToken: 'generic-managed-launch'
  }
}

function createRequest(
  overrides: Partial<RuntimeCreateAgentSessionRequest> = {}
): RuntimeCreateAgentSessionRequest {
  return {
    clientOperationId: operationId(),
    worktree: 'id:worktree-1',
    agent: 'codex',
    prompt: 'implement the issue',
    presentation: 'background',
    ...overrides
  }
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  operationSequence = 0
})

describe('OrcaRuntimeService Conversation allocation', () => {
  it('allocates a Conversation for generic managed-agent terminal creation before spawn', async () => {
    const repository = openRepository('generic-managed')
    const runtime = createRuntime(repository)
    const spawn = vi.fn(async () => {
      expect(repository.conversations.list()).toEqual([
        expect.objectContaining({
          issueId: null,
          workspaceRef: { type: 'worktree', worktreeId: 'worktree-1' },
          agent: 'codex',
          state: 'active'
        })
      ])
      return { id: 'pty-generic-managed' }
    })
    setPtySpawn(runtime, spawn)

    const created = await runtime.createTerminal('id:worktree-1', managedLaunchOptions())

    expect(created.conversationId).toBe(repository.conversations.list()[0]?.id)
    expect(spawn).toHaveBeenCalledOnce()
  })

  it('does not allocate a Conversation for an ordinary shell terminal', async () => {
    const repository = openRepository('generic-shell')
    const runtime = createRuntime(repository)
    const spawn = vi.fn().mockResolvedValue({ id: 'pty-shell' })
    setPtySpawn(runtime, spawn)

    const created = await runtime.createTerminal('id:worktree-1', {
      command: 'git status'
    })

    expect(created.conversationId).toBeUndefined()
    expect(repository.conversations.list()).toEqual([])
  })

  it('reuses a structured create allocation at the generic spawn boundary', async () => {
    const repository = openRepository('structured-boundary')
    const runtime = createRuntime(repository)
    const spawn = vi.fn(async () => {
      expect(repository.conversations.list()).toHaveLength(1)
      return { id: 'pty-structured-boundary' }
    })
    setPtySpawn(runtime, spawn)

    const result = await runtime.createAgentSession(createRequest())

    expect(result.conversationId).toBe(repository.conversations.list()[0]?.id)
    expect(repository.conversations.list()).toHaveLength(1)
  })

  it('closes a generic managed launch only when spawn fails before commit', async () => {
    const repository = openRepository('generic-failure')
    const runtime = createRuntime(repository)
    setPtySpawn(runtime, vi.fn().mockRejectedValue(new Error('spawn ENOENT')))

    await expect(
      runtime.createTerminal('id:worktree-1', managedLaunchOptions())
    ).rejects.toThrow('spawn ENOENT')

    expect(repository.conversations.list()).toEqual([
      expect.objectContaining({
        state: 'closed',
        launchFailure: 'spawn ENOENT'
      })
    ])
  })

  it('keeps a generic managed Conversation active when spawn outcome is unknown', async () => {
    const repository = openRepository('generic-unknown')
    const runtime = createRuntime(repository)
    const unknown = Object.assign(new Error('transport disconnected'), {
      agentSessionOperationOutcome: 'unknown'
    })
    setPtySpawn(runtime, vi.fn().mockRejectedValue(unknown))

    await expect(
      runtime.createTerminal('id:worktree-1', managedLaunchOptions())
    ).rejects.toThrow('transport disconnected')

    expect(repository.conversations.list()).toEqual([
      expect.objectContaining({
        state: 'active',
        launchFailure: null
      })
    ])
  })

  it('persists one Issue-bound Conversation before spawn and replays it by operation ID', async () => {
    const repository = openRepository('fresh')
    const issue = repository.issues.create({
      identity: { callerFingerprint: 'runtime-test', mutationId: 'issue-1' },
      input: { kind: 'local', executionHostId: 'local', title: 'Tracked work' }
    })
    const runtime = createRuntime(repository)
    const request = createRequest({ issueId: issue.id })
    const createTerminal = vi.spyOn(runtime, 'createTerminal').mockImplementation(
      async (_selector, options) => {
        const conversations = repository.conversations.list()
        expect(conversations).toEqual([
          expect.objectContaining({
            issueId: issue.id,
            workspaceRef: { type: 'worktree', worktreeId: 'worktree-1' },
            workspaceSnapshot: { name: 'Worktree One', path: '/tmp/worktree-1' },
            state: 'active'
          })
        ])
        expect(
          repository.database
            .prepare('SELECT COUNT(*) AS count FROM conversation_launch_claims')
            .get()
        ).toEqual({ count: 1 })
        options?.onPtySpawnCommitted?.()
        return terminal()
      }
    )

    const first = await runtime.createAgentSession(request, { clientId: 'device-1' })
    const replay = await runtime.createAgentSession(request, { clientId: 'device-1' })

    expect(first).toMatchObject({
      disposition: 'created',
      conversationId: repository.conversations.list()[0]?.id
    })
    expect(replay).toMatchObject({
      disposition: 'replayed',
      conversationId: first.conversationId
    })
    expect(repository.conversations.list()).toHaveLength(1)
    expect(createTerminal).toHaveBeenCalledOnce()
  })

  it('includes issueId in the operation fingerprint', async () => {
    const repository = openRepository('fingerprint')
    const firstIssue = repository.issues.create({
      identity: { callerFingerprint: 'runtime-test', mutationId: 'issue-1' },
      input: { kind: 'local', executionHostId: 'local', title: 'First' }
    })
    const secondIssue = repository.issues.create({
      identity: { callerFingerprint: 'runtime-test', mutationId: 'issue-2' },
      input: { kind: 'local', executionHostId: 'local', title: 'Second' }
    })
    const runtime = createRuntime(repository)
    vi.spyOn(runtime, 'createTerminal').mockImplementation(async (_selector, options) => {
      options?.onPtySpawnCommitted?.()
      return terminal()
    })
    const request = createRequest({ issueId: firstIssue.id })

    await runtime.createAgentSession(request, { clientId: 'device-1' })
    await expect(
      runtime.createAgentSession(
        { ...request, issueId: secondIssue.id },
        { clientId: 'device-1' }
      )
    ).rejects.toThrow('agent_session_operation_conflict')
    expect(repository.conversations.list()).toEqual([
      expect.objectContaining({ issueId: firstIssue.id })
    ])
  })

  it('keeps a pre-spawn failure as a closed diagnostic Conversation', async () => {
    const repository = openRepository('failure')
    const runtime = createRuntime(repository)
    vi.spyOn(runtime, 'createTerminal').mockRejectedValue(new Error('spawn ENOENT'))

    await expect(runtime.createAgentSession(createRequest())).rejects.toThrow('spawn ENOENT')

    expect(repository.conversations.list()).toEqual([
      expect.objectContaining({
        state: 'closed',
        launchFailure: 'spawn ENOENT'
      })
    ])
    expect(
      repository.database
        .prepare('SELECT consumed_at IS NOT NULL AS retired FROM conversation_launch_claims')
        .get()
    ).toEqual({ retired: 1 })
  })

  it('does not close a Conversation when physical spawn committed before publication failed', async () => {
    const repository = openRepository('committed-failure')
    const runtime = createRuntime(repository)
    vi.spyOn(runtime, 'createTerminal').mockImplementation(async (_selector, options) => {
      options?.onPtySpawnCommitted?.()
      throw new Error('publication failed')
    })
    const request = createRequest()

    await expect(runtime.createAgentSession(request)).rejects.toThrow('publication failed')
    await expect(runtime.createAgentSession(request)).rejects.toThrow('publication failed')

    expect(repository.conversations.list()).toEqual([
      expect.objectContaining({ state: 'active', launchFailure: null })
    ])
    expect(
      repository.database
        .prepare('SELECT consumed_at FROM conversation_launch_claims')
        .get()
    ).toEqual({ consumed_at: null })
  })

  it('reuses the Conversation for a strong resume identity without changing Issue binding', async () => {
    const repository = openRepository('resume')
    const issue = repository.issues.create({
      identity: { callerFingerprint: 'runtime-test', mutationId: 'issue-1' },
      input: { kind: 'local', executionHostId: 'local', title: 'Resume work' }
    })
    const allocated = repository.conversationAllocator.allocateFreshLaunch({
      executionHostId: 'local',
      workspaceRef: { type: 'worktree', worktreeId: 'worktree-1' },
      workspaceSnapshot: { name: 'Worktree One', path: '/tmp/worktree-1' },
      agent: 'codex',
      issueId: issue.id,
      launchToken: 'seed-launch'
    })
    repository.conversationAllocator.attachProviderIdentity({
      executionHostId: 'local',
      agent: 'codex',
      providerSession: { key: 'session_id', id: 'provider-session-1' },
      launchToken: 'seed-launch'
    })
    const runtime = createRuntime(repository)
    vi.spyOn(runtime, 'createTerminal').mockImplementation(async (_selector, options) => {
      options?.onPtySpawnCommitted?.()
      return terminal()
    })

    const result = await runtime.ensureAgentSession({
      kind: 'explicit',
      worktree: 'id:worktree-1',
      agent: 'codex',
      providerSession: { key: 'session_id', id: 'provider-session-1' }
    })

    expect(result.conversationId).toBe(allocated.conversation.id)
    expect(repository.conversations.list()).toEqual([
      expect.objectContaining({ id: allocated.conversation.id, issueId: issue.id })
    ])
    expect(
      repository.database
        .prepare('SELECT COUNT(*) AS count FROM conversation_launch_claims')
        .get()
    ).toEqual({ count: 2 })
  })

  it('persists folder Workspace membership rather than a path-only identity', async () => {
    const repository = openRepository('folder')
    const runtime = createRuntime(repository, folderScope())
    vi.spyOn(runtime, 'createTerminal').mockImplementation(async (_selector, options) => {
      options?.onPtySpawnCommitted?.()
      return { ...terminal(), worktreeId: 'folder:folder-1' }
    })

    const result = await runtime.createAgentSession(
      createRequest({ worktree: 'id:folder:folder-1' })
    )

    expect(result.conversationId).toBeTruthy()
    expect(repository.conversations.list()).toEqual([
      expect.objectContaining({
        workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-1' },
        workspaceSnapshot: { name: 'Folder One', path: '/tmp/folder-1' }
      })
    ])
  })

  it('resolves one live pane to its Conversation identity ownership context', async () => {
    const repository = openRepository('hook-context')
    const runtime = createRuntime(repository)
    setPtySpawn(runtime, vi.fn().mockResolvedValue({ id: 'pty-hook-context' }))
    const created = await runtime.createTerminal('id:worktree-1', {
      command: 'codex'
    })
    const paneKey = created.paneKey
    expect(paneKey).toBeTruthy()
    if (!paneKey) {
      throw new Error('Expected createTerminal to return a pane key.')
    }

    await expect(
      runtime.resolveConversationHookIdentityContext(paneKey, 'worktree-1')
    ).resolves.toEqual({
      executionHostId: 'local',
      workspaceRef: { type: 'worktree', worktreeId: 'worktree-1' },
      workspaceSnapshot: { name: 'Worktree One', path: '/tmp/worktree-1' },
      processIncarnation: expect.stringContaining('pty-hook-context'),
      connectionId: null,
      hostPlatform: process.platform
    })
    await expect(
      runtime.resolveConversationHookIdentityContext(paneKey, 'other-worktree')
    ).resolves.toBeNull()
  })
})
