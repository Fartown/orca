import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  getIssueDatabasePath,
  IssueDatabase,
  type OpenIssueDatabaseOptions
} from './issue-database'

const READ_ONLY_CODES = new Set(['EACCES', 'EPERM', 'EROFS'])
const directories: string[] = []
let logicalPathSequence = 0

function detectFileDatabaseSupport(): boolean {
  try {
    const directory = mkdtempSync(join(tmpdir(), 'orca-issues-capability-'))
    rmSync(directory, { recursive: true, force: true })
    return true
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code
    if (process.env.CODEX_SANDBOX && code && READ_ONLY_CODES.has(code)) {
      return false
    }
    throw error
  }
}

export const issueFileDatabaseTestsAvailable = detectFileDatabaseSupport()

export function createIssueTestUserDataPath(prefix: string): string {
  if (issueFileDatabaseTestsAvailable) {
    const directory = mkdtempSync(join(tmpdir(), `${prefix}-`))
    directories.push(directory)
    return directory
  }
  logicalPathSequence += 1
  return join(tmpdir(), `${prefix}-transient-${logicalPathSequence}`)
}

export function openIssueTestDatabase(options: OpenIssueDatabaseOptions): IssueDatabase {
  if (issueFileDatabaseTestsAvailable) {
    return IssueDatabase.open(options)
  }
  return IssueDatabase.openTransient({
    logicalPath: getIssueDatabasePath(options.profileId, options.userDataPath),
    migrationHooks: options.migrationHooks,
    roundRetentionLimits: options.roundRetentionLimits
  })
}

export function removeIssueTestDirectories(): void {
  for (const directory of directories.splice(0)) {
    rmSync(directory, { recursive: true, force: true })
  }
}
