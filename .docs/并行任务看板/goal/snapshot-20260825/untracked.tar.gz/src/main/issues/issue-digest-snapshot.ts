import { createHash } from 'node:crypto'
import type {
  IssueDigestCoverage,
  IssueDigestInputSummary
} from '../../shared/issues/digest-types'
import type { ConversationRecord, IssueRecord } from '../../shared/issues/types'
import { listConversationRecords } from './conversation-record-queries'
import type { IssueDatabase } from './issue-database'
import {
  applyIssueDigestInputBudget,
  type MaterializedIssueDigestInput
} from './issue-digest-input-budget'
import type { IssueDigestInputCandidate } from './issue-digest-input-candidate'
import {
  readDirectChildDigestCandidates,
  readUserArtifactDigestCandidates
} from './issue-digest-reference-candidates'
import {
  readOutstandingDigestRoundCandidates,
  readResolvedDigestRoundCandidates
} from './issue-digest-round-candidates'
import { issueDisplayTitle } from './issue-event-repository'

export type { MaterializedIssueDigestInput } from './issue-digest-input-budget'

export type MaterializedIssueDigestSnapshot = {
  issueId: string
  issueTitle: string
  coversUntil: number
  inputFingerprint: string
  inputs: IssueDigestInputSummary[]
  materializedInputs: MaterializedIssueDigestInput[]
  coverage: IssueDigestCoverage
  directConversations: ConversationRecord[]
}

export function buildIssueDigestSnapshot(
  database: IssueDatabase,
  issue: IssueRecord,
  coversUntil: number
): MaterializedIssueDigestSnapshot {
  const candidates = readDigestCandidates(database, issue, coversUntil)
  const budgeted = applyIssueDigestInputBudget(candidates)
  return {
    issueId: issue.id,
    issueTitle: issueDisplayTitle(issue),
    coversUntil,
    inputFingerprint: fingerprintDigestInputs(
      issue.id,
      candidates,
      budgeted.inputs
    ),
    ...budgeted,
    directConversations: listConversationRecords(database, { issueId: issue.id })
  }
}

function readDigestCandidates(
  database: IssueDatabase,
  issue: IssueRecord,
  coversUntil: number
): IssueDigestInputCandidate[] {
  return [
    ...readOutstandingDigestRoundCandidates(database, issue, coversUntil),
    ...readDirectChildDigestCandidates(database, issue),
    ...readUserArtifactDigestCandidates(database, issue),
    ...readResolvedDigestRoundCandidates(database, issue, coversUntil)
  ]
}

function fingerprintDigestInputs(
  issueId: string,
  candidates: IssueDigestInputCandidate[],
  inputs: IssueDigestInputSummary[]
): string {
  return createHash('sha256')
    .update(
      JSON.stringify({
        version: 1,
        issueId,
        inputs: candidates.map((candidate, index) => ({
          kind: candidate.kind,
          inputId: candidate.inputId,
          inputVersion: candidate.inputVersion,
          sourceFingerprint: candidate.sourceFingerprint,
          includedBytes: inputs[index]?.includedBytes ?? 0,
          omissionReason: inputs[index]?.omissionReason ?? null
        }))
      })
    )
    .digest('hex')
}
