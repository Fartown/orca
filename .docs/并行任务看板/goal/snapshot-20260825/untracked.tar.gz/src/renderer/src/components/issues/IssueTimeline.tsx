import React from 'react'
import {
  AlertCircle,
  CheckCircle2,
  Circle,
  Loader2
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import type { RoundRecordPreview } from '../../../../shared/issues/types'
import {
  getPrimaryRoundPreviewField,
  getRoundPreviewFields
} from '../../issues/round-record-preview-presentation'

export type IssueTimelineStatus =
  | 'idle'
  | 'loading'
  | 'ready'
  | 'cached'
  | 'unsupported'
  | 'error'

type IssueTimelineProps = {
  rounds: readonly RoundRecordPreview[]
  status: IssueTimelineStatus
  error?: string | null
  hasMore?: boolean
  loadingMore?: boolean
  onLoadMore?: () => void
}

export function IssueTimeline({
  rounds,
  status,
  error = null,
  hasMore = false,
  loadingMore = false,
  onLoadMore
}: IssueTimelineProps): React.JSX.Element {
  return (
    <section aria-labelledby="issue-history-heading">
      <div className="mb-2 flex items-center gap-2">
        <h2 id="issue-history-heading" className="text-sm font-semibold">
          History
        </h2>
        <span className="text-xs tabular-nums text-muted-foreground">
          {rounds.length}
        </span>
      </div>
      {status === 'cached' ? (
        <StatusNotice text={error || 'Showing cached Round Records.'} />
      ) : null}
      {status === 'unsupported' ? (
        <StatusNotice text="This Orca host does not support Issue history yet." />
      ) : null}
      {status === 'error' && error ? <StatusNotice text={error} error /> : null}
      {status === 'loading' && rounds.length === 0 ? (
        <div className="flex items-center justify-center gap-2 rounded-lg border border-border/60 py-8 text-xs text-muted-foreground">
          <Loader2 className="size-3.5 animate-spin" />
          Loading Round Records…
        </div>
      ) : rounds.length === 0 && status !== 'unsupported' && status !== 'error' ? (
        <div className="rounded-lg border border-dashed border-border/70 px-4 py-6 text-center text-xs text-muted-foreground">
          No Round Records yet.
        </div>
      ) : (
        <div className="space-y-2">
          {rounds.map((round) => (
            <RoundRecordCard key={round.id} round={round} />
          ))}
        </div>
      )}
      {hasMore && onLoadMore ? (
        <div className="mt-3 flex justify-center">
          <Button
            type="button"
            variant="outline"
            size="sm"
            disabled={loadingMore}
            onClick={onLoadMore}
          >
            {loadingMore ? (
              <Loader2 className="size-3.5 animate-spin" />
            ) : null}
            Load older records
          </Button>
        </div>
      ) : null}
    </section>
  )
}

function RoundRecordCard({
  round
}: {
  round: RoundRecordPreview
}): React.JSX.Element {
  const primary = getPrimaryRoundPreviewField(round)
  const resolved = round.effectiveResolvedAt !== null
  const timestamp = new Date(round.occurredAt)
  return (
    <article
      data-round-record-id={round.id}
      className="rounded-lg border border-border/60 bg-card px-3 py-2.5"
    >
      <div className="flex flex-wrap items-center gap-1.5">
        <Badge variant="outline" className="h-5 px-1.5 text-[10px]">
          {round.kind}
        </Badge>
        <Badge
          variant={round.readAt === null ? 'secondary' : 'ghost'}
          className="h-5 px-1.5 text-[10px]"
        >
          {round.readAt === null ? 'Unread' : 'Read'}
        </Badge>
        <Badge
          variant={resolved ? 'ghost' : 'default'}
          className="h-5 px-1.5 text-[10px]"
        >
          {resolved ? (
            <CheckCircle2 className="size-3" />
          ) : (
            <Circle className="size-3" />
          )}
          {resolved ? 'Resolved' : 'Needs attention'}
        </Badge>
        <time
          className="ml-auto text-[10px] text-muted-foreground"
          dateTime={timestamp.toISOString()}
          title={timestamp.toLocaleString()}
        >
          {timestamp.toLocaleString()}
        </time>
      </div>
      <div className="mt-2" data-round-preview-only="true">
        <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
          {primary.label} · bounded preview
        </p>
        <p className="mt-1 whitespace-pre-wrap break-words text-xs leading-5">
          {primary.value.preview ?? 'Preview unavailable.'}
        </p>
      </div>
      <dl className="mt-2 grid gap-x-3 gap-y-1 border-t border-border/50 pt-2 text-[10px] text-muted-foreground sm:grid-cols-[auto_1fr]">
        {getRoundPreviewFields(round).map(({ key, label, value }) => (
          <React.Fragment key={key}>
            <dt>{label}</dt>
            <dd
              data-round-field={key}
              data-completeness={value.completeness}
              data-storage={value.storage}
            >
              {value.completeness} · {value.storage}
            </dd>
          </React.Fragment>
        ))}
      </dl>
    </article>
  )
}

function StatusNotice({
  text,
  error = false
}: {
  text: string
  error?: boolean
}): React.JSX.Element {
  return (
    <div
      role={error ? 'alert' : 'status'}
      className="mb-2 flex items-start gap-2 rounded-md border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground"
    >
      <AlertCircle className="mt-0.5 size-3.5 shrink-0" />
      <span>{text}</span>
    </div>
  )
}
