import { createHash } from 'node:crypto'
import type { ExecutionHostId } from '../../shared/execution-host'
import type {
  LegacyActivityMigrationEntry,
  LegacyActivityMigrationResult
} from '../../shared/issues/types'
import {
  issueAuthorityDescriptor,
  resolveIssueAuthorityRoute
} from './issue-authority-route'
import { IssueDashboardProjectionQuery } from './issue-dashboard-projection'
import { executeIssueMutation } from './issue-mutation-receipt'
import {
  issueMutationIdentity,
  type IssueRepository
} from './issue-repository'

export class LegacyActivityMigration {
  private readonly dashboardProjection: IssueDashboardProjectionQuery

  constructor(
    private readonly repository: IssueRepository,
    private readonly options: {
      isManagedSshTarget?: (targetId: string) => boolean
    } = {}
  ) {
    this.dashboardProjection = new IssueDashboardProjectionQuery(
      repository.database
    )
  }

  migrate(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      entries: LegacyActivityMigrationEntry[]
    },
    callerFingerprint: string
  ): LegacyActivityMigrationResult {
    const route = resolveIssueAuthorityRoute(
      params.executionHostId,
      this.options
    )
    return executeIssueMutation({
      database: this.repository.database,
      identity: issueMutationIdentity(
        callerFingerprint,
        params.mutationId
      ),
      method: 'issues.migrateLegacyActivity',
      payload: params,
      operation: () => {
        const entries = uniqueMigrationEntries(params.entries)
        const projection = this.dashboardProjection.projectWithinTransaction(
          route,
          entries.map((entry) => entry.paneKey)
        )
        const conversationByPane = new Map(
          projection.panes.map((pane) => [
            pane.paneKey,
            pane.conversationId
          ])
        )
        const migrated: LegacyActivityMigrationResult['migrated'] = []
        const unresolvedLegacyEventIds: string[] = []
        for (const entry of entries) {
          const conversationId = conversationByPane.get(entry.paneKey)
          if (!conversationId) {
            unresolvedLegacyEventIds.push(entry.legacyEventId)
            continue
          }
          const round = this.repository.rounds.create({
            identity: issueMutationIdentity(
              `${callerFingerprint}:legacy-activity`,
              eventMutationId(
                route.hostPartitionKey,
                entry
              )
            ),
            input: {
              conversationId,
              kind: entry.state === 'done' ? 'completion' : 'waiting',
              stateSource: 'reconciled',
              occurredAt: entry.occurredAt,
              dedupeKey: legacyRoundDedupeKey(
                route.hostPartitionKey,
                conversationId,
                entry.legacyEventId
              ),
              userInput: previewInput(entry.userInputPreview),
              agentOutput: previewInput(entry.agentOutputPreview),
              pendingQuestion: previewInput(
                entry.pendingQuestionPreview
              ),
              finalizedAt: entry.occurredAt,
              refs: [
                {
                  kind: 'legacy-activity-event',
                  value: entry.legacyEventId,
                  reachable: null
                }
              ]
            }
          })
          if (
            entry.acknowledgedAt !== null &&
            entry.acknowledgedAt >= entry.occurredAt &&
            (round.readAt === null || round.readAt < entry.acknowledgedAt)
          ) {
            this.repository.rounds.markRead({
              identity: issueMutationIdentity(
                `${callerFingerprint}:legacy-activity-read`,
                eventReadMutationId(
                  route.hostPartitionKey,
                  entry.legacyEventId,
                  entry.acknowledgedAt
                )
              ),
              input: {
                ids: [round.id],
                readAt: entry.acknowledgedAt
              }
            })
          }
          migrated.push({
            legacyEventId: entry.legacyEventId,
            conversationId,
            roundRecordId: round.id
          })
        }
        return {
          authority: issueAuthorityDescriptor(
            this.repository.database,
            route
          ),
          migrated,
          unresolvedLegacyEventIds
        }
      }
    })
  }
}

function uniqueMigrationEntries(
  entries: readonly LegacyActivityMigrationEntry[]
): LegacyActivityMigrationEntry[] {
  const unique = new Map<string, LegacyActivityMigrationEntry>()
  for (const entry of entries) {
    if (!unique.has(entry.legacyEventId)) {
      unique.set(entry.legacyEventId, entry)
    }
  }
  return [...unique.values()]
}

function previewInput(preview: string | null | undefined) {
  if (!preview) {
    return undefined
  }
  return {
    completeness: 'truncated' as const,
    storage: 'preview' as const,
    preview
  }
}

function eventMutationId(
  hostPartitionKey: string,
  entry: LegacyActivityMigrationEntry
): string {
  return `legacy-activity-${hashIdentity(
    JSON.stringify([
      hostPartitionKey,
      entry.legacyEventId,
      entry.userInputPreview ?? null,
      entry.agentOutputPreview ?? null,
      entry.pendingQuestionPreview ?? null
    ])
  )}`
}

function eventReadMutationId(
  hostPartitionKey: string,
  legacyEventId: string,
  acknowledgedAt: number
): string {
  return `legacy-activity-read-${hashIdentity(
    `${hostPartitionKey}\0${legacyEventId}\0${acknowledgedAt}`
  )}`
}

function legacyRoundDedupeKey(
  hostPartitionKey: string,
  conversationId: string,
  legacyEventId: string
): string {
  return `legacy-activity:${hashIdentity(
    `${hostPartitionKey}\0${conversationId}\0${legacyEventId}`
  )}`
}

function hashIdentity(value: string): string {
  return createHash('sha256').update(value).digest('hex')
}
