import type {
  ConversationNavigationTarget,
  IssueAuthorityDescriptor,
  IssueDisplayProjection,
  RoundRecordPreview
} from './types'

export type IssueMobilePendingEntry = {
  round: RoundRecordPreview
  conversation: ConversationNavigationTarget
  issue: IssueDisplayProjection | null
}

export type IssueMobilePendingPage = {
  authority: IssueAuthorityDescriptor
  snapshotFactsRevision: number
  entries: IssueMobilePendingEntry[]
  nextCursor: string | null
}
