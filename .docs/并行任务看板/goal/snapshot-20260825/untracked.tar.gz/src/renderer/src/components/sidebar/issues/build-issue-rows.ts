import type { ExecutionHostId } from '../../../../../shared/execution-host'
import type {
  ConversationSummary,
  IssueListFilter,
  IssueSummary
} from '../../../../../shared/issues/types'
import { groupIssueConversationsByWorkspace } from '../../../issues/issue-conversation-groups'
import type {
  IssueSidebarPartition,
  IssueSidebarRow
} from './issue-row-types'

export const UNASSIGNED_ISSUE_ROW_KEY = 'unassigned'

export type BuildIssueRowsInput = {
  partitions: readonly IssueSidebarPartition[]
  filter: IssueListFilter
  collapsedIssueIds: ReadonlySet<string>
  selectedRouteExecutionHostId: ExecutionHostId | null
  searchQuery?: string
  typeFilter?: string | null
}

export function buildIssueRows(input: BuildIssueRowsInput): IssueSidebarRow[] {
  const rows: IssueSidebarRow[] = []
  const partitions = input.selectedRouteExecutionHostId
    ? input.partitions.filter(
        (partition) =>
          partition.routeExecutionHostId === input.selectedRouteExecutionHostId
      )
    : input.partitions

  for (const partition of partitions) {
    rows.push({
      id: `host:${partition.routeExecutionHostId}`,
      type: 'host-state',
      routeExecutionHostId: partition.routeExecutionHostId,
      status: partition.status,
      error: partition.error ?? null
    })
    if (!partition.authority || !partition.issues.length) {
      if (partition.status === 'ready' || partition.status === 'cached') {
        rows.push({
          id: `empty:${partition.routeExecutionHostId}:${input.filter}`,
          type: 'empty',
          routeExecutionHostId: partition.routeExecutionHostId,
          filter: input.filter
        })
      }
      appendUnassignedRows(rows, partition, input.collapsedIssueIds)
      continue
    }

    const tree = buildIssueTree(partition.issues)
    const directMatches = new Set(
      partition.issues
        .filter((issue) => issueMatches(issue, input))
        .map((issue) => issue.id)
    )
    const included = includeAncestorPaths(directMatches, tree.byId)
    for (const root of tree.roots) {
      appendIssueTreeRows({
        rows,
        partition,
        issue: root,
        depth: 0,
        included,
        directMatches,
        childrenByParentId: tree.childrenByParentId,
        collapsedIssueIds: input.collapsedIssueIds
      })
    }
    if (directMatches.size === 0) {
      rows.push({
        id: `empty:${partition.routeExecutionHostId}:${input.filter}`,
        type: 'empty',
        routeExecutionHostId: partition.routeExecutionHostId,
        filter: input.filter
      })
    }
    appendUnassignedRows(rows, partition, input.collapsedIssueIds)
  }
  return rows
}

function issueMatches(
  issue: IssueSummary,
  input: Pick<BuildIssueRowsInput, 'filter' | 'searchQuery' | 'typeFilter'>
): boolean {
  const stateMatches =
    input.filter === 'all'
      ? issue.state === 'active'
      : input.filter === 'archived'
        ? issue.state === 'archived'
        : issue.ownUnresolvedCount > 0
  if (!stateMatches) {
    return false
  }
  if (input.typeFilter && issue.typeLabel !== input.typeFilter) {
    return false
  }
  const query = input.searchQuery?.trim().toLocaleLowerCase()
  if (!query) {
    return true
  }
  return issueSearchText(issue).includes(query)
}

function issueSearchText(issue: IssueSummary): string {
  const sourceTitle =
    issue.source.kind === 'external'
      ? `${issue.source.provider} ${issue.source.identifier ?? issue.source.number ?? ''} ${issue.source.titleSnapshot}`
      : `${issue.source.number}`
  return [issue.localTitle, sourceTitle, issue.typeLabel, issue.note]
    .filter((value): value is string => Boolean(value))
    .join(' ')
    .toLocaleLowerCase()
}

function buildIssueTree(issues: readonly IssueSummary[]): {
  byId: Map<string, IssueSummary>
  roots: IssueSummary[]
  childrenByParentId: Map<string, IssueSummary[]>
} {
  const byId = new Map(issues.map((issue) => [issue.id, issue]))
  const childrenByParentId = new Map<string, IssueSummary[]>()
  const roots: IssueSummary[] = []
  for (const issue of issues) {
    if (!issue.parentId || !byId.has(issue.parentId)) {
      roots.push(issue)
      continue
    }
    const siblings = childrenByParentId.get(issue.parentId) ?? []
    siblings.push(issue)
    childrenByParentId.set(issue.parentId, siblings)
  }
  sortIssues(roots)
  for (const children of childrenByParentId.values()) {
    sortIssues(children)
  }
  return { byId, roots, childrenByParentId }
}

function sortIssues(issues: IssueSummary[]): void {
  issues.sort(
    (left, right) =>
      left.siblingOrder - right.siblingOrder ||
      left.createdAt - right.createdAt ||
      left.id.localeCompare(right.id)
  )
}

function includeAncestorPaths(
  matches: ReadonlySet<string>,
  byId: ReadonlyMap<string, IssueSummary>
): Set<string> {
  const included = new Set(matches)
  for (const issueId of matches) {
    let current = byId.get(issueId)
    const seen = new Set<string>()
    while (current?.parentId && !seen.has(current.parentId)) {
      seen.add(current.parentId)
      included.add(current.parentId)
      current = byId.get(current.parentId)
    }
  }
  return included
}

function appendIssueTreeRows(args: {
  rows: IssueSidebarRow[]
  partition: IssueSidebarPartition
  issue: IssueSummary
  depth: number
  included: ReadonlySet<string>
  directMatches: ReadonlySet<string>
  childrenByParentId: ReadonlyMap<string, readonly IssueSummary[]>
  collapsedIssueIds: ReadonlySet<string>
}): void {
  const {
    rows,
    partition,
    issue,
    included,
    directMatches,
    childrenByParentId,
    collapsedIssueIds
  } = args
  if (!included.has(issue.id) || !partition.authority) {
    return
  }
  const children = (childrenByParentId.get(issue.id) ?? []).filter((child) =>
    included.has(child.id)
  )
  const conversations = partition.detailsByIssueId[issue.id] ?? []
  const contextOnly = !directMatches.has(issue.id)
  const expandable =
    children.length > 0 ||
    conversations.length > 0 ||
    issue.directConversationCount > 0
  const expanded =
    contextOnly || (expandable && !collapsedIssueIds.has(issue.id))
  rows.push({
    id: `issue:${partition.routeExecutionHostId}:${issue.id}`,
    type: 'issue',
    routeExecutionHostId: partition.routeExecutionHostId,
    authority: partition.authority,
    issue,
    depth: Math.min(args.depth, 2) as 0 | 1 | 2,
    contextOnly,
    expandable,
    expanded
  })
  if (!expanded) {
    return
  }
  if (!contextOnly) {
    appendConversationGroups(
      rows,
      partition.routeExecutionHostId,
      issue.id,
      conversations,
      args.depth + 1
    )
  }
  for (const child of children) {
    appendIssueTreeRows({
      ...args,
      issue: child,
      depth: args.depth + 1
    })
  }
}

function appendUnassignedRows(
  rows: IssueSidebarRow[],
  partition: IssueSidebarPartition,
  collapsedIssueIds: ReadonlySet<string>
): void {
  const summary = partition.unassignedSummary
  const count = summary?.conversationCount ?? partition.unassignedConversations.length
  if (count === 0) {
    return
  }
  const key = `${UNASSIGNED_ISSUE_ROW_KEY}:${partition.routeExecutionHostId}`
  const expanded = !collapsedIssueIds.has(key)
  rows.push({
    id: key,
    type: 'unassigned-summary',
    routeExecutionHostId: partition.routeExecutionHostId,
    conversationCount: count,
    unresolvedCount: summary?.unresolvedCount ?? 0,
    expanded
  })
  if (expanded) {
    appendConversationGroups(
      rows,
      partition.routeExecutionHostId,
      null,
      partition.unassignedConversations,
      1
    )
  }
}

function appendConversationGroups(
  rows: IssueSidebarRow[],
  routeExecutionHostId: ExecutionHostId,
  issueId: string | null,
  conversations: readonly ConversationSummary[],
  depth: number
): void {
  for (const group of groupIssueConversationsByWorkspace(conversations)) {
    rows.push({
      id: `workspace:${routeExecutionHostId}:${issueId ?? 'unassigned'}:${group.key}`,
      type: 'workspace-header',
      routeExecutionHostId,
      issueId,
      workspace: group.workspace,
      depth,
      count: group.conversations.length
    })
    for (const conversation of group.conversations) {
      rows.push({
        id: `conversation:${routeExecutionHostId}:${conversation.id}`,
        type: 'conversation',
        routeExecutionHostId,
        issueId,
        conversation,
        depth: depth + 1
      })
    }
  }
}
