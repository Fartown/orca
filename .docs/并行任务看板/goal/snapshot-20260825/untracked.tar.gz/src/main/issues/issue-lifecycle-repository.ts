import type {
  ArchiveIssueBlocker,
  IssueRecord,
  RoundRecordKind
} from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { issueEventRef, IssueEventRepository } from './issue-event-repository'
import { bumpIssueHostRevisions, getIssueHostRevisions } from './issue-host-state'
import { executeIssueMutation } from './issue-mutation-receipt'
import { requireIssueRecord } from './issue-record-queries'
import { IssueRepositoryError } from './issue-repository-error'
import type {
  ArchiveIssueInput,
  ArchiveIssueResult,
  IssueMutationParams,
  ReopenIssueInput
} from './issue-repository-types'

type WaitingBlockerRow = {
  conversationId: string
  roundRecordId: string
  dedupeKey: string
}

export class IssueLifecycleRepository {
  constructor(
    private readonly database: IssueDatabase,
    private readonly events: IssueEventRepository
  ) {}

  archive(params: IssueMutationParams<ArchiveIssueInput>): ArchiveIssueResult {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.archive',
      payload: params.input,
      operation: () => this.archiveWithinTransaction(params.input)
    })
  }

  reopen(params: IssueMutationParams<ReopenIssueInput>): IssueRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.reopen',
      payload: params.input,
      operation: () => this.reopenWithinTransaction(params.input)
    })
  }

  findAutoReopenCandidate(params: {
    conversationId: string
    kind: RoundRecordKind
    occurredAt: number
    authoritativeCurrentState: boolean
  }): IssueRecord | null {
    const row = this.database
      .prepare(
        `SELECT issue.*
         FROM conversations conversation
         JOIN issues issue ON issue.id = conversation.issue_id
         WHERE conversation.id = ? AND issue.state = 'archived'`
      )
      .get(params.conversationId) as Record<string, unknown> | undefined
    if (!row) {
      return null
    }
    const issue = requireIssueRecord(this.database, String(row.id))
    const isNewer = issue.archivedAt === null || params.occurredAt > issue.archivedAt
    const isCurrentWaiting = params.kind === 'waiting' && params.authoritativeCurrentState
    return isNewer || isCurrentWaiting ? issue : null
  }

  applyAutoReopenWithinTransaction(issue: IssueRecord, now: number): IssueRecord {
    this.database
      .prepare(
        `UPDATE issues
         SET state = 'active', archived_at = NULL, updated_at = ?
         WHERE id = ? AND state = 'archived'`
      )
      .run(now, issue.id)
    return requireIssueRecord(this.database, issue.id)
  }

  appendAutoReopenEventWithinTransaction(params: {
    issue: IssueRecord
    roundId: string
    occurredAt: number
    factsRevision: number
  }): void {
    this.events.appendWithinTransaction({
      hostPartitionKey: params.issue.hostPartitionKey,
      kind: 'reopened',
      issueRefs: [issueEventRef(params.issue, 'issue')],
      payload: { cause: 'new-round', roundRecordId: params.roundId },
      occurredAt: params.occurredAt,
      factsRevision: params.factsRevision,
      dedupeKey: `issue-reopened:round:${params.roundId}`
    })
  }

  private archiveWithinTransaction(input: ArchiveIssueInput): ArchiveIssueResult {
    const issue = requireIssueRecord(this.database, input.id)
    this.assertFactsRevision(issue, input.expectedFactsRevision)
    if (issue.state === 'archived') {
      const revisions = getIssueHostRevisions(this.database, issue.hostPartitionKey)
      return {
        status: 'archived',
        issueId: issue.id,
        archivedAt: issue.archivedAt ?? issue.updatedAt,
        resolvedCompletionIds: [],
        revisions
      }
    }
    const blockers = this.listArchiveBlockers(issue, input.runtimeBlockers ?? [])
    if (blockers.length > 0) {
      return { status: 'blocked', issueId: issue.id, blockers }
    }

    const now = Date.now()
    const completionIds = (
      this.database
        .prepare(
          `SELECT round.id
           FROM round_record_effective_state round
           JOIN conversations conversation ON conversation.id = round.conversation_id
           WHERE conversation.issue_id = ?
             AND round.kind = 'completion'
             AND round.effective_resolved_at IS NULL
           ORDER BY round.occurred_at, round.id`
        )
        .all(issue.id) as { id: string }[]
    ).map((row) => row.id)
    if (completionIds.length > 0) {
      const resolve = this.database.prepare(
        `UPDATE round_records
         SET resolved_at = ?, resolution = 'archive'
         WHERE id = ? AND resolved_at IS NULL`
      )
      for (const roundId of completionIds) {
        resolve.run(now, roundId)
      }
    }
    this.database
      .prepare(
        `UPDATE issues
         SET state = 'archived', archived_at = ?, updated_at = ?
         WHERE id = ?`
      )
      .run(now, now, issue.id)
    const revisions = bumpIssueHostRevisions(
      this.database,
      issue.hostPartitionKey,
      { tree: false },
      now
    )
    const archived = requireIssueRecord(this.database, issue.id)
    this.events.appendWithinTransaction({
      hostPartitionKey: issue.hostPartitionKey,
      kind: 'archived',
      issueRefs: [issueEventRef(archived, 'issue')],
      payload: { resolvedCompletionIds: completionIds },
      occurredAt: now,
      factsRevision: revisions.factsRevision
    })
    return {
      status: 'archived',
      issueId: issue.id,
      archivedAt: now,
      resolvedCompletionIds: completionIds,
      revisions
    }
  }

  private reopenWithinTransaction(input: ReopenIssueInput): IssueRecord {
    const issue = requireIssueRecord(this.database, input.id)
    this.assertFactsRevision(issue, input.expectedFactsRevision)
    if (issue.state === 'active') {
      return issue
    }
    const now = Date.now()
    const reopened = this.applyAutoReopenWithinTransaction(issue, now)
    const revisions = bumpIssueHostRevisions(
      this.database,
      issue.hostPartitionKey,
      { tree: false },
      now
    )
    this.events.appendWithinTransaction({
      hostPartitionKey: issue.hostPartitionKey,
      kind: 'reopened',
      issueRefs: [issueEventRef(reopened, 'issue')],
      payload: { cause: 'explicit' },
      occurredAt: now,
      factsRevision: revisions.factsRevision
    })
    return reopened
  }

  private listArchiveBlockers(
    issue: IssueRecord,
    runtimeBlockers: readonly { conversationId: string; dedupeKey?: string | null }[]
  ): ArchiveIssueBlocker[] {
    const rows = this.database
      .prepare(
        `SELECT
           conversation.id AS conversationId,
           round.id AS roundRecordId,
           round.dedupe_key AS dedupeKey
         FROM conversations conversation
         JOIN round_record_effective_state round
           ON round.conversation_id = conversation.id
         WHERE conversation.issue_id = ?
           AND round.kind = 'waiting'
           AND round.effective_resolved_at IS NULL
         ORDER BY round.occurred_at, round.id`
      )
      .all(issue.id) as WaitingBlockerRow[]
    const blockers: ArchiveIssueBlocker[] = rows.map((row) => ({
      conversationId: row.conversationId,
      kind: 'unresolved-waiting',
      roundRecordId: row.roundRecordId,
      dedupeKey: row.dedupeKey
    }))
    const knownConversations = new Set(
      (
        this.database
          .prepare('SELECT id FROM conversations WHERE issue_id = ?')
          .all(issue.id) as { id: string }[]
      ).map((row) => row.id)
    )
    for (const blocker of runtimeBlockers) {
      if (!knownConversations.has(blocker.conversationId)) {
        throw new IssueRepositoryError(
          'issue_archive_blocked',
          `Runtime blocker Conversation ${blocker.conversationId} is not direct to Issue ${issue.id}.`
        )
      }
      if (
        blockers.some(
          (candidate) =>
            candidate.conversationId === blocker.conversationId &&
            candidate.dedupeKey === (blocker.dedupeKey ?? null)
        )
      ) {
        continue
      }
      blockers.push({
        conversationId: blocker.conversationId,
        kind: 'runtime-waiting',
        roundRecordId: null,
        dedupeKey: blocker.dedupeKey ?? null
      })
    }
    return blockers
  }

  private assertFactsRevision(issue: IssueRecord, expected: number | undefined): void {
    if (expected === undefined) {
      return
    }
    const current = getIssueHostRevisions(this.database, issue.hostPartitionKey).factsRevision
    if (current !== expected) {
      throw new IssueRepositoryError(
        'issue_facts_revision_stale',
        `Issue facts revision ${expected} is stale.`,
        { expectedFactsRevision: expected, currentFactsRevision: current }
      )
    }
  }
}
