import React, { useMemo } from 'react'
import {
  CircleDot,
  Folder,
  MessageSquare,
  PauseCircle
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import type { ConversationSummary } from '../../../../shared/issues/types'
import {
  groupIssueConversationsByWorkspace
} from '../../issues/issue-conversation-groups'
import {
  getPrimaryRoundPreviewField
} from '../../issues/round-record-preview-presentation'

type IssueConversationListProps = {
  conversations: readonly ConversationSummary[]
  onOpenConversation?: (conversation: ConversationSummary) => void
}

export function IssueConversationList({
  conversations,
  onOpenConversation
}: IssueConversationListProps): React.JSX.Element {
  const groups = useMemo(
    () => groupIssueConversationsByWorkspace(conversations),
    [conversations]
  )

  return (
    <section aria-labelledby="issue-direct-work-heading">
      <SectionHeading
        id="issue-direct-work-heading"
        title="Direct work"
        count={conversations.length}
      />
      {groups.length === 0 ? (
        <EmptyState text="No Conversations are directly attached to this Issue." />
      ) : (
        <div className="space-y-4">
          {groups.map((group) => (
            <div
              key={group.key}
              data-workspace-group={group.key}
              className="overflow-hidden rounded-lg border border-border/60 bg-card"
            >
              <div className="flex h-8 items-center gap-2 border-b border-border/50 px-3 text-xs text-muted-foreground">
                <Folder className="size-3.5 shrink-0" />
                <span className="min-w-0 flex-1 truncate">
                  {group.workspace.name}
                </span>
                <span className="tabular-nums">
                  {group.conversations.length}
                </span>
              </div>
              <div className="divide-y divide-border/50">
                {group.conversations.map((conversation) => (
                  <ConversationRow
                    key={conversation.id}
                    conversation={conversation}
                    onOpen={onOpenConversation}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  )
}

function ConversationRow({
  conversation,
  onOpen
}: {
  conversation: ConversationSummary
  onOpen?: (conversation: ConversationSummary) => void
}): React.JSX.Element {
  const latest = conversation.latestRound
    ? getPrimaryRoundPreviewField(conversation.latestRound)
    : null
  const content = (
    <>
      <div className="flex min-w-0 items-center gap-2">
        {conversation.state === 'active' ? (
          <CircleDot className="size-3.5 shrink-0 text-muted-foreground" />
        ) : (
          <PauseCircle className="size-3.5 shrink-0 text-muted-foreground" />
        )}
        <span className="min-w-0 flex-1 truncate text-sm font-medium">
          {conversation.title || 'Untitled conversation'}
        </span>
        <Badge variant="outline" className="h-5 px-1.5 text-[10px]">
          {conversation.agent}
        </Badge>
        {conversation.unresolvedRoundCount > 0 ? (
          <Badge className="h-5 px-1.5 text-[10px]">
            {conversation.unresolvedRoundCount} pending
          </Badge>
        ) : null}
      </div>
      {latest ? (
        <div className="mt-1.5 flex min-w-0 items-start gap-2 pl-5 text-xs text-muted-foreground">
          <MessageSquare className="mt-0.5 size-3 shrink-0" />
          <div className="min-w-0">
            <p className="line-clamp-2 whitespace-pre-wrap break-words">
              {latest.value.preview ?? 'Preview unavailable.'}
            </p>
            <p
              className="mt-1 text-[10px]"
              data-round-capture={`${latest.value.completeness}:${latest.value.storage}`}
            >
              {latest.label} · {latest.value.completeness} ·{' '}
              {latest.value.storage}
            </p>
          </div>
        </div>
      ) : null}
    </>
  )

  return onOpen ? (
    <button
      type="button"
      className="block w-full px-3 py-2.5 text-left hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-ring"
      onClick={() => onOpen(conversation)}
    >
      {content}
    </button>
  ) : (
    <div className="px-3 py-2.5">{content}</div>
  )
}

function SectionHeading({
  id,
  title,
  count
}: {
  id: string
  title: string
  count: number
}): React.JSX.Element {
  return (
    <div className="mb-2 flex items-center gap-2">
      <h2 id={id} className="text-sm font-semibold">
        {title}
      </h2>
      <span className="text-xs tabular-nums text-muted-foreground">
        {count}
      </span>
    </div>
  )
}

function EmptyState({ text }: { text: string }): React.JSX.Element {
  return (
    <div className="rounded-lg border border-dashed border-border/70 px-4 py-5 text-center text-xs text-muted-foreground">
      {text}
    </div>
  )
}
