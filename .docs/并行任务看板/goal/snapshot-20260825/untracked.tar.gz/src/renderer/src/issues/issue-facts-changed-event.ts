import type { ExecutionHostId } from '../../../shared/execution-host'
import type { IssueFactsChangedEvent } from '../../../shared/issues/types'

export const ISSUE_FACTS_CHANGED_EVENT = 'orca:issue-facts-changed'

export type IssueFactsChangedEventDetail = IssueFactsChangedEvent & {
  routeExecutionHostId: ExecutionHostId
}

export function dispatchIssueFactsChanged(
  detail: IssueFactsChangedEventDetail
): void {
  window.dispatchEvent(
    new CustomEvent<IssueFactsChangedEventDetail>(ISSUE_FACTS_CHANGED_EVENT, {
      detail
    })
  )
}
