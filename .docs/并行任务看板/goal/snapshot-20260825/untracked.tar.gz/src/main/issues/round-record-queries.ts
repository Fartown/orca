import type { RoundRecord, RoundRecordRef } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { IssueRepositoryError } from './issue-repository-error'
import type { RoundRecordListFilter } from './issue-repository-types'
import { roundRecordFromRow, type RoundRecordRow } from './issue-row-mappers'

const ROUND_SELECT = 'SELECT * FROM round_record_effective_state'

export function getRoundRecord(database: IssueDatabase, id: string): RoundRecord | undefined {
  const row = database.prepare(`${ROUND_SELECT} WHERE id = ?`).get(id) as RoundRecordRow | undefined
  return row ? roundRecordFromRow(row) : undefined
}

export function getRoundRecordByDedupeKey(
  database: IssueDatabase,
  dedupeKey: string
): RoundRecord | undefined {
  const row = database
    .prepare(`${ROUND_SELECT} WHERE dedupe_key = ?`)
    .get(dedupeKey) as RoundRecordRow | undefined
  return row ? roundRecordFromRow(row) : undefined
}

export function getRoundRecordByRef(
  database: IssueDatabase,
  ref: Pick<RoundRecordRef, 'kind' | 'value'>
): RoundRecord | undefined {
  const row = database
    .prepare(
      `${ROUND_SELECT}
       WHERE id = (
         SELECT round_id
         FROM round_refs
         WHERE ref_kind = ? AND value = ?
         ORDER BY round_id
         LIMIT 1
       )`
    )
    .get(ref.kind, ref.value) as RoundRecordRow | undefined
  return row ? roundRecordFromRow(row) : undefined
}

export function listRoundRecordRefs(
  database: IssueDatabase,
  roundId: string
): RoundRecordRef[] {
  const rows = database
    .prepare(
      `SELECT ref_kind AS kind, value, reachable
       FROM round_refs
       WHERE round_id = ?
       ORDER BY ref_kind, value`
    )
    .all(roundId) as Array<{ kind: string; value: string; reachable: number | null }>
  return rows.map((row) => ({
    kind: row.kind,
    value: row.value,
    reachable: row.reachable === null ? null : row.reachable === 1
  }))
}

export function requireRoundRecord(database: IssueDatabase, id: string): RoundRecord {
  const round = getRoundRecord(database, id)
  if (!round) {
    throw new IssueRepositoryError('round_not_found', `Round Record ${id} was not found.`)
  }
  return round
}

export function listRoundRecords(
  database: IssueDatabase,
  filter: RoundRecordListFilter
): RoundRecord[] {
  const rows = filter.kind
    ? (database
        .prepare(
          `${ROUND_SELECT}
           WHERE conversation_id = ? AND kind = ?
           ORDER BY occurred_at DESC, id`
        )
        .all(filter.conversationId, filter.kind) as RoundRecordRow[])
    : (database
        .prepare(
          `${ROUND_SELECT}
           WHERE conversation_id = ?
           ORDER BY occurred_at DESC, id`
        )
        .all(filter.conversationId) as RoundRecordRow[])
  return rows.map(roundRecordFromRow)
}
