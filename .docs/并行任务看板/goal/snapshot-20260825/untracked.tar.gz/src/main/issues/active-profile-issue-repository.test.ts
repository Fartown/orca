import { afterEach, describe, expect, it } from 'vitest'
import {
  createIssueTestUserDataPath,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { ActiveProfileIssueRepository } from './active-profile-issue-repository'

const lifecycles: ActiveProfileIssueRepository[] = []

afterEach(() => {
  for (const lifecycle of lifecycles.splice(0)) {
    lifecycle.close()
  }
  removeIssueTestDirectories()
})

describe('ActiveProfileIssueRepository', () => {
  it('opens the active profile partition and exposes its Conversation allocator', () => {
    const userDataPath = createIssueTestUserDataPath('orca-active-profile-issues')
    const first = ActiveProfileIssueRepository.open({
      profileId: 'profile-a',
      userDataPath
    })
    const second = ActiveProfileIssueRepository.open({
      profileId: 'profile-b',
      userDataPath
    })
    lifecycles.push(first, second)

    const allocated = first.conversationAllocator.allocateFreshLaunch({
      executionHostId: 'local',
      workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-a' },
      workspaceSnapshot: { name: 'Folder A', path: '/workspace/a' },
      agent: 'codex',
      title: 'Active profile launch',
      titleSource: 'user',
      issueId: null,
      launchToken: 'active-profile-token'
    })

    expect(first.repository.conversations.get(allocated.conversation.id)).toEqual(
      allocated.conversation
    )
    expect(second.repository.conversations.get(allocated.conversation.id)).toBeUndefined()
  })

  it('closes once and rejects allocator use after committed shutdown', () => {
    const lifecycle = ActiveProfileIssueRepository.open({
      profileId: 'profile-close',
      userDataPath: createIssueTestUserDataPath('orca-active-profile-close')
    })
    lifecycles.push(lifecycle)

    lifecycle.close()
    lifecycle.close()

    expect(() => lifecycle.conversationAllocator).toThrow(
      'Active profile Issue repository is closed.'
    )
  })
})
