import type { ExecutionHostId } from '../../../shared/execution-host'
import { parseExecutionHostId } from '../../../shared/execution-host'
import {
  DEFAULT_ISSUE_CLIENT_PREFERENCES,
  type IssueClientPreferences,
  type IssueClientSnapshot
} from '../../../shared/issues/client-data'
import type {
  ConversationSummary,
  IssueAuthorityDescriptor,
  IssueDetail,
  IssueListFilter,
  RoundRecordPage,
  RoundRecordPreview
} from '../../../shared/issues/types'
import type { IssueSidebarPartition } from '../components/sidebar/issues/issue-row-types'
import { createStore, type StoreApi } from 'zustand/vanilla'
import {
  cancelIssueDigest,
  confirmIssueDigest,
  generateIssueDigest,
  loadIssueDetail,
  loadIssuePartition,
  loadIssueRounds,
  loadUnassignedConversations,
  prepareIssueDigest,
  searchIssues,
  updateIssueDigestDraft,
  type IssueClientLoadResult,
  type IssueRoundLoadScope
} from './issue-client-data'
import {
  createIssueDigestDomain,
  type IssueDigestDomainActions,
  type IssueDigestDomainDependencies,
  type IssueDigestDomainFields
} from './issue-digest-domain'
import {
  ISSUE_FACTS_CHANGED_EVENT,
  type IssueFactsChangedEventDetail
} from './issue-facts-changed-event'
import {
  createIssueSearchDomain,
  type IssueSearchDomainActions,
  type IssueSearchDomainDependencies,
  type IssueSearchDomainFields
} from './issue-search-domain'

type HydrationStatus = 'idle' | 'loading' | 'ready' | 'error'

export type IssuesDomainPartition = IssueSidebarPartition & {
  cachedAt: number | null
  factsRevision: number | null
  treeRevision: number | null
}

export type IssueDetailLoadState =
  | { status: 'idle' | 'loading' | 'unsupported' }
  | { status: 'ready' | 'cached'; detail: IssueDetail; error: string | null }
  | { status: 'error'; error: string }

export type IssueRoundLoadState = {
  status:
    | 'idle'
    | 'loading'
    | 'ready'
    | 'cached'
    | 'unsupported'
    | 'error'
  authority: IssueAuthorityDescriptor | null
  snapshotFactsRevision: number | null
  rounds: readonly RoundRecordPreview[]
  nextCursor: string | null
  error: string | null
  loadingMore: boolean
}

type IssuesDomainCoreState = {
  hydrationStatus: HydrationStatus
  hydrationError: string | null
  preferenceWriteError: string | null
  preferences: IssueClientPreferences
  visibleRouteExecutionHostIds: ExecutionHostId[]
  partitionsByRoute: Partial<Record<ExecutionHostId, IssuesDomainPartition>>
  detailLoadsByKey: Record<string, IssueDetailLoadState>
  roundLoadsByKey: Record<string, IssueRoundLoadState>
  hydrate: () => Promise<void>
  flushPreferences: () => Promise<void>
  setVisibleRoutes: (routes: readonly ExecutionHostId[]) => Promise<void>
  refreshPartition: (routeExecutionHostId: ExecutionHostId) => Promise<void>
  refreshVisibleRoutes: () => Promise<void>
  loadDetail: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string
  ) => Promise<IssueDetailLoadState>
  loadUnassigned: (
    routeExecutionHostId: ExecutionHostId
  ) => Promise<IssueClientLoadResult<ConversationSummary[]>>
  loadRounds: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string
  ) => Promise<IssueRoundLoadState>
  loadMoreRounds: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string
  ) => Promise<IssueRoundLoadState>
  setSidebarRootMode: (
    mode: IssueClientPreferences['sidebarRootMode']
  ) => void
  setFilter: (filter: IssueListFilter) => void
  setSearchQuery: (searchQuery: string) => void
  setTypeFilter: (typeFilter: string | null) => void
  toggleCollapsedIssue: (issueId: string) => void
  selectIssue: (
    routeExecutionHostId: ExecutionHostId | null,
    issueId: string | null
  ) => void
  setSidebarScrollOffset: (sidebarScrollOffset: number) => void
}

export type IssuesDomainState = IssuesDomainCoreState &
  IssueSearchDomainFields &
  IssueSearchDomainActions &
  IssueDigestDomainFields &
  IssueDigestDomainActions

type IssuesDomainCoreDependencies = {
  readPreferences: () => Promise<IssueClientPreferences>
  writePreferences: (
    preferences: IssueClientPreferences
  ) => Promise<IssueClientPreferences>
  loadPartition: (
    routeExecutionHostId: ExecutionHostId
  ) => Promise<IssueClientLoadResult<IssueClientSnapshot>>
  loadDetail: (
    routeExecutionHostId: ExecutionHostId,
    issueId: string
  ) => Promise<IssueClientLoadResult<IssueDetail>>
  loadUnassigned: (
    routeExecutionHostId: ExecutionHostId
  ) => Promise<IssueClientLoadResult<ConversationSummary[]>>
  loadRounds: (
    routeExecutionHostId: ExecutionHostId,
    scope: IssueRoundLoadScope
  ) => Promise<IssueClientLoadResult<RoundRecordPage>>
}

export type IssuesDomainDependencies = IssuesDomainCoreDependencies &
  Partial<
    IssueSearchDomainDependencies &
      Omit<IssueDigestDomainDependencies, 'refreshDetail'>
  >

type PreferencePatch = Partial<
  Omit<IssueClientPreferences, 'version'>
>

type RefreshEntry = {
  promise: Promise<void>
  rerun: boolean
}

export function createIssuesDomainStore(
  dependencies: IssuesDomainDependencies
): StoreApi<IssuesDomainState> {
  let hydrationPromise: Promise<void> | null = null
  let pendingPreferencePatch: PreferencePatch = {}
  let preferenceRevision = 0
  let preferenceWriteTail = Promise.resolve()
  const refreshes = new Map<ExecutionHostId, RefreshEntry>()
  const detailGenerations = new Map<string, number>()
  const roundGenerations = new Map<string, number>()

  return createStore<IssuesDomainState>()((set, get) => {
    const searchDomain = createIssueSearchDomain(
      {
        searchIssues:
          dependencies.searchIssues ??
          (async () => ({
            status: 'error',
            error: 'Issue search is unavailable.'
          }))
      },
      set,
      get
    )
    const digestUnavailable = async () =>
      ({
        status: 'error',
        error: 'Issue summary editing is unavailable.'
      }) as const
    const digestDomain = createIssueDigestDomain(
      {
        prepareDigest: dependencies.prepareDigest ?? digestUnavailable,
        generateDigest: dependencies.generateDigest ?? digestUnavailable,
        cancelDigest: dependencies.cancelDigest ?? digestUnavailable,
        updateDigestDraft:
          dependencies.updateDigestDraft ?? digestUnavailable,
        confirmDigest: dependencies.confirmDigest ?? digestUnavailable,
        refreshDetail: (routeExecutionHostId, issueId) =>
          get().loadDetail(routeExecutionHostId, issueId)
      },
      set,
      get
    )
    const queuePreferenceWrite = (
      preferences: IssueClientPreferences,
      revision: number
    ): void => {
      preferenceWriteTail = preferenceWriteTail
        .catch(() => undefined)
        .then(async () => {
          try {
            const persisted = await dependencies.writePreferences(preferences)
            if (revision === preferenceRevision) {
              set({
                preferences: persisted,
                preferenceWriteError: null
              })
            }
          } catch (error) {
            if (revision === preferenceRevision) {
              set({ preferenceWriteError: errorMessage(error) })
            }
          }
        })
    }

    const updatePreferences = (patch: PreferencePatch): void => {
      preferenceRevision += 1
      pendingPreferencePatch = { ...pendingPreferencePatch, ...patch }
      const preferences = { ...get().preferences, ...patch }
      set({ preferences, preferenceWriteError: null })
      if (get().hydrationStatus === 'ready') {
        pendingPreferencePatch = {}
        queuePreferenceWrite(preferences, preferenceRevision)
      }
    }

    const runPartitionRefresh = async (
      routeExecutionHostId: ExecutionHostId,
      entry: RefreshEntry
    ): Promise<void> => {
      do {
        entry.rerun = false
        const previous = get().partitionsByRoute[routeExecutionHostId]
        setPartition(set, routeExecutionHostId, {
          ...(previous ?? emptyPartition(routeExecutionHostId)),
          status: 'loading',
          error: null
        })
        const result = await dependencies.loadPartition(routeExecutionHostId)
        setPartition(
          set,
          routeExecutionHostId,
          partitionFromLoad(routeExecutionHostId, result, previous)
        )
      } while (entry.rerun)
    }

    const refreshPartition = (
      routeExecutionHostId: ExecutionHostId
    ): Promise<void> => {
      const parsed = parseExecutionHostId(routeExecutionHostId)
      if (!parsed) {
        return Promise.resolve()
      }
      const existing = refreshes.get(parsed.id)
      if (existing) {
        existing.rerun = true
        return existing.promise
      }
      const entry: RefreshEntry = {
        promise: Promise.resolve(),
        rerun: false
      }
      entry.promise = runPartitionRefresh(parsed.id, entry).finally(() => {
        if (refreshes.get(parsed.id) === entry) {
          refreshes.delete(parsed.id)
        }
      })
      refreshes.set(parsed.id, entry)
      return entry.promise
    }

    return {
      hydrationStatus: 'idle',
      hydrationError: null,
      preferenceWriteError: null,
      preferences: { ...DEFAULT_ISSUE_CLIENT_PREFERENCES },
      visibleRouteExecutionHostIds: [],
      partitionsByRoute: {},
      detailLoadsByKey: {},
      roundLoadsByKey: {},
      searchLoadsByRoute: {},
      digestLoadsByKey: {},
      ...searchDomain,
      ...digestDomain,
      hydrate: () => {
        if (hydrationPromise) {
          return hydrationPromise
        }
        set({ hydrationStatus: 'loading', hydrationError: null })
        hydrationPromise = dependencies
          .readPreferences()
          .then((persisted) => {
            const preferences = {
              ...persisted,
              ...pendingPreferencePatch
            }
            const hasPendingPatch =
              Object.keys(pendingPreferencePatch).length > 0
            pendingPreferencePatch = {}
            set({
              hydrationStatus: 'ready',
              hydrationError: null,
              preferences
            })
            if (hasPendingPatch) {
              queuePreferenceWrite(preferences, preferenceRevision)
            }
          })
          .catch((error) => {
            set({
              hydrationStatus: 'error',
              hydrationError: errorMessage(error)
            })
          })
          .finally(() => {
            hydrationPromise = null
          })
        return hydrationPromise
      },
      flushPreferences: async () => {
        await preferenceWriteTail
      },
      setVisibleRoutes: async (routes) => {
        const normalized = normalizeRoutes(routes)
        const previous = get().visibleRouteExecutionHostIds
        set({ visibleRouteExecutionHostIds: normalized })
        const previousSet = new Set(previous)
        await Promise.all(
          normalized
            .filter(
              (route) =>
                !previousSet.has(route) ||
                !get().partitionsByRoute[route]
            )
            .map((route) => refreshPartition(route))
        )
      },
      refreshPartition,
      refreshVisibleRoutes: async () => {
        await Promise.all(
          get().visibleRouteExecutionHostIds.map((route) =>
            refreshPartition(route)
          )
        )
      },
      loadDetail: async (routeExecutionHostId, issueId) => {
        const key = issueDetailKey(routeExecutionHostId, issueId)
        const generation = (detailGenerations.get(key) ?? 0) + 1
        detailGenerations.set(key, generation)
        set((state) => ({
          detailLoadsByKey: {
            ...state.detailLoadsByKey,
            [key]: { status: 'loading' }
          }
        }))
        const result = await dependencies.loadDetail(
          routeExecutionHostId,
          issueId
        )
        const next = detailStateFromLoad(result)
        if (detailGenerations.get(key) !== generation) {
          return get().detailLoadsByKey[key] ?? next
        }
        set((state) => ({
          detailLoadsByKey: {
            ...state.detailLoadsByKey,
            [key]: next
          },
          partitionsByRoute: patchPartitionDetail(
            state.partitionsByRoute,
            routeExecutionHostId,
            next
          )
        }))
        return next
      },
      loadUnassigned: async (routeExecutionHostId) => {
        const result = await dependencies.loadUnassigned(
          routeExecutionHostId
        )
        if (result.status === 'ready' || result.status === 'cached') {
          set((state) => ({
            partitionsByRoute: patchUnassignedConversations(
              state.partitionsByRoute,
              routeExecutionHostId,
              result.value
            )
          }))
        }
        return result
      },
      loadRounds: async (routeExecutionHostId, issueId) => {
        const key = issueRoundKey(routeExecutionHostId, issueId)
        const generation = (roundGenerations.get(key) ?? 0) + 1
        roundGenerations.set(key, generation)
        const previous =
          get().roundLoadsByKey[key] ?? emptyRoundLoadState()
        setRoundLoadState(set, key, {
          ...previous,
          status: 'loading',
          error: null,
          loadingMore: false
        })
        const result = await dependencies.loadRounds(routeExecutionHostId, {
          issueId
        })
        const next = roundStateFromLoad(result, previous)
        if (roundGenerations.get(key) !== generation) {
          return get().roundLoadsByKey[key] ?? next
        }
        setRoundLoadState(set, key, next)
        return next
      },
      loadMoreRounds: async (routeExecutionHostId, issueId) => {
        const key = issueRoundKey(routeExecutionHostId, issueId)
        const previous =
          get().roundLoadsByKey[key] ?? emptyRoundLoadState()
        if (
          previous.loadingMore ||
          !previous.nextCursor ||
          previous.snapshotFactsRevision === null ||
          (previous.status !== 'ready' && previous.status !== 'cached')
        ) {
          return previous
        }
        const generation = (roundGenerations.get(key) ?? 0) + 1
        roundGenerations.set(key, generation)
        setRoundLoadState(set, key, {
          ...previous,
          error: null,
          loadingMore: true
        })
        const result = await dependencies.loadRounds(routeExecutionHostId, {
          issueId,
          cursor: previous.nextCursor,
          expectedFactsRevision: previous.snapshotFactsRevision
        })
        const next = appendRoundLoadState(previous, result)
        if (roundGenerations.get(key) !== generation) {
          return get().roundLoadsByKey[key] ?? next
        }
        setRoundLoadState(set, key, next)
        return next
      },
      setSidebarRootMode: (sidebarRootMode) =>
        updatePreferences({ sidebarRootMode }),
      setFilter: (filter) => updatePreferences({ filter }),
      setSearchQuery: (searchQuery) =>
        updatePreferences({ searchQuery }),
      setTypeFilter: (typeFilter) => updatePreferences({ typeFilter }),
      toggleCollapsedIssue: (issueId) => {
        const collapsed = new Set(get().preferences.collapsedIssueIds)
        if (collapsed.has(issueId)) {
          collapsed.delete(issueId)
        } else {
          collapsed.add(issueId)
        }
        updatePreferences({ collapsedIssueIds: [...collapsed] })
      },
      selectIssue: (selectedRouteExecutionHostId, selectedIssueId) =>
        updatePreferences({
          selectedRouteExecutionHostId,
          selectedIssueId
        }),
      setSidebarScrollOffset: (sidebarScrollOffset) =>
        updatePreferences({
          sidebarScrollOffset: Math.max(0, sidebarScrollOffset)
        })
    }
  })
}

export function issueDetailKey(
  routeExecutionHostId: ExecutionHostId,
  issueId: string
): string {
  return `${routeExecutionHostId}\0${issueId}`
}

export function issueRoundKey(
  routeExecutionHostId: ExecutionHostId,
  issueId: string
): string {
  return `${routeExecutionHostId}\0${issueId}`
}

export function connectIssuesDomainEvents(
  store: StoreApi<IssuesDomainState>,
  target: Pick<EventTarget, 'addEventListener' | 'removeEventListener'>
): () => void {
  const listener: EventListener = (event) => {
    const detail = (event as CustomEvent<IssueFactsChangedEventDetail>).detail
    const route = parseExecutionHostId(detail?.routeExecutionHostId)
    if (
      !route ||
      !store
        .getState()
        .visibleRouteExecutionHostIds.includes(route.id)
    ) {
      return
    }
    void store.getState().refreshPartition(route.id)
  }
  target.addEventListener(ISSUE_FACTS_CHANGED_EVENT, listener)
  return () => target.removeEventListener(ISSUE_FACTS_CHANGED_EVENT, listener)
}

function normalizeRoutes(
  routes: readonly ExecutionHostId[]
): ExecutionHostId[] {
  const normalized: ExecutionHostId[] = []
  const seen = new Set<ExecutionHostId>()
  for (const route of routes) {
    const id = parseExecutionHostId(route)?.id
    if (!id || seen.has(id)) {
      continue
    }
    seen.add(id)
    normalized.push(id)
  }
  return normalized
}

function emptyPartition(
  routeExecutionHostId: ExecutionHostId
): IssuesDomainPartition {
  return {
    routeExecutionHostId,
    status: 'idle',
    authority: null,
    issues: [],
    detailsByIssueId: {},
    unassignedConversations: [],
    error: null,
    cachedAt: null,
    factsRevision: null,
    treeRevision: null
  }
}

function partitionFromLoad(
  routeExecutionHostId: ExecutionHostId,
  result: IssueClientLoadResult<IssueClientSnapshot>,
  previous: IssuesDomainPartition | undefined
): IssuesDomainPartition {
  if (result.status === 'ready' || result.status === 'cached') {
    const snapshot = result.value
    return {
      routeExecutionHostId,
      status: result.status,
      authority: snapshot.authority,
      issues: snapshot.issues,
      detailsByIssueId: Object.fromEntries(
        snapshot.details.map((detail) => [
          detail.issue.id,
          detail.directConversations
        ])
      ),
      ...(snapshot.unassigned
        ? { unassignedSummary: snapshot.unassigned }
        : {}),
      unassignedConversations: snapshot.unassignedConversations,
      error: result.status === 'cached' ? result.error : null,
      cachedAt: snapshot.cachedAt,
      factsRevision: snapshot.factsRevision,
      treeRevision: snapshot.treeRevision
    }
  }
  if (result.status === 'unsupported') {
    return {
      ...emptyPartition(routeExecutionHostId),
      status: 'unsupported'
    }
  }
  return {
    ...(previous ?? emptyPartition(routeExecutionHostId)),
    status: 'error',
    error: result.error
  }
}

function detailStateFromLoad(
  result: IssueClientLoadResult<IssueDetail>
): IssueDetailLoadState {
  switch (result.status) {
    case 'ready':
      return { status: 'ready', detail: result.value, error: null }
    case 'cached':
      return {
        status: 'cached',
        detail: result.value,
        error: result.error
      }
    case 'unsupported':
      return { status: 'unsupported' }
    case 'error':
      return { status: 'error', error: result.error }
  }
}

function emptyRoundLoadState(): IssueRoundLoadState {
  return {
    status: 'idle',
    authority: null,
    snapshotFactsRevision: null,
    rounds: [],
    nextCursor: null,
    error: null,
    loadingMore: false
  }
}

function roundStateFromLoad(
  result: IssueClientLoadResult<RoundRecordPage>,
  previous: IssueRoundLoadState
): IssueRoundLoadState {
  if (result.status === 'ready' || result.status === 'cached') {
    return {
      status: result.status,
      authority: result.value.authority,
      snapshotFactsRevision: result.value.snapshotFactsRevision,
      rounds: result.value.rounds,
      nextCursor: result.value.nextCursor,
      error: result.status === 'cached' ? result.error : null,
      loadingMore: false
    }
  }
  if (result.status === 'unsupported') {
    return {
      ...emptyRoundLoadState(),
      status: 'unsupported'
    }
  }
  return {
    ...previous,
    status: 'error',
    error: result.error,
    loadingMore: false
  }
}

function appendRoundLoadState(
  previous: IssueRoundLoadState,
  result: IssueClientLoadResult<RoundRecordPage>
): IssueRoundLoadState {
  if (result.status === 'ready' || result.status === 'cached') {
    return {
      status: result.status,
      authority: result.value.authority,
      snapshotFactsRevision: result.value.snapshotFactsRevision,
      rounds: dedupeRoundPreviews([
        ...previous.rounds,
        ...result.value.rounds
      ]),
      nextCursor: result.value.nextCursor,
      error: result.status === 'cached' ? result.error : null,
      loadingMore: false
    }
  }
  if (result.status === 'unsupported') {
    return {
      ...previous,
      status: 'unsupported',
      error: null,
      loadingMore: false
    }
  }
  return {
    ...previous,
    error: result.error,
    loadingMore: false
  }
}

function dedupeRoundPreviews(
  rounds: readonly RoundRecordPreview[]
): RoundRecordPreview[] {
  const byId = new Map(rounds.map((round) => [round.id, round]))
  return [...byId.values()].sort(
    (left, right) =>
      right.occurredAt - left.occurredAt ||
      right.id.localeCompare(left.id)
  )
}

function setRoundLoadState(
  set: StoreApi<IssuesDomainState>['setState'],
  key: string,
  value: IssueRoundLoadState
): void {
  set((state) => ({
    roundLoadsByKey: {
      ...state.roundLoadsByKey,
      [key]: value
    }
  }))
}

function setPartition(
  set: StoreApi<IssuesDomainState>['setState'],
  routeExecutionHostId: ExecutionHostId,
  partition: IssuesDomainPartition
): void {
  set((state) => ({
    partitionsByRoute: {
      ...state.partitionsByRoute,
      [routeExecutionHostId]: partition
    }
  }))
}

function patchPartitionDetail(
  partitions: IssuesDomainState['partitionsByRoute'],
  routeExecutionHostId: ExecutionHostId,
  detailState: IssueDetailLoadState
): IssuesDomainState['partitionsByRoute'] {
  if (
    detailState.status !== 'ready' &&
    detailState.status !== 'cached'
  ) {
    return partitions
  }
  const partition = partitions[routeExecutionHostId]
  if (!partition) {
    return partitions
  }
  return {
    ...partitions,
    [routeExecutionHostId]: {
      ...partition,
      detailsByIssueId: {
        ...partition.detailsByIssueId,
        [detailState.detail.issue.id]:
          detailState.detail.directConversations
      }
    }
  }
}

function patchUnassignedConversations(
  partitions: IssuesDomainState['partitionsByRoute'],
  routeExecutionHostId: ExecutionHostId,
  conversations: readonly ConversationSummary[]
): IssuesDomainState['partitionsByRoute'] {
  const partition = partitions[routeExecutionHostId]
  if (!partition) {
    return partitions
  }
  return {
    ...partitions,
    [routeExecutionHostId]: {
      ...partition,
      unassignedConversations: conversations
    }
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error && error.message.trim()
    ? error.message
    : 'Unable to update Issues.'
}

const defaultDependencies: IssuesDomainDependencies = {
  readPreferences: () =>
    window.api?.issueClientData?.readPreferences() ??
    Promise.resolve({ ...DEFAULT_ISSUE_CLIENT_PREFERENCES }),
  writePreferences: (preferences) =>
    window.api?.issueClientData?.writePreferences(preferences) ??
    Promise.resolve(preferences),
  loadPartition: (routeExecutionHostId) =>
    loadIssuePartition(routeExecutionHostId),
  loadDetail: (routeExecutionHostId, issueId) =>
    loadIssueDetail(routeExecutionHostId, issueId),
  loadUnassigned: (routeExecutionHostId) =>
    loadUnassignedConversations(routeExecutionHostId),
  loadRounds: (routeExecutionHostId, scope) =>
    loadIssueRounds(routeExecutionHostId, scope),
  searchIssues: (routeExecutionHostId, query) =>
    searchIssues(routeExecutionHostId, query),
  prepareDigest: (routeExecutionHostId, issueId) =>
    prepareIssueDigest(routeExecutionHostId, issueId),
  generateDigest: (routeExecutionHostId, input) =>
    generateIssueDigest(routeExecutionHostId, input),
  cancelDigest: (routeExecutionHostId, input) =>
    cancelIssueDigest(routeExecutionHostId, input),
  updateDigestDraft: (routeExecutionHostId, input) =>
    updateIssueDigestDraft(routeExecutionHostId, input),
  confirmDigest: (routeExecutionHostId, input) =>
    confirmIssueDigest(routeExecutionHostId, input)
}

export const issuesDomainStore = createIssuesDomainStore(defaultDependencies)
