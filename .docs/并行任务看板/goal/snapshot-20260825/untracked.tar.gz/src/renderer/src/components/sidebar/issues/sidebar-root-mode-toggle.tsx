import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import type { IssueClientPreferences } from '../../../../../shared/issues/client-data'

type SidebarRootModeToggleProps = {
  value: IssueClientPreferences['sidebarRootMode']
  onChange: (value: IssueClientPreferences['sidebarRootMode']) => void
}

export function SidebarRootModeToggle({
  value,
  onChange
}: SidebarRootModeToggleProps): React.JSX.Element {
  return (
    <ToggleGroup
      type="single"
      value={value}
      onValueChange={(next) => {
        if (next === 'workspaces' || next === 'issues') {
          onChange(next)
        }
      }}
      size="sm"
      className="h-6 min-w-0 bg-sidebar-accent/40 p-0.5"
      aria-label="Sidebar root mode"
    >
      <ToggleGroupItem
        value="workspaces"
        className="h-5 min-w-0 px-1.5 text-[11px] data-[state=on]:bg-sidebar data-[state=on]:font-semibold"
      >
        Workspaces
      </ToggleGroupItem>
      <ToggleGroupItem
        value="issues"
        className="h-5 min-w-0 px-1.5 text-[11px] data-[state=on]:bg-sidebar data-[state=on]:font-semibold"
      >
        Issues
      </ToggleGroupItem>
    </ToggleGroup>
  )
}
