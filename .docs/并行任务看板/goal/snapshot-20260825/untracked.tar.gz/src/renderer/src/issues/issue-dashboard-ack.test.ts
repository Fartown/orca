import { describe, expect, it, vi } from 'vitest'
import type { DashboardCardIssueContext } from '../../../shared/dashboard-snapshot'
import {
  createIssueDashboardAcknowledger,
  type IssueDashboardAckDependencies
} from './issue-dashboard-ack'

const MAPPED: DashboardCardIssueContext = {
  status: 'mapped',
  authority: {
    authorityId: '11111111-1111-4111-8111-111111111111',
    hostPartitionKey: 'local',
    routeExecutionHostId: 'local'
  },
  conversationId: '22222222-2222-4222-8222-222222222222',
  issue: {
    id: '33333333-3333-4333-8333-333333333333',
    title: 'Dashboard integration',
    typeLabel: null,
    state: 'active'
  },
  latestRound: {
    id: '44444444-4444-4444-8444-444444444444',
    readAt: null
  }
}

describe('createIssueDashboardAcknowledger', () => {
  it('coalesces mapped Round acknowledgements and never resolves the Round', async () => {
    let release!: () => void
    const markRead = vi.fn<IssueDashboardAckDependencies['markRead']>(
      (_input) =>
        new Promise<void>((resolve) => {
          release = resolve
        })
    )
    const patchRead = vi.fn()
    const ackPane = vi.fn()
    const acknowledge = createIssueDashboardAcknowledger({
      markRead,
      patchRead,
      ackPane,
      createMutationId: () => 'mutation-1',
      now: () => 100
    })

    const first = acknowledge({
      paneKey: 'pane-1',
      issueContext: MAPPED
    })
    const second = acknowledge({
      paneKey: 'pane-1',
      issueContext: MAPPED
    })

    expect(markRead).toHaveBeenCalledTimes(1)
    expect(markRead).toHaveBeenCalledWith({
      executionHostId: 'local',
      mutationId: 'mutation-1',
      roundRecordIds: ['44444444-4444-4444-8444-444444444444'],
      readAt: 100
    })
    expect(markRead.mock.calls[0]?.[0]).not.toHaveProperty('resolvedAt')
    expect(ackPane).not.toHaveBeenCalled()

    release()
    await Promise.all([first, second])
    expect(patchRead).toHaveBeenCalledWith(
      'local',
      '44444444-4444-4444-8444-444444444444',
      100
    )
  })

  it('uses pane ack only for legacy, unsupported, or confirmed-unmapped cards', async () => {
    const ackPane = vi.fn()
    const acknowledge = createIssueDashboardAcknowledger({
      markRead: vi.fn(),
      patchRead: vi.fn(),
      ackPane,
      createMutationId: () => 'mutation-1',
      now: () => 100
    })

    await acknowledge({ paneKey: 'legacy' })
    await acknowledge({
      paneKey: 'unsupported',
      issueContext: { status: 'unsupported' }
    })
    await acknowledge({
      paneKey: 'unmapped',
      issueContext: { status: 'unmapped' }
    })
    await acknowledge({
      paneKey: 'unavailable',
      issueContext: { status: 'unavailable' }
    })
    await acknowledge({
      paneKey: 'mapped-without-round',
      issueContext: { ...MAPPED, latestRound: null }
    })

    expect(ackPane.mock.calls.map(([paneKey]) => paneKey)).toEqual([
      'legacy',
      'unsupported',
      'unmapped'
    ])
  })
})
