import { z } from 'zod'
import {
  ConversationNavigationTargetSchema,
  IssueAuthorityDescriptorSchema,
  IssueDisplayProjectionSchema,
  IssueRouteExecutionHostId,
  RoundRecordPreviewSchema
} from './schemas'

const EntityId = z.string().uuid()
const FactsRevision = z.number().int().nonnegative()

export const IssuesPendingForMobileParams = z.object({
  executionHostId: IssueRouteExecutionHostId,
  cursor: z.string().min(1).max(2_048).optional(),
  limit: z.number().int().min(1).max(200).default(100)
})

export const IssueMobilePendingEntrySchema = z.object({
  round: RoundRecordPreviewSchema.extend({
    id: EntityId
  }),
  conversation: ConversationNavigationTargetSchema,
  issue: IssueDisplayProjectionSchema.nullable()
})

export const IssueMobilePendingPageSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  snapshotFactsRevision: FactsRevision,
  entries: z.array(IssueMobilePendingEntrySchema).max(200),
  nextCursor: z.string().max(2_048).nullable()
})
