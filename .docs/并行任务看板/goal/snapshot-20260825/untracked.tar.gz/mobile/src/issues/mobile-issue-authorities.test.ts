import { describe, expect, it, vi } from 'vitest'
import type { RpcClient } from '../transport/rpc-client'
import type { RpcFailure, RpcSuccess } from '../transport/types'
import { loadMobileIssueAuthorities } from './mobile-issue-authorities'

function ok(result: unknown): RpcSuccess {
  return { id: 'rpc', ok: true, result, _meta: { runtimeId: 'runtime' } }
}

function fail(message: string): RpcFailure {
  return {
    id: 'rpc',
    ok: false,
    error: { code: 'runtime_error', message },
    _meta: { runtimeId: 'runtime' }
  }
}

describe('loadMobileIssueAuthorities', () => {
  it('keeps local for unassigned work and discovers unique runtime and SSH partitions', async () => {
    const sendRequest = vi.fn<RpcClient['sendRequest']>().mockResolvedValue(
      ok({
        worktrees: [
          { worktreeId: 'local-1' },
          { worktreeId: 'runtime-1', hostId: 'runtime:devbox' },
          { worktreeId: 'runtime-2', hostId: 'runtime:devbox' },
          { worktreeId: 'ssh-1', hostId: 'ssh:builder' }
        ]
      })
    )

    await expect(loadMobileIssueAuthorities({ sendRequest })).resolves.toEqual({
      status: 'ready',
      executionHostIds: ['local', 'runtime:devbox', 'ssh:builder']
    })
    expect(sendRequest).toHaveBeenCalledWith('worktree.ps', { limit: 10_000 })
  })

  it('preserves known routes but marks malformed host facts as invalid', async () => {
    const sendRequest = vi.fn<RpcClient['sendRequest']>().mockResolvedValue(
      ok({
        worktrees: [
          { worktreeId: 'runtime-1', hostId: 'runtime:devbox' },
          { worktreeId: 'broken', hostId: 'runtime:' }
        ]
      })
    )

    await expect(loadMobileIssueAuthorities({ sendRequest })).resolves.toEqual({
      status: 'invalid',
      executionHostIds: ['local', 'runtime:devbox'],
      message: 'Some Workspace authority routes were invalid.'
    })
  })

  it('does not turn catalog failures into a proven empty authority set', async () => {
    const failedRequest = vi
      .fn<RpcClient['sendRequest']>()
      .mockResolvedValue(fail('catalog unavailable'))
    await expect(loadMobileIssueAuthorities({ sendRequest: failedRequest })).resolves.toEqual({
      status: 'unreachable',
      executionHostIds: ['local'],
      message: 'catalog unavailable'
    })

    const rejectedRequest = vi
      .fn<RpcClient['sendRequest']>()
      .mockRejectedValue(new Error('socket closed'))
    await expect(loadMobileIssueAuthorities({ sendRequest: rejectedRequest })).resolves.toEqual({
      status: 'unreachable',
      executionHostIds: ['local'],
      message: 'socket closed'
    })
  })
})
