import { useCallback, useRef, useState } from 'react'
import { ActivityIndicator, Pressable, ScrollView, Text, View } from 'react-native'
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context'
import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router'
import { AlertTriangle, Bell, ChevronLeft, MessageSquare, RefreshCw } from 'lucide-react-native'
import { normalizeExecutionHostId } from '../../../../../src/shared/execution-host'
import type { ConversationNavigationTarget } from '../../../../../src/shared/issues'
import type { MobileIssueDetailState } from '../../../../src/issues/mobile-issue-data'
import {
  loadMobileIssueConversation,
  loadMobileIssuePending,
  resolveMobileIssueDetailState
} from '../../../../src/issues/mobile-issue-data'
import { activateMobileIssueConversation } from '../../../../src/issues/mobile-issue-route'
import {
  buildMobileIssueDetailPresentation,
  supportsMobileIssues
} from '../../../../src/issues/mobile-issue-screen-model'
import { mobileIssueScreenStyles as styles } from '../../../../src/issues/mobile-issue-screen-styles'
import { useOpenHostStackRoute } from '../../../../src/navigation/use-open-host-stack-route'
import { useHostProtocolGates } from '../../../../src/components/HostProtocolGate'
import { useHostClient } from '../../../../src/transport/client-context'
import { colors, spacing } from '../../../../src/theme/mobile-theme'

type DetailParams = {
  hostId: string
  executionHostId?: string
  conversationId: string
  roundRecordId?: string
}

function detailConversation(state: MobileIssueDetailState): ConversationNavigationTarget | null {
  if (state.status === 'ready') {
    return state.item.entry.conversation
  }
  if (state.status === 'handled-active') {
    return state.conversation
  }
  if (state.status === 'closed') {
    return state.conversation ?? null
  }
  return null
}

export default function MobileIssueDetailScreen() {
  const params = useLocalSearchParams<DetailParams>()
  const router = useRouter()
  const insets = useSafeAreaInsets()
  const openHostStackRoute = useOpenHostStackRoute()
  const { client, state: connectionState } = useHostClient(params.hostId)
  const { hostCapabilities } = useHostProtocolGates()
  const supported = supportsMobileIssues(hostCapabilities)
  const requestRef = useRef(0)
  const [refreshing, setRefreshing] = useState(false)
  const [detail, setDetail] = useState<MobileIssueDetailState | null>(null)
  const executionHostId = normalizeExecutionHostId(params.executionHostId)

  const refresh = useCallback(
    async (showRefresh = false) => {
      const requestId = ++requestRef.current
      if (showRefresh) {
        setRefreshing(true)
      } else {
        setDetail(null)
      }
      if (!executionHostId || !params.conversationId) {
        setDetail({ status: 'invalid', message: 'The Issue route is incomplete.' })
        setRefreshing(false)
        return
      }
      if (!client || connectionState !== 'connected') {
        setDetail({ status: 'unreachable', message: 'Reconnect to the host and try again.' })
        setRefreshing(false)
        return
      }
      const [pending, conversation] = await Promise.all([
        loadMobileIssuePending(client, [executionHostId]),
        loadMobileIssueConversation(client, executionHostId, params.conversationId)
      ])
      if (requestRef.current === requestId) {
        setDetail(
          resolveMobileIssueDetailState({
            executionHostId,
            conversationId: params.conversationId,
            roundRecordId: params.roundRecordId,
            pending,
            conversation
          })
        )
        setRefreshing(false)
      }
    },
    [client, connectionState, executionHostId, params.conversationId, params.roundRecordId]
  )

  useFocusEffect(
    useCallback(() => {
      if (supported) {
        void refresh()
      }
      return () => {
        requestRef.current++
      }
    }, [refresh, supported])
  )

  const openConversation = useCallback(async () => {
    const conversation = detail ? detailConversation(detail) : null
    if (!client || !conversation) {
      return
    }
    const result = await activateMobileIssueConversation(client, params.hostId, conversation)
    openHostStackRoute(params.hostId, result.target)
  }, [client, detail, openHostStackRoute, params.hostId])

  const effectiveDetail: MobileIssueDetailState | null = supported
    ? detail
    : { status: 'unsupported', message: 'This host does not support mobile Issue waiting.' }
  const presentation = effectiveDetail ? buildMobileIssueDetailPresentation(effectiveDetail) : null
  const conversation = effectiveDetail ? detailConversation(effectiveDetail) : null
  const issueTitle =
    effectiveDetail?.status === 'ready'
      ? (effectiveDetail.item.entry.issue?.title ?? 'Unassigned')
      : 'Conversation'
  const iconColor =
    presentation?.tone === 'danger'
      ? colors.statusRed
      : presentation?.tone === 'warning' || presentation?.tone === 'attention'
        ? colors.statusAmber
        : colors.textSecondary

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Pressable
          style={styles.headerButton}
          onPress={() => router.back()}
          accessibilityRole="button"
          accessibilityLabel="Back"
        >
          <ChevronLeft size={22} color={colors.textPrimary} />
        </Pressable>
        <View style={styles.headerTitleWrap}>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {issueTitle}
          </Text>
          <Text style={styles.headerSubtitle} numberOfLines={1}>
            {conversation?.title || conversation?.workspaceSnapshot.name || 'Issue context'}
          </Text>
        </View>
        <Pressable
          style={styles.headerButton}
          onPress={() => void refresh(true)}
          disabled={!supported || refreshing}
          accessibilityRole="button"
          accessibilityLabel="Refresh Issue context"
        >
          {refreshing ? (
            <ActivityIndicator size="small" color={colors.textSecondary} />
          ) : (
            <RefreshCw size={18} color={supported ? colors.textSecondary : colors.textMuted} />
          )}
        </Pressable>
      </View>

      {!presentation ? (
        <View style={styles.stateWrap}>
          <ActivityIndicator color={colors.textSecondary} />
          <Text style={styles.stateMessage}>Loading Issue context…</Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={[
            styles.detailContent,
            { paddingBottom: insets.bottom + spacing.xl }
          ]}
        >
          <View style={styles.detailCard}>
            <View style={styles.stateIcon}>
              {presentation.tone === 'danger' || presentation.tone === 'warning' ? (
                <AlertTriangle size={24} color={iconColor} />
              ) : (
                <Bell size={24} color={iconColor} />
              )}
            </View>
            <Text style={styles.stateTitle}>{presentation.title}</Text>
            <Text style={styles.stateMessage}>{presentation.message}</Text>

            {conversation ? (
              <>
                <View style={styles.detailDivider} />
                <Text style={styles.detailLabel}>Conversation</Text>
                <Text style={styles.detailTitle}>
                  {conversation.title || conversation.workspaceSnapshot.name}
                </Text>
                <Text style={styles.detailMeta}>
                  {conversation.workspaceSnapshot.name}
                  {'\n'}
                  {conversation.workspaceSnapshot.path}
                </Text>
              </>
            ) : null}

            {presentation.preview ? (
              <>
                <View style={styles.detailDivider} />
                <Text style={styles.detailLabel}>Captured context</Text>
                <Text style={styles.preview}>{presentation.preview}</Text>
                {presentation.captureLabel ? (
                  <Text style={styles.captureLabel}>{presentation.captureLabel}</Text>
                ) : null}
              </>
            ) : null}

            {presentation.canOpenConversation ? (
              <Pressable
                style={styles.primaryButton}
                onPress={() => void openConversation()}
                accessibilityRole="button"
                accessibilityLabel="Open Conversation"
              >
                <MessageSquare size={18} color={colors.onAccent} />
                <Text style={styles.primaryButtonText}>Open Conversation</Text>
              </Pressable>
            ) : null}
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  )
}
