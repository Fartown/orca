import type {
  AuthorityHostPartitionKey,
  IssueSearchCompleteness,
  IssueSearchEntityKind
} from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'

export type IssueSearchDocument = {
  entityKind: IssueSearchEntityKind
  entityId: string
  issueId: string | null
  title: string
  body: string
  keywords: string
  completeness: IssueSearchCompleteness | null
}

type IssueSearchSourceRow = {
  entity_kind: IssueSearchEntityKind
  entity_id: string
  issue_id: string | null
  title: string | null
  body: string | null
  completeness: IssueSearchCompleteness | null
}

export function buildIssueSearchDocuments(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): IssueSearchDocument[] {
  return [
    ...readIssueDocuments(database, hostPartitionKey),
    ...readConversationDocuments(database, hostPartitionKey),
    ...readRoundDocuments(database, hostPartitionKey),
    ...readDigestDocuments(database, hostPartitionKey),
    ...readArtifactDocuments(database, hostPartitionKey)
  ].map(toSearchDocument)
}

export function buildCjkBigrams(value: string): string {
  const bigrams = new Set<string>()
  for (const run of value.match(/\p{Script=Han}+/gu) ?? []) {
    const characters = [...run]
    for (let index = 0; index + 1 < characters.length; index += 1) {
      bigrams.add(`${characters[index]}${characters[index + 1]}`)
    }
  }
  return [...bigrams].join(' ')
}

function readIssueDocuments(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): IssueSearchSourceRow[] {
  return database
    .prepare(
      `SELECT
         'issue' AS entity_kind,
         id AS entity_id,
         id AS issue_id,
         COALESCE(local_title, source_title, '') AS title,
         TRIM(
           COALESCE(type_label, '') || ' ' ||
           COALESCE(note, '') || ' ' ||
           COALESCE(source_identifier, '') || ' ' ||
           COALESCE(CAST(source_number AS TEXT), '') || ' ' ||
           COALESCE(source_state, '') || ' ' ||
           COALESCE(source_url, '')
         ) AS body,
         NULL AS completeness
       FROM issues
       WHERE host_partition_key = ?`
    )
    .all(hostPartitionKey) as IssueSearchSourceRow[]
}

function readConversationDocuments(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): IssueSearchSourceRow[] {
  return database
    .prepare(
      `SELECT
         'conversation' AS entity_kind,
         id AS entity_id,
         issue_id,
         COALESCE(title, workspace_name_snapshot, '') AS title,
         TRIM(
           COALESCE(workspace_name_snapshot, '') || ' ' ||
           COALESCE(workspace_path_snapshot, '') || ' ' ||
           COALESCE(agent, '')
         ) AS body,
         NULL AS completeness
       FROM conversations
       WHERE host_partition_key = ?`
    )
    .all(hostPartitionKey) as IssueSearchSourceRow[]
}

function readRoundDocuments(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): IssueSearchSourceRow[] {
  const rows = database
    .prepare(
      `SELECT
         'round' AS entity_kind,
         round.id AS entity_id,
         conversation.issue_id,
         CASE round.kind
           WHEN 'waiting' THEN 'Waiting'
           ELSE 'Completion'
         END AS title,
         TRIM(
           COALESCE(round.user_input, round.user_input_preview, '') || ' ' ||
           COALESCE(round.agent_output, round.output_preview, '') || ' ' ||
           COALESCE(round.pending_question, round.question_preview, '')
         ) AS body,
         CASE
           WHEN (
             round.user_input_storage IN ('deleted', 'evicted', 'none') AND
             round.output_storage IN ('deleted', 'evicted', 'none') AND
             round.question_storage IN ('deleted', 'evicted', 'none')
           ) THEN 'unavailable'
           WHEN (
             round.user_input_completeness = 'complete' AND
             round.output_completeness = 'complete' AND
             round.question_completeness = 'complete' AND
             round.user_input_storage = 'full' AND
             round.output_storage = 'full' AND
             round.question_storage = 'full'
           ) THEN 'complete'
           ELSE 'partial'
         END AS completeness
       FROM round_records round
       JOIN conversations conversation ON conversation.id = round.conversation_id
       WHERE conversation.host_partition_key = ?`
    )
    .all(hostPartitionKey) as IssueSearchSourceRow[]
  return rows
}

function readDigestDocuments(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): IssueSearchSourceRow[] {
  return database
    .prepare(
      `SELECT
         'digest' AS entity_kind,
         digest.id AS entity_id,
         digest.issue_id,
         'Digest v' || CAST(digest.version AS TEXT) AS title,
         TRIM(
           COALESCE(digest.problem, '') || ' ' ||
           COALESCE(digest.conclusion, '') || ' ' ||
           COALESCE(digest.key_artifacts, '') || ' ' ||
           COALESCE(digest.open_issues, '') || ' ' ||
           COALESCE(digest.next_steps, '') || ' ' ||
           COALESCE(digest.coverage_note, '')
         ) AS body,
         CASE
           WHEN digest.coverage_note IS NULL OR digest.coverage_note = ''
             THEN 'complete'
           ELSE 'partial'
         END AS completeness
       FROM issue_digests digest
       JOIN issues issue ON issue.id = digest.issue_id
       WHERE issue.host_partition_key = ?
         AND digest.status IN ('draft', 'confirmed')`
    )
    .all(hostPartitionKey) as IssueSearchSourceRow[]
}

function readArtifactDocuments(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): IssueSearchSourceRow[] {
  return database
    .prepare(
      `SELECT
         'artifact' AS entity_kind,
         artifact.id AS entity_id,
         artifact.issue_id,
         COALESCE(artifact.label, artifact.value) AS title,
         artifact.value AS body,
         CASE
           WHEN artifact.reachable = 0 THEN 'unavailable'
           ELSE 'complete'
         END AS completeness
       FROM issue_artifact_refs artifact
       JOIN issues issue ON issue.id = artifact.issue_id
       WHERE issue.host_partition_key = ?`
    )
    .all(hostPartitionKey) as IssueSearchSourceRow[]
}

function toSearchDocument(row: IssueSearchSourceRow): IssueSearchDocument {
  const title = row.title ?? ''
  const body = row.body ?? ''
  return {
    entityKind: row.entity_kind,
    entityId: row.entity_id,
    issueId: row.issue_id,
    title,
    body,
    keywords: buildCjkBigrams(`${title}\n${body}`),
    completeness: row.completeness
  }
}
