import { describe, expect, it, vi } from 'vitest'
import type { IssueMutationResult } from '../../../shared/issues/types'
import {
  markIssueActivityRead,
  type IssueActivityReadDependencies
} from './issue-activity-read'

const result: IssueMutationResult = {
  authority: {
    authorityId: 'authority-a',
    hostPartitionKey: 'local',
    routeExecutionHostId: 'local'
  },
  factsRevision: 2,
  treeRevision: 1,
  affectedIssueIds: [],
  affectedConversationIds: [],
  affectedRoundRecordIds: ['round-a', 'round-b']
}

describe('markIssueActivityRead', () => {
  it('deduplicates per host and patches readAt only after persistence succeeds', async () => {
    const order: string[] = []
    const markRead = vi.fn<IssueActivityReadDependencies['markRead']>(async () => {
      order.push('persist')
      return result
    })
    const patchRead = vi.fn(() => order.push('patch'))

    await markIssueActivityRead(
      [
        { routeExecutionHostId: 'local', roundRecordIds: ['round-a', 'round-b'] },
        { routeExecutionHostId: 'local', roundRecordIds: ['round-a'] }
      ],
      123,
      {
        markRead,
        patchRead,
        createMutationId: () => 'activity-read'
      }
    )

    expect(markRead).toHaveBeenCalledWith({
      executionHostId: 'local',
      mutationId: 'activity-read',
      roundRecordIds: ['round-a', 'round-b'],
      readAt: 123
    })
    expect(markRead.mock.calls[0]?.[0]).not.toHaveProperty('resolvedAt')
    expect(patchRead).toHaveBeenCalledWith('local', ['round-a', 'round-b'], 123)
    expect(order).toEqual(['persist', 'patch'])
  })

  it('does not optimistically patch when the authoritative write fails', async () => {
    const patchRead = vi.fn()

    await expect(
      markIssueActivityRead(
        [{ routeExecutionHostId: 'local', roundRecordIds: ['round-a'] }],
        123,
        {
          markRead: vi.fn().mockRejectedValue(new Error('offline')),
          patchRead,
          createMutationId: () => 'activity-read'
        }
      )
    ).rejects.toThrow('offline')

    expect(patchRead).not.toHaveBeenCalled()
  })
})
