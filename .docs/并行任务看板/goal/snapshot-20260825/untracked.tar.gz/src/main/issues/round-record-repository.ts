import { randomUUID } from 'node:crypto'
import {
  ROUND_AGENT_OUTPUT_MAX_BYTES,
  ROUND_PENDING_QUESTION_MAX_BYTES,
  ROUND_USER_INPUT_MAX_BYTES
} from '../../shared/issues/constants'
import type {
  AuthorityHostPartitionKey,
  RoundRecord,
  RoundRecordRef
} from '../../shared/issues/types'
import type Database from '../sqlite/sync-database'
import { requireConversationRecord } from './conversation-record-queries'
import type { IssueDatabase } from './issue-database'
import { bumpIssueHostRevisions } from './issue-host-state'
import type { IssueLifecycleRepository } from './issue-lifecycle-repository'
import { executeIssueMutation } from './issue-mutation-receipt'
import {
  retainedRoundRecordBytes,
  roundRecordBodiesEqual,
  writeRoundRecordBodies,
  type RoundRecordBodies
} from './round-record-body-persistence'
import {
  getRoundRecord,
  getRoundRecordByDedupeKey,
  getRoundRecordByRef,
  listRoundRecordRefs,
  listRoundRecords,
  requireRoundRecord
} from './round-record-queries'
import {
  RoundRecordRetention,
  type RoundRecordRetentionTransactionResult
} from './round-record-retention'
import { markRoundRecordSearchableChange } from './round-record-search-rebuild'
import {
  deleteRoundRecordText,
  normalizeRoundRecordText,
  preferMoreCompleteRoundRecordText
} from './round-record-text'
import { IssueRepositoryError } from './issue-repository-error'
import type {
  CreateRoundRecordInput,
  DeleteRecordInput,
  IssueMutationParams,
  MarkRoundRecordsReadInput,
  RoundRecordListFilter,
  UpdateRoundRecordInput
} from './issue-repository-types'

export class RoundRecordRepository {
  constructor(
    private readonly database: IssueDatabase,
    private readonly retention = new RoundRecordRetention(database),
    private readonly onRetentionNeeded?: () => void,
    private readonly issueLifecycle?: IssueLifecycleRepository
  ) {}

  create(params: IssueMutationParams<CreateRoundRecordInput>): RoundRecord {
    const result = executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'rounds.create',
      payload: params.input,
      operation: () => this.createOrUpgradeRecord(params.input)
    })
    this.onRetentionNeeded?.()
    return result
  }

  get(id: string): RoundRecord | undefined {
    return getRoundRecord(this.database, id)
  }

  list(filter: RoundRecordListFilter): RoundRecord[] {
    return listRoundRecords(this.database, filter)
  }

  findByRef(ref: Pick<RoundRecordRef, 'kind' | 'value'>): RoundRecord | undefined {
    return getRoundRecordByRef(this.database, ref)
  }

  listRefs(roundId: string): RoundRecordRef[] {
    return listRoundRecordRefs(this.database, roundId)
  }

  update(params: IssueMutationParams<UpdateRoundRecordInput>): RoundRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'rounds.update',
      payload: params.input,
      operation: () => this.updateRecord(params.input)
    })
  }

  markRead(
    params: IssueMutationParams<MarkRoundRecordsReadInput>
  ): RoundRecord[] {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.markRead',
      payload: params.input,
      operation: () =>
        params.input.ids.map((id) =>
          this.updateRecord({ id, readAt: params.input.readAt })
        )
    })
  }

  resolve(
    params: IssueMutationParams<{ id: string; resolvedAt: number }>
  ): RoundRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.resolveRound',
      payload: params.input,
      operation: () =>
        this.updateRecord({
          id: params.input.id,
          resolvedAt: params.input.resolvedAt,
          resolution: 'explicit'
        })
    })
  }

  delete(params: IssueMutationParams<DeleteRecordInput>): { deletedRoundId: string } {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'rounds.delete',
      payload: params.input,
      operation: () => this.deleteRecordBodies(params.input.id)
    })
  }

  private createOrUpgradeRecord(input: CreateRoundRecordInput): RoundRecord {
    const reopenCandidate = this.issueLifecycle?.findAutoReopenCandidate({
      conversationId: input.conversationId,
      kind: input.kind,
      occurredAt: input.occurredAt,
      authoritativeCurrentState: input.authoritativeCurrentState ?? false
    })
    const existing = getRoundRecordByDedupeKey(this.database, input.dedupeKey)
    const round = existing
      ? this.upgradeDuplicate(existing, input)
      : this.createRecord(input)
    if (reopenCandidate && this.issueLifecycle) {
      const reopened = this.issueLifecycle.applyAutoReopenWithinTransaction(
        reopenCandidate,
        Date.now()
      )
      const revisions = bumpIssueHostRevisions(
        this.database,
        reopened.hostPartitionKey,
        { tree: false },
        Date.now()
      )
      this.issueLifecycle.appendAutoReopenEventWithinTransaction({
        issue: reopened,
        roundId: round.id,
        occurredAt: input.occurredAt,
        factsRevision: revisions.factsRevision
      })
    }
    return round
  }

  private createRecord(input: CreateRoundRecordInput): RoundRecord {
    const conversation = requireConversationRecord(this.database, input.conversationId)
    this.assertResolution(input.resolvedAt ?? null, input.resolution ?? null)
    this.assertSupersession(input)
    const bodies = normalizeRoundBodies(input)
    const id = randomUUID()
    const now = Date.now()
    this.insertRecord(id, input, bodies, now)
    this.upsertRefs(id, input.refs)
    this.adjustRetainedBytes(retainedRoundRecordBytes(bodies))

    const retentionResult = this.retention.enforceHardLimitWithinTransaction()
    const searchableChanges = cloneRetentionChanges(retentionResult)
    if (retainedRoundRecordBytes(bodies) > 0) {
      addChangedRound(searchableChanges, conversation.hostPartitionKey, id)
    }
    this.markRoundChanges(
      searchableChanges,
      conversation.hostPartitionKey,
      retainedRoundRecordBytes(bodies) === 0,
      now
    )
    return requireRoundRecord(this.database, id)
  }

  private upgradeDuplicate(
    current: RoundRecord,
    input: CreateRoundRecordInput
  ): RoundRecord {
    this.assertDuplicateIdentity(current, input)
    const conversation = requireConversationRecord(this.database, current.conversationId)
    const incoming = normalizeRoundBodies(input)
    const next: RoundRecordBodies = {
      userInput: preferMoreCompleteRoundRecordText(current.userInput, incoming.userInput),
      agentOutput: preferMoreCompleteRoundRecordText(current.agentOutput, incoming.agentOutput),
      pendingQuestion: preferMoreCompleteRoundRecordText(
        current.pendingQuestion,
        incoming.pendingQuestion
      )
    }
    const finalizedAt = current.finalizedAt ?? input.finalizedAt ?? null
    const bodiesChanged = !roundRecordBodiesEqual(current, next)
    const finalizedChanged = finalizedAt !== current.finalizedAt
    const refsChanged = this.upsertRefs(current.id, input.refs)
    if (!bodiesChanged && !finalizedChanged && !refsChanged) {
      return current
    }

    const now = Date.now()
    if (bodiesChanged) {
      writeRoundRecordBodies(this.database, current.id, next)
      this.adjustRetainedBytes(
        retainedRoundRecordBytes(next) - retainedRoundRecordBytes(current)
      )
    }
    if (finalizedChanged) {
      this.database
        .prepare('UPDATE round_records SET finalized_at = ? WHERE id = ?')
        .run(finalizedAt, current.id)
    }

    const retentionResult = this.retention.enforceHardLimitWithinTransaction()
    const searchableChanges = cloneRetentionChanges(retentionResult)
    if (bodiesChanged) {
      addChangedRound(searchableChanges, conversation.hostPartitionKey, current.id)
    }
    this.markRoundChanges(
      searchableChanges,
      conversation.hostPartitionKey,
      !bodiesChanged && (finalizedChanged || refsChanged),
      now
    )
    return requireRoundRecord(this.database, current.id)
  }

  private updateRecord(input: UpdateRoundRecordInput): RoundRecord {
    const current = requireRoundRecord(this.database, input.id)
    const conversation = requireConversationRecord(this.database, current.conversationId)
    const readAt = Object.hasOwn(input, 'readAt') ? (input.readAt ?? null) : current.readAt
    const resolvedAt = Object.hasOwn(input, 'resolvedAt')
      ? (input.resolvedAt ?? null)
      : current.resolvedAt
    const resolution = Object.hasOwn(input, 'resolution')
      ? (input.resolution ?? null)
      : current.resolution
    this.assertResolution(resolvedAt, resolution)
    if (
      readAt === current.readAt &&
      resolvedAt === current.resolvedAt &&
      resolution === current.resolution
    ) {
      return current
    }
    this.database
      .prepare('UPDATE round_records SET read_at = ?, resolved_at = ?, resolution = ? WHERE id = ?')
      .run(readAt, resolvedAt, resolution, current.id)
    bumpIssueHostRevisions(
      this.database,
      conversation.hostPartitionKey,
      { tree: false },
      Date.now()
    )
    return requireRoundRecord(this.database, current.id)
  }

  private deleteRecordBodies(id: string): { deletedRoundId: string } {
    const current = requireRoundRecord(this.database, id)
    const next: RoundRecordBodies = {
      userInput: deleteRoundRecordText(current.userInput),
      agentOutput: deleteRoundRecordText(current.agentOutput),
      pendingQuestion: deleteRoundRecordText(current.pendingQuestion)
    }
    if (roundRecordBodiesEqual(current, next)) {
      return { deletedRoundId: id }
    }
    const conversation = requireConversationRecord(this.database, current.conversationId)
    const now = Date.now()
    writeRoundRecordBodies(this.database, id, next, { deletedAt: now })
    this.adjustRetainedBytes(-retainedRoundRecordBytes(current))
    markRoundRecordSearchableChange(
      this.database,
      conversation.hostPartitionKey,
      [current.id],
      now
    )
    return { deletedRoundId: id }
  }

  private insertRecord(
    id: string,
    input: CreateRoundRecordInput,
    bodies: RoundRecordBodies,
    now: number
  ): void {
    this.database
      .prepare(
        `INSERT INTO round_records (
           id, conversation_id, kind, state_source, occurred_at, dedupe_key,
           execution_chain_id, supersedes_round_id,
           user_input, user_input_completeness, user_input_storage,
           user_input_bytes, user_input_preview, user_input_preview_bytes,
           agent_output, output_completeness, output_storage,
           output_bytes, output_preview, output_preview_bytes,
           pending_question, question_completeness, question_storage,
           question_bytes, question_preview, question_preview_bytes,
           read_at, resolved_at, resolution, finalized_at, created_at
         ) VALUES (
           ?, ?, ?, ?, ?, ?, ?, ?,
           ?, ?, ?, ?, ?, ?,
           ?, ?, ?, ?, ?, ?,
           ?, ?, ?, ?, ?, ?,
           ?, ?, ?, ?, ?
         )`
      )
      .run(
        id,
        input.conversationId,
        input.kind,
        input.stateSource,
        input.occurredAt,
        input.dedupeKey,
        input.executionChainId ?? null,
        input.supersedesRoundId ?? null,
        ...roundTextSqlValues(bodies.userInput),
        ...roundTextSqlValues(bodies.agentOutput),
        ...roundTextSqlValues(bodies.pendingQuestion),
        input.readAt ?? null,
        input.resolvedAt ?? null,
        input.resolution ?? null,
        input.finalizedAt ?? null,
        now
      )
  }

  private upsertRefs(roundId: string, refs: readonly RoundRecordRef[] | undefined): boolean {
    let changed = false
    for (const ref of normalizeRoundRefs(refs)) {
      if (ref.kind === 'provider-turn') {
        const owner = this.database
          .prepare(
            `SELECT round_id
             FROM round_refs
             WHERE ref_kind = ? AND value = ? AND round_id <> ?`
          )
          .get(ref.kind, ref.value, roundId) as { round_id: string } | undefined
        if (owner) {
          throw new IssueRepositoryError(
            'round_ref_conflict',
            `Round ref ${ref.kind}:${ref.value} belongs to Round Record ${owner.round_id}.`
          )
        }
      }
      const result = this.database
        .prepare(
          `INSERT INTO round_refs (round_id, ref_kind, value, reachable)
           VALUES (?, ?, ?, ?)
           ON CONFLICT(round_id, ref_kind, value) DO UPDATE SET
             reachable = excluded.reachable
           WHERE round_refs.reachable IS NOT excluded.reachable`
        )
        .run(roundId, ref.kind, ref.value, ref.reachable === null ? null : ref.reachable ? 1 : 0)
      changed = changed || result.changes > 0
    }
    return changed
  }

  private markRoundChanges(
    changedByHost: Map<AuthorityHostPartitionKey, Set<string>>,
    primaryHost: AuthorityHostPartitionKey,
    primaryFactsOnly: boolean,
    now: number
  ): void {
    if (primaryFactsOnly && !changedByHost.has(primaryHost)) {
      bumpIssueHostRevisions(this.database, primaryHost, { tree: false }, now)
    }
    this.retention.markChanges(changedByHost, now)
  }

  private assertDuplicateIdentity(current: RoundRecord, input: CreateRoundRecordInput): void {
    const matches =
      current.conversationId === input.conversationId &&
      current.kind === input.kind &&
      current.occurredAt === input.occurredAt &&
      current.executionChainId === (input.executionChainId ?? null) &&
      current.supersedesRoundId === (input.supersedesRoundId ?? null)
    if (!matches) {
      throw new IssueRepositoryError(
        'round_dedupe_conflict',
        `Round dedupe key ${input.dedupeKey} belongs to another stop fact.`
      )
    }
  }

  private assertResolution(resolvedAt: number | null, resolution: RoundRecord['resolution']): void {
    if ((resolvedAt === null) === (resolution === null)) {
      return
    }
    throw new IssueRepositoryError(
      'round_resolution_invalid',
      'Round resolution and resolvedAt must be set or cleared together.'
    )
  }

  private assertSupersession(input: CreateRoundRecordInput): void {
    if (!input.supersedesRoundId) {
      return
    }
    const predecessor = requireRoundRecord(this.database, input.supersedesRoundId)
    const hasSuccessor = this.database
      .prepare('SELECT 1 AS found FROM round_records WHERE supersedes_round_id = ?')
      .get(predecessor.id)
    const valid =
      input.kind === 'completion' &&
      predecessor.kind === 'completion' &&
      predecessor.conversationId === input.conversationId &&
      predecessor.executionChainId !== null &&
      predecessor.executionChainId === input.executionChainId &&
      predecessor.resolvedAt === null &&
      input.occurredAt >= predecessor.occurredAt &&
      !hasSuccessor
    if (!valid) {
      throw new IssueRepositoryError(
        'round_supersession_invalid',
        `Round Record ${predecessor.id} cannot be superseded by this completion.`
      )
    }
  }

  private adjustRetainedBytes(delta: number): void {
    this.database
      .prepare(
        `UPDATE issue_authority_meta
         SET retained_round_text_bytes = MAX(0, retained_round_text_bytes + ?)
         WHERE singleton = 1`
      )
      .run(delta)
  }
}

function normalizeRoundRefs(refs: readonly RoundRecordRef[] | undefined): RoundRecordRef[] {
  if (!refs) {
    return []
  }
  const normalized = new Map<string, RoundRecordRef>()
  for (const ref of refs) {
    const kind = ref.kind.trim()
    const value = ref.value.trim()
    if (!kind || !value || kind.length > 128 || value.length > 1024) {
      throw new IssueRepositoryError('round_ref_invalid', 'Round refs require bounded values.')
    }
    normalized.set(`${kind}\0${value}`, {
      kind,
      value,
      reachable: ref.reachable ?? null
    })
  }
  return [...normalized.values()]
}

function normalizeRoundBodies(input: CreateRoundRecordInput): RoundRecordBodies {
  return {
    userInput: normalizeRoundRecordText(
      input.userInput,
      ROUND_USER_INPUT_MAX_BYTES,
      'Round user input'
    ),
    agentOutput: normalizeRoundRecordText(
      input.agentOutput,
      ROUND_AGENT_OUTPUT_MAX_BYTES,
      'Round agent output'
    ),
    pendingQuestion: normalizeRoundRecordText(
      input.pendingQuestion,
      ROUND_PENDING_QUESTION_MAX_BYTES,
      'Round pending question'
    )
  }
}

function roundTextSqlValues(text: RoundRecord['userInput']): Database.BindValue[] {
  return [
    text.text,
    text.completeness,
    text.storage,
    text.bytes,
    text.preview,
    text.previewBytes
  ]
}

function cloneRetentionChanges(
  result: RoundRecordRetentionTransactionResult
): Map<AuthorityHostPartitionKey, Set<string>> {
  return new Map(
    [...result.changedByHost].map(([host, ids]) => [host, new Set(ids)])
  )
}

function addChangedRound(
  changedByHost: Map<AuthorityHostPartitionKey, Set<string>>,
  hostPartitionKey: AuthorityHostPartitionKey,
  roundId: string
): void {
  const ids = changedByHost.get(hostPartitionKey) ?? new Set<string>()
  ids.add(roundId)
  changedByHost.set(hostPartitionKey, ids)
}
