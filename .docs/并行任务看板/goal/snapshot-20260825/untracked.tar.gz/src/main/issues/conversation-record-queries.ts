import type { ConversationRecord } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { IssueRepositoryError } from './issue-repository-error'
import type { ConversationListFilter } from './issue-repository-types'
import { conversationFromRow, type ConversationRow } from './issue-row-mappers'

export function getConversationRecord(
  database: IssueDatabase,
  id: string
): ConversationRecord | undefined {
  const row = database.prepare('SELECT * FROM conversations WHERE id = ?').get(id) as
    | ConversationRow
    | undefined
  return row ? conversationFromRow(row) : undefined
}

export function requireConversationRecord(database: IssueDatabase, id: string): ConversationRecord {
  const conversation = getConversationRecord(database, id)
  if (!conversation) {
    throw new IssueRepositoryError('conversation_not_found', `Conversation ${id} was not found.`)
  }
  return conversation
}

export function listConversationRecords(
  database: IssueDatabase,
  filter: ConversationListFilter
): ConversationRecord[] {
  const conditions: string[] = []
  const bindings: (string | null)[] = []
  if (filter.executionHostId) {
    conditions.push('execution_host_id = ?')
    bindings.push(filter.executionHostId)
  }
  if (Object.hasOwn(filter, 'issueId')) {
    conditions.push('issue_id IS ?')
    if (filter.issueId !== null && filter.issueId !== undefined) {
      bindings.push(filter.issueId)
    } else {
      bindings.push(null)
    }
  }
  if (filter.workspaceRef) {
    conditions.push('workspace_kind = ?', 'workspace_id = ?')
    bindings.push(
      filter.workspaceRef.type,
      filter.workspaceRef.type === 'worktree'
        ? filter.workspaceRef.worktreeId
        : filter.workspaceRef.folderWorkspaceId
    )
  }
  if (filter.state) {
    conditions.push('state = ?')
    bindings.push(filter.state)
  }
  const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : ''
  const rows = database
    .prepare(
      `SELECT * FROM conversations ${where}
       ORDER BY host_partition_key, updated_at DESC, id`
    )
    .all(...bindings) as ConversationRow[]
  return rows.map(conversationFromRow)
}
