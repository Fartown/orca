import React, { useEffect, useMemo } from 'react'
import { AlertCircle, ListTree, Loader2 } from 'lucide-react'
import { useStore, type StoreApi } from 'zustand'
import { Button } from '@/components/ui/button'
import type { ExecutionHostId } from '../../../../shared/execution-host'
import type {
  ConversationSummary,
  IssueAuthorityDescriptor,
  IssueSummary
} from '../../../../shared/issues/types'
import {
  issueDetailKey,
  issueRoundKey,
  issuesDomainStore,
  type IssuesDomainState
} from '../../issues/issues-domain-store'
import { issueDigestKey } from '../../issues/issue-digest-domain'
import { IssueDetail } from './IssueDetail'
import { openIssueDetail } from '../../issues/issue-navigation'
import { openIssueConversation } from '../../issues/issue-conversation-navigation'
import { useAppStore } from '../../store'

type IssuesPageProps = {
  store?: StoreApi<IssuesDomainState>
  onOpenIssue?: (
    authority: IssueAuthorityDescriptor,
    issueId: string
  ) => void
  onOpenConversation?: (
    routeExecutionHostId: ExecutionHostId,
    conversation: ConversationSummary
  ) => void
  onBack?: () => void
  onOpenExternalSource?: (url: string) => void
}

export default function IssuesPage({
  store = issuesDomainStore,
  onOpenIssue,
  onOpenConversation,
  onBack,
  onOpenExternalSource
}: IssuesPageProps): React.JSX.Element {
  const closeIssuesPage = useAppStore((state) => state.closeIssuesPage)
  const preferences = useStore(store, (state) => state.preferences)
  const partitions = useStore(store, (state) => state.partitionsByRoute)
  const detailLoads = useStore(store, (state) => state.detailLoadsByKey)
  const roundLoads = useStore(store, (state) => state.roundLoadsByKey)
  const digestLoads = useStore(store, (state) => state.digestLoadsByKey)
  const routeExecutionHostId = preferences.selectedRouteExecutionHostId
  const issueId = preferences.selectedIssueId
  const detailKey =
    routeExecutionHostId && issueId
      ? issueDetailKey(routeExecutionHostId, issueId)
      : null
  const roundKey =
    routeExecutionHostId && issueId
      ? issueRoundKey(routeExecutionHostId, issueId)
      : null
  const digestKey =
    routeExecutionHostId && issueId
      ? issueDigestKey(routeExecutionHostId, issueId)
      : null
  const detailLoad = detailKey ? detailLoads[detailKey] : undefined
  const roundLoad = roundKey ? roundLoads[roundKey] : undefined
  const digestLoad = digestKey ? digestLoads[digestKey] : undefined
  const partition = routeExecutionHostId
    ? partitions[routeExecutionHostId]
    : undefined
  const ancestors = useMemo(
    () =>
      detailLoad?.status === 'ready' || detailLoad?.status === 'cached'
        ? findIssueAncestors(partition?.issues ?? [], detailLoad.detail.issue)
        : [],
    [detailLoad, partition?.issues]
  )

  useEffect(() => {
    void store.getState().hydrate()
  }, [store])

  useEffect(() => {
    if (!routeExecutionHostId || !issueId) {
      return
    }
    const state = store.getState()
    const currentDetail = state.detailLoadsByKey[
      issueDetailKey(routeExecutionHostId, issueId)
    ]
    const currentRounds = state.roundLoadsByKey[
      issueRoundKey(routeExecutionHostId, issueId)
    ]
    if (!currentDetail || currentDetail.status === 'idle') {
      void state.loadDetail(routeExecutionHostId, issueId)
    }
    if (!currentRounds || currentRounds.status === 'idle') {
      void state.loadRounds(routeExecutionHostId, issueId)
    }
  }, [issueId, routeExecutionHostId, store])

  const openIssue = (issue: IssueSummary): void => {
    if (!routeExecutionHostId) {
      return
    }
    store.getState().selectIssue(routeExecutionHostId, issue.id)
    const authority =
      detailLoad?.status === 'ready' || detailLoad?.status === 'cached'
        ? detailLoad.detail.authority
        : partition?.authority
    if (!authority) {
      return
    }
    if (onOpenIssue) {
      onOpenIssue(authority, issue.id)
    } else {
      openIssueDetail({ authority, issueId: issue.id })
    }
  }
  const openConversation = (conversation: ConversationSummary): void => {
    if (!routeExecutionHostId) {
      return
    }
    if (onOpenConversation) {
      onOpenConversation(routeExecutionHostId, conversation)
      return
    }
    void openIssueConversation({ routeExecutionHostId, conversation })
  }

  return (
    <main
      className="h-full min-h-0 flex-1 overflow-y-auto bg-background text-foreground"
      data-issues-page=""
    >
      {!routeExecutionHostId || !issueId ? (
        <PageState
          icon={<ListTree className="size-7" />}
          title="Select an Issue"
          description="Choose an Issue from the sidebar to inspect its direct work, children, and history."
        />
      ) : detailLoad?.status === 'ready' ||
        detailLoad?.status === 'cached' ? (
        <IssueDetail
          detail={detailLoad.detail}
          ancestors={ancestors}
          rounds={roundLoad?.rounds ?? []}
          roundStatus={roundLoad?.status ?? 'idle'}
          roundError={roundLoad?.error}
          roundHasMore={Boolean(roundLoad?.nextCursor)}
          roundLoadingMore={roundLoad?.loadingMore}
          cachedError={
            detailLoad.status === 'cached' ? detailLoad.error : null
          }
          onOpenIssue={openIssue}
          onOpenConversation={openConversation}
          onLoadMoreRounds={() =>
            void store
              .getState()
              .loadMoreRounds(routeExecutionHostId, issueId)
          }
          onOpenExternalSource={onOpenExternalSource}
          digestPreparation={digestLoad?.preparation}
          digestAttempt={digestLoad?.mutation?.digest}
          digestConfirmation={digestLoad?.confirmation}
          digestStatus={digestLoad?.status}
          digestError={digestLoad?.error}
          onPrepareDigest={() =>
            void store
              .getState()
              .prepareDigest(routeExecutionHostId, issueId)
          }
          onGenerateDigest={(agent) => {
            const preparation =
              store.getState().digestLoadsByKey[
                issueDigestKey(routeExecutionHostId, issueId)
              ]?.preparation
            if (!preparation) {
              return
            }
            void store.getState().generateDigest(routeExecutionHostId, {
              mutationId: crypto.randomUUID(),
              issueId,
              coversUntil: preparation.coversUntil,
              agent,
              expectedInputFingerprint: preparation.inputFingerprint
            })
          }}
          onUpdateDigestDraft={(patch) => {
            const digest =
              store.getState().digestLoadsByKey[
                issueDigestKey(routeExecutionHostId, issueId)
              ]?.mutation?.digest ?? detailLoad.detail.digest?.latestAttempt
            if (!digest) {
              return
            }
            void store
              .getState()
              .updateDigestDraft(routeExecutionHostId, issueId, {
                mutationId: crypto.randomUUID(),
                digestId: digest.id,
                expectedDigestRevision: digest.revision,
                ...patch
              })
          }}
          onConfirmDigest={(confirmStaleAgainstFingerprint) => {
            const digest =
              store.getState().digestLoadsByKey[
                issueDigestKey(routeExecutionHostId, issueId)
              ]?.mutation?.digest ?? detailLoad.detail.digest?.latestAttempt
            if (!digest) {
              return
            }
            void store
              .getState()
              .confirmDigest(routeExecutionHostId, issueId, {
                mutationId: crypto.randomUUID(),
                digestId: digest.id,
                expectedDigestRevision: digest.revision,
                inputFingerprint: digest.inputFingerprint,
                ...(confirmStaleAgainstFingerprint
                  ? { confirmStaleAgainstFingerprint }
                  : {})
              })
          }}
          onCancelDigest={() => {
            const digest =
              store.getState().digestLoadsByKey[
                issueDigestKey(routeExecutionHostId, issueId)
              ]?.mutation?.digest ?? detailLoad.detail.digest?.latestAttempt
            if (!digest) {
              return
            }
            void store
              .getState()
              .cancelDigest(routeExecutionHostId, issueId, {
                mutationId: crypto.randomUUID(),
                digestId: digest.id
              })
          }}
        />
      ) : detailLoad?.status === 'unsupported' ? (
        <PageState
          icon={<AlertCircle className="size-7" />}
          title="Update this Orca host"
          description="This host does not advertise Issue support. Existing Workspace features remain available."
          action={{ label: 'Back', onClick: onBack ?? closeIssuesPage }}
        />
      ) : isDeletedSelection(partition, issueId, detailLoad) ? (
        <PageState
          icon={<AlertCircle className="size-7" />}
          title="Issue deleted"
          description="This navigation entry points to an Issue that no longer exists."
          action={{ label: 'Back', onClick: onBack ?? closeIssuesPage }}
        />
      ) : detailLoad?.status === 'error' ? (
        <PageState
          icon={<AlertCircle className="size-7" />}
          title="Could not load Issue"
          description={detailLoad.error}
          action={{
            label: 'Retry',
            onClick: () =>
              void store
                .getState()
                .loadDetail(routeExecutionHostId, issueId)
          }}
        />
      ) : (
        <PageState
          icon={<Loader2 className="size-7 animate-spin" />}
          title="Loading Issue"
          description="Fetching the current Issue facts from its owning host."
        />
      )}
    </main>
  )
}

function PageState({
  icon,
  title,
  description,
  action
}: {
  icon: React.ReactNode
  title: string
  description: string
  action?: { label: string; onClick: () => void }
}): React.JSX.Element {
  return (
    <div className="flex h-full min-h-72 items-center justify-center px-6 py-10 text-center">
      <div className="flex max-w-sm flex-col items-center gap-2 text-muted-foreground">
        {icon}
        <h1 className="text-sm font-semibold text-foreground">{title}</h1>
        <p className="text-xs leading-5">{description}</p>
        {action ? (
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-2"
            onClick={action.onClick}
          >
            {action.label}
          </Button>
        ) : null}
      </div>
    </div>
  )
}

function findIssueAncestors(
  issues: readonly IssueSummary[],
  issue: IssueSummary
): IssueSummary[] {
  const byId = new Map(issues.map((candidate) => [candidate.id, candidate]))
  const ancestors: IssueSummary[] = []
  const seen = new Set([issue.id])
  let parentId = issue.parentId
  while (parentId && !seen.has(parentId)) {
    const parent = byId.get(parentId)
    if (!parent) {
      break
    }
    seen.add(parent.id)
    ancestors.unshift(parent)
    parentId = parent.parentId
  }
  return ancestors
}

function isDeletedSelection(
  partition: IssuesDomainState['partitionsByRoute'][ExecutionHostId] | undefined,
  issueId: string,
  detailLoad: IssuesDomainState['detailLoadsByKey'][string] | undefined
): boolean {
  return (
    detailLoad?.status === 'error' &&
    (partition?.status === 'ready' || partition?.status === 'cached') &&
    !partition.issues.some((issue) => issue.id === issueId)
  )
}
