import type { ExecutionHostId } from '../../../../../shared/execution-host'
import type {
  ConversationSummary,
  IssueAuthorityDescriptor,
  IssueDisplayProjection,
  IssueListFilter,
  IssueSearchMatch,
  IssueSummary,
  WorkspaceSnapshot
} from '../../../../../shared/issues/types'

export type IssuePartitionLoadStatus =
  | 'idle'
  | 'loading'
  | 'ready'
  | 'cached'
  | 'unsupported'
  | 'error'

export type IssueSidebarPartition = {
  routeExecutionHostId: ExecutionHostId
  status: IssuePartitionLoadStatus
  authority: IssueAuthorityDescriptor | null
  issues: readonly IssueSummary[]
  detailsByIssueId: Readonly<Record<string, readonly ConversationSummary[]>>
  unassignedSummary?: {
    conversationCount: number
    unresolvedCount: number
  }
  unassignedConversations: readonly ConversationSummary[]
  error?: string | null
}

export type IssueSidebarRow =
  | {
      id: string
      type: 'host-state'
      routeExecutionHostId: ExecutionHostId
      status: IssuePartitionLoadStatus
      error: string | null
    }
  | {
      id: string
      type: 'issue'
      routeExecutionHostId: ExecutionHostId
      authority: IssueAuthorityDescriptor
      issue: IssueSummary
      depth: 0 | 1 | 2
      contextOnly: boolean
      expandable: boolean
      expanded: boolean
    }
  | {
      id: string
      type: 'workspace-header'
      routeExecutionHostId: ExecutionHostId
      issueId: string | null
      workspace: WorkspaceSnapshot
      depth: number
      count: number
    }
  | {
      id: string
      type: 'conversation'
      routeExecutionHostId: ExecutionHostId
      issueId: string | null
      conversation: ConversationSummary
      depth: number
    }
  | {
      id: string
      type: 'unassigned-summary'
      routeExecutionHostId: ExecutionHostId
      conversationCount: number
      unresolvedCount: number
      expanded: boolean
    }
  | {
      id: string
      type: 'empty'
      routeExecutionHostId: ExecutionHostId
      filter: IssueListFilter
    }
  | {
      id: string
      type: 'search-status'
      routeExecutionHostId: ExecutionHostId
      isStale: boolean
      partial: boolean
    }
  | {
      id: string
      type: 'search-group'
      routeExecutionHostId: ExecutionHostId
      issue: IssueDisplayProjection | null
    }
  | {
      id: string
      type: 'search-result'
      routeExecutionHostId: ExecutionHostId
      authority: IssueAuthorityDescriptor
      issue: IssueDisplayProjection | null
      match: IssueSearchMatch
    }
  | {
      id: string
      type: 'search-empty'
      routeExecutionHostId: ExecutionHostId
    }
