import { createHash } from 'node:crypto'
import {
  chmodSync,
  existsSync,
  mkdirSync,
  rmSync
} from 'node:fs'
import { dirname, join } from 'node:path'
import {
  IssueClientSnapshotSchema,
  type IssueClientSnapshot
} from '../../shared/issues/client-data'
import type {
  AuthorityHostPartitionKey,
  IssueAuthorityDescriptor
} from '../../shared/issues/types'
import { getOrcaProfileDirectory } from '../orca-profiles/profile-storage-paths'
import SyncDatabase from '../sqlite/sync-database'

const ISSUE_CACHE_DIRECTORY_NAME = 'issues-cache'
const ISSUE_CACHE_SCHEMA_VERSION = 1

export type IssueReadCacheSnapshot = IssueClientSnapshot & {
  authority: IssueAuthorityDescriptor
}

type IssueReadCacheHeader = {
  profileId: string
  authorityId: string
  hostPartitionKey: AuthorityHostPartitionKey
  routeExecutionHostId: string
  cachedAt: number
}

export function getIssueReadCacheDirectory(
  profileId: string,
  userDataPath?: string
): string {
  return join(
    getOrcaProfileDirectory(profileId, userDataPath),
    ISSUE_CACHE_DIRECTORY_NAME
  )
}

export function getIssueReadCacheFileHash(
  authorityId: string,
  hostPartitionKey: AuthorityHostPartitionKey
): string {
  return createHash('sha256')
    .update(`${authorityId}\0${hostPartitionKey}`)
    .digest('hex')
}

export function getIssueReadCachePath(
  profileId: string,
  authority: Pick<IssueAuthorityDescriptor, 'authorityId' | 'hostPartitionKey'>,
  userDataPath?: string
): string {
  return join(
    getIssueReadCacheDirectory(profileId, userDataPath),
    `${getIssueReadCacheFileHash(
      authority.authorityId,
      authority.hostPartitionKey
    )}.db`
  )
}

export class IssueReadCache {
  readonly path: string
  private readonly database: SyncDatabase.Database
  private closed = false

  private constructor(
    private readonly profileId: string,
    private readonly authority: IssueAuthorityDescriptor,
    path: string,
    database: SyncDatabase.Database
  ) {
    this.path = path
    this.database = database
  }

  static open(options: {
    profileId: string
    userDataPath?: string
    authority: IssueAuthorityDescriptor
  }): IssueReadCache {
    const path = getIssueReadCachePath(
      options.profileId,
      options.authority,
      options.userDataPath
    )
    ensureCacheDirectory(path)
    let database = openCacheDatabase(path)
    let cache = new IssueReadCache(
      options.profileId,
      options.authority,
      path,
      database
    )
    if (!cache.headerMatches()) {
      database.close()
      removeCacheFiles(path)
      database = openCacheDatabase(path)
      cache = new IssueReadCache(
        options.profileId,
        options.authority,
        path,
        database
      )
    }
    cache.ensureHeader()
    hardenCacheFiles(path)
    return cache
  }

  replace(snapshot: IssueReadCacheSnapshot): void {
    this.assertOpen()
    const parsed = parseIssueReadCacheSnapshot(snapshot)
    this.assertAuthority(parsed.authority)
    this.database.exec('BEGIN IMMEDIATE')
    try {
      this.database
        .prepare(
          `UPDATE issue_cache_meta
           SET route_execution_host_id = ?, cached_at = ?
           WHERE singleton = 1`
        )
        .run(parsed.authority.routeExecutionHostId, parsed.cachedAt)
      this.database
        .prepare(
          `INSERT INTO issue_cache_snapshot (
             singleton, facts_revision, tree_revision, search_revision, payload_json
           ) VALUES (1, ?, ?, ?, ?)
           ON CONFLICT(singleton) DO UPDATE SET
             facts_revision = excluded.facts_revision,
             tree_revision = excluded.tree_revision,
             search_revision = excluded.search_revision,
             payload_json = excluded.payload_json`
        )
        .run(
          parsed.factsRevision,
          parsed.treeRevision,
          parsed.searchRevision,
          JSON.stringify(parsed)
        )
      this.database.exec('COMMIT')
    } catch (error) {
      this.database.exec('ROLLBACK')
      throw error
    }
    hardenCacheFiles(this.path)
  }

  read(): IssueReadCacheSnapshot | null {
    this.assertOpen()
    const row = this.database
      .prepare(
        `SELECT payload_json AS payloadJson
         FROM issue_cache_snapshot WHERE singleton = 1`
      )
      .get() as { payloadJson: string } | undefined
    if (!row) {
      return null
    }
    try {
      const snapshot = parseIssueReadCacheSnapshot(JSON.parse(row.payloadJson))
      this.assertAuthority(snapshot.authority)
      return snapshot
    } catch {
      return null
    }
  }

  getHeader(): IssueReadCacheHeader {
    this.assertOpen()
    const header = readCacheHeader(this.database)
    if (!header) {
      throw new Error('Issue read cache header is missing.')
    }
    return header
  }

  close(): void {
    if (this.closed) {
      return
    }
    this.database.close()
    hardenCacheFiles(this.path)
    this.closed = true
  }

  private headerMatches(): boolean {
    const header = readCacheHeader(this.database)
    return (
      header === null ||
      (header.profileId === this.profileId &&
        header.authorityId === this.authority.authorityId &&
        header.hostPartitionKey === this.authority.hostPartitionKey)
    )
  }

  private ensureHeader(): void {
    this.database
      .prepare(
        `INSERT OR IGNORE INTO issue_cache_meta (
           singleton, profile_id, authority_id, host_partition_key,
           route_execution_host_id, cached_at
         ) VALUES (1, ?, ?, ?, ?, 0)`
      )
      .run(
        this.profileId,
        this.authority.authorityId,
        this.authority.hostPartitionKey,
        this.authority.routeExecutionHostId
      )
  }

  private assertAuthority(authority: IssueAuthorityDescriptor): void {
    if (
      authority.authorityId !== this.authority.authorityId ||
      authority.hostPartitionKey !== this.authority.hostPartitionKey
    ) {
      throw new Error('Issue read cache authority mismatch.')
    }
  }

  private assertOpen(): void {
    if (this.closed) {
      throw new Error('Issue read cache is closed.')
    }
  }
}

export function inspectIssueReadCacheHeader(
  path: string
): IssueReadCacheHeader | null {
  if (!existsSync(path)) {
    return null
  }
  const database = new SyncDatabase(path, {
    readonly: true,
    fileMustExist: true,
    timeout: 5_000
  })
  try {
    return readCacheHeader(database)
  } catch {
    return null
  } finally {
    database.close()
  }
}

function openCacheDatabase(path: string): SyncDatabase.Database {
  const database = new SyncDatabase(path)
  try {
    database.pragma('journal_mode = WAL')
    database.pragma('synchronous = NORMAL')
    database.pragma('busy_timeout = 5000')
    database.pragma('foreign_keys = ON')
    database.exec('BEGIN IMMEDIATE')
    try {
      const version = Number(database.pragma('user_version', { simple: true }))
      if (version > ISSUE_CACHE_SCHEMA_VERSION) {
        throw new Error(`Unsupported Issue read cache schema ${version}.`)
      }
      if (version < 1) {
        database.exec(`
          CREATE TABLE issue_cache_meta (
            singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
            profile_id TEXT NOT NULL,
            authority_id TEXT NOT NULL,
            host_partition_key TEXT NOT NULL,
            route_execution_host_id TEXT NOT NULL,
            cached_at INTEGER NOT NULL
          );
          CREATE TABLE issue_cache_snapshot (
            singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
            facts_revision INTEGER NOT NULL,
            tree_revision INTEGER NOT NULL,
            search_revision INTEGER NOT NULL,
            payload_json TEXT NOT NULL,
            FOREIGN KEY (singleton) REFERENCES issue_cache_meta(singleton)
              ON DELETE CASCADE
          );
        `)
        database.pragma(`user_version = ${ISSUE_CACHE_SCHEMA_VERSION}`)
      }
      database.exec('COMMIT')
    } catch (error) {
      database.exec('ROLLBACK')
      throw error
    }
    return database
  } catch (error) {
    database.close()
    throw error
  }
}

function parseIssueReadCacheSnapshot(value: unknown): IssueReadCacheSnapshot {
  const parsed = IssueClientSnapshotSchema.parse(value)
  return {
    ...parsed,
    authority: {
      ...parsed.authority,
      hostPartitionKey:
        parsed.authority.hostPartitionKey as AuthorityHostPartitionKey
    }
  }
}

function readCacheHeader(
  database: SyncDatabase.Database
): IssueReadCacheHeader | null {
  try {
    const row = database
      .prepare(
        `SELECT
           profile_id AS profileId,
           authority_id AS authorityId,
           host_partition_key AS hostPartitionKey,
           route_execution_host_id AS routeExecutionHostId,
           cached_at AS cachedAt
         FROM issue_cache_meta WHERE singleton = 1`
      )
      .get() as IssueReadCacheHeader | undefined
    return row ?? null
  } catch {
    return null
  }
}

function ensureCacheDirectory(path: string): void {
  const directory = dirname(path)
  mkdirSync(directory, { recursive: true, mode: 0o700 })
  if (process.platform !== 'win32') {
    chmodSync(directory, 0o700)
  }
}

function hardenCacheFiles(path: string): void {
  if (process.platform === 'win32') {
    return
  }
  for (const candidate of [path, `${path}-wal`, `${path}-shm`]) {
    if (existsSync(candidate)) {
      chmodSync(candidate, 0o600)
    }
  }
}

function removeCacheFiles(path: string): void {
  for (const candidate of [path, `${path}-wal`, `${path}-shm`]) {
    rmSync(candidate, { force: true })
  }
}
