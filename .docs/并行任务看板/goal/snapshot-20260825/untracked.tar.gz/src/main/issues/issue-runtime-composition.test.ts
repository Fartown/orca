import { afterEach, describe, expect, it, vi } from 'vitest'
import type { IssueDigestGenerationExecutor } from './issue-digest-runtime-coordinator'
import {
  createIssueTestUserDataPath,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import { createIssueRuntimeService } from './issue-runtime-composition'

const repositories: IssueRepository[] = []

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
})

describe('Issue runtime composition', () => {
  it('passes the production Digest executor through to the runtime service', async () => {
    const repository = new IssueRepository(
      openIssueTestDatabase({
        profileId: 'composition-digest',
        userDataPath: createIssueTestUserDataPath('orca-issue-composition-digest')
      })
    )
    repositories.push(repository)
    const digestExecutor: IssueDigestGenerationExecutor = {
      generate: vi.fn(async () => ({
        problem: 'Problem',
        conclusion: 'Conclusion',
        keyArtifacts: null,
        openIssues: null,
        nextSteps: null
      })),
      cancel: vi.fn(async () => {})
    }
    const service = createIssueRuntimeService({
      repository,
      store: {
        getRepos: () => [],
        getProjectHostSetups: () => []
      },
      isManagedSshTarget: () => false,
      digestExecutor
    } as Parameters<typeof createIssueRuntimeService>[0] & {
      digestExecutor: IssueDigestGenerationExecutor
    })
    const issue = repository.issues.create({
      identity: issueMutationIdentity('composition-test', 'create-issue'),
      input: {
        kind: 'local',
        executionHostId: 'local',
        title: 'Digest composition'
      }
    })
    const preparation = service.prepareDigest({
      executionHostId: 'local',
      issueId: issue.id,
      coversUntil: 100
    })

    const generated = service.generateDigest(
      {
        executionHostId: 'local',
        mutationId: 'generate-digest',
        issueId: issue.id,
        coversUntil: 100,
        agent: 'codex',
        expectedInputFingerprint: preparation.inputFingerprint
      },
      'desktop-profile'
    )

    expect(generated.digest.status).toBe('generating')
    await vi.waitFor(() => {
      expect(repository.digests.require(generated.digest.id).status).toBe('draft')
    })
    expect(digestExecutor.generate).toHaveBeenCalledTimes(1)
  })
})
