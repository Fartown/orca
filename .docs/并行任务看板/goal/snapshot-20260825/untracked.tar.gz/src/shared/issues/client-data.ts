import { z } from 'zod'
import { parseExecutionHostId } from '../execution-host'
import {
  ConversationSummarySchema,
  IssueAuthorityDescriptorSchema,
  IssueDetailSchema,
  IssueRouteExecutionHostId,
  IssueSummarySchema,
  RoundRecordPreviewSchema,
  UnassignedConversationSummarySchema
} from './schemas'
import type { IssueAuthorityDescriptor } from './types'

export const ISSUE_SIDEBAR_ROOT_MODES = ['workspaces', 'issues'] as const

const CollapsedIssueNodeIdSchema = z.union([
  z.string().uuid(),
  z
    .string()
    .max(4_128)
    .refine(
      (value) =>
        value.startsWith('unassigned:') &&
        parseExecutionHostId(value.slice('unassigned:'.length)) !== null,
      'Invalid collapsed Issue node id'
    )
])

export const IssueClientSnapshotSchema = z.object({
  authority: IssueAuthorityDescriptorSchema,
  cachedAt: z.number().int().nonnegative(),
  factsRevision: z.number().int().nonnegative(),
  treeRevision: z.number().int().nonnegative(),
  searchRevision: z.number().int().nonnegative(),
  issues: z.array(IssueSummarySchema).max(100_000),
  unassigned: UnassignedConversationSummarySchema.optional(),
  details: z.array(IssueDetailSchema).max(100_000),
  unassignedConversations: z.array(ConversationSummarySchema).max(100_000),
  rounds: z.array(RoundRecordPreviewSchema).max(100_000)
})

export type IssueClientSnapshot = Omit<
  z.infer<typeof IssueClientSnapshotSchema>,
  'authority'
> & {
  authority: IssueAuthorityDescriptor
}

export const IssueClientPreferencesSchema = z.object({
  version: z.literal(1),
  sidebarRootMode: z.enum(ISSUE_SIDEBAR_ROOT_MODES),
  filter: z.enum(['all', 'needs-me', 'archived']),
  searchQuery: z.string().max(512).default(''),
  typeFilter: z.string().max(128).nullable().default(null),
  collapsedIssueIds: z.array(CollapsedIssueNodeIdSchema).max(100_000),
  selectedRouteExecutionHostId: IssueRouteExecutionHostId.nullable(),
  selectedIssueId: z.string().uuid().nullable(),
  sidebarScrollOffset: z.number().finite().nonnegative()
})

export type IssueClientPreferences = z.infer<typeof IssueClientPreferencesSchema>

export const DEFAULT_ISSUE_CLIENT_PREFERENCES: IssueClientPreferences = {
  version: 1,
  sidebarRootMode: 'workspaces',
  filter: 'all',
  searchQuery: '',
  typeFilter: null,
  collapsedIssueIds: [],
  selectedRouteExecutionHostId: null,
  selectedIssueId: null,
  sidebarScrollOffset: 0
}

export const IssueClientCacheReadArgsSchema = z.object({
  routeExecutionHostId: IssueRouteExecutionHostId
})

export const IssueClientCacheReplaceArgsSchema = z.object({
  routeExecutionHostId: IssueRouteExecutionHostId,
  snapshot: IssueClientSnapshotSchema
})

export type IssueClientCacheReadResult =
  | { status: 'hit'; snapshot: IssueClientSnapshot }
  | { status: 'miss' }
