import {
  IssueDigestConfirmationResultSchema,
  IssueDigestMutationResultSchema,
  IssueDigestPreparationSchema,
  IssuesCancelDigestParams,
  IssuesConfirmDigestParams,
  IssuesGenerateDigestParams,
  IssuesPrepareDigestParams,
  IssuesUpdateDigestDraftParams
} from '../../../../shared/issues/digest-schemas'
import {
  IssueMobilePendingPageSchema,
  IssuesPendingForMobileParams
} from '../../../../shared/issues/mobile-schemas'
import {
  ConversationBindingMutationResultSchema,
  ConversationPageSchema,
  ConversationSummarySchema,
  ConversationsBindIssueParams,
  ConversationsGetParams,
  ConversationsListUnassignedParams,
  IssueActivityPageSchema,
  IssueArchiveMutationResultSchema,
  IssueDashboardProjectionSchema,
  IssueDeletePreparationResultSchema,
  IssueDetailSchema,
  IssueMutationResultSchema,
  IssueSearchResultSchema,
  IssuesMigrateLegacyActivityParams,
  IssuesCreateParams,
  IssuesDeleteParams,
  IssuesGetParams,
  IssuesLifecycleParams,
  IssuesListParams,
  IssuesListResult,
  IssuesListActivityParams,
  IssuesListRoundsParams,
  IssuesMarkReadParams,
  IssuesPrepareDeleteParams,
  IssuesProjectDashboardPanesParams,
  IssuesReadRoundBodyParams,
  IssuesReparentParams,
  IssuesResolveRoundParams,
  IssuesSearchParams,
  IssuesUpdateParams,
  LegacyActivityMigrationResultSchema,
  RoundRecordBodyReadResultSchema,
  RoundRecordPageSchema
} from '../../../../shared/issues/schemas'
import type { IssueRuntimeService } from '../../../issues'
import { defineMethod, type RpcContext, type RpcMethod } from '../core'

let issueRuntimeServiceForRpc: IssueRuntimeService | null = null

export function setIssueRuntimeServiceForRpc(service: IssueRuntimeService | null): void {
  issueRuntimeServiceForRpc = service
}

export function getIssueRuntimeServiceForRpc(): IssueRuntimeService | null {
  return issueRuntimeServiceForRpc
}

function requireIssueRuntimeService(): IssueRuntimeService {
  if (!issueRuntimeServiceForRpc) {
    throw new Error('Issue runtime service is not available on this runtime.')
  }
  return issueRuntimeServiceForRpc
}

function requireCallerFingerprint(context: RpcContext): string {
  if (!context.authenticatedCallerFingerprint) {
    throw new Error('Authenticated Issue mutation identity is unavailable.')
  }
  return context.authenticatedCallerFingerprint
}

export const ISSUE_METHODS: readonly RpcMethod[] = [
  defineMethod({
    name: 'issues.list',
    params: IssuesListParams,
    handler: (params) => IssuesListResult.parse(requireIssueRuntimeService().list(params))
  }),
  defineMethod({
    name: 'issues.get',
    params: IssuesGetParams,
    handler: (params) => IssueDetailSchema.parse(requireIssueRuntimeService().get(params))
  }),
  defineMethod({
    name: 'issues.create',
    params: IssuesCreateParams,
    handler: async (params, context) => {
      const { mutationId, ...input } = params
      const result = await requireIssueRuntimeService().create(input, {
        mutationId,
        callerFingerprint: requireCallerFingerprint(context)
      })
      return IssueMutationResultSchema.parse(result)
    }
  }),
  defineMethod({
    name: 'issues.update',
    params: IssuesUpdateParams,
    handler: (params, context) =>
      IssueMutationResultSchema.parse(
        requireIssueRuntimeService().update(params, requireCallerFingerprint(context))
      )
  }),
  defineMethod({
    name: 'issues.archive',
    params: IssuesLifecycleParams,
    handler: (params, context) =>
      IssueArchiveMutationResultSchema.parse(
        requireIssueRuntimeService().archive(params, requireCallerFingerprint(context))
      )
  }),
  defineMethod({
    name: 'issues.reopen',
    params: IssuesLifecycleParams,
    handler: (params, context) =>
      IssueMutationResultSchema.parse(
        requireIssueRuntimeService().reopen(params, requireCallerFingerprint(context))
      )
  }),
  defineMethod({
    name: 'issues.reparent',
    params: IssuesReparentParams,
    handler: (params, context) =>
      IssueMutationResultSchema.parse(
        requireIssueRuntimeService().reparent(params, requireCallerFingerprint(context))
      )
  }),
  defineMethod({
    name: 'issues.prepareDelete',
    params: IssuesPrepareDeleteParams,
    handler: (params) =>
      IssueDeletePreparationResultSchema.parse(requireIssueRuntimeService().prepareDelete(params))
  }),
  defineMethod({
    name: 'issues.delete',
    params: IssuesDeleteParams,
    handler: (params, context) =>
      IssueMutationResultSchema.parse(
        requireIssueRuntimeService().delete(params, requireCallerFingerprint(context))
      )
  }),
  defineMethod({
    name: 'conversations.bindIssue',
    params: ConversationsBindIssueParams,
    handler: (params, context) =>
      ConversationBindingMutationResultSchema.parse(
        requireIssueRuntimeService().bindConversation(params, requireCallerFingerprint(context))
      )
  }),
  defineMethod({
    name: 'conversations.get',
    params: ConversationsGetParams,
    handler: (params) =>
      ConversationSummarySchema.parse(
        requireIssueRuntimeService().getConversation(params)
      )
  }),
  defineMethod({
    name: 'conversations.listUnassigned',
    params: ConversationsListUnassignedParams,
    handler: (params) =>
      ConversationPageSchema.parse(requireIssueRuntimeService().listUnassigned(params))
  }),
  defineMethod({
    name: 'issues.listActivity',
    params: IssuesListActivityParams,
    handler: (params) =>
      IssueActivityPageSchema.parse(requireIssueRuntimeService().listActivity(params))
  }),
  defineMethod({
    name: 'issues.pendingForMobile',
    params: IssuesPendingForMobileParams,
    handler: (params) =>
      IssueMobilePendingPageSchema.parse(
        requireIssueRuntimeService().pendingForMobile(params)
      )
  }),
  defineMethod({
    name: 'issues.search',
    params: IssuesSearchParams,
    handler: (params) =>
      IssueSearchResultSchema.parse(requireIssueRuntimeService().search(params))
  }),
  defineMethod({
    name: 'issues.projectDashboardPanes',
    params: IssuesProjectDashboardPanesParams,
    handler: (params) =>
      IssueDashboardProjectionSchema.parse(
        requireIssueRuntimeService().projectDashboardPanes(params)
      )
  }),
  defineMethod({
    name: 'issues.migrateLegacyActivity',
    params: IssuesMigrateLegacyActivityParams,
    handler: (params, context) =>
      LegacyActivityMigrationResultSchema.parse(
        requireIssueRuntimeService().migrateLegacyActivity(
          params,
          requireCallerFingerprint(context)
        )
      )
  }),
  defineMethod({
    name: 'issues.listRounds',
    params: IssuesListRoundsParams,
    handler: (params) =>
      RoundRecordPageSchema.parse(requireIssueRuntimeService().listRounds(params))
  }),
  defineMethod({
    name: 'issues.readRoundBody',
    params: IssuesReadRoundBodyParams,
    handler: (params) =>
      RoundRecordBodyReadResultSchema.parse(requireIssueRuntimeService().readRoundBody(params))
  }),
  defineMethod({
    name: 'issues.markRead',
    params: IssuesMarkReadParams,
    handler: (params, context) =>
      IssueMutationResultSchema.parse(
        requireIssueRuntimeService().markRead(params, requireCallerFingerprint(context))
      )
  }),
  defineMethod({
    name: 'issues.resolveRound',
    params: IssuesResolveRoundParams,
    handler: (params, context) =>
      IssueMutationResultSchema.parse(
        requireIssueRuntimeService().resolveRound(params, requireCallerFingerprint(context))
      )
  }),
  defineMethod({
    name: 'issues.prepareDigest',
    params: IssuesPrepareDigestParams,
    handler: (params) =>
      IssueDigestPreparationSchema.parse(
        requireIssueRuntimeService().prepareDigest(params)
      )
  }),
  defineMethod({
    name: 'issues.generateDigest',
    params: IssuesGenerateDigestParams,
    handler: (params, context) =>
      IssueDigestMutationResultSchema.parse(
        requireIssueRuntimeService().generateDigest(
          params,
          requireCallerFingerprint(context)
        )
      )
  }),
  defineMethod({
    name: 'issues.cancelDigest',
    params: IssuesCancelDigestParams,
    handler: async (params, context) =>
      IssueDigestMutationResultSchema.parse(
        await requireIssueRuntimeService().cancelDigest(
          params,
          requireCallerFingerprint(context)
        )
      )
  }),
  defineMethod({
    name: 'issues.updateDigestDraft',
    params: IssuesUpdateDigestDraftParams,
    handler: (params, context) =>
      IssueDigestMutationResultSchema.parse(
        requireIssueRuntimeService().updateDigestDraft(
          params,
          requireCallerFingerprint(context)
        )
      )
  }),
  defineMethod({
    name: 'issues.confirmDigest',
    params: IssuesConfirmDigestParams,
    handler: (params, context) =>
      IssueDigestConfirmationResultSchema.parse(
        requireIssueRuntimeService().confirmDigest(
          params,
          requireCallerFingerprint(context)
        )
      )
  })
]
