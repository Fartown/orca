import type { AgentStatusEntry } from '../../../shared/agent-status-types'
import {
  getWorktreeExecutionHostId,
  toSshExecutionHostId,
  type ExecutionHostId
} from '../../../shared/execution-host'
import type { Repo } from '../../../shared/repo-types'
import { parsePaneKey } from '../../../shared/stable-pane-id'
import type { TerminalTab } from '../../../shared/terminal-tab-types'
import type { Worktree } from '../../../shared/worktree/types'

export function resolveLegacyActivityPaneRoutes(args: {
  entriesByPaneKey: Readonly<Record<string, AgentStatusEntry>>
  tabsByWorktree: Readonly<Record<string, readonly TerminalTab[]>>
  worktrees: readonly Worktree[]
  repos: readonly Repo[]
}): Partial<Record<string, ExecutionHostId>> {
  const worktreeById = new Map(
    args.worktrees.map((worktree) => [worktree.id, worktree])
  )
  const repoById = new Map(args.repos.map((repo) => [repo.id, repo]))
  const worktreeIdByTab = new Map<string, string>()
  for (const [worktreeId, tabs] of Object.entries(args.tabsByWorktree)) {
    for (const tab of tabs) {
      worktreeIdByTab.set(tab.id, worktreeId)
    }
  }

  const routes: Partial<Record<string, ExecutionHostId>> = {}
  for (const [paneKey, entry] of Object.entries(args.entriesByPaneKey)) {
    const parsedPane = parsePaneKey(paneKey)
    const worktreeId =
      entry.worktreeId ??
      (parsedPane ? worktreeIdByTab.get(parsedPane.tabId) : undefined)
    const worktree = worktreeId ? worktreeById.get(worktreeId) : undefined
    if (worktree) {
      routes[paneKey] = getWorktreeExecutionHostId(
        worktree,
        repoById.get(worktree.repoId)
      )
      continue
    }
    if (entry.connectionId) {
      routes[paneKey] = toSshExecutionHostId(entry.connectionId)
    }
  }
  return routes
}
