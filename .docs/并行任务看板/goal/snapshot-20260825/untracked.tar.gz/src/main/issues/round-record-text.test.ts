import { describe, expect, it } from 'vitest'
import {
  ROUND_TEXT_PREVIEW_MAX_BYTES,
  ROUND_USER_INPUT_MAX_BYTES
} from '../../shared/issues/constants'
import { getUtf8ByteLength } from '../../shared/utf8-byte-limits'
import { normalizeRoundRecordText } from './round-record-text'

describe('normalizeRoundRecordText', () => {
  it('retains both ends of oversized UTF-8 text and records truncation', () => {
    const prefix = 'BEGIN🙂'
    const suffix = '🙂END'
    const oversized = `${prefix}${'界'.repeat(ROUND_USER_INPUT_MAX_BYTES)}${suffix}`

    const normalized = normalizeRoundRecordText(
      { text: oversized, completeness: 'complete' },
      ROUND_USER_INPUT_MAX_BYTES,
      'Round user input'
    )

    expect(normalized.text).not.toBe(oversized)
    expect(normalized.text?.startsWith(prefix)).toBe(true)
    expect(normalized.text?.endsWith(suffix)).toBe(true)
    expect(getUtf8ByteLength(normalized.text ?? '')).toBeLessThanOrEqual(
      ROUND_USER_INPUT_MAX_BYTES
    )
    expect(normalized.completeness).toBe('truncated')
    expect(normalized.storage).toBe('full')
    expect(normalized.preview).not.toBeNull()
    expect(getUtf8ByteLength(normalized.preview ?? '')).toBeLessThanOrEqual(
      ROUND_TEXT_PREVIEW_MAX_BYTES
    )
  })

  it('keeps a bounded explicit preview on a code-point boundary', () => {
    const normalized = normalizeRoundRecordText(
      {
        preview: '🙂'.repeat(ROUND_TEXT_PREVIEW_MAX_BYTES),
        completeness: 'preview-complete',
        storage: 'preview'
      },
      ROUND_USER_INPUT_MAX_BYTES,
      'Round user input'
    )

    expect(normalized.preview).not.toBeNull()
    expect(getUtf8ByteLength(normalized.preview ?? '')).toBeLessThanOrEqual(
      ROUND_TEXT_PREVIEW_MAX_BYTES
    )
    expect(normalized.preview?.endsWith('🙂')).toBe(true)
  })
})
