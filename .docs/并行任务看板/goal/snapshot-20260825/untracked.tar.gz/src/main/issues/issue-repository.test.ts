import { afterEach, describe, expect, it } from 'vitest'
import type { ExecutionHostId } from '../../shared/execution-host'
import { PROFILE_ROUND_TEXT_HARD_LIMIT_BYTES } from '../../shared/issues/constants'
import { getUtf8ByteLength } from '../../shared/utf8-byte-limits'
import {
  createIssueTestUserDataPath,
  issueFileDatabaseTestsAvailable,
  openIssueTestDatabase,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import type { CreateConversationInput, CreateIssueInput } from './issue-repository-types'
import { getIssueHostRevisions } from './issue-host-state'
import { IssueRepository, issueMutationIdentity } from './issue-repository'
import { IssueRepositoryError, type IssueRepositoryErrorCode } from './issue-repository-error'

const repositories: IssueRepository[] = []
let mutationSequence = 0

function createUserDataPath(): string {
  return createIssueTestUserDataPath('orca-issues-repository')
}

function openRepository(profileId: string, userDataPath: string): IssueRepository {
  const repository = new IssueRepository(openIssueTestDatabase({ profileId, userDataPath }))
  repositories.push(repository)
  return repository
}

function identity(label = 'mutation') {
  mutationSequence += 1
  return issueMutationIdentity('test-caller', `${label}-${mutationSequence}`)
}

function localIssue(
  title: string,
  options: Partial<Omit<CreateIssueInput, 'kind' | 'title'>> = {}
): CreateIssueInput {
  return { kind: 'local', executionHostId: 'local', title, ...options }
}

function conversation(
  executionHostId: ExecutionHostId = 'local',
  issueId: string | null = null
): CreateConversationInput {
  return {
    executionHostId,
    workspaceRef: { type: 'folder', folderWorkspaceId: `folder-${executionHostId}` },
    workspaceSnapshot: { name: 'Workspace', path: '/workspace' },
    agent: 'codex',
    title: 'Conversation',
    titleSource: 'user',
    issueId
  }
}

function expectRepositoryError(
  operation: () => unknown,
  code: IssueRepositoryErrorCode
): IssueRepositoryError {
  try {
    operation()
  } catch (error) {
    expect(error).toBeInstanceOf(IssueRepositoryError)
    expect((error as IssueRepositoryError).code).toBe(code)
    return error as IssueRepositoryError
  }
  throw new Error(`Expected IssueRepositoryError(${code}).`)
}

afterEach(() => {
  for (const repository of repositories.splice(0)) {
    repository.close()
  }
  removeIssueTestDirectories()
  mutationSequence = 0
})

describe('IssueRepository profile and mutation boundaries', () => {
  it('keeps different profiles in different files with mutually invisible records', () => {
    const userDataPath = createUserDataPath()
    const profileA = openRepository('profile-a', userDataPath)
    const profileB = openRepository('profile-b', userDataPath)
    const created = profileA.issues.create({
      identity: identity('profile-create'),
      input: localIssue('Only in A')
    })

    expect(profileA.database.path).not.toBe(profileB.database.path)
    expect(profileA.database.getAuthorityId()).not.toBe(profileB.database.getAuthorityId())
    expect(profileA.issues.get(created.id)?.localTitle).toBe('Only in A')
    expect(profileB.issues.get(created.id)).toBeUndefined()
    expect(profileB.issues.list()).toEqual([])
  })

  it('replays one receipt without allocating a second Issue number or revision', () => {
    const userDataPath = createUserDataPath()
    const repository = openRepository('idempotency', userDataPath)
    const mutation = issueMutationIdentity('stable-caller', 'stable-create')
    const input = localIssue('Idempotent')

    const first = repository.issues.create({ identity: mutation, input })
    const second = repository.issues.create({ identity: mutation, input })

    expect(second).toEqual(first)
    expect(repository.issues.list()).toEqual([first])
    expect(
      repository.database
        .prepare(
          `SELECT next_local_issue_number, facts_revision, tree_revision
           FROM issue_host_state WHERE host_partition_key = 'local'`
        )
        .get()
    ).toEqual({
      next_local_issue_number: 2,
      facts_revision: 1,
      tree_revision: 1
    })
    expect(
      repository.database.prepare('SELECT COUNT(*) AS count FROM issue_mutation_receipts').get()
    ).toEqual({ count: 1 })
  })

  it.runIf(issueFileDatabaseTestsAvailable)('persists a receipt across database reopen', () => {
    const userDataPath = createUserDataPath()
    const repository = openRepository('receipt-persistence', userDataPath)
    const mutation = issueMutationIdentity('stable-caller', 'persistent-create')
    const input = localIssue('Persistent receipt')
    const first = repository.issues.create({ identity: mutation, input })
    repository.close()

    const reopened = openRepository('receipt-persistence', userDataPath)
    expect(reopened.issues.create({ identity: mutation, input })).toEqual(first)
    expect(reopened.issues.list()).toEqual([first])
    expect(
      reopened.database.prepare('SELECT COUNT(*) AS count FROM issue_mutation_receipts').get()
    ).toEqual({ count: 1 })
  })

  it('rejects reuse of one mutation id with different payload', () => {
    const repository = openRepository('mutation-conflict', createUserDataPath())
    const mutation = issueMutationIdentity('stable-caller', 'reused')
    repository.issues.create({ identity: mutation, input: localIssue('First') })

    expectRepositoryError(
      () => repository.issues.create({ identity: mutation, input: localIssue('Second') }),
      'mutation_mismatch'
    )
    expect(repository.issues.list().map((issue) => issue.localTitle)).toEqual(['First'])
  })
})

describe('IssueRecordRepository', () => {
  it('persists create, read, list, update, and delete behavior', () => {
    const repository = openRepository('issue-crud', createUserDataPath())
    const created = repository.issues.create({
      identity: identity('create'),
      input: localIssue('Initial', { typeLabel: 'feature', note: 'first note' })
    })

    expect(repository.issues.get(created.id)).toEqual(created)
    expect(repository.issues.list({ state: 'active' })).toEqual([created])
    const updated = repository.issues.update({
      identity: identity('update'),
      input: {
        id: created.id,
        localTitle: 'Renamed',
        typeLabel: null,
        note: 'updated'
      }
    })
    expect(updated).toMatchObject({
      id: created.id,
      localTitle: 'Renamed',
      typeLabel: null,
      note: 'updated'
    })
    const archived = repository.issues.archive({
      identity: identity('archive'),
      input: { id: created.id }
    })
    expect(archived).toMatchObject({
      status: 'archived',
      issueId: created.id,
      archivedAt: expect.any(Number)
    })
    expect(repository.issues.get(created.id)).toMatchObject({
      state: 'archived',
      archivedAt: expect.any(Number)
    })
    expect(repository.issues.list({ state: 'active' })).toEqual([])

    const deletePlan = repository.issues.prepareDelete(created.id).plan
    expect(
      repository.issues.delete({
        identity: identity('delete'),
        input: deletePlan
      })
    ).toMatchObject({ deletedIssueId: created.id })
    expect(repository.issues.get(created.id)).toBeUndefined()
  })

  it('rejects repository and direct-SQL executionHostId changes', () => {
    const repository = openRepository('host-immutable', createUserDataPath())
    const issue = repository.issues.create({
      identity: identity('create'),
      input: localIssue('Fixed host')
    })

    expectRepositoryError(
      () =>
        repository.issues.update({
          identity: identity('host-update'),
          input: { id: issue.id, executionHostId: 'ssh:other' } as never
        }),
      'issue_host_immutable'
    )
    expect(() =>
      repository.database
        .prepare(
          `UPDATE issues
           SET execution_host_id = 'ssh:other', host_partition_key = 'ssh:other'
           WHERE id = ?`
        )
        .run(issue.id)
    ).toThrow()
    expect(repository.issues.get(issue.id)?.executionHostId).toBe('local')
  })

  it('rejects cross-host parents through both repository and database triggers', () => {
    const repository = openRepository('parent-host', createUserDataPath())
    const parent = repository.issues.create({
      identity: identity('parent'),
      input: localIssue('Local parent')
    })

    expectRepositoryError(
      () =>
        repository.issues.create({
          identity: identity('cross-host-child'),
          input: {
            kind: 'local',
            executionHostId: 'ssh:remote',
            title: 'Remote child',
            parentId: parent.id
          }
        }),
      'parent_host_mismatch'
    )
    expect(() =>
      repository.database
        .prepare(
          `INSERT INTO issues (
             id, host_partition_key, execution_host_id, source_kind, source_number,
             local_title, state, parent_id, sibling_order, created_at, updated_at
           ) VALUES (
             'direct-child', 'ssh:remote', 'ssh:remote', 'local', 1,
             'Direct child', 'active', ?, 0, 1, 1
           )`
        )
        .run(parent.id)
    ).toThrow()
    expect(repository.issues.list()).toEqual([parent])
  })

  it('allows three levels while rejecting a fourth level and cycles', () => {
    const repository = openRepository('hierarchy', createUserDataPath())
    const root = repository.issues.create({
      identity: identity('root'),
      input: localIssue('Root')
    })
    const child = repository.issues.create({
      identity: identity('child'),
      input: localIssue('Child', { parentId: root.id })
    })
    const grandchild = repository.issues.create({
      identity: identity('grandchild'),
      input: localIssue('Grandchild', { parentId: child.id })
    })

    expectRepositoryError(
      () =>
        repository.issues.create({
          identity: identity('too-deep'),
          input: localIssue('Too deep', { parentId: grandchild.id })
        }),
      'issue_depth_exceeded'
    )
    expectRepositoryError(
      () =>
        repository.issues.reparent({
          identity: identity('cycle'),
          input: {
            issueId: root.id,
            parentId: grandchild.id,
            index: 0,
            expectedTreeRevision: getIssueHostRevisions(
              repository.database,
              'local'
            ).treeRevision
          }
        }),
      'parent_cycle'
    )
  })

  it('rejects an incomplete delete plan without moving any child', () => {
    const repository = openRepository('issue-child-delete', createUserDataPath())
    const parent = repository.issues.create({
      identity: identity('parent'),
      input: localIssue('Parent')
    })
    const child = repository.issues.create({
      identity: identity('child'),
      input: localIssue('Child', { parentId: parent.id })
    })

    const preparation = repository.issues.prepareDelete(parent.id)
    expect(preparation.plan.children).toHaveLength(1)
    expectRepositoryError(() => {
      repository.issues.delete({
        identity: identity('delete-parent'),
        input: { ...preparation.plan, children: [] }
      })
    }, 'issue_delete_plan_invalid')
    expect(repository.issues.get(parent.id)).toEqual(parent)
    expect(repository.issues.get(child.id)).toEqual(child)
  })
})

describe('ConversationRecordRepository', () => {
  it('replays a create receipt without producing a second Conversation or revision', () => {
    const repository = openRepository('conversation-idempotency', createUserDataPath())
    const mutation = issueMutationIdentity('conversation-caller', 'stable-conversation-create')
    const input = conversation()

    const first = repository.conversations.create({ identity: mutation, input })
    const second = repository.conversations.create({ identity: mutation, input })

    expect(second).toEqual(first)
    expect(repository.conversations.list()).toEqual([first])
    expect(
      repository.database
        .prepare(
          `SELECT facts_revision, tree_revision
           FROM issue_host_state WHERE host_partition_key = 'local'`
        )
        .get()
    ).toEqual({ facts_revision: 1, tree_revision: 0 })
  })

  it('persists unassigned create, binding update, listing, close, and delete', () => {
    const repository = openRepository('conversation-crud', createUserDataPath())
    const issue = repository.issues.create({
      identity: identity('issue'),
      input: localIssue('Conversation owner')
    })
    const created = repository.conversations.create({
      identity: identity('conversation-create'),
      input: conversation()
    })

    expect(created.issueId).toBeNull()
    expect(repository.conversations.get(created.id)).toEqual(created)
    expect(repository.conversations.list({ issueId: null })).toEqual([created])
    const bound = repository.conversations.update({
      identity: identity('conversation-bind'),
      input: {
        id: created.id,
        title: 'Bound conversation',
        titleSource: 'generated',
        state: 'closed',
        issueId: issue.id
      }
    })
    expect(bound).toMatchObject({
      title: 'Bound conversation',
      titleSource: 'generated',
      state: 'closed',
      issueId: issue.id
    })
    expect(repository.conversations.list({ issueId: issue.id })).toEqual([bound])
    const incompleteDeletePlan = repository.issues.prepareDelete(issue.id).plan
    expectRepositoryError(() => {
      repository.issues.delete({
        identity: identity('blocked-delete'),
        input: { ...incompleteDeletePlan, conversations: [] }
      })
    }, 'issue_delete_plan_invalid')

    repository.conversations.update({
      identity: identity('conversation-unbind'),
      input: { id: created.id, issueId: null }
    })
    repository.issues.delete({
      identity: identity('issue-delete'),
      input: repository.issues.prepareDelete(issue.id).plan
    })
    expect(
      repository.conversations.delete({
        identity: identity('conversation-delete'),
        input: { id: created.id }
      })
    ).toEqual({ deletedConversationId: created.id })
    expect(repository.conversations.get(created.id)).toBeUndefined()
  })

  it('rejects binding a Conversation to an Issue on another execution host', () => {
    const repository = openRepository('conversation-host', createUserDataPath())
    const remoteIssue = repository.issues.create({
      identity: identity('remote-issue'),
      input: {
        kind: 'local',
        executionHostId: 'ssh:remote',
        title: 'Remote Issue'
      }
    })

    expectRepositoryError(
      () =>
        repository.conversations.create({
          identity: identity('cross-host-conversation'),
          input: conversation('local', remoteIssue.id)
        }),
      'conversation_issue_host_mismatch'
    )
    expect(repository.conversations.list()).toEqual([])
  })
})

describe('RoundRecordRepository', () => {
  it('persists text, derives supersession, updates read/resolution, and tombstones bodies', () => {
    const repository = openRepository('round-crud', createUserDataPath())
    const conversationRecord = repository.conversations.create({
      identity: identity('conversation'),
      input: conversation()
    })
    const first = repository.rounds.create({
      identity: identity('round-first'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'round:first',
        executionChainId: 'chain-1',
        agentOutput: { text: 'first result' }
      }
    })
    expect(
      repository.database
        .prepare(
          'SELECT retained_round_text_bytes AS bytes FROM issue_authority_meta WHERE singleton = 1'
        )
        .get()
    ).toEqual({ bytes: 24 })
    const secondMutation = issueMutationIdentity('round-caller', 'round-second')
    const secondInput = {
      conversationId: conversationRecord.id,
      kind: 'completion' as const,
      stateSource: 'hook' as const,
      occurredAt: 20,
      dedupeKey: 'round:second',
      executionChainId: 'chain-1',
      supersedesRoundId: first.id,
      agentOutput: { text: 'second result' }
    }
    const second = repository.rounds.create({
      identity: secondMutation,
      input: secondInput
    })
    expect(repository.rounds.create({ identity: secondMutation, input: secondInput })).toEqual(
      second
    )

    expect(repository.rounds.get(first.id)).toMatchObject({
      resolvedAt: null,
      resolution: null,
      effectiveResolvedAt: 20,
      effectiveResolution: 'superseded'
    })
    expect(repository.rounds.list({ conversationId: conversationRecord.id })).toHaveLength(2)
    const resolved = repository.rounds.update({
      identity: identity('round-resolve'),
      input: {
        id: second.id,
        readAt: 30,
        resolvedAt: 31,
        resolution: 'explicit'
      }
    })
    expect(resolved).toMatchObject({
      readAt: 30,
      resolvedAt: 31,
      resolution: 'explicit',
      effectiveResolution: 'explicit'
    })

    expect(
      repository.rounds.delete({
        identity: identity('round-delete'),
        input: { id: second.id }
      })
    ).toEqual({ deletedRoundId: second.id })
    expect(repository.rounds.get(second.id)).toMatchObject({
      id: second.id,
      resolvedAt: 31,
      resolution: 'explicit',
      bodyDeletedAt: expect.any(Number),
      agentOutput: {
        text: null,
        preview: null,
        bytes: 0,
        previewBytes: 0,
        completeness: 'complete',
        storage: 'deleted'
      }
    })
    expect(repository.rounds.get(first.id)).toMatchObject({
      effectiveResolvedAt: 20,
      effectiveResolution: 'superseded'
    })
    expect(
      repository.database
        .prepare(
          'SELECT retained_round_text_bytes AS bytes FROM issue_authority_meta WHERE singleton = 1'
        )
        .get()
    ).toEqual({ bytes: 24 })
  })

  it('deduplicates replayed stops and only upgrades body completeness', () => {
    const repository = openRepository('round-dedupe', createUserDataPath())
    const conversationRecord = repository.conversations.create({
      identity: identity('conversation'),
      input: conversation()
    })
    const first = repository.rounds.create({
      identity: identity('preview'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'round:stable-stop',
        agentOutput: {
          preview: 'partial result',
          completeness: 'preview-complete',
          storage: 'preview'
        }
      }
    })
    const replay = repository.rounds.create({
      identity: identity('complete'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'completion',
        stateSource: 'reconciled',
        occurredAt: 10,
        dedupeKey: 'round:stable-stop',
        agentOutput: {
          text: 'complete result',
          completeness: 'complete'
        }
      }
    })

    expect(replay.id).toBe(first.id)
    expect(replay).toMatchObject({
      stateSource: 'hook',
      agentOutput: {
        text: 'complete result',
        completeness: 'complete',
        storage: 'full'
      }
    })
    expect(repository.rounds.list({ conversationId: conversationRecord.id })).toHaveLength(1)

    const weakerReplay = repository.rounds.create({
      identity: identity('weaker'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'completion',
        stateSource: 'scrape',
        occurredAt: 10,
        dedupeKey: 'round:stable-stop',
        agentOutput: {
          preview: 'weaker',
          completeness: 'preview-complete',
          storage: 'preview'
        }
      }
    })
    expect(weakerReplay.agentOutput).toEqual(replay.agentOutput)
  })

  it('rolls back the entire mutation when a provider turn ref already has an owner', () => {
    const repository = openRepository('round-ref-conflict', createUserDataPath())
    const conversationRecord = repository.conversations.create({
      identity: identity('conversation'),
      input: conversation()
    })
    const providerRef = {
      kind: 'provider-turn',
      value: 'v1:stable-provider-turn',
      reachable: true
    }
    const first = repository.rounds.create({
      identity: identity('first-round'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'round:first-provider-turn',
        agentOutput: { text: 'first result' },
        refs: [providerRef]
      }
    })
    const before = {
      authority: repository.database
        .prepare(
          `SELECT retained_round_text_bytes AS bytes
           FROM issue_authority_meta WHERE singleton = 1`
        )
        .get(),
      host: repository.database
        .prepare(
          `SELECT facts_revision, search_revision, search_index_dirty
           FROM issue_host_state WHERE host_partition_key = 'local'`
        )
        .get(),
      receiptCount: repository.database
        .prepare('SELECT COUNT(*) AS count FROM issue_mutation_receipts')
        .get()
    }

    expectRepositoryError(
      () =>
        repository.rounds.create({
          identity: identity('conflicting-round'),
          input: {
            conversationId: conversationRecord.id,
            kind: 'completion',
            stateSource: 'reconciled',
            occurredAt: 20,
            dedupeKey: 'round:conflicting-provider-turn',
            agentOutput: { text: 'must roll back' },
            refs: [providerRef]
          }
        }),
      'round_ref_conflict'
    )

    expect(repository.rounds.list({ conversationId: conversationRecord.id })).toEqual([first])
    expect(
      repository.database
        .prepare(
          `SELECT round_id, ref_kind, value
           FROM round_refs`
        )
        .all()
    ).toEqual([
      {
        round_id: first.id,
        ref_kind: providerRef.kind,
        value: providerRef.value
      }
    ])
    expect({
      authority: repository.database
        .prepare(
          `SELECT retained_round_text_bytes AS bytes
           FROM issue_authority_meta WHERE singleton = 1`
        )
        .get(),
      host: repository.database
        .prepare(
          `SELECT facts_revision, search_revision, search_index_dirty
           FROM issue_host_state WHERE host_partition_key = 'local'`
        )
        .get(),
      receiptCount: repository.database
        .prepare('SELECT COUNT(*) AS count FROM issue_mutation_receipts')
        .get()
    }).toEqual(before)
  })

  it('marks a Round read without resolving its obligation', () => {
    const repository = openRepository('round-read-resolution', createUserDataPath())
    const conversationRecord = repository.conversations.create({
      identity: identity('conversation'),
      input: conversation()
    })
    const waiting = repository.rounds.create({
      identity: identity('waiting'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'round:read-only',
        pendingQuestion: { text: 'Approve?' }
      }
    })

    expect(
      repository.rounds.update({
        identity: identity('read'),
        input: { id: waiting.id, readAt: 20 }
      })
    ).toMatchObject({
      readAt: 20,
      resolvedAt: null,
      resolution: null,
      effectiveResolvedAt: null
    })
  })

  it('queues searchable Round bodies at the same revision as the authority state', () => {
    const repository = openRepository('round-search-queue', createUserDataPath())
    const conversationRecord = repository.conversations.create({
      identity: identity('conversation'),
      input: conversation()
    })
    const before = repository.database
      .prepare(
        `SELECT search_revision AS revision
         FROM issue_host_state WHERE host_partition_key = 'local'`
      )
      .get() as { revision: number }
    const round = repository.rounds.create({
      identity: identity('round'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'completion',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'round:searchable',
        agentOutput: { text: 'searchable output' }
      }
    })
    const state = repository.database
      .prepare(
        `SELECT search_revision AS revision, search_index_dirty AS dirty
         FROM issue_host_state WHERE host_partition_key = 'local'`
      )
      .get() as { revision: number; dirty: number }

    expect(state).toEqual({ revision: before.revision + 1, dirty: 1 })
    expect(
      repository.database
        .prepare(
          `SELECT entity_kind, entity_id, requested_revision
           FROM issue_search_rebuild_queue
           WHERE host_partition_key = 'local'`
        )
        .all()
    ).toEqual([
      {
        entity_kind: 'round',
        entity_id: round.id,
        requested_revision: state.revision
      }
    ])
  })

  it('never commits retained text beyond the profile hard limit', () => {
    const repository = openRepository('round-hard-limit', createUserDataPath())
    const conversationRecord = repository.conversations.create({
      identity: identity('conversation'),
      input: conversation()
    })
    repository.database
      .prepare(
        `UPDATE issue_authority_meta
         SET retained_round_text_bytes = ?
         WHERE singleton = 1`
      )
      .run(PROFILE_ROUND_TEXT_HARD_LIMIT_BYTES - 4)

    const round = repository.rounds.create({
      identity: identity('round'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'round:hard-limit',
        pendingQuestion: { text: '1234567890' }
      }
    })
    const retained = repository.database
      .prepare(
        'SELECT retained_round_text_bytes AS bytes FROM issue_authority_meta WHERE singleton = 1'
      )
      .get() as { bytes: number }

    expect(retained.bytes).toBeLessThanOrEqual(PROFILE_ROUND_TEXT_HARD_LIMIT_BYTES)
    expect(getUtf8ByteLength(round.pendingQuestion.text ?? '')).toBeLessThanOrEqual(10)
  })

  it('keeps an unresolved waiting obligation after explicit body deletion', () => {
    const repository = openRepository('round-delete-obligation', createUserDataPath())
    const conversationRecord = repository.conversations.create({
      identity: identity('conversation'),
      input: conversation()
    })
    const waiting = repository.rounds.create({
      identity: identity('round'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'round:delete-body',
        pendingQuestion: { text: 'Keep the obligation' }
      }
    })

    repository.rounds.delete({
      identity: identity('delete-body'),
      input: { id: waiting.id }
    })

    expect(repository.rounds.get(waiting.id)).toMatchObject({
      id: waiting.id,
      kind: 'waiting',
      resolvedAt: null,
      effectiveResolvedAt: null,
      pendingQuestion: {
        text: null,
        preview: null,
        storage: 'deleted',
        completeness: 'complete'
      }
    })
  })

  it('keeps retained body-byte accounting correct when Conversation deletion cascades rounds', () => {
    const repository = openRepository('round-cascade-accounting', createUserDataPath())
    const conversationRecord = repository.conversations.create({
      identity: identity('conversation'),
      input: conversation()
    })
    repository.rounds.create({
      identity: identity('round'),
      input: {
        conversationId: conversationRecord.id,
        kind: 'waiting',
        stateSource: 'hook',
        occurredAt: 10,
        dedupeKey: 'round:waiting',
        pendingQuestion: { text: 'approve?' }
      }
    })
    expect(
      repository.database
        .prepare(
          'SELECT retained_round_text_bytes AS bytes FROM issue_authority_meta WHERE singleton = 1'
        )
        .get()
    ).toEqual({ bytes: 16 })

    repository.conversations.delete({
      identity: identity('conversation-delete'),
      input: { id: conversationRecord.id }
    })

    expect(repository.rounds.list({ conversationId: conversationRecord.id })).toEqual([])
    expect(
      repository.database
        .prepare(
          'SELECT retained_round_text_bytes AS bytes FROM issue_authority_meta WHERE singleton = 1'
        )
        .get()
    ).toEqual({ bytes: 0 })
  })
})
