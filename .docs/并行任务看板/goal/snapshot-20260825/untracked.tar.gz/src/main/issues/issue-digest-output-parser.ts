import type { IssueDigestSections } from '../../shared/issues/digest-types'
import { ISSUE_DIGEST_DRAFT_MAX_BYTES } from '../../shared/issues/digest-constants'
import { assertJsonTextStructureWithinLimits } from '../../shared/json-text-structure-limit'
import { measureUtf8ByteLength } from '../../shared/utf8-byte-limits'
import { IssueRepositoryError } from './issue-repository-error'

const DIGEST_SECTION_KEYS = [
  'problem',
  'conclusion',
  'keyArtifacts',
  'openIssues',
  'nextSteps'
] as const

const DIGEST_OUTPUT_STRUCTURE_LIMITS = {
  structuralTokens: 64 * 1024,
  nestingDepth: 16
} as const

export function parseIssueDigestOutput(output: string): IssueDigestSections {
  try {
    assertJsonTextStructureWithinLimits(output, DIGEST_OUTPUT_STRUCTURE_LIMITS)
    const value = JSON.parse(output) as unknown
    if (!isPlainRecord(value)) {
      throw new Error('Digest output must be a JSON object.')
    }
    const keys = Object.keys(value)
    if (
      keys.length !== DIGEST_SECTION_KEYS.length ||
      DIGEST_SECTION_KEYS.some((key) => !Object.hasOwn(value, key))
    ) {
      throw new Error('Digest output must contain exactly the five required sections.')
    }

    const sections = Object.fromEntries(
      DIGEST_SECTION_KEYS.map((key) => {
        const section = value[key]
        if (section !== null && typeof section !== 'string') {
          throw new Error(`Digest section "${key}" must be a string or null.`)
        }
        return [key, section]
      })
    ) as IssueDigestSections
    const content = DIGEST_SECTION_KEYS.map((key) => sections[key] ?? '').join('')
    if (
      measureUtf8ByteLength(content, {
        stopAfterBytes: ISSUE_DIGEST_DRAFT_MAX_BYTES
      }).exceededLimit
    ) {
      throw new Error('Digest output exceeds the UTF-8 byte limit.')
    }
    return sections
  } catch (error) {
    if (error instanceof IssueRepositoryError) {
      throw error
    }
    throw new IssueRepositoryError(
      'digest_output_invalid',
      error instanceof Error ? error.message : 'Digest output is invalid.'
    )
  }
}

function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
