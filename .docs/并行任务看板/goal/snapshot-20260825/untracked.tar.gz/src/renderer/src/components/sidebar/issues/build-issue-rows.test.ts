import { randomUUID } from 'node:crypto'
import { describe, expect, it } from 'vitest'
import {
  DEFAULT_ISSUE_CLIENT_PREFERENCES,
  IssueClientPreferencesSchema
} from '../../../../../shared/issues/client-data'
import type {
  ConversationSummary,
  IssueAuthorityDescriptor,
  IssueSummary
} from '../../../../../shared/issues/types'
import { buildIssueRows, UNASSIGNED_ISSUE_ROW_KEY } from './build-issue-rows'
import type { IssueSidebarPartition } from './issue-row-types'

const authority: IssueAuthorityDescriptor = {
  authorityId: randomUUID(),
  hostPartitionKey: 'local',
  routeExecutionHostId: 'local'
}

function authorityForRoute(
  routeExecutionHostId: IssueAuthorityDescriptor['routeExecutionHostId']
): IssueAuthorityDescriptor {
  return {
    authorityId: randomUUID(),
    hostPartitionKey: 'local',
    routeExecutionHostId
  }
}

function issue(
  title: string,
  options: Partial<IssueSummary> = {}
): IssueSummary {
  return {
    id: randomUUID(),
    hostPartitionKey: 'local',
    executionHostId: 'local',
    source: { kind: 'local', number: 1 },
    localTitle: title,
    typeLabel: null,
    note: null,
    state: 'active',
    parentId: null,
    siblingOrder: 0,
    createdAt: 1,
    updatedAt: 1,
    archivedAt: null,
    ownUnresolvedCount: 0,
    descendantAttentionCount: 0,
    directConversationCount: 0,
    activeConversationCount: 0,
    ...options
  }
}

function conversation(
  title: string,
  workspaceId: string,
  options: Partial<ConversationSummary> = {}
): ConversationSummary {
  return {
    id: randomUUID(),
    hostPartitionKey: 'local',
    executionHostId: 'local',
    workspaceRef: { type: 'worktree', worktreeId: workspaceId },
    workspaceSnapshot: { name: `Workspace ${workspaceId}`, path: `/tmp/${workspaceId}` },
    agent: 'claude',
    title,
    titleSource: 'user',
    issueId: null,
    state: 'active',
    launchFailure: null,
    createdAt: 1,
    updatedAt: 1,
    unresolvedRoundCount: 0,
    latestRound: null,
    ...options
  }
}

function partition(
  issues: IssueSummary[],
  options: Partial<IssueSidebarPartition> = {}
): IssueSidebarPartition {
  return {
    routeExecutionHostId: 'local',
    status: 'ready',
    authority,
    issues,
    detailsByIssueId: {},
    unassignedConversations: [],
    ...options
  }
}

describe('buildIssueRows', () => {
  it('keeps only matching Issues plus ordered ancestor context in needs-me', () => {
    const root = issue('Root', { siblingOrder: 1 })
    const quietChild = issue('Quiet child', {
      parentId: root.id,
      siblingOrder: 0
    })
    const actionableChild = issue('Actionable child', {
      parentId: root.id,
      siblingOrder: 1,
      ownUnresolvedCount: 1
    })

    const rows = buildIssueRows({
      partitions: [partition([actionableChild, root, quietChild])],
      filter: 'needs-me',
      collapsedIssueIds: new Set([root.id]),
      selectedRouteExecutionHostId: null
    }).filter((row) => row.type === 'issue')

    expect(rows.map((row) => row.issue.localTitle)).toEqual([
      'Root',
      'Actionable child'
    ])
    expect(rows.map((row) => row.contextOnly)).toEqual([true, false])
    expect(rows.map((row) => row.depth)).toEqual([0, 1])
  })

  it('keeps context-only ancestor Conversations out of needs-me results', () => {
    const root = issue('Root')
    const actionableChild = issue('Actionable child', {
      parentId: root.id,
      ownUnresolvedCount: 1
    })
    const rootConversation = conversation('Unrelated root work', 'workspace-a', {
      issueId: root.id
    })

    const rows = buildIssueRows({
      partitions: [
        partition([root, actionableChild], {
          detailsByIssueId: { [root.id]: [rootConversation] }
        })
      ],
      filter: 'needs-me',
      collapsedIssueIds: new Set(),
      selectedRouteExecutionHostId: null
    })

    expect(rows.filter((row) => row.type === 'conversation')).toEqual([])
    expect(
      rows.filter((row) => row.type === 'issue').map((row) => row.issue.id)
    ).toEqual([root.id, actionableChild.id])
  })

  it('groups only direct Conversations by Workspace under an expanded Issue', () => {
    const parent = issue('Parent', { directConversationCount: 2 })
    const first = conversation('First', 'workspace-a', {
      issueId: parent.id,
      updatedAt: 2
    })
    const second = conversation('Second', 'workspace-a', {
      issueId: parent.id,
      updatedAt: 3
    })

    const rows = buildIssueRows({
      partitions: [
        partition([parent], {
          detailsByIssueId: { [parent.id]: [first, second] }
        })
      ],
      filter: 'all',
      collapsedIssueIds: new Set(),
      selectedRouteExecutionHostId: null
    })

    expect(rows.map((row) => row.type)).toEqual([
      'host-state',
      'issue',
      'workspace-header',
      'conversation',
      'conversation'
    ])
    expect(
      rows
        .filter((row) => row.type === 'conversation')
        .map((row) => row.conversation.title)
    ).toEqual(['Second', 'First'])
  })

  it('keeps a leaf Issue expandable before its Conversation detail is loaded', () => {
    const parent = issue('Parent', { directConversationCount: 1 })

    const issueRow = buildIssueRows({
      partitions: [partition([parent])],
      filter: 'all',
      collapsedIssueIds: new Set(),
      selectedRouteExecutionHostId: null
    }).find((row) => row.type === 'issue')

    expect(issueRow).toMatchObject({
      expandable: true,
      expanded: true
    })
  })

  it('keeps unassigned Conversations outside Issue counts and expands them independently', () => {
    const orphan = conversation('Orphan', 'folder-a', {
      workspaceRef: { type: 'folder', folderWorkspaceId: 'folder-a' },
      unresolvedRoundCount: 2
    })
    const collapsedKey = `${UNASSIGNED_ISSUE_ROW_KEY}:local`

    const collapsed = buildIssueRows({
      partitions: [
        partition([], {
          unassignedSummary: { conversationCount: 1, unresolvedCount: 2 },
          unassignedConversations: [orphan]
        })
      ],
      filter: 'all',
      collapsedIssueIds: new Set([collapsedKey]),
      selectedRouteExecutionHostId: null
    })
    expect(collapsed.filter((row) => row.type === 'conversation')).toHaveLength(0)
    expect(
      collapsed.find((row) => row.type === 'unassigned-summary')
    ).toMatchObject({ conversationCount: 1, unresolvedCount: 2 })

    const expanded = buildIssueRows({
      partitions: [
        partition([], {
          unassignedSummary: { conversationCount: 1, unresolvedCount: 2 },
          unassignedConversations: [orphan]
        })
      ],
      filter: 'all',
      collapsedIssueIds: new Set(),
      selectedRouteExecutionHostId: null
    })
    expect(expanded.filter((row) => row.type === 'conversation')).toHaveLength(1)
  })

  it('persists the unassigned section collapse identity', () => {
    const orphan = conversation('Orphan', 'folder-a')
    const rows = buildIssueRows({
      partitions: [
        partition([], {
          unassignedConversations: [orphan]
        })
      ],
      filter: 'all',
      collapsedIssueIds: new Set(),
      selectedRouteExecutionHostId: null
    })
    const unassignedRow = rows.find(
      (row) => row.type === 'unassigned-summary'
    )

    expect(unassignedRow).toBeDefined()
    expect(() =>
      IssueClientPreferencesSchema.parse({
        ...DEFAULT_ISSUE_CLIENT_PREFERENCES,
        collapsedIssueIds: [unassignedRow!.id]
      })
    ).not.toThrow()
  })

  it('applies host, type, and text filters without flattening ancestor context', () => {
    const localRoot = issue('Local umbrella', { typeLabel: 'Epic' })
    const localChild = issue('Renderer search target', {
      parentId: localRoot.id,
      typeLabel: 'Frontend'
    })
    const remoteIssue = issue('Renderer search target', {
      executionHostId: 'runtime:remote',
      hostPartitionKey: 'local',
      typeLabel: 'Frontend'
    })

    const rows = buildIssueRows({
      partitions: [
        partition([localRoot, localChild]),
        {
          ...partition([remoteIssue]),
          routeExecutionHostId: 'runtime:remote',
          authority: authorityForRoute('runtime:remote')
        }
      ],
      filter: 'all',
      collapsedIssueIds: new Set(),
      selectedRouteExecutionHostId: 'local',
      searchQuery: 'renderer SEARCH',
      typeFilter: 'Frontend'
    })

    expect(rows.filter((row) => row.type === 'host-state')).toHaveLength(1)
    expect(
      rows.filter((row) => row.type === 'issue').map((row) => ({
        title: row.issue.localTitle,
        contextOnly: row.contextOnly
      }))
    ).toEqual([
      { title: 'Local umbrella', contextOnly: true },
      { title: 'Renderer search target', contextOnly: false }
    ])
  })

  it('never renders an empty state while a host is loading or unsupported', () => {
    const rows = buildIssueRows({
      partitions: [
        partition([], { status: 'loading', authority: null }),
        {
          ...partition([], { status: 'unsupported', authority: null }),
          routeExecutionHostId: 'runtime:legacy'
        }
      ],
      filter: 'all',
      collapsedIssueIds: new Set(),
      selectedRouteExecutionHostId: null
    })

    expect(rows.filter((row) => row.type === 'empty')).toHaveLength(0)
    expect(rows.filter((row) => row.type === 'host-state')).toHaveLength(2)
  })
})
