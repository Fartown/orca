import { randomUUID } from 'node:crypto'
import {
  copyFileSync,
  existsSync,
  readFileSync,
  writeFileSync
} from 'node:fs'
import { afterEach, describe, expect, it } from 'vitest'
import type {
  IssueAuthorityDescriptor,
  RoundRecordPreview
} from '../../shared/issues/types'
import {
  createIssueTestUserDataPath,
  issueFileDatabaseTestsAvailable,
  removeIssueTestDirectories
} from './issue-database.test-environment'
import {
  IssueCacheRouteIndex,
  issueCacheAuthorityFromRoute
} from './issue-cache-route-index'
import {
  getIssueReadCacheFileHash,
  getIssueReadCachePath,
  IssueReadCache,
  type IssueReadCacheSnapshot
} from './issue-read-cache'

const caches: IssueReadCache[] = []

function authority(
  routeExecutionHostId: IssueAuthorityDescriptor['routeExecutionHostId'],
  authorityId = randomUUID()
): IssueAuthorityDescriptor {
  return {
    authorityId,
    hostPartitionKey: 'local',
    routeExecutionHostId
  }
}

function roundPreview(): RoundRecordPreview {
  const text = {
    completeness: 'complete' as const,
    storage: 'full' as const,
    bytes: 12,
    preview: 'bounded text',
    previewBytes: 12
  }
  return {
    id: randomUUID(),
    conversationId: randomUUID(),
    kind: 'completion',
    stateSource: 'hook',
    occurredAt: 10,
    executionChainId: null,
    supersedesRoundId: null,
    userInput: text,
    agentOutput: text,
    pendingQuestion: {
      completeness: 'not-captured',
      storage: 'none',
      bytes: 0,
      preview: null,
      previewBytes: 0
    },
    readAt: null,
    resolvedAt: null,
    resolution: null,
    effectiveResolvedAt: null,
    effectiveResolution: null,
    finalizedAt: 10,
    bodyEvictedAt: null,
    bodyDeletedAt: null,
    bodyRevision: 0,
    createdAt: 10
  }
}

function snapshot(
  descriptor: IssueAuthorityDescriptor,
  cachedAt: number
): IssueReadCacheSnapshot {
  return {
    authority: descriptor,
    cachedAt,
    factsRevision: 3,
    treeRevision: 2,
    searchRevision: 1,
    issues: [],
    details: [],
    unassignedConversations: [],
    rounds: [roundPreview()]
  }
}

function openCache(
  profileId: string,
  userDataPath: string,
  descriptor: IssueAuthorityDescriptor
): IssueReadCache {
  const cache = IssueReadCache.open({
    profileId,
    userDataPath,
    authority: descriptor
  })
  caches.push(cache)
  return cache
}

afterEach(() => {
  for (const cache of caches.splice(0)) {
    cache.close()
  }
  removeIssueTestDirectories()
})

describe.skipIf(!issueFileDatabaseTestsAvailable)('Issue read cache', () => {
  it('isolates profiles and persists only bounded Round previews', () => {
    const userDataPath = createIssueTestUserDataPath('orca-issue-cache-profile')
    const descriptor = authority('runtime:paired')
    const first = openCache('profile-a', userDataPath, descriptor)
    const second = openCache('profile-b', userDataPath, descriptor)

    first.replace(snapshot(descriptor, 100))

    expect(first.path).not.toBe(second.path)
    expect(first.read()).toMatchObject({
      cachedAt: 100,
      rounds: [
        {
          agentOutput: {
            preview: 'bounded text',
            completeness: 'complete',
            storage: 'full'
          }
        }
      ]
    })
    expect(first.read()?.rounds[0].agentOutput).not.toHaveProperty('text')
    expect(second.read()).toBeNull()
  })

  it('rebuilds a mismatched cache header instead of exposing another authority', () => {
    const userDataPath = createIssueTestUserDataPath('orca-issue-cache-header')
    const firstAuthority = authority('runtime:first')
    const secondAuthority = authority('runtime:second')
    const first = openCache('profile-a', userDataPath, firstAuthority)
    first.replace(snapshot(firstAuthority, 100))
    first.close()
    caches.splice(caches.indexOf(first), 1)

    const secondPath = getIssueReadCachePath(
      'profile-a',
      secondAuthority,
      userDataPath
    )
    copyFileSync(first.path, secondPath)
    const second = openCache('profile-a', userDataPath, secondAuthority)

    expect(second.getHeader()).toMatchObject({
      profileId: 'profile-a',
      authorityId: secondAuthority.authorityId,
      routeExecutionHostId: 'runtime:second'
    })
    expect(second.read()).toBeNull()
  })

  it('re-points a route to a new authority without merging the old cache', () => {
    const userDataPath = createIssueTestUserDataPath('orca-issue-cache-repair')
    const firstAuthority = authority('runtime:environment')
    const secondAuthority = authority('runtime:environment')
    const first = openCache('profile-a', userDataPath, firstAuthority)
    const second = openCache('profile-a', userDataPath, secondAuthority)
    first.replace(snapshot(firstAuthority, 100))
    second.replace(snapshot(secondAuthority, 200))
    const index = new IssueCacheRouteIndex('profile-a', userDataPath)

    index.record('runtime:environment', firstAuthority, 100)
    index.record('runtime:environment', secondAuthority, 200)

    const resolved = index.resolve('runtime:environment')
    expect(resolved).toMatchObject({
      authorityId: secondAuthority.authorityId,
      cacheFileHash: getIssueReadCacheFileHash(
        secondAuthority.authorityId,
        'local'
      ),
      lastSeenAt: 200
    })
    expect(issueCacheAuthorityFromRoute(resolved!)).toEqual(secondAuthority)
    expect(first.read()?.cachedAt).toBe(100)
    expect(second.read()?.cachedAt).toBe(200)
    expect(existsSync(first.path)).toBe(true)
  })

  it('reconstructs a corrupt route index from validated cache headers', () => {
    const userDataPath = createIssueTestUserDataPath('orca-issue-cache-index')
    const descriptor = authority('ssh:managed')
    const cache = openCache('profile-a', userDataPath, descriptor)
    cache.replace(snapshot(descriptor, 300))
    const index = new IssueCacheRouteIndex('profile-a', userDataPath)
    writeFileSync(index.path, '{corrupt', 'utf-8')

    expect(index.resolve('ssh:managed')).toMatchObject({
      routeKey: 'ssh:managed',
      authorityId: descriptor.authorityId,
      hostPartitionKey: 'local',
      lastSeenAt: 300
    })
    expect(JSON.parse(readFileSync(index.path, 'utf-8'))).toMatchObject({
      version: 1,
      routes: [{ routeKey: 'ssh:managed' }]
    })
  })
})
