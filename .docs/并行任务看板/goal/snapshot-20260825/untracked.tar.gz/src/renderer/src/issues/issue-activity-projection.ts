import type { ExecutionHostId } from '../../../shared/execution-host'
import type {
  ConversationNavigationTarget,
  IssueActivityEntry,
  IssueAuthorityDescriptor,
  IssueDisplayProjection,
  IssueEventKind
} from '../../../shared/issues/types'
import type { AgentStatusState, AgentType } from '../../../shared/agent-status-types'
import { getPrimaryRoundPreviewField } from './round-record-preview-presentation'

export type IssueActivityThreadProjection = {
  key: string
  routeExecutionHostId: ExecutionHostId
  authority: IssueAuthorityDescriptor
  conversation: ConversationNavigationTarget | null
  issue: IssueDisplayProjection | null
  paneKey: string | null
  agentType: AgentType
  state: Extract<AgentStatusState, 'done' | 'waiting'>
  title: string
  preview: string
  workspaceName: string
  workspacePath: string
  latestOccurredAt: number
  unread: boolean
  roundRecordIds: string[]
  unreadRoundRecordIds: string[]
  entries: IssueActivityEntry[]
}

export type IssueActivityProjectionPartition = {
  routeExecutionHostId: ExecutionHostId
  authority: IssueAuthorityDescriptor
  entries: readonly IssueActivityEntry[]
}

export function buildIssueActivityThreadProjections(
  partitions: readonly IssueActivityProjectionPartition[]
): IssueActivityThreadProjection[] {
  const threads = new Map<string, IssueActivityThreadProjection>()
  for (const partition of partitions) {
    for (const entry of partition.entries) {
      const key = activityThreadKey(partition.routeExecutionHostId, entry)
      const existing = threads.get(key)
      if (!existing) {
        threads.set(key, createProjection(partition, entry, key))
        continue
      }
      appendEntry(existing, entry)
    }
  }
  return [...threads.values()]
    .map((thread) => ({
      ...thread,
      entries: [...thread.entries].sort(compareActivityEntries),
      roundRecordIds: [...new Set(thread.roundRecordIds)],
      unreadRoundRecordIds: [...new Set(thread.unreadRoundRecordIds)]
    }))
    .sort(
      (left, right) =>
        right.latestOccurredAt - left.latestOccurredAt || left.key.localeCompare(right.key)
    )
}

export function issueActivityProjectedPaneKeys(
  threads: readonly IssueActivityThreadProjection[]
): Set<string> {
  return new Set(
    threads.flatMap((thread) => (thread.paneKey ? [thread.paneKey] : []))
  )
}

function activityThreadKey(
  routeExecutionHostId: ExecutionHostId,
  entry: IssueActivityEntry
): string {
  const conversation =
    entry.type === 'round' ? entry.conversation : entry.conversation
  return conversation
    ? `${routeExecutionHostId}\0conversation:${conversation.id}`
    : `${routeExecutionHostId}\0event:${entry.id}`
}

function createProjection(
  partition: IssueActivityProjectionPartition,
  entry: IssueActivityEntry,
  key: string
): IssueActivityThreadProjection {
  const conversation =
    entry.type === 'round' ? entry.conversation : entry.conversation
  const issue = activityEntryIssue(entry)
  const projection: IssueActivityThreadProjection = {
    key,
    routeExecutionHostId: partition.routeExecutionHostId,
    authority: partition.authority,
    conversation,
    issue,
    paneKey: conversation?.navigation?.paneKey ?? null,
    agentType: conversation?.agent ?? 'unknown',
    state: activityEntryState(entry),
    title: activityEntryTitle(entry),
    preview: activityEntryPreview(entry),
    workspaceName: conversation?.workspaceSnapshot.name ?? 'Issues',
    workspacePath: conversation?.workspaceSnapshot.path ?? '',
    latestOccurredAt: entry.occurredAt,
    unread: false,
    roundRecordIds: [],
    unreadRoundRecordIds: [],
    entries: []
  }
  appendEntry(projection, entry)
  return projection
}

function appendEntry(
  projection: IssueActivityThreadProjection,
  entry: IssueActivityEntry
): void {
  projection.entries.push(entry)
  if (entry.type === 'round') {
    projection.roundRecordIds.push(entry.round.id)
    if (entry.round.readAt === null) {
      projection.unread = true
      projection.unreadRoundRecordIds.push(entry.round.id)
    }
  }
  if (entry.occurredAt < projection.latestOccurredAt) {
    return
  }
  const conversation =
    entry.type === 'round' ? entry.conversation : entry.conversation
  projection.latestOccurredAt = entry.occurredAt
  projection.conversation = conversation ?? projection.conversation
  projection.issue = activityEntryIssue(entry) ?? projection.issue
  projection.paneKey =
    conversation?.navigation?.paneKey ?? projection.paneKey
  projection.agentType = conversation?.agent ?? projection.agentType
  projection.state = activityEntryState(entry)
  projection.title = activityEntryTitle(entry)
  projection.preview = activityEntryPreview(entry)
  projection.workspaceName =
    conversation?.workspaceSnapshot.name ?? projection.workspaceName
  projection.workspacePath =
    conversation?.workspaceSnapshot.path ?? projection.workspacePath
}

function activityEntryIssue(
  entry: IssueActivityEntry
): IssueDisplayProjection | null {
  if (entry.type === 'round') {
    return entry.issue
  }
  const reference = entry.event.issueRefs[0]
  return reference
    ? {
        id: reference.issueId,
        title: reference.titleSnapshot,
        typeLabel: null,
        state: entry.event.kind === 'archived' ? 'archived' : 'active'
      }
    : null
}

function activityEntryState(
  entry: IssueActivityEntry
): Extract<AgentStatusState, 'done' | 'waiting'> {
  return entry.type === 'round' && entry.round.kind === 'waiting'
    ? 'waiting'
    : 'done'
}

function activityEntryTitle(entry: IssueActivityEntry): string {
  if (entry.type === 'round') {
    return (
      entry.issue?.title ||
      entry.conversation.title ||
      entry.conversation.workspaceSnapshot.name
    )
  }
  const reference = entry.event.issueRefs[0]
  return reference?.titleSnapshot || issueEventLabel(entry.event.kind)
}

function activityEntryPreview(entry: IssueActivityEntry): string {
  if (entry.type === 'round') {
    const field = getPrimaryRoundPreviewField(entry.round)
    return field.value.preview?.trim() || `${field.label} was not captured.`
  }
  const reference = entry.event.issueRefs[0]
  const title = reference?.titleSnapshot
  const label = issueEventLabel(entry.event.kind)
  return title ? `${label}: ${title}` : label
}

function issueEventLabel(kind: IssueEventKind): string {
  return kind
    .split('-')
    .map((part) => `${part.slice(0, 1).toUpperCase()}${part.slice(1)}`)
    .join(' ')
}

function compareActivityEntries(left: IssueActivityEntry, right: IssueActivityEntry): number {
  return (
    right.occurredAt - left.occurredAt ||
    `${right.type}:${right.id}`.localeCompare(`${left.type}:${left.id}`)
  )
}
