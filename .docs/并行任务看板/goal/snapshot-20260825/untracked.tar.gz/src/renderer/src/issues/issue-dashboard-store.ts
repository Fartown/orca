import {
  parseExecutionHostId,
  type ExecutionHostId
} from '../../../shared/execution-host'
import type { DashboardCard } from '../../../shared/dashboard-snapshot'
import type { IssueDashboardProjection } from '../../../shared/issues/types'
import { createStore, type StoreApi } from 'zustand/vanilla'
import {
  loadIssueDashboardProjection,
  type IssueDashboardLoadResult
} from './issue-dashboard-client'
import {
  ISSUE_FACTS_CHANGED_EVENT,
  type IssueFactsChangedEventDetail
} from './issue-facts-changed-event'

export type IssueDashboardPartitionState = {
  routeExecutionHostId: ExecutionHostId
  paneKeySignature: string
  requestedPaneKeys: readonly string[]
  status: 'idle' | 'loading' | 'ready' | 'unsupported' | 'error'
  projection: IssueDashboardProjection | null
  error: string | null
  retryAt: number | null
}

export type IssueDashboardState = {
  partitionsByRoute: Partial<
    Record<ExecutionHostId, IssueDashboardPartitionState>
  >
  syncCards: (
    cards: readonly DashboardCard[],
    options?: { forceRefresh?: boolean }
  ) => Promise<void>
  refreshPartition: (routeExecutionHostId: ExecutionHostId) => Promise<void>
  patchRoundRead: (
    routeExecutionHostId: ExecutionHostId,
    roundRecordId: string,
    readAt: number
  ) => void
}

export type IssueDashboardStoreDependencies = {
  load: (
    routeExecutionHostId: ExecutionHostId,
    paneKeys: readonly string[]
  ) => Promise<IssueDashboardLoadResult>
  now: () => number
}

type RefreshEntry = {
  promise: Promise<void>
  rerun: boolean
}

export function createIssueDashboardStore(
  dependencies: IssueDashboardStoreDependencies
): StoreApi<IssueDashboardState> {
  const refreshes = new Map<ExecutionHostId, RefreshEntry>()
  return createStore<IssueDashboardState>()((set, get) => {
    const runRefresh = async (
      routeExecutionHostId: ExecutionHostId,
      entry: RefreshEntry
    ): Promise<void> => {
      do {
        entry.rerun = false
        const request = get().partitionsByRoute[routeExecutionHostId]
        if (!request) {
          return
        }
        setPartition(set, routeExecutionHostId, {
          ...request,
          status: 'loading',
          error: null,
          retryAt: null
        })
        const result = await dependencies.load(
          routeExecutionHostId,
          request.requestedPaneKeys
        )
        const current = get().partitionsByRoute[routeExecutionHostId]
        if (!current || current.paneKeySignature !== request.paneKeySignature) {
          continue
        }
        setPartition(
          set,
          routeExecutionHostId,
          partitionFromLoad(current, result, dependencies.now())
        )
      } while (entry.rerun)
    }

    const refreshPartition = (
      routeExecutionHostId: ExecutionHostId
    ): Promise<void> => {
      const route = parseExecutionHostId(routeExecutionHostId)
      if (!route || !get().partitionsByRoute[route.id]) {
        return Promise.resolve()
      }
      const active = refreshes.get(route.id)
      if (active) {
        active.rerun = true
        return active.promise
      }
      const entry: RefreshEntry = {
        promise: Promise.resolve(),
        rerun: false
      }
      entry.promise = runRefresh(route.id, entry).finally(() => {
        if (refreshes.get(route.id) === entry) {
          refreshes.delete(route.id)
        }
      })
      refreshes.set(route.id, entry)
      return entry.promise
    }

    return {
      partitionsByRoute: {},
      syncCards: async (cards, options) => {
        const requests = dashboardPaneRequests(cards)
        const pending: Promise<void>[] = []
        const current = get().partitionsByRoute
        if (!sameDashboardRequests(current, requests)) {
          const next: IssueDashboardState['partitionsByRoute'] = {}
          for (const [routeExecutionHostId, paneKeys] of requests) {
            const paneKeySignature = paneKeys.join('\0')
            const previous = current[routeExecutionHostId]
            next[routeExecutionHostId] =
              previous?.paneKeySignature === paneKeySignature
                ? previous
                : {
                    routeExecutionHostId,
                    paneKeySignature,
                    requestedPaneKeys: paneKeys,
                    status: 'idle',
                    projection: null,
                    error: null,
                    retryAt: null
                  }
          }
          set({ partitionsByRoute: next })
        }
        for (const [routeExecutionHostId, paneKeys] of requests) {
          const partition = get().partitionsByRoute[routeExecutionHostId]
          if (
            partition &&
            partition.paneKeySignature === paneKeys.join('\0') &&
            (partition.status === 'idle' || options?.forceRefresh === true)
          ) {
            pending.push(refreshPartition(routeExecutionHostId))
          }
        }
        await Promise.all(pending)
      },
      refreshPartition,
      patchRoundRead: (routeExecutionHostId, roundRecordId, readAt) => {
        const partition = get().partitionsByRoute[routeExecutionHostId]
        if (!partition?.projection) {
          return
        }
        let changed = false
        const panes = partition.projection.panes.map((pane) => {
          if (pane.latestRound?.id !== roundRecordId) {
            return pane
          }
          changed = true
          return {
            ...pane,
            latestRound: { ...pane.latestRound, readAt }
          }
        })
        if (!changed) {
          return
        }
        setPartition(set, routeExecutionHostId, {
          ...partition,
          projection: { ...partition.projection, panes }
        })
      }
    }
  })
}

function sameDashboardRequests(
  current: IssueDashboardState['partitionsByRoute'],
  requests: ReadonlyMap<ExecutionHostId, readonly string[]>
): boolean {
  const routes = Object.keys(current) as ExecutionHostId[]
  if (routes.length !== requests.size) {
    return false
  }
  return routes.every(
    (routeExecutionHostId) =>
      current[routeExecutionHostId]?.paneKeySignature ===
      requests.get(routeExecutionHostId)?.join('\0')
  )
}

function dashboardPaneRequests(
  cards: readonly DashboardCard[]
): Map<ExecutionHostId, string[]> {
  const byRoute = new Map<ExecutionHostId, Set<string>>()
  for (const card of cards) {
    const route = parseExecutionHostId(card.executionHostId)
    if (!route) {
      continue
    }
    const paneKeys = byRoute.get(route.id) ?? new Set<string>()
    paneKeys.add(card.paneKey)
    byRoute.set(route.id, paneKeys)
  }
  return new Map(
    [...byRoute].map(([routeExecutionHostId, paneKeys]) => [
      routeExecutionHostId,
      [...paneKeys].sort()
    ])
  )
}

function partitionFromLoad(
  previous: IssueDashboardPartitionState,
  result: IssueDashboardLoadResult,
  now: number
): IssueDashboardPartitionState {
  if (result.status === 'ready') {
    return {
      ...previous,
      status: 'ready',
      projection: result.projection,
      error: null,
      retryAt: null
    }
  }
  if (result.status === 'unsupported') {
    return {
      ...previous,
      status: 'unsupported',
      projection: null,
      error: null,
      retryAt: null
    }
  }
  return {
    ...previous,
    status: 'error',
    projection: null,
    error: result.error,
    retryAt: now
  }
}

function setPartition(
  set: StoreApi<IssueDashboardState>['setState'],
  routeExecutionHostId: ExecutionHostId,
  partition: IssueDashboardPartitionState
): void {
  set((state) => ({
    partitionsByRoute: {
      ...state.partitionsByRoute,
      [routeExecutionHostId]: partition
    }
  }))
}

export const issueDashboardStore = createIssueDashboardStore({
  load: loadIssueDashboardProjection,
  now: () => Date.now()
})

export function connectIssueDashboardEvents(
  store: StoreApi<IssueDashboardState>,
  target: Pick<EventTarget, 'addEventListener' | 'removeEventListener'>
): () => void {
  const listener: EventListener = (event) => {
    const detail = (event as CustomEvent<IssueFactsChangedEventDetail>).detail
    const route = parseExecutionHostId(detail?.routeExecutionHostId)
    if (!route || !store.getState().partitionsByRoute[route.id]) {
      return
    }
    void store.getState().refreshPartition(route.id)
  }
  target.addEventListener(ISSUE_FACTS_CHANGED_EVENT, listener)
  return () => target.removeEventListener(ISSUE_FACTS_CHANGED_EVENT, listener)
}
