import { randomUUID } from 'node:crypto'
import {
  chmodSync,
  existsSync,
  mkdirSync,
  readFileSync
} from 'node:fs'
import { join } from 'node:path'
import {
  DEFAULT_ISSUE_CLIENT_PREFERENCES,
  IssueClientCacheReadArgsSchema,
  IssueClientCacheReplaceArgsSchema,
  IssueClientPreferencesSchema,
  type IssueClientCacheReadResult,
  type IssueClientPreferences,
  type IssueClientSnapshot
} from '../../shared/issues/client-data'
import { writeFileDurableSync } from '../durable-file-write'
import { getOrcaProfileDirectory } from '../orca-profiles/profile-storage-paths'
import {
  IssueCacheRouteIndex,
  issueCacheAuthorityFromRoute
} from './issue-cache-route-index'
import { IssueReadCache } from './issue-read-cache'

const ISSUE_CLIENT_PREFERENCES_FILE = 'issues-ui.json'

export class IssueClientDataService {
  private readonly routeIndex: IssueCacheRouteIndex
  private readonly preferencesPath: string

  constructor(
    private readonly profileId: string,
    private readonly userDataPath: string
  ) {
    this.routeIndex = new IssueCacheRouteIndex(profileId, userDataPath)
    this.preferencesPath = join(
      getOrcaProfileDirectory(profileId, userDataPath),
      ISSUE_CLIENT_PREFERENCES_FILE
    )
  }

  readCache(args: unknown): IssueClientCacheReadResult {
    const { routeExecutionHostId } = IssueClientCacheReadArgsSchema.parse(args)
    const cachedRoute = this.routeIndex.resolve(routeExecutionHostId)
    if (!cachedRoute) {
      return { status: 'miss' }
    }
    const cache = IssueReadCache.open({
      profileId: this.profileId,
      userDataPath: this.userDataPath,
      authority: issueCacheAuthorityFromRoute(cachedRoute)
    })
    try {
      const snapshot = cache.read()
      if (!snapshot) {
        return { status: 'miss' }
      }
      return {
        status: 'hit',
        snapshot: {
          ...snapshot,
          authority: {
            ...snapshot.authority,
            routeExecutionHostId
          }
        }
      }
    } finally {
      cache.close()
    }
  }

  replaceCache(args: unknown): IssueClientSnapshot {
    const parsed = IssueClientCacheReplaceArgsSchema.parse(args)
    const snapshot = parsed.snapshot as IssueClientSnapshot
    if (
      snapshot.authority.routeExecutionHostId !==
      parsed.routeExecutionHostId
    ) {
      throw new Error('Issue cache route does not match its authority descriptor.')
    }
    const cache = IssueReadCache.open({
      profileId: this.profileId,
      userDataPath: this.userDataPath,
      authority: snapshot.authority
    })
    try {
      cache.replace(snapshot)
    } finally {
      cache.close()
    }
    this.routeIndex.record(
      parsed.routeExecutionHostId,
      snapshot.authority,
      snapshot.cachedAt
    )
    return snapshot
  }

  readPreferences(): IssueClientPreferences {
    if (!existsSync(this.preferencesPath)) {
      return { ...DEFAULT_ISSUE_CLIENT_PREFERENCES }
    }
    try {
      return IssueClientPreferencesSchema.parse(
        JSON.parse(readFileSync(this.preferencesPath, 'utf-8'))
      )
    } catch {
      return { ...DEFAULT_ISSUE_CLIENT_PREFERENCES }
    }
  }

  writePreferences(value: unknown): IssueClientPreferences {
    const preferences = IssueClientPreferencesSchema.parse(value)
    const directory = getOrcaProfileDirectory(
      this.profileId,
      this.userDataPath
    )
    mkdirSync(directory, { recursive: true, mode: 0o700 })
    const temporary = `${this.preferencesPath}.${process.pid}.${randomUUID()}.tmp`
    writeFileDurableSync(
      temporary,
      this.preferencesPath,
      JSON.stringify(preferences, null, 2)
    )
    if (process.platform !== 'win32') {
      chmodSync(directory, 0o700)
      chmodSync(this.preferencesPath, 0o600)
    }
    return preferences
  }
}
