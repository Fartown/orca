// @vitest-environment happy-dom

import React from 'react'
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import '@testing-library/jest-dom/vitest'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { IssueSidebarRow } from './issue-row-types'
import { IssueVirtualRow } from './issue-virtual-row'

afterEach(cleanup)

const issueRow: Extract<IssueSidebarRow, { type: 'issue' }> = {
  id: 'issue:local:issue-1',
  type: 'issue',
  routeExecutionHostId: 'local',
  authority: {
    authorityId: 'authority',
    hostPartitionKey: 'local',
    routeExecutionHostId: 'local'
  },
  issue: {
    id: 'issue-1',
    hostPartitionKey: 'local',
    executionHostId: 'local',
    source: { kind: 'local', number: 7 },
    localTitle: 'Ship Issues',
    typeLabel: null,
    note: null,
    state: 'active',
    parentId: null,
    siblingOrder: 0,
    createdAt: 1,
    updatedAt: 1,
    archivedAt: null,
    ownUnresolvedCount: 2,
    descendantAttentionCount: 3,
    directConversationCount: 1,
    activeConversationCount: 1
  },
  depth: 0,
  contextOnly: false,
  expandable: true,
  expanded: false
}

function renderRow(
  row: IssueSidebarRow,
  overrides: Partial<React.ComponentProps<typeof IssueVirtualRow>> = {}
) {
  const props: React.ComponentProps<typeof IssueVirtualRow> = {
    row,
    hostLabelById: new Map([['local', 'This Mac']]),
    selectedIssueId: null,
    unassignedLoaded: false,
    onToggleIssue: vi.fn(),
    onSelectIssue: vi.fn(),
    onToggleUnassigned: vi.fn(),
    onSelectConversation: vi.fn(),
    onSelectSearchResult: vi.fn(),
    ...overrides
  }
  render(<IssueVirtualRow {...props} />)
  return props
}

describe('IssueVirtualRow', () => {
  it('keeps expand and selection actions independent', () => {
    const props = renderRow(issueRow)

    fireEvent.click(screen.getByRole('button', { name: 'Expand Ship Issues' }))
    expect(props.onToggleIssue).toHaveBeenCalledWith(issueRow)
    expect(props.onSelectIssue).not.toHaveBeenCalled()

    fireEvent.click(screen.getByRole('button', { name: 'Open Ship Issues' }))
    expect(props.onSelectIssue).toHaveBeenCalledWith(issueRow)
  })

  it('shows own attention instead of combining it with descendant attention', () => {
    renderRow(issueRow)

    expect(screen.getByText('2')).toBeInTheDocument()
    expect(screen.queryByText('3')).not.toBeInTheDocument()
  })

  it('keeps the unassigned section visually collapsed until its Conversations load', () => {
    const row: Extract<IssueSidebarRow, { type: 'unassigned-summary' }> = {
      id: 'unassigned:local',
      type: 'unassigned-summary',
      routeExecutionHostId: 'local',
      conversationCount: 2,
      unresolvedCount: 1,
      expanded: true
    }
    const props = renderRow(row)

    expect(screen.getByRole('button', { name: /Unassigned/ })).toHaveAttribute(
      'aria-expanded',
      'false'
    )
    fireEvent.click(screen.getByRole('button', { name: /Unassigned/ }))
    expect(props.onToggleUnassigned).toHaveBeenCalledWith(row)
  })
})
