import {
  LOCAL_EXECUTION_HOST_ID,
  type ExecutionHostId
} from '../../../shared/execution-host'
import type {
  AuthorityHostPartitionKey,
  IssueFactsChangedEvent
} from '../../../shared/issues/types'
import {
  dispatchIssueFactsChanged,
  type IssueFactsChangedEventDetail
} from './issue-facts-changed-event'

type LocalIssueFactsApi = {
  onFactsChanged?: (
    callback: (event: IssueFactsChangedEvent) => void
  ) => () => void
}

function routeForHostPartition(
  hostPartitionKey: AuthorityHostPartitionKey
): ExecutionHostId {
  return hostPartitionKey === 'local'
    ? LOCAL_EXECUTION_HOST_ID
    : hostPartitionKey
}

export function subscribeLocalIssueFacts(
  api: LocalIssueFactsApi | null | undefined,
  dispatch: (detail: IssueFactsChangedEventDetail) => void =
    dispatchIssueFactsChanged
): () => void {
  if (!api?.onFactsChanged) {
    return () => {}
  }
  return api.onFactsChanged((event) => {
    dispatch({
      ...event,
      routeExecutionHostId: routeForHostPartition(event.hostPartitionKey)
    })
  })
}
