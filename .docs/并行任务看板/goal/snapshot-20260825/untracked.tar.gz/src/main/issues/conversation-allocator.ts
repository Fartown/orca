import type { AgentProviderSessionMetadata } from '../../shared/agent-session-resume'
import type {
  ConversationLaunchClaim,
  ConversationProviderIdentity,
  ConversationRecord
} from '../../shared/issues/types'
import type { TuiAgent } from '../../shared/tui-agent'
import type { ConversationRecordRepository } from './conversation-record-repository'
import type {
  ConversationIdentityRepository
} from './conversation-identity-repository'
import type {
  ConversationLaunchClaimRepository,
  ResolveConversationLaunchClaimInput
} from './conversation-launch-claim-repository'
import type { IssueDatabase } from './issue-database'
import { hostPartitionForExecutionHost } from './issue-host-partition'
import type { CreateConversationInput } from './issue-repository-types'
import { IssueRepositoryError } from './issue-repository-error'

const DEFAULT_LAUNCH_CLAIM_TTL_MS = 15 * 60 * 1000

export type AllocateConversationLaunchInput = CreateConversationInput & {
  launchToken: string
  paneKey?: string | null
  processIncarnation?: string | null
  connectionId?: string | null
  now?: number
  claimTtlMs?: number
}

export type AllocateConversationLaunchResult = {
  conversation: ConversationRecord
  claim: ConversationLaunchClaim
  disposition: 'created' | 'replayed'
}

export type AttachConversationLaunchIdentityInput = Omit<
  ResolveConversationLaunchClaimInput,
  'hostPartitionKey'
> & {
  executionHostId: ConversationRecord['executionHostId']
  agent: TuiAgent
  providerSession: AgentProviderSessionMetadata
  resumeLocator?: string | null
  observedAt?: number
}

export type ResolveConversationResumeInput = AllocateConversationLaunchInput & {
  providerSession: AgentProviderSessionMetadata
  resumeLocator?: string | null
}

export type ResolveObservedConversationIdentityInput = CreateConversationInput & {
  providerSession: AgentProviderSessionMetadata
  resumeLocator?: string | null
  observedAt?: number
}

export class ConversationAllocator {
  constructor(
    private readonly database: IssueDatabase,
    private readonly conversations: ConversationRecordRepository,
    private readonly identities: ConversationIdentityRepository,
    private readonly claims: ConversationLaunchClaimRepository
  ) {}

  allocateFreshLaunch(
    input: AllocateConversationLaunchInput
  ): AllocateConversationLaunchResult {
    return this.database.transaction(() => this.allocateWithinTransaction(input))
  }

  resolveResumeOrAllocate(
    input: ResolveConversationResumeInput
  ): AllocateConversationLaunchResult {
    return this.database.transaction(() => {
      const existingIdentity = this.identities.findActiveForExecutionHost({
        executionHostId: input.executionHostId,
        agent: input.agent,
        providerSession: input.providerSession
      })
      if (!existingIdentity) {
        const allocated = this.allocateWithinTransaction({ ...input, issueId: null })
        this.identities.attachWithinTransaction({
          conversationId: allocated.conversation.id,
          agent: input.agent,
          providerSession: input.providerSession,
          resumeLocator: input.resumeLocator,
          observedAt: input.now
        })
        return allocated
      }
      const conversation = this.conversations.get(existingIdentity.conversationId)
      if (!conversation) {
        throw new IssueRepositoryError(
          'conversation_not_found',
          `Conversation ${existingIdentity.conversationId} was not found.`
        )
      }
      const claim = this.claims.createWithinTransaction({
        conversationId: conversation.id,
        launchToken: input.launchToken,
        paneKey: input.paneKey,
        processIncarnation: input.processIncarnation,
        connectionId: input.connectionId,
        createdAt: input.now,
        expiresAt: claimExpiry(input)
      })
      return { conversation, claim, disposition: 'replayed' }
    })
  }

  resolveObservedIdentityOrAllocate(
    input: ResolveObservedConversationIdentityInput
  ): {
    conversation: ConversationRecord
    identity: ConversationProviderIdentity
    disposition: 'created' | 'replayed'
  } {
    return this.database.transaction(() => {
      const existingIdentity = this.identities.findActiveForExecutionHost({
        executionHostId: input.executionHostId,
        agent: input.agent,
        providerSession: input.providerSession
      })
      if (existingIdentity) {
        const conversation = this.requireConversation(existingIdentity.conversationId)
        const identity = this.identities.attachWithinTransaction({
          conversationId: conversation.id,
          agent: input.agent,
          providerSession: input.providerSession,
          resumeLocator: input.resumeLocator,
          observedAt: input.observedAt
        })
        return { conversation, identity, disposition: 'replayed' }
      }
      const conversation = this.conversations.createWithinTransaction({
        ...input,
        issueId: null
      })
      const identity = this.identities.attachWithinTransaction({
        conversationId: conversation.id,
        agent: input.agent,
        providerSession: input.providerSession,
        resumeLocator: input.resumeLocator,
        observedAt: input.observedAt
      })
      return { conversation, identity, disposition: 'created' }
    })
  }

  attachProviderIdentity(
    input: AttachConversationLaunchIdentityInput
  ): {
    conversation: ConversationRecord
    identity: ConversationProviderIdentity
    claim: ConversationLaunchClaim | null
  } {
    return this.database.transaction(() => {
      const hostPartitionKey = hostPartitionForExecutionHost(input.executionHostId)
      const existingIdentity = this.identities.findActive({
        hostPartitionKey,
        agent: input.agent,
        providerSession: input.providerSession
      })
      if (existingIdentity) {
        const conversation = this.requireConversation(existingIdentity.conversationId)
        const claim = this.resolveOptionalClaim(input, hostPartitionKey)
        if (claim && claim.conversationId !== conversation.id) {
          throw new IssueRepositoryError(
            'conversation_identity_conflict',
            'Provider identity and launch claim resolve to different Conversations.'
          )
        }
        const refreshed = this.identities.attachWithinTransaction({
          conversationId: conversation.id,
          agent: input.agent,
          providerSession: input.providerSession,
          resumeLocator: input.resumeLocator,
          observedAt: input.observedAt
        })
        return {
          conversation,
          identity: refreshed,
          claim: claim ? this.consumeIfNeeded(claim, input.observedAt) : null
        }
      }

      const claim = this.claims.resolveActive({
        hostPartitionKey,
        launchToken: input.launchToken,
        paneKey: input.paneKey,
        processIncarnation: input.processIncarnation,
        connectionId: input.connectionId,
        now: input.observedAt
      })
      const conversation = this.requireConversation(claim.conversationId)
      if (conversation.executionHostId !== input.executionHostId) {
        throw new IssueRepositoryError(
          'conversation_identity_conflict',
          'Conversation launch claim belongs to another execution host.'
        )
      }
      const identity = this.identities.attachWithinTransaction({
        conversationId: conversation.id,
        agent: input.agent,
        providerSession: input.providerSession,
        resumeLocator: input.resumeLocator,
        observedAt: input.observedAt
      })
      return {
        conversation,
        identity,
        claim: this.claims.consumeWithinTransaction(
          claim.claimId,
          input.observedAt ?? Date.now()
        )
      }
    })
  }

  recordLaunchFailure(input: {
    conversationId: string
    claimId: string
    failure: string
    occurredAt?: number
    closeConversation?: boolean
  }): ConversationRecord {
    return this.database.transaction(() => {
      const conversation =
        input.closeConversation === false
          ? this.requireConversation(input.conversationId)
          : this.conversations.closeAfterLaunchFailureWithinTransaction(
              input.conversationId,
              input.failure
            )
      const claim = this.claims.retireWithinTransaction(
        input.claimId,
        input.occurredAt ?? Date.now()
      )
      if (claim.conversationId !== conversation.id) {
        throw new IssueRepositoryError(
          'conversation_launch_claim_invalid',
          'Launch failure claim belongs to another Conversation.'
        )
      }
      return conversation
    })
  }

  private allocateWithinTransaction(
    input: AllocateConversationLaunchInput
  ): AllocateConversationLaunchResult {
    const hostPartitionKey = hostPartitionForExecutionHost(input.executionHostId)
    const existingClaim = this.claims.findByToken(
      hostPartitionKey,
      input.launchToken,
      false
    )
    if (existingClaim) {
      const conversation = this.requireConversation(existingClaim.conversationId)
      assertLaunchReplayMatches(conversation, input)
      return { conversation, claim: existingClaim, disposition: 'replayed' }
    }
    const conversation = this.conversations.createWithinTransaction(input)
    const claim = this.claims.createWithinTransaction({
      conversationId: conversation.id,
      launchToken: input.launchToken,
      paneKey: input.paneKey,
      processIncarnation: input.processIncarnation,
      connectionId: input.connectionId,
      createdAt: input.now,
      expiresAt: claimExpiry(input)
    })
    return { conversation, claim, disposition: 'created' }
  }

  private resolveOptionalClaim(
    input: AttachConversationLaunchIdentityInput,
    hostPartitionKey: ReturnType<typeof hostPartitionForExecutionHost>
  ): ConversationLaunchClaim | null {
    if (
      !input.launchToken &&
      !input.paneKey &&
      !input.processIncarnation &&
      !input.connectionId
    ) {
      return null
    }
    try {
      return this.claims.resolveActive({
        hostPartitionKey,
        launchToken: input.launchToken,
        paneKey: input.paneKey,
        processIncarnation: input.processIncarnation,
        connectionId: input.connectionId,
        now: input.observedAt
      })
    } catch (error) {
      if (
        error instanceof IssueRepositoryError &&
        (error.code === 'conversation_launch_claim_not_found' ||
          error.code === 'conversation_launch_claim_invalid')
      ) {
        return null
      }
      throw error
    }
  }

  private consumeIfNeeded(
    claim: ConversationLaunchClaim,
    observedAt: number | undefined
  ): ConversationLaunchClaim {
    return claim.consumedAt === null
      ? this.claims.consumeWithinTransaction(claim.claimId, observedAt ?? Date.now())
      : claim
  }

  private requireConversation(id: string): ConversationRecord {
    const conversation = this.conversations.get(id)
    if (!conversation) {
      throw new IssueRepositoryError(
        'conversation_not_found',
        `Conversation ${id} was not found.`
      )
    }
    return conversation
  }
}

function claimExpiry(input: AllocateConversationLaunchInput): number {
  const now = input.now ?? Date.now()
  const ttl = input.claimTtlMs ?? DEFAULT_LAUNCH_CLAIM_TTL_MS
  if (!Number.isSafeInteger(ttl) || ttl <= 0) {
    throw new IssueRepositoryError(
      'conversation_launch_claim_invalid',
      'Conversation launch claim TTL must be a positive integer.'
    )
  }
  return now + ttl
}

function assertLaunchReplayMatches(
  conversation: ConversationRecord,
  input: AllocateConversationLaunchInput
): void {
  const workspaceId =
    input.workspaceRef.type === 'worktree'
      ? input.workspaceRef.worktreeId
      : input.workspaceRef.folderWorkspaceId
  const currentWorkspaceId =
    conversation.workspaceRef.type === 'worktree'
      ? conversation.workspaceRef.worktreeId
      : conversation.workspaceRef.folderWorkspaceId
  if (
    conversation.executionHostId !== input.executionHostId ||
    conversation.workspaceRef.type !== input.workspaceRef.type ||
    currentWorkspaceId !== workspaceId ||
    conversation.agent !== input.agent ||
    conversation.issueId !== (input.issueId ?? null)
  ) {
    throw new IssueRepositoryError(
      'conversation_launch_claim_invalid',
      'Conversation launch token was replayed with different launch input.'
    )
  }
}
