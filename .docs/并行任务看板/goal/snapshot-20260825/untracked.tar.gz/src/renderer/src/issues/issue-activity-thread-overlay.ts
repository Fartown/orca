import type {
  AgentStatusEntry,
  AgentStatusState,
  AgentType
} from '../../../shared/agent-status-types'
import type { ExecutionHostId } from '../../../shared/execution-host'
import type { Repo } from '../../../shared/repo-types'
import { parsePaneKey } from '../../../shared/stable-pane-id'
import type { TerminalTab } from '../../../shared/terminal-tab-types'
import type { Worktree } from '../../../shared/worktree/types'
import {
  getPrimaryRoundPreviewField
} from './round-record-preview-presentation'
import type { IssueActivityThreadProjection } from './issue-activity-projection'

export type ActivityTimelineEventView = {
  id: string
  state: Extract<AgentStatusState, 'done' | 'blocked' | 'waiting'>
  timestamp: number
  worktree: Worktree
  repo: Repo | null
  entry: AgentStatusEntry
  tab: TerminalTab
  agentType: AgentType
  agentAlive: boolean
  migrationUnsupportedPtyId?: string
  unread: boolean
}

export type ActivityTimelineThreadView = {
  threadKey: string
  paneKey: string
  paneTitle: string
  worktree: Worktree
  repo: Repo | null
  tab: TerminalTab
  agentType: AgentType
  currentAgentState: Extract<AgentStatusState, 'working' | 'blocked' | 'waiting'> | null
  currentAgentEntry: AgentStatusEntry | null
  responsePreview: string
  latestTimestamp: number
  latestEvent: ActivityTimelineEventView | null
  events: ActivityTimelineEventView[]
  migrationUnsupportedPtyId?: string
  unread: boolean
  issueActivity?: IssueActivityThreadProjection
}

export type IssueActivityWorkspaceContext = {
  worktree: Worktree
  repo: Repo | null
  tab: TerminalTab | null
}

export function overlayIssueActivityThreads(args: {
  legacyThreads: readonly ActivityTimelineThreadView[]
  projections: readonly IssueActivityThreadProjection[]
  authoritativeRoutes: ReadonlySet<ExecutionHostId>
  routeForLegacyThread: (
    thread: ActivityTimelineThreadView
  ) => ExecutionHostId
  resolveWorkspace: (
    projection: IssueActivityThreadProjection
  ) => IssueActivityWorkspaceContext | null
}): ActivityTimelineThreadView[] {
  const availableByPane = new Map<string, ActivityTimelineThreadView>()
  for (const thread of args.legacyThreads) {
    availableByPane.set(
      routePaneKey(args.routeForLegacyThread(thread), thread.paneKey),
      thread
    )
  }

  const overlaid = args.projections.map((projection) => {
    const liveThread = projection.paneKey
      ? availableByPane.get(
          routePaneKey(projection.routeExecutionHostId, projection.paneKey)
        ) ?? null
      : null
    if (liveThread) {
      availableByPane.delete(
        routePaneKey(projection.routeExecutionHostId, liveThread.paneKey)
      )
    }
    return projectActivityThread(
      projection,
      liveThread,
      args.resolveWorkspace(projection)
    )
  })

  const remaining = args.legacyThreads.flatMap((thread) => {
    const routeExecutionHostId = args.routeForLegacyThread(thread)
    if (
      !availableByPane.has(routePaneKey(routeExecutionHostId, thread.paneKey))
    ) {
      return []
    }
    if (!args.authoritativeRoutes.has(routeExecutionHostId)) {
      return [thread]
    }
    return thread.currentAgentState
      ? [
          {
            ...thread,
            latestEvent: null,
            events: [],
            unread: false
          }
        ]
      : []
  })

  return [...overlaid, ...remaining].sort(
    (left, right) =>
      right.latestTimestamp - left.latestTimestamp ||
      left.threadKey.localeCompare(right.threadKey)
  )
}

function projectActivityThread(
  projection: IssueActivityThreadProjection,
  liveThread: ActivityTimelineThreadView | null,
  workspace: IssueActivityWorkspaceContext | null
): ActivityTimelineThreadView {
  const paneKey =
    liveThread?.paneKey ??
    projection.paneKey ??
    `issue-activity:${projection.key}`
  const worktree =
    liveThread?.worktree ??
    workspace?.worktree ??
    snapshotWorktree(projection)
  const repo = liveThread?.repo ?? workspace?.repo ?? null
  const tab =
    liveThread?.tab ??
    workspace?.tab ??
    snapshotTab(projection, worktree.id)
  const events = projection.entries.map((entry) => {
    const state =
      entry.type === 'round' && entry.round.kind === 'waiting'
        ? 'waiting'
        : 'done'
    const preview =
      entry.type === 'round'
        ? getPrimaryRoundPreviewField(entry.round).value.preview?.trim() ||
          projection.preview
        : projection.preview
    const agentType = projection.conversation?.agent ?? projection.agentType
    const statusEntry: AgentStatusEntry = {
      state,
      prompt: projection.title,
      updatedAt: entry.occurredAt,
      stateStartedAt: entry.occurredAt,
      paneKey,
      terminalTitle: projection.title,
      stateHistory: [],
      agentType,
      lastAssistantMessage: preview
    }
    return {
      id: `${entry.type}:${entry.id}`,
      state,
      timestamp: entry.occurredAt,
      worktree,
      repo,
      entry: statusEntry,
      tab,
      agentType,
      agentAlive: Boolean(liveThread?.currentAgentState),
      unread: entry.type === 'round' && entry.round.readAt === null
    } satisfies ActivityTimelineEventView
  })
  const latestEvent = events[0] ?? null
  return {
    threadKey: `issue:${projection.key}`,
    paneKey,
    paneTitle: projection.title,
    worktree,
    repo,
    tab,
    agentType: liveThread?.agentType ?? projection.agentType,
    currentAgentState: liveThread?.currentAgentState ?? null,
    currentAgentEntry: liveThread?.currentAgentEntry ?? null,
    responsePreview:
      liveThread?.currentAgentState && liveThread.responsePreview.trim()
        ? liveThread.responsePreview
        : projection.preview,
    latestTimestamp: Math.max(
      projection.latestOccurredAt,
      liveThread?.currentAgentState ? liveThread.latestTimestamp : 0
    ),
    latestEvent,
    events,
    migrationUnsupportedPtyId: liveThread?.migrationUnsupportedPtyId,
    unread: projection.unread,
    issueActivity: projection
  }
}

function snapshotWorktree(
  projection: IssueActivityThreadProjection
): Worktree {
  return {
    id: projection.conversation
      ? workspaceKey(projection)
      : `issue-activity:${projection.routeExecutionHostId}:${projection.issue?.id ?? projection.key}`,
    repoId: `issue-activity:${projection.routeExecutionHostId}`,
    path: projection.workspacePath,
    head: '',
    branch: projection.workspaceName,
    isBare: false,
    isMainWorktree: false,
    displayName: projection.workspaceName,
    comment: '',
    linkedIssue: null,
    linkedPR: null,
    linkedLinearIssue: null,
    isArchived: false,
    isUnread: false,
    isPinned: false,
    sortOrder: 0,
    lastActivityAt: projection.latestOccurredAt,
    hostId: projection.routeExecutionHostId
  }
}

function snapshotTab(
  projection: IssueActivityThreadProjection,
  worktreeId: string
): TerminalTab {
  const parsed = projection.paneKey
    ? parsePaneKey(projection.paneKey)
    : null
  return {
    id:
      parsed?.tabId ??
      projection.conversation?.id ??
      projection.entries[0]?.id ??
      projection.key,
    ptyId: null,
    worktreeId,
    title: projection.title,
    customTitle: null,
    color: null,
    sortOrder: 0,
    createdAt: projection.latestOccurredAt
  }
}

function workspaceKey(
  projection: IssueActivityThreadProjection
): string {
  const workspaceRef = projection.conversation?.workspaceRef
  if (!workspaceRef) {
    return `issue-activity:${projection.key}`
  }
  return workspaceRef.type === 'folder'
    ? `folder:${workspaceRef.folderWorkspaceId}`
    : workspaceRef.worktreeId
}

function routePaneKey(
  routeExecutionHostId: ExecutionHostId,
  paneKey: string
): string {
  return `${routeExecutionHostId}\0${paneKey}`
}
