import { randomUUID } from 'node:crypto'
import type { ConversationRecord } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import {
  getConversationRecord,
  listConversationRecords,
  requireConversationRecord
} from './conversation-record-queries'
import { issueEventRef, IssueEventRepository } from './issue-event-repository'
import {
  bumpIssueHostRevisions,
  ensureIssueHostState,
  getIssueHostRevisions
} from './issue-host-state'
import { hostPartitionForExecutionHost } from './issue-host-partition'
import { executeIssueMutation } from './issue-mutation-receipt'
import { requireIssueRecord } from './issue-record-queries'
import { IssueRepositoryError } from './issue-repository-error'
import type {
  BindConversationIssueInput,
  ConversationListFilter,
  CreateConversationInput,
  DeleteRecordInput,
  IssueMutationParams,
  UpdateConversationInput
} from './issue-repository-types'

export class ConversationRecordRepository {
  constructor(
    private readonly database: IssueDatabase,
    private readonly events: IssueEventRepository
  ) {}

  create(params: IssueMutationParams<CreateConversationInput>): ConversationRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'conversations.create',
      payload: params.input,
      operation: () => this.createRecord(params.input)
    })
  }

  get(id: string): ConversationRecord | undefined {
    return getConversationRecord(this.database, id)
  }

  list(filter: ConversationListFilter = {}): ConversationRecord[] {
    return listConversationRecords(this.database, filter)
  }

  update(params: IssueMutationParams<UpdateConversationInput>): ConversationRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'conversations.update',
      payload: params.input,
      operation: () => this.updateRecord(params.input)
    })
  }

  bindIssue(params: IssueMutationParams<BindConversationIssueInput>): ConversationRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'conversations.bindIssue',
      payload: params.input,
      operation: () => {
        const current = requireConversationRecord(this.database, params.input.id)
        const revisions = getIssueHostRevisions(
          this.database,
          current.hostPartitionKey
        )
        if (revisions.factsRevision !== params.input.expectedFactsRevision) {
          throw new IssueRepositoryError(
            'issue_facts_revision_stale',
            `Conversation binding revision ${params.input.expectedFactsRevision} is stale.`,
            {
              expectedFactsRevision: params.input.expectedFactsRevision,
              currentFactsRevision: revisions.factsRevision
            }
          )
        }
        return this.updateRecord({
          id: params.input.id,
          issueId: params.input.issueId
        })
      }
    })
  }

  delete(params: IssueMutationParams<DeleteRecordInput>): { deletedConversationId: string } {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'conversations.delete',
      payload: params.input,
      operation: () => this.deleteRecord(params.input.id)
    })
  }

  createWithinTransaction(input: CreateConversationInput): ConversationRecord {
    return this.createRecord(input)
  }

  private createRecord(input: CreateConversationInput): ConversationRecord {
    const hostPartitionKey = hostPartitionForExecutionHost(input.executionHostId)
    const issueId = input.issueId ?? null
    this.assertIssueBinding(issueId, input.executionHostId)
    const now = Date.now()
    const id = randomUUID()
    const workspaceId =
      input.workspaceRef.type === 'worktree'
        ? input.workspaceRef.worktreeId
        : input.workspaceRef.folderWorkspaceId
    ensureIssueHostState(this.database, hostPartitionKey, now)
    this.database
      .prepare(
        `INSERT INTO conversations (
           id, host_partition_key, execution_host_id, workspace_kind, workspace_id,
           workspace_name_snapshot, workspace_path_snapshot, agent, title, title_source,
           issue_id, state, launch_failure, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        id,
        hostPartitionKey,
        input.executionHostId,
        input.workspaceRef.type,
        workspaceId,
        input.workspaceSnapshot.name,
        input.workspaceSnapshot.path,
        input.agent,
        input.title ?? null,
        normalizeTitleSource(input.title ?? null, input.titleSource),
        issueId,
        input.state ?? 'active',
        null,
        now,
        now
      )
    const revisions = bumpIssueHostRevisions(
      this.database,
      hostPartitionKey,
      { tree: false, searchable: true },
      now
    )
    const conversation = requireConversationRecord(this.database, id)
    if (issueId) {
      const issue = requireIssueRecord(this.database, issueId)
      this.events.appendWithinTransaction({
        hostPartitionKey,
        kind: 'conversation-bound',
        conversationId: conversation.id,
        issueRefs: [issueEventRef(issue, 'issue')],
        payload: { previousIssueId: null, issueId },
        occurredAt: now,
        factsRevision: revisions.factsRevision
      })
    }
    return conversation
  }

  closeAfterLaunchFailure(id: string, failure: string): ConversationRecord {
    return this.database.transaction(() =>
      this.closeAfterLaunchFailureWithinTransaction(id, failure)
    )
  }

  closeAfterLaunchFailureWithinTransaction(
    id: string,
    failure: string
  ): ConversationRecord {
    const current = requireConversationRecord(this.database, id)
    const now = Date.now()
    this.database
      .prepare(
        `UPDATE conversations
         SET state = 'closed', launch_failure = ?, updated_at = ?
         WHERE id = ?`
      )
      .run(failure, now, current.id)
    bumpIssueHostRevisions(
      this.database,
      current.hostPartitionKey,
      { tree: false, searchable: false },
      now
    )
    return requireConversationRecord(this.database, current.id)
  }

  private updateRecord(input: UpdateConversationInput): ConversationRecord {
    if (Object.hasOwn(input, 'executionHostId')) {
      throw new IssueRepositoryError(
        'conversation_host_immutable',
        `Conversation ${input.id} cannot change executionHostId.`
      )
    }
    const current = requireConversationRecord(this.database, input.id)
    const issueId = Object.hasOwn(input, 'issueId') ? (input.issueId ?? null) : current.issueId
    this.assertIssueBinding(issueId, current.executionHostId)
    const title = Object.hasOwn(input, 'title') ? (input.title ?? null) : current.title
    const titleSource = Object.hasOwn(input, 'titleSource')
      ? normalizeTitleSource(title, input.titleSource)
      : title === null
        ? null
        : current.titleSource
    const now = Date.now()
    this.database
      .prepare(
        `UPDATE conversations
         SET title = ?, title_source = ?, issue_id = ?, state = ?, updated_at = ?
         WHERE id = ?`
      )
      .run(title, titleSource, issueId, input.state ?? current.state, now, current.id)
    const revisions = bumpIssueHostRevisions(
      this.database,
      current.hostPartitionKey,
      { tree: false, searchable: Object.hasOwn(input, 'title') },
      now
    )
    const updated = requireConversationRecord(this.database, current.id)
    if (issueId !== current.issueId) {
      this.appendBindingEvent(current, updated, revisions.factsRevision, now)
    }
    return updated
  }

  private deleteRecord(id: string): { deletedConversationId: string } {
    const current = requireConversationRecord(this.database, id)
    const retainedBytes = (
      this.database
        .prepare(
          `SELECT COALESCE(SUM(
             user_input_bytes + user_input_preview_bytes +
             output_bytes + output_preview_bytes +
             question_bytes + question_preview_bytes
           ), 0) AS bytes
           FROM round_records WHERE conversation_id = ?`
        )
        .get(id) as { bytes: number }
    ).bytes
    this.database.prepare('DELETE FROM conversations WHERE id = ?').run(id)
    if (retainedBytes > 0) {
      this.database
        .prepare(
          `UPDATE issue_authority_meta
           SET retained_round_text_bytes = MAX(0, retained_round_text_bytes - ?)
           WHERE singleton = 1`
        )
        .run(retainedBytes)
    }
    bumpIssueHostRevisions(
      this.database,
      current.hostPartitionKey,
      { tree: false, searchable: true },
      Date.now()
    )
    return { deletedConversationId: id }
  }

  private assertIssueBinding(
    issueId: string | null,
    executionHostId: ConversationRecord['executionHostId']
  ): void {
    if (!issueId) {
      return
    }
    const issue = requireIssueRecord(this.database, issueId)
    if (
      issue.hostPartitionKey !== hostPartitionForExecutionHost(executionHostId) ||
      issue.executionHostId !== executionHostId
    ) {
      throw new IssueRepositoryError(
        'conversation_issue_host_mismatch',
        `Issue ${issueId} belongs to another execution host.`
      )
    }
  }

  private appendBindingEvent(
    previous: ConversationRecord,
    current: ConversationRecord,
    factsRevision: number,
    occurredAt: number
  ): void {
    const previousIssue = previous.issueId
      ? requireIssueRecord(this.database, previous.issueId)
      : null
    const currentIssue = current.issueId
      ? requireIssueRecord(this.database, current.issueId)
      : null
    this.events.appendWithinTransaction({
      hostPartitionKey: current.hostPartitionKey,
      kind:
        previousIssue === null
          ? 'conversation-bound'
          : currentIssue === null
            ? 'conversation-unbound'
            : 'conversation-rebound',
      conversationId: current.id,
      issueRefs: [
        ...(previousIssue ? [issueEventRef(previousIssue, 'previous-issue')] : []),
        ...(currentIssue ? [issueEventRef(currentIssue, 'issue')] : [])
      ],
      payload: {
        previousIssueId: previous.issueId,
        issueId: current.issueId
      },
      occurredAt,
      factsRevision
    })
  }
}

function normalizeTitleSource(
  title: string | null,
  source: ConversationRecord['titleSource'] | undefined
): ConversationRecord['titleSource'] {
  if (title === null) {
    return null
  }
  return source ?? 'user'
}
