import { describe, expect, it } from 'vitest'
import type {
  ConversationSummary,
  IssueMobilePendingEntry,
  RoundRecordPreview,
  RoundRecordTextSummary
} from '../../../src/shared/issues'
import type { ExecutionHostId } from '../../../src/shared/execution-host'
import {
  buildMobileIssueDetailPresentation,
  buildMobileIssuePendingRow,
  supportsMobileIssues
} from './mobile-issue-screen-model'

const executionHostId = 'local' as ExecutionHostId

function text(
  preview: string | null,
  completeness: RoundRecordTextSummary['completeness'] = 'not-captured',
  storage: RoundRecordTextSummary['storage'] = 'none'
): RoundRecordTextSummary {
  return {
    preview,
    completeness,
    storage,
    bytes: preview?.length ?? 0,
    previewBytes: preview?.length ?? 0
  }
}

function round(overrides: Partial<RoundRecordPreview> = {}): RoundRecordPreview {
  return {
    id: '22222222-2222-4222-8222-222222222222',
    conversationId: '11111111-1111-4111-8111-111111111111',
    kind: 'waiting',
    stateSource: 'hook',
    occurredAt: 1_700_000_000_000,
    executionChainId: null,
    supersedesRoundId: null,
    userInput: text(null),
    agentOutput: text(null),
    pendingQuestion: text('Approve the deployment?', 'truncated', 'preview'),
    readAt: null,
    resolvedAt: null,
    resolution: null,
    effectiveResolvedAt: null,
    effectiveResolution: null,
    finalizedAt: null,
    bodyEvictedAt: null,
    bodyDeletedAt: null,
    bodyRevision: 0,
    createdAt: 1_700_000_000_000,
    ...overrides
  }
}

function conversation(overrides: Partial<ConversationSummary> = {}): ConversationSummary {
  return {
    id: '11111111-1111-4111-8111-111111111111',
    hostPartitionKey: 'local',
    executionHostId,
    workspaceRef: { type: 'worktree', worktreeId: 'worktree-1' },
    workspaceSnapshot: { name: 'Orca', path: '/repo/orca' },
    agent: 'claude',
    title: 'Ship mobile waiting',
    titleSource: 'user',
    issueId: '33333333-3333-4333-8333-333333333333',
    state: 'active',
    launchFailure: null,
    createdAt: 1_699_999_000_000,
    updatedAt: 1_700_000_000_000,
    unresolvedRoundCount: 1,
    latestRound: round(),
    ...overrides
  }
}

function pendingEntry(overrides: Partial<IssueMobilePendingEntry> = {}): IssueMobilePendingEntry {
  return {
    round: round(),
    conversation: conversation(),
    issue: {
      id: '33333333-3333-4333-8333-333333333333',
      title: 'Parallel task board',
      typeLabel: 'Feature',
      state: 'active'
    },
    ...overrides
  }
}

describe('mobile Issue screen model', () => {
  it('shows the entry point only after the host advertises the Issues capability', () => {
    expect(supportsMobileIssues([])).toBe(false)
    expect(supportsMobileIssues(['mobile.tasks.v1'])).toBe(false)
    expect(supportsMobileIssues(['mobile.tasks.v1', 'orca-issues.v1'])).toBe(true)
  })

  it('keeps an unassigned Conversation visible and labels a bounded preview honestly', () => {
    const row = buildMobileIssuePendingRow(
      executionHostId,
      pendingEntry({
        issue: null,
        conversation: conversation({ title: null }),
        round: round({
          pendingQuestion: text('Approve the deployment?', 'truncated', 'preview')
        })
      })
    )

    expect(row.issueTitle).toBe('Unassigned')
    expect(row.conversationTitle).toBe('Orca')
    expect(row.preview).toBe('Approve the deployment?')
    expect(row.captureLabel).toBe('Truncated preview')
    expect(row.isUnread).toBe(true)
  })

  it('does not present evicted or uncaptured text as a full body', () => {
    const row = buildMobileIssuePendingRow(
      executionHostId,
      pendingEntry({
        round: round({
          pendingQuestion: text('Old bounded preview', 'complete', 'evicted-preview'),
          readAt: 1_700_000_000_100
        })
      })
    )

    expect(row.preview).toBe('Old bounded preview')
    expect(row.captureLabel).toBe('Body removed · preview only')
    expect(row.isUnread).toBe(false)
  })

  it('keeps handled, closed, unsupported, unreachable, and invalid detail states distinct', () => {
    const handled = buildMobileIssueDetailPresentation({
      status: 'handled-active',
      conversation: conversation({ unresolvedRoundCount: 0 })
    })
    const closed = buildMobileIssueDetailPresentation({
      status: 'closed',
      conversation: conversation({ state: 'closed', unresolvedRoundCount: 0 })
    })
    const unsupported = buildMobileIssueDetailPresentation({
      status: 'unsupported',
      message: 'method not found'
    })
    const unreachable = buildMobileIssueDetailPresentation({
      status: 'unreachable',
      message: 'socket closed'
    })
    const invalid = buildMobileIssueDetailPresentation({
      status: 'invalid',
      message: 'bad payload'
    })

    expect(handled).toMatchObject({
      tone: 'neutral',
      title: 'Already handled',
      canOpenConversation: true
    })
    expect(closed).toMatchObject({
      tone: 'neutral',
      title: 'Conversation ended',
      canOpenConversation: false
    })
    expect(unsupported).toMatchObject({
      tone: 'warning',
      title: 'Host update required',
      canOpenConversation: false
    })
    expect(unreachable).toMatchObject({
      tone: 'danger',
      title: 'Host unreachable',
      canOpenConversation: false
    })
    expect(invalid).toMatchObject({
      tone: 'danger',
      title: 'Issue data unavailable',
      canOpenConversation: false
    })
  })

  it('lets an active waiting detail open the existing Conversation surface', () => {
    const presentation = buildMobileIssueDetailPresentation({
      status: 'ready',
      item: {
        executionHostId,
        entry: pendingEntry()
      }
    })

    expect(presentation).toMatchObject({
      tone: 'attention',
      title: 'Needs your input',
      canOpenConversation: true,
      preview: 'Approve the deployment?',
      captureLabel: 'Truncated preview'
    })
  })
})
