import { describe, expect, it, vi } from 'vitest'
import type {
  ConversationNavigationTarget,
  ConversationSummary,
  IssueMobilePendingEntry,
  IssueMobilePendingPage,
  RoundRecordPreview
} from '../../../src/shared/issues'
import type { RpcClient } from '../transport/rpc-client'
import type { RpcFailure, RpcResponse, RpcSuccess } from '../transport/types'
import {
  loadMobileIssueConversation,
  loadMobileIssuePending,
  resolveMobileIssueDetailState
} from './mobile-issue-data'

const AUTHORITY_ID = '11111111-1111-4111-8111-111111111111'
const CONVERSATION_ID = '22222222-2222-4222-8222-222222222222'
const ROUND_ID = '33333333-3333-4333-8333-333333333333'
const ISSUE_ID = '44444444-4444-4444-8444-444444444444'

function ok(result: unknown): RpcSuccess {
  return { id: 'rpc', ok: true, result, _meta: { runtimeId: 'runtime' } }
}

function fail(code: string, message: string): RpcFailure {
  return {
    id: 'rpc',
    ok: false,
    error: { code, message },
    _meta: { runtimeId: 'runtime' }
  }
}

function textSummary(preview: string | null = null) {
  return {
    completeness: preview ? ('preview-complete' as const) : ('not-captured' as const),
    storage: preview ? ('preview' as const) : ('none' as const),
    bytes: preview ? Buffer.byteLength(preview) : 0,
    preview,
    previewBytes: preview ? Buffer.byteLength(preview) : 0
  }
}

function round(
  occurredAt: number,
  overrides: Partial<RoundRecordPreview> = {}
): RoundRecordPreview {
  return {
    id: ROUND_ID,
    conversationId: CONVERSATION_ID,
    kind: 'waiting',
    stateSource: 'hook',
    occurredAt,
    executionChainId: 'chain-1',
    supersedesRoundId: null,
    userInput: textSummary('Run the command'),
    agentOutput: textSummary(),
    pendingQuestion: textSummary('Approve?'),
    readAt: null,
    resolvedAt: null,
    resolution: null,
    effectiveResolvedAt: null,
    effectiveResolution: null,
    finalizedAt: occurredAt,
    bodyEvictedAt: null,
    bodyDeletedAt: null,
    bodyRevision: 1,
    createdAt: occurredAt,
    ...overrides
  }
}

function conversation(
  overrides: Partial<ConversationNavigationTarget> = {}
): ConversationNavigationTarget {
  return {
    id: CONVERSATION_ID,
    hostPartitionKey: 'local',
    executionHostId: 'local',
    workspaceRef: { type: 'worktree', worktreeId: 'worktree-1' },
    workspaceSnapshot: { name: 'Orca', path: '/tmp/orca' },
    agent: 'codex',
    title: 'Finish Issue mobile',
    titleSource: 'user',
    issueId: ISSUE_ID,
    state: 'active',
    launchFailure: null,
    createdAt: 10,
    updatedAt: 20,
    navigation: {
      paneKey: null,
      providerSession: null,
      resumeLocator: null
    },
    ...overrides
  }
}

function conversationSummary(
  overrides: Partial<ConversationSummary> = {}
): ConversationSummary {
  return {
    ...conversation(),
    unresolvedRoundCount: 0,
    latestRound: round(30, {
      resolvedAt: 31,
      resolution: 'explicit',
      effectiveResolvedAt: 31,
      effectiveResolution: 'explicit'
    }),
    ...overrides
  }
}

function entry(
  occurredAt: number,
  overrides: Partial<IssueMobilePendingEntry> = {}
): IssueMobilePendingEntry {
  return {
    round: round(occurredAt),
    conversation: conversation(),
    issue: {
      id: ISSUE_ID,
      title: 'Mobile waiting',
      typeLabel: 'Bug',
      state: 'active'
    },
    ...overrides
  }
}

function page(
  executionHostId: 'local' | `ssh:${string}` | `runtime:${string}`,
  entries: IssueMobilePendingEntry[],
  nextCursor: string | null = null
): IssueMobilePendingPage {
  return {
    authority: {
      authorityId: AUTHORITY_ID,
      hostPartitionKey: executionHostId.startsWith('ssh:') ? executionHostId : 'local',
      routeExecutionHostId: executionHostId
    },
    snapshotFactsRevision: 7,
    entries,
    nextCursor
  }
}

function clientWith(
  responder: (method: string, params: unknown) => RpcResponse | Promise<RpcResponse>
): Pick<RpcClient, 'sendRequest'> & {
  sendRequest: ReturnType<typeof vi.fn<RpcClient['sendRequest']>>
} {
  const sendRequest = vi.fn<RpcClient['sendRequest']>(async (method, params) =>
    responder(method, params)
  )
  return { sendRequest }
}

describe('loadMobileIssuePending', () => {
  it('deduplicates authorities, follows cursors, and merges newest waiting records first', async () => {
    const localOld = entry(100)
    const localNew = entry(300, {
      round: round(300, { id: '55555555-5555-4555-8555-555555555555' })
    })
    const sshEntry = entry(200, {
      round: round(200, {
        id: '66666666-6666-4666-8666-666666666666'
      }),
      conversation: conversation({
        id: '77777777-7777-4777-8777-777777777777',
        hostPartitionKey: 'ssh:docs',
        executionHostId: 'ssh:docs'
      })
    })
    const client = clientWith((_method, params) => {
      const request = params as { executionHostId: string; cursor?: string }
      if (request.executionHostId === 'local' && !request.cursor) {
        return ok(page('local', [localOld], 'next-local'))
      }
      if (request.executionHostId === 'local') {
        return ok(page('local', [localNew]))
      }
      return ok(page('ssh:docs', [sshEntry]))
    })

    const result = await loadMobileIssuePending(client, ['local', 'ssh:docs', 'local'])

    expect(result.status).toBe('ready')
    expect(result.items.map((item) => item.entry.round.occurredAt)).toEqual([300, 200, 100])
    expect(result.items.map((item) => item.executionHostId)).toEqual([
      'local',
      'ssh:docs',
      'local'
    ])
    expect(result.partitions).toEqual([
      expect.objectContaining({ executionHostId: 'local', status: 'ready' }),
      expect.objectContaining({ executionHostId: 'ssh:docs', status: 'ready' })
    ])
    expect(client.sendRequest).toHaveBeenCalledTimes(3)
    expect(client.sendRequest).toHaveBeenCalledWith('issues.pendingForMobile', {
      executionHostId: 'local',
      limit: 200
    })
    expect(client.sendRequest).toHaveBeenCalledWith('issues.pendingForMobile', {
      executionHostId: 'local',
      cursor: 'next-local',
      limit: 200
    })
  })

  it('keeps successful partitions while identifying unsupported and unreachable hosts', async () => {
    const client = clientWith((_method, params) => {
      const executionHostId = (params as { executionHostId: string }).executionHostId
      if (executionHostId === 'local') {
        return ok(page('local', [entry(100)]))
      }
      if (executionHostId === 'runtime:old') {
        return fail('method_not_found', 'Unknown method: issues.pendingForMobile')
      }
      throw new Error('host unreachable')
    })

    const result = await loadMobileIssuePending(client, [
      'local',
      'runtime:old',
      'ssh:offline'
    ])

    expect(result.status).toBe('ready')
    expect(result.items).toHaveLength(1)
    expect(result.partitions).toEqual([
      expect.objectContaining({ executionHostId: 'local', status: 'ready' }),
      expect.objectContaining({ executionHostId: 'runtime:old', status: 'unsupported' }),
      expect.objectContaining({ executionHostId: 'ssh:offline', status: 'unreachable' })
    ])
  })

  it('does not accept malformed runtime payloads as an empty waiting list', async () => {
    const client = clientWith(() => ok({ entries: [] }))

    const result = await loadMobileIssuePending(client, ['local'])

    expect(result).toMatchObject({
      status: 'invalid',
      items: [],
      partitions: [{ executionHostId: 'local', status: 'invalid' }]
    })
  })
})

describe('loadMobileIssueConversation', () => {
  it.each([
    {
      name: 'unsupported runtime',
      response: fail('method_not_found', 'Unknown method'),
      expected: 'unsupported'
    },
    {
      name: 'closed conversation',
      response: fail('conversation_not_found', 'Conversation missing'),
      expected: 'closed'
    },
    {
      name: 'malformed payload',
      response: ok({ id: CONVERSATION_ID, state: 'active' }),
      expected: 'invalid'
    }
  ])('classifies $name without treating it as an empty active conversation', async (testCase) => {
    const client = clientWith(() => testCase.response)

    const result = await loadMobileIssueConversation(client, 'local', CONVERSATION_ID)

    expect(result.status).toBe(testCase.expected)
  })

  it('returns a schema-validated Conversation and classifies transport loss separately', async () => {
    const readyClient = clientWith(() => ok(conversationSummary()))
    await expect(
      loadMobileIssueConversation(readyClient, 'local', CONVERSATION_ID)
    ).resolves.toEqual({
      status: 'ready',
      conversation: conversationSummary()
    })

    const unreachableClient = clientWith(() => {
      throw new Error('socket closed')
    })
    await expect(
      loadMobileIssueConversation(unreachableClient, 'local', CONVERSATION_ID)
    ).resolves.toMatchObject({
      status: 'unreachable',
      message: 'socket closed'
    })
  })
})

describe('resolveMobileIssueDetailState', () => {
  it('distinguishes a pending target from handled-active and closed conversations', () => {
    const pendingItem = {
      executionHostId: 'local' as const,
      entry: entry(100)
    }
    const pending = {
      status: 'ready' as const,
      items: [pendingItem],
      partitions: [{ executionHostId: 'local' as const, status: 'ready' as const }]
    }

    expect(
      resolveMobileIssueDetailState({
        executionHostId: 'local',
        conversationId: CONVERSATION_ID,
        roundRecordId: ROUND_ID,
        pending,
        conversation: { status: 'ready', conversation: conversationSummary() }
      })
    ).toEqual({ status: 'ready', item: pendingItem })

    expect(
      resolveMobileIssueDetailState({
        executionHostId: 'local',
        conversationId: CONVERSATION_ID,
        roundRecordId: ROUND_ID,
        pending: { ...pending, items: [] },
        conversation: { status: 'ready', conversation: conversationSummary() }
      })
    ).toEqual({
      status: 'handled-active',
      conversation: conversationSummary()
    })

    const closed = conversationSummary({ state: 'closed' })
    expect(
      resolveMobileIssueDetailState({
        executionHostId: 'local',
        conversationId: CONVERSATION_ID,
        roundRecordId: ROUND_ID,
        pending: { ...pending, items: [] },
        conversation: { status: 'ready', conversation: closed }
      })
    ).toEqual({ status: 'closed', conversation: closed })
  })
})
