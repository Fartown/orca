import type {
  AuthorityHostPartitionKey,
  ConversationNavigationTarget,
  IssueActivityEntry,
  IssueActivityPage,
  IssueEvent,
  IssueEventKind,
  IssueRecord,
  RoundRecord
} from '../../shared/issues/types'
import type { IssueAuthorityRoute } from './issue-authority-route'
import { issueAuthorityDescriptor } from './issue-authority-route'
import type { IssueDatabase } from './issue-database'
import { encodeIssueQueryCursor, readTimelineCursor } from './issue-query-cursor'
import {
  readConversationNavigationTargets,
  readHostRevisions,
  toRoundRecordPreview
} from './issue-query-projections'
import {
  issueFromRow,
  roundRecordFromRow,
  type IssueRow,
  type RoundRecordRow
} from './issue-row-mappers'

type ActivityIndexRow = {
  source: IssueActivityEntry['type']
  entity_id: string
  occurred_at: number
  sort_id: string
}

type IssueEventRow = {
  id: string
  host_partition_key: AuthorityHostPartitionKey
  kind: IssueEventKind
  conversation_id: string | null
  payload_json: string
  occurred_at: number
  facts_revision: number
}

type IssueEventRefRow = {
  event_id: string
  issue_id: string
  role: string
  issue_title_snapshot: string
}

type RoundContext = {
  round: RoundRecord
  conversation: ConversationNavigationTarget
  issue: IssueRecord | null
}

export class IssueActivityQuery {
  constructor(private readonly database: IssueDatabase) {}

  list(route: IssueAuthorityRoute, params: { cursor?: string; limit: number }): IssueActivityPage {
    return this.database.readTransaction(() => {
      const revisions = readHostRevisions(this.database, route.hostPartitionKey)
      const cursor = params.cursor
        ? readTimelineCursor(params.cursor, 'activity-list', revisions.factsRevision)
        : null
      const limit = Math.max(1, params.limit)
      const rows = this.readIndex(route.hostPartitionKey, cursor?.occurredAt, cursor?.id, limit + 1)
      const pageRows = rows.slice(0, limit)
      const last = pageRows.at(-1)
      return {
        authority: issueAuthorityDescriptor(this.database, route),
        snapshotFactsRevision: revisions.factsRevision,
        entries: this.readEntries(route, pageRows),
        nextCursor:
          rows.length > pageRows.length && last
            ? encodeIssueQueryCursor({
                v: 1,
                kind: 'activity-list',
                factsRevision: revisions.factsRevision,
                occurredAt: last.occurred_at,
                id: last.sort_id
              })
            : null
      }
    })
  }

  private readIndex(
    hostPartitionKey: AuthorityHostPartitionKey,
    cursorTime: number | undefined,
    cursorId: string | undefined,
    limit: number
  ): ActivityIndexRow[] {
    return this.database
      .prepare(
        `SELECT source, entity_id, occurred_at, sort_id
         FROM (
           SELECT
             'round' AS source,
             round.id AS entity_id,
             round.occurred_at,
             'round:' || round.id AS sort_id
           FROM round_record_effective_state round
           JOIN conversations conversation
             ON conversation.id = round.conversation_id
           WHERE conversation.host_partition_key = ?
           UNION ALL
           SELECT
             'issue-event' AS source,
             event.id AS entity_id,
             event.occurred_at,
             'issue-event:' || event.id AS sort_id
           FROM issue_events event
           WHERE event.host_partition_key = ?
         ) activity
         WHERE (
           ? IS NULL OR activity.occurred_at < ? OR
           (activity.occurred_at = ? AND activity.sort_id < ?)
         )
         ORDER BY activity.occurred_at DESC, activity.sort_id DESC
         LIMIT ?`
      )
      .all(
        hostPartitionKey,
        hostPartitionKey,
        cursorTime ?? null,
        cursorTime ?? null,
        cursorTime ?? null,
        cursorId ?? null,
        limit
      ) as ActivityIndexRow[]
  }

  private readEntries(
    route: IssueAuthorityRoute,
    rows: readonly ActivityIndexRow[]
  ): IssueActivityEntry[] {
    const roundIds = rows.filter((row) => row.source === 'round').map((row) => row.entity_id)
    const eventIds = rows.filter((row) => row.source === 'issue-event').map((row) => row.entity_id)
    const rounds = this.readRoundContexts(route, roundIds)
    const events = this.readEvents(route, eventIds)
    const entries: IssueActivityEntry[] = []
    for (const row of rows) {
      if (row.source === 'round') {
        const context = rounds.get(row.entity_id)
        if (context) {
          entries.push(toRoundEntry(context))
        }
        continue
      }
      const event = events.get(row.entity_id)
      if (event) {
        entries.push(event)
      }
    }
    return entries
  }

  private readRoundContexts(
    route: IssueAuthorityRoute,
    ids: readonly string[]
  ): Map<string, RoundContext> {
    if (ids.length === 0) {
      return new Map()
    }
    const placeholders = ids.map(() => '?').join(', ')
    const rows = this.database
      .prepare(
        `SELECT *
         FROM round_record_effective_state
         WHERE id IN (${placeholders})`
      )
      .all(...ids) as RoundRecordRow[]
    const conversations = readConversationNavigationTargets(
      this.database,
      route,
      rows.map((row) => row.conversation_id)
    )
    const issues = this.readIssues(
      [...conversations.values()].flatMap((conversation) =>
        conversation.issueId ? [conversation.issueId] : []
      )
    )
    return new Map(
      rows.flatMap((row) => {
        const conversation = conversations.get(row.conversation_id)
        if (!conversation) {
          return []
        }
        return [
          [
            row.id,
            {
              round: roundRecordFromRow(row),
              conversation,
              issue: conversation.issueId ? (issues.get(conversation.issueId) ?? null) : null
            }
          ] as const
        ]
      })
    )
  }

  private readEvents(
    route: IssueAuthorityRoute,
    ids: readonly string[]
  ): Map<string, Extract<IssueActivityEntry, { type: 'issue-event' }>> {
    if (ids.length === 0) {
      return new Map()
    }
    const placeholders = ids.map(() => '?').join(', ')
    const events = this.database
      .prepare(`SELECT * FROM issue_events WHERE id IN (${placeholders})`)
      .all(...ids) as IssueEventRow[]
    const refs = this.database
      .prepare(
        `SELECT event_id, issue_id, role, issue_title_snapshot
         FROM issue_event_issue_refs
         WHERE event_id IN (${placeholders})
         ORDER BY event_id, role, issue_id`
      )
      .all(...ids) as IssueEventRefRow[]
    const refsByEvent = groupEventRefs(refs)
    const conversationIds = events.flatMap((event) =>
      event.conversation_id ? [event.conversation_id] : []
    )
    const conversations = readConversationNavigationTargets(this.database, route, conversationIds)
    return new Map(
      events.map((row) => {
        const event: IssueEvent = {
          id: row.id,
          hostPartitionKey: row.host_partition_key,
          executionHostId: route.routeExecutionHostId,
          kind: row.kind,
          conversationId: row.conversation_id,
          issueRefs: refsByEvent.get(row.id) ?? [],
          payload: JSON.parse(row.payload_json) as Record<string, unknown>,
          occurredAt: row.occurred_at,
          factsRevision: row.facts_revision
        }
        const conversation = row.conversation_id
          ? (conversations.get(row.conversation_id) ?? null)
          : null
        return [
          row.id,
          {
            type: 'issue-event' as const,
            id: row.id,
            occurredAt: row.occurred_at,
            event,
            conversation
          }
        ]
      })
    )
  }

  private readIssues(ids: readonly string[]): Map<string, IssueRecord> {
    const uniqueIds = [...new Set(ids)]
    if (uniqueIds.length === 0) {
      return new Map()
    }
    const placeholders = uniqueIds.map(() => '?').join(', ')
    const rows = this.database
      .prepare(`SELECT * FROM issues WHERE id IN (${placeholders})`)
      .all(...uniqueIds) as IssueRow[]
    return new Map(rows.map((row) => [row.id, issueFromRow(row)]))
  }
}

function toRoundEntry(
  context: RoundContext
): Extract<IssueActivityEntry, { type: 'round' }> {
  return {
    type: 'round',
    id: context.round.id,
    occurredAt: context.round.occurredAt,
    round: toRoundRecordPreview(context.round),
    conversation: context.conversation,
    issue: context.issue
      ? {
          id: context.issue.id,
          title:
            context.issue.source.kind === 'local'
              ? (context.issue.localTitle ?? '')
              : context.issue.source.titleSnapshot,
          typeLabel: context.issue.typeLabel,
          state: context.issue.state
        }
      : null
  }
}

function groupEventRefs(rows: readonly IssueEventRefRow[]): Map<string, IssueEvent['issueRefs']> {
  const grouped = new Map<string, IssueEvent['issueRefs']>()
  for (const row of rows) {
    const refs = grouped.get(row.event_id) ?? []
    refs.push({
      issueId: row.issue_id,
      role: row.role,
      titleSnapshot: row.issue_title_snapshot
    })
    grouped.set(row.event_id, refs)
  }
  return grouped
}
