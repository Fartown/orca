import React from 'react'
import { Archive, ChevronRight, CircleDot } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import type { IssueSummary } from '../../../../shared/issues/types'
import { getIssueDisplayTitle } from '../../issues/issue-display'

type IssueChildrenProps = {
  children: readonly IssueSummary[]
  onOpenIssue?: (issue: IssueSummary) => void
}

export function IssueChildren({
  children,
  onOpenIssue
}: IssueChildrenProps): React.JSX.Element {
  return (
    <section aria-labelledby="issue-children-heading">
      <div className="mb-2 flex items-center gap-2">
        <h2 id="issue-children-heading" className="text-sm font-semibold">
          Child Issues
        </h2>
        <span className="text-xs tabular-nums text-muted-foreground">
          {children.length}
        </span>
      </div>
      {children.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border/70 px-4 py-5 text-center text-xs text-muted-foreground">
          No direct child Issues.
        </div>
      ) : (
        <div className="divide-y divide-border/50 overflow-hidden rounded-lg border border-border/60 bg-card">
          {children.map((issue) => {
            const content = (
              <>
                {issue.state === 'archived' ? (
                  <Archive className="size-3.5 shrink-0 text-muted-foreground" />
                ) : (
                  <CircleDot className="size-3.5 shrink-0 text-muted-foreground" />
                )}
                <span className="min-w-0 flex-1 truncate text-sm font-medium">
                  {getIssueDisplayTitle(issue)}
                </span>
                {issue.ownUnresolvedCount > 0 ? (
                  <Badge className="h-5 px-1.5 text-[10px]">
                    {issue.ownUnresolvedCount} own
                  </Badge>
                ) : null}
                {issue.descendantAttentionCount > 0 ? (
                  <Badge
                    variant="outline"
                    className="h-5 px-1.5 text-[10px]"
                  >
                    {issue.descendantAttentionCount} descendants
                  </Badge>
                ) : null}
                <ChevronRight className="size-3.5 shrink-0 text-muted-foreground" />
              </>
            )
            return onOpenIssue ? (
              <button
                key={issue.id}
                type="button"
                className="flex h-10 w-full min-w-0 items-center gap-2 px-3 text-left hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-ring"
                onClick={() => onOpenIssue(issue)}
              >
                {content}
              </button>
            ) : (
              <div
                key={issue.id}
                className="flex h-10 min-w-0 items-center gap-2 px-3"
              >
                {content}
              </div>
            )
          })}
        </div>
      )}
    </section>
  )
}
