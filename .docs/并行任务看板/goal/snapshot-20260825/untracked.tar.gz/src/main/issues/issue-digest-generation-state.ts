import { randomUUID } from 'node:crypto'
import type {
  IssueDigestInputSummary,
  IssueDigestRecord,
  IssueDigestSections
} from '../../shared/issues/digest-types'
import { ISSUE_DIGEST_GENERATION_ERROR_MAX_BYTES } from '../../shared/issues/digest-constants'
import type { IssueMutationIdentity, IssueRecord } from '../../shared/issues/types'
import type { TuiAgent } from '../../shared/tui-agent'
import { clampUtf8TextPrefix } from '../../shared/utf8-byte-limits'
import type { IssueDatabase } from './issue-database'
import { requireIssueDigest } from './issue-digest-record'
import { bumpIssueHostRevisions } from './issue-host-state'
import { executeIssueMutationWithReceipt } from './issue-mutation-receipt'
import { requireIssueRecord } from './issue-record-queries'
import { IssueRepositoryError } from './issue-repository-error'

export function recoverInterruptedIssueDigests(database: IssueDatabase): string[] {
  const rows = database
    .prepare(
      `SELECT digest.id, issue.host_partition_key
       FROM issue_digests digest
       JOIN issues issue ON issue.id = digest.issue_id
       WHERE digest.status = 'generating'
       ORDER BY digest.id`
    )
    .all() as Array<{
    id: string
    host_partition_key: IssueRecord['hostPartitionKey']
  }>
  if (rows.length === 0) {
    return []
  }
  const now = Date.now()
  database.transaction(() => {
    database
      .prepare(
        `UPDATE issue_digests
         SET status = 'failed',
             generation_error = 'runtime-restarted',
             generation_finished_at = ?,
             updated_at = ?
         WHERE status = 'generating'`
      )
      .run(now, now)
    for (const partition of new Set(rows.map((row) => row.host_partition_key))) {
      bumpIssueHostRevisions(database, partition, { tree: false }, now)
    }
  })
  return rows.map((row) => row.id)
}

export function createGeneratingIssueDigest(
  database: IssueDatabase,
  params: {
    identity: IssueMutationIdentity
    issue: IssueRecord
    agent: TuiAgent
    coversUntil: number
    inputFingerprint: string
    coverageNote: string | null
    inputs: IssueDigestInputSummary[]
  }
): { digest: IssueDigestRecord; replayed: boolean } {
  const receipt = executeIssueMutationWithReceipt({
    database,
    identity: params.identity,
    method: 'issues.generateDigest',
    payload: {
      issueId: params.issue.id,
      agent: params.agent,
      coversUntil: params.coversUntil,
      inputFingerprint: params.inputFingerprint
    },
    operation: () => insertGeneratingDigest(database, params)
  })
  return {
    digest: requireIssueDigest(database, receipt.result.digestId),
    replayed: receipt.replayed
  }
}

export function createCheckedGeneratingIssueDigest<
  Snapshot extends {
    inputFingerprint: string
    coverageNote: string | null
    inputs: IssueDigestInputSummary[]
  }
>(
  database: IssueDatabase,
  params: {
    identity: IssueMutationIdentity
    issue: IssueRecord
    agent: TuiAgent
    coversUntil: number
    expectedInputFingerprint: string
    resolveSnapshot: () => Snapshot
  }
): { digest: IssueDigestRecord; replayed: boolean; snapshot?: Snapshot } {
  let snapshot: Snapshot | undefined
  const receipt = executeIssueMutationWithReceipt({
    database,
    identity: params.identity,
    method: 'issues.generateDigest',
    payload: {
      issueId: params.issue.id,
      agent: params.agent,
      coversUntil: params.coversUntil,
      expectedInputFingerprint: params.expectedInputFingerprint
    },
    operation: () => {
      const current = params.resolveSnapshot()
      if (current.inputFingerprint !== params.expectedInputFingerprint) {
        throw new IssueRepositoryError(
          'digest_input_stale',
          `Issue ${params.issue.id} changed after its Digest inputs were prepared.`,
          {
            expectedInputFingerprint: params.expectedInputFingerprint,
            currentInputFingerprint: current.inputFingerprint
          }
        )
      }
      snapshot = current
      return insertGeneratingDigest(database, {
        issue: params.issue,
        agent: params.agent,
        coversUntil: params.coversUntil,
        inputFingerprint: current.inputFingerprint,
        coverageNote: current.coverageNote,
        inputs: current.inputs
      })
    }
  })
  return {
    digest: requireIssueDigest(database, receipt.result.digestId),
    replayed: receipt.replayed,
    ...(snapshot ? { snapshot } : {})
  }
}

function insertGeneratingDigest(
  database: IssueDatabase,
  params: {
    issue: IssueRecord
    agent: TuiAgent
    coversUntil: number
    inputFingerprint: string
    coverageNote: string | null
    inputs: IssueDigestInputSummary[]
  }
): { digestId: string } {
  const active = database
    .prepare(
      `SELECT id FROM issue_digests
       WHERE issue_id = ? AND status = 'generating'`
    )
    .get(params.issue.id) as { id: string } | undefined
  if (active) {
    throw new IssueRepositoryError(
      'digest_generation_in_progress',
      `Issue ${params.issue.id} already has a Digest generation in progress.`,
      { digestId: active.id }
    )
  }
  const version = (
    database
      .prepare(
        `SELECT COALESCE(MAX(version), 0) + 1 AS version
         FROM issue_digests WHERE issue_id = ?`
      )
      .get(params.issue.id) as { version: number }
  ).version
  const id = randomUUID()
  const generationId = randomUUID()
  const now = Date.now()
  database
    .prepare(
      `INSERT INTO issue_digests (
         id, issue_id, version, revision, status, covers_until,
         coverage_note, input_fingerprint, generator_agent, generation_id,
         generation_started_at, created_at, updated_at
       ) VALUES (?, ?, ?, 0, 'generating', ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      id,
      params.issue.id,
      version,
      params.coversUntil,
      params.coverageNote,
      params.inputFingerprint,
      params.agent,
      generationId,
      now,
      now,
      now
    )
  const insertInput = database.prepare(
    `INSERT INTO issue_digest_inputs (
       digest_id, input_kind, input_id, input_version, title_snapshot
     ) VALUES (?, ?, ?, ?, ?)`
  )
  for (const input of params.inputs) {
    if (input.includedBytes > 0) {
      insertInput.run(
        id,
        input.kind,
        input.inputId,
        input.inputVersion,
        input.titleSnapshot
      )
    }
  }
  bumpIssueHostRevisions(
    database,
    params.issue.hostPartitionKey,
    { tree: false },
    now
  )
  return { digestId: id }
}

export function finishIssueDigestGeneration(
  database: IssueDatabase,
  id: string,
  result: {
    status: 'draft' | 'failed'
    sections: IssueDigestSections | null
    error: string | null
    searchable: boolean
  }
): IssueDigestRecord {
  const current = requireIssueDigest(database, id)
  if (current.status !== 'generating') {
    return current
  }
  const issue = requireIssueRecord(database, current.issueId)
  const now = Date.now()
  database.transaction(() => {
    const sections = result.sections ?? current
    const update = database
      .prepare(
        `UPDATE issue_digests
         SET status = ?, problem = ?, conclusion = ?, key_artifacts = ?,
             open_issues = ?, next_steps = ?, generation_error = ?,
             generation_finished_at = ?, updated_at = ?
         WHERE id = ? AND status = 'generating'`
      )
      .run(
        result.status,
        sections.problem,
        sections.conclusion,
        sections.keyArtifacts,
        sections.openIssues,
        sections.nextSteps,
        result.error === null
          ? null
          : clampUtf8TextPrefix(
              result.error,
              ISSUE_DIGEST_GENERATION_ERROR_MAX_BYTES
            ),
        now,
        now,
        id
      )
    if (update.changes === 1) {
      bumpIssueHostRevisions(
        database,
        issue.hostPartitionKey,
        { tree: false, searchable: result.searchable },
        now
      )
    }
  })
  return requireIssueDigest(database, id)
}

export function cancelIssueDigestGeneration(
  database: IssueDatabase,
  params: {
    identity: IssueMutationIdentity
    digestId: string
  }
): { digest: IssueDigestRecord; changed: boolean; replayed: boolean } {
  const receipt = executeIssueMutationWithReceipt<{
    digestId: string
    changed: boolean
  }>({
    database,
    identity: params.identity,
    method: 'issues.cancelDigest',
    payload: { digestId: params.digestId },
    operation: () => {
      const digest = requireIssueDigest(database, params.digestId)
      const issue = requireIssueRecord(database, digest.issueId)
      const now = Date.now()
      const update = database
        .prepare(
          `UPDATE issue_digests
           SET status = 'canceled',
               generation_error = NULL,
               generation_finished_at = ?,
               updated_at = ?
           WHERE id = ? AND status = 'generating'`
        )
        .run(now, now, digest.id)
      if (update.changes === 1) {
        bumpIssueHostRevisions(
          database,
          issue.hostPartitionKey,
          { tree: false },
          now
        )
      }
      return { digestId: digest.id, changed: update.changes === 1 }
    }
  })
  return {
    digest: requireIssueDigest(database, receipt.result.digestId),
    changed: receipt.result.changed,
    replayed: receipt.replayed
  }
}
