export const ISSUE_DATABASE_SUPPORT_SCHEMA = `
CREATE TABLE issue_digests (
  id                    TEXT PRIMARY KEY,
  issue_id              TEXT NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  version               INTEGER NOT NULL,
  revision              INTEGER NOT NULL DEFAULT 0 CHECK(revision >= 0),
  status                TEXT NOT NULL CHECK(status IN (
                          'generating', 'draft', 'failed', 'canceled', 'confirmed'
                        )),
  covers_until          INTEGER NOT NULL,
  problem               TEXT,
  conclusion            TEXT,
  key_artifacts         TEXT,
  open_issues           TEXT,
  next_steps            TEXT,
  coverage_note         TEXT,
  input_fingerprint     TEXT NOT NULL,
  generator_agent       TEXT,
  generation_id         TEXT,
  generation_error      TEXT,
  generation_started_at INTEGER,
  generation_finished_at INTEGER,
  created_at            INTEGER NOT NULL,
  updated_at            INTEGER NOT NULL,
  confirmed_at          INTEGER,
  UNIQUE(issue_id, version)
);
CREATE UNIQUE INDEX idx_issue_digest_one_generating
  ON issue_digests(issue_id)
  WHERE status = 'generating';

CREATE TABLE issue_digest_inputs (
  digest_id      TEXT NOT NULL REFERENCES issue_digests(id) ON DELETE CASCADE,
  input_kind     TEXT NOT NULL CHECK(input_kind IN (
                   'direct-round', 'direct-child-digest', 'user-artifact'
                 )),
  input_id       TEXT NOT NULL,
  input_version  INTEGER NOT NULL,
  title_snapshot TEXT,
  PRIMARY KEY(digest_id, input_kind, input_id)
);

CREATE TABLE issue_artifact_refs (
  id          TEXT PRIMARY KEY,
  issue_id    TEXT NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  source_kind TEXT NOT NULL CHECK(source_kind IN ('user', 'round', 'digest')),
  source_id   TEXT,
  ref_kind    TEXT NOT NULL CHECK(ref_kind IN ('file', 'url')),
  value       TEXT NOT NULL,
  label       TEXT,
  reachable   INTEGER,
  created_at  INTEGER NOT NULL,
  UNIQUE(issue_id, ref_kind, value)
);

CREATE TABLE issue_events (
  id                 TEXT PRIMARY KEY,
  host_partition_key TEXT NOT NULL,
  kind               TEXT NOT NULL CHECK(kind IN (
                       'created', 'metadata-updated', 'reparented', 'archived', 'reopened',
                       'deleted', 'conversation-bound', 'conversation-unbound',
                       'conversation-rebound', 'digest-confirmed', 'source-refreshed',
                       'profile-transferred-in', 'profile-transferred-out'
                     )),
  conversation_id    TEXT REFERENCES conversations(id) ON DELETE SET NULL,
  payload_json       TEXT NOT NULL,
  occurred_at        INTEGER NOT NULL,
  facts_revision     INTEGER NOT NULL,
  dedupe_key         TEXT,
  created_at         INTEGER NOT NULL,
  UNIQUE(host_partition_key, dedupe_key)
);
CREATE INDEX idx_issue_events_host_time
  ON issue_events(host_partition_key, occurred_at DESC, id);
CREATE INDEX idx_issue_events_conversation
  ON issue_events(conversation_id, occurred_at DESC);

CREATE TABLE issue_event_issue_refs (
  event_id             TEXT NOT NULL REFERENCES issue_events(id) ON DELETE CASCADE,
  issue_id             TEXT NOT NULL,
  role                 TEXT NOT NULL,
  issue_title_snapshot TEXT NOT NULL,
  PRIMARY KEY(event_id, issue_id, role)
);
CREATE INDEX idx_issue_event_refs_issue
  ON issue_event_issue_refs(issue_id, event_id);

CREATE TABLE issue_search_documents (
  rowid               INTEGER PRIMARY KEY,
  host_partition_key  TEXT NOT NULL,
  issue_id            TEXT,
  entity_kind         TEXT NOT NULL,
  entity_id           TEXT NOT NULL,
  title               TEXT NOT NULL DEFAULT '',
  body                TEXT NOT NULL DEFAULT '',
  keywords            TEXT NOT NULL DEFAULT '',
  completeness        TEXT,
  indexed_revision    INTEGER NOT NULL,
  UNIQUE(host_partition_key, entity_kind, entity_id)
);

CREATE VIRTUAL TABLE issue_search_fts USING fts5(
  title,
  body,
  keywords,
  content = 'issue_search_documents',
  content_rowid = 'rowid',
  tokenize = 'unicode61 remove_diacritics 2',
  prefix = '2 3'
);

CREATE TABLE issue_search_rebuild_queue (
  host_partition_key TEXT NOT NULL,
  entity_kind        TEXT NOT NULL,
  entity_id          TEXT NOT NULL,
  requested_revision INTEGER NOT NULL,
  PRIMARY KEY(host_partition_key, entity_kind, entity_id)
);

CREATE TABLE issue_mutation_receipts (
  caller_fingerprint TEXT NOT NULL,
  mutation_id        TEXT NOT NULL,
  method             TEXT NOT NULL,
  payload_hash       TEXT NOT NULL,
  state              TEXT NOT NULL CHECK(state IN ('pending', 'completed')),
  result_json        TEXT,
  created_at         INTEGER NOT NULL,
  updated_at         INTEGER NOT NULL,
  PRIMARY KEY(caller_fingerprint, mutation_id)
);
`
