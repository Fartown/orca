import type { AgentProviderSessionMetadata } from '../../shared/agent-session-resume'
import type { AgentStatusState, AgentType } from '../../shared/agent-status-types'
import type { ExecutionHostId } from '../../shared/execution-host'
import type { WorkspaceScope } from '../../shared/folder-workspace-types'
import type { WorkspaceSnapshot } from '../../shared/issues/types'
import { isTuiAgent } from '../../shared/tui-agent-config'
import {
  canonicalizeAgentSessionIdentityWithPathAccess,
  type AgentSessionIdentityPathAccess
} from '../runtime/agent-session-claim-identity'
import type { IssueRepository } from './issue-repository'
import { IssueRepositoryError } from './issue-repository-error'

export type ConversationHookIdentityContext = {
  executionHostId: ExecutionHostId
  workspaceRef: WorkspaceScope
  workspaceSnapshot: WorkspaceSnapshot
  processIncarnation: string | null
  connectionId: string | null
  hostPlatform: NodeJS.Platform
  wslDistro?: string | null
}

export type ConversationHookIdentityEvent = {
  paneKey: string
  worktreeId?: string
  connectionId?: string | null
  launchToken?: string
  providerSession?: AgentProviderSessionMetadata
  providerSessionOnly?: boolean
  restoredUnconfirmed?: true
  isReplay?: boolean
  payload: {
    state?: AgentStatusState
    agentType?: AgentType
  }
  receivedAt: number
}

export type ConversationHookIdentityIngestResult =
  | {
      disposition: 'attached' | 'created' | 'replayed'
      conversationId: string
    }
  | {
      disposition: 'ignored'
      reason:
        | 'identity-missing'
        | 'workspace-unresolved'
        | 'runtime-evidence-mismatch'
        | 'identity-invalid'
        | 'claim-unresolved'
    }

export type ConversationHookIdentityIngestorDependencies = {
  resolveContext(
    paneKey: string,
    expectedWorktreeId?: string
  ): Promise<ConversationHookIdentityContext | null>
  resolvePathAccess?(
    context: ConversationHookIdentityContext
  ): AgentSessionIdentityPathAccess | null
  onDiagnostic?(result: ConversationHookIdentityIngestResult, event: ConversationHookIdentityEvent): void
}

const CLAIM_RESOLUTION_ERRORS = new Set([
  'conversation_launch_claim_not_found',
  'conversation_launch_claim_invalid',
  'conversation_launch_claim_expired',
  'conversation_launch_claim_ambiguous'
])

export class ConversationHookIdentityIngestor {
  constructor(
    private readonly repository: IssueRepository,
    private readonly dependencies: ConversationHookIdentityIngestorDependencies
  ) {}

  async ingest(
    event: ConversationHookIdentityEvent
  ): Promise<ConversationHookIdentityIngestResult> {
    if (
      event.restoredUnconfirmed ||
      (event.isReplay && !event.launchToken) ||
      !event.providerSession ||
      !isTuiAgent(event.payload.agentType)
    ) {
      return this.finish({ disposition: 'ignored', reason: 'identity-missing' }, event)
    }
    const context = await this.dependencies
      .resolveContext(event.paneKey, event.worktreeId)
      .catch(() => null)
    if (!context) {
      return this.finish({ disposition: 'ignored', reason: 'workspace-unresolved' }, event)
    }
    if (
      event.connectionId !== undefined &&
      (event.connectionId ?? null) !== context.connectionId
    ) {
      return this.finish(
        { disposition: 'ignored', reason: 'runtime-evidence-mismatch' },
        event
      )
    }

    let providerSession: AgentProviderSessionMetadata
    try {
      const pathAccess = this.dependencies.resolvePathAccess?.(context) ?? undefined
      if (
        (event.payload.agentType === 'pi' || event.payload.agentType === 'prime-agent') &&
        context.connectionId &&
        !pathAccess
      ) {
        throw new Error('agent_session_identity_required')
      }
      providerSession = (
        await canonicalizeAgentSessionIdentityWithPathAccess(
          event.payload.agentType,
          event.providerSession,
          pathAccess
        )
      ).providerSession
    } catch {
      return this.finish({ disposition: 'ignored', reason: 'identity-invalid' }, event)
    }

    if (event.launchToken) {
      try {
        const attached = this.repository.conversationAllocator.attachProviderIdentity({
          executionHostId: context.executionHostId,
          agent: event.payload.agentType,
          providerSession,
          resumeLocator: providerSession.transcriptPath ?? null,
          launchToken: event.launchToken,
          paneKey: event.paneKey,
          processIncarnation: context.processIncarnation,
          connectionId: context.connectionId,
          observedAt: event.receivedAt
        })
        return this.finish(
          { disposition: 'attached', conversationId: attached.conversation.id },
          event
        )
      } catch (error) {
        if (
          error instanceof IssueRepositoryError &&
          CLAIM_RESOLUTION_ERRORS.has(error.code)
        ) {
          return this.finish({ disposition: 'ignored', reason: 'claim-unresolved' }, event)
        }
        throw error
      }
    }

    const resolved = this.repository.conversationAllocator.resolveObservedIdentityOrAllocate({
      executionHostId: context.executionHostId,
      workspaceRef: context.workspaceRef,
      workspaceSnapshot: context.workspaceSnapshot,
      agent: event.payload.agentType,
      issueId: null,
      providerSession,
      resumeLocator: providerSession.transcriptPath ?? null,
      observedAt: event.receivedAt
    })
    return this.finish(
      {
        disposition: resolved.disposition,
        conversationId: resolved.conversation.id
      },
      event
    )
  }

  private finish(
    result: ConversationHookIdentityIngestResult,
    event: ConversationHookIdentityEvent
  ): ConversationHookIdentityIngestResult {
    this.dependencies.onDiagnostic?.(result, event)
    return result
  }
}
