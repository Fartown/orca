export const ISSUE_DATABASE_ROUND_SCHEMA = `
CREATE TABLE round_records (
  id                       TEXT PRIMARY KEY,
  conversation_id          TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  kind                     TEXT NOT NULL CHECK(kind IN ('completion', 'waiting')),
  state_source             TEXT NOT NULL CHECK(state_source IN ('hook', 'scrape', 'reconciled')),
  occurred_at              INTEGER NOT NULL,
  dedupe_key               TEXT NOT NULL UNIQUE,
  execution_chain_id       TEXT,
  supersedes_round_id      TEXT REFERENCES round_records(id) ON DELETE RESTRICT,
  user_input               TEXT,
  user_input_completeness  TEXT NOT NULL,
  user_input_storage       TEXT NOT NULL DEFAULT 'none'
                           CHECK(user_input_storage IN (
                             'none', 'preview', 'full', 'evicted-preview',
                             'evicted', 'deleted'
                           )),
  user_input_bytes         INTEGER NOT NULL DEFAULT 0 CHECK(user_input_bytes >= 0),
  user_input_preview       TEXT,
  user_input_preview_bytes INTEGER NOT NULL DEFAULT 0
                           CHECK(user_input_preview_bytes >= 0),
  agent_output             TEXT,
  output_completeness      TEXT NOT NULL,
  output_storage           TEXT NOT NULL DEFAULT 'none'
                           CHECK(output_storage IN (
                             'none', 'preview', 'full', 'evicted-preview',
                             'evicted', 'deleted'
                           )),
  output_bytes             INTEGER NOT NULL DEFAULT 0 CHECK(output_bytes >= 0),
  output_preview           TEXT,
  output_preview_bytes     INTEGER NOT NULL DEFAULT 0
                           CHECK(output_preview_bytes >= 0),
  pending_question         TEXT,
  question_completeness    TEXT NOT NULL,
  question_storage         TEXT NOT NULL DEFAULT 'none'
                           CHECK(question_storage IN (
                             'none', 'preview', 'full', 'evicted-preview',
                             'evicted', 'deleted'
                           )),
  question_bytes           INTEGER NOT NULL DEFAULT 0 CHECK(question_bytes >= 0),
  question_preview         TEXT,
  question_preview_bytes   INTEGER NOT NULL DEFAULT 0
                           CHECK(question_preview_bytes >= 0),
  read_at                  INTEGER,
  resolved_at              INTEGER,
  resolution               TEXT CHECK(
                             resolution IS NULL OR
                             resolution IN ('new-input', 'explicit', 'archive', 'resumed')
                           ),
  finalized_at             INTEGER,
  body_evicted_at          INTEGER,
  body_deleted_at          INTEGER,
  body_revision            INTEGER NOT NULL DEFAULT 0 CHECK(body_revision >= 0),
  created_at               INTEGER NOT NULL,
  CHECK(supersedes_round_id IS NULL OR supersedes_round_id <> id),
  CHECK(
    (resolved_at IS NULL AND resolution IS NULL) OR
    (resolved_at IS NOT NULL AND resolution IS NOT NULL)
  )
);
CREATE INDEX idx_rounds_conversation
  ON round_records(conversation_id, occurred_at DESC);
CREATE INDEX idx_rounds_resolution
  ON round_records(resolved_at, kind, occurred_at DESC);
CREATE INDEX idx_rounds_execution_chain
  ON round_records(conversation_id, execution_chain_id, occurred_at DESC);
CREATE UNIQUE INDEX idx_rounds_one_direct_successor
  ON round_records(supersedes_round_id)
  WHERE supersedes_round_id IS NOT NULL;

CREATE VIEW round_record_effective_state AS
SELECT
  round.*,
  CASE
    WHEN round.resolved_at IS NOT NULL THEN round.resolved_at
    WHEN successor.id IS NOT NULL THEN successor.occurred_at
    ELSE NULL
  END AS effective_resolved_at,
  CASE
    WHEN round.resolved_at IS NOT NULL THEN round.resolution
    WHEN successor.id IS NOT NULL THEN 'superseded'
    ELSE NULL
  END AS effective_resolution
FROM round_records round
LEFT JOIN round_records successor
  ON successor.supersedes_round_id = round.id;

CREATE TABLE round_refs (
  round_id  TEXT NOT NULL REFERENCES round_records(id) ON DELETE CASCADE,
  ref_kind TEXT NOT NULL,
  value    TEXT NOT NULL,
  reachable INTEGER,
  PRIMARY KEY(round_id, ref_kind, value)
);
CREATE UNIQUE INDEX idx_round_refs_provider_turn
  ON round_refs(ref_kind, value)
  WHERE ref_kind = 'provider-turn';
`
