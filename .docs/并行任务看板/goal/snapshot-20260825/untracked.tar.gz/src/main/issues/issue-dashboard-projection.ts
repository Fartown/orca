import type {
  IssueDashboardProjection,
  IssueDashboardPaneProjection
} from '../../shared/issues/types'
import type { IssueAuthorityRoute } from './issue-authority-route'
import { issueAuthorityDescriptor } from './issue-authority-route'
import type { IssueDatabase } from './issue-database'
import {
  readHostRevisions,
  toRoundRecordPreview
} from './issue-query-projections'
import {
  roundRecordFromRow,
  type RoundRecordRow
} from './issue-row-mappers'

type DashboardProjectionRow = RoundRecordRow & {
  pane_key: string
  projected_conversation_id: string
  issue_id: string | null
  issue_title: string | null
  issue_type_label: string | null
  issue_state: 'active' | 'archived' | null
  round_id: string | null
}

export class IssueDashboardProjectionQuery {
  constructor(private readonly database: IssueDatabase) {}

  project(
    route: IssueAuthorityRoute,
    paneKeys: readonly string[]
  ): IssueDashboardProjection {
    return this.database.readTransaction(() =>
      this.projectWithinTransaction(route, paneKeys)
    )
  }

  projectWithinTransaction(
    route: IssueAuthorityRoute,
    paneKeys: readonly string[]
  ): IssueDashboardProjection {
    const revisions = readHostRevisions(this.database, route.hostPartitionKey)
    return {
      authority: issueAuthorityDescriptor(this.database, route),
      snapshotFactsRevision: revisions.factsRevision,
      panes: this.readPanes(route, [...new Set(paneKeys)])
    }
  }

  private readPanes(
    route: IssueAuthorityRoute,
    paneKeys: readonly string[]
  ): IssueDashboardPaneProjection[] {
    if (paneKeys.length === 0) {
      return []
    }
    const placeholders = paneKeys.map(() => '?').join(', ')
    const rows = this.database
      .prepare(
        `SELECT
           claim.pane_key,
           conversation.id AS projected_conversation_id,
           issue.id AS issue_id,
           CASE
             WHEN issue.source_kind = 'local' THEN issue.local_title
             ELSE issue.source_title
           END AS issue_title,
           issue.type_label AS issue_type_label,
           issue.state AS issue_state,
           round.id AS round_id,
           round.*
         FROM conversation_launch_claims claim
         JOIN conversations conversation ON conversation.id = claim.conversation_id
         LEFT JOIN issues issue ON issue.id = conversation.issue_id
         LEFT JOIN round_record_effective_state round
           ON round.id = (
             SELECT candidate.id
             FROM round_record_effective_state candidate
             WHERE candidate.conversation_id = conversation.id
             ORDER BY candidate.occurred_at DESC, candidate.id DESC
             LIMIT 1
           )
         WHERE claim.host_partition_key = ?
           AND conversation.host_partition_key = ?
           AND claim.pane_key IN (${placeholders})
           AND NOT EXISTS (
             SELECT 1
             FROM conversation_launch_claims newer
             WHERE newer.host_partition_key = claim.host_partition_key
               AND newer.pane_key = claim.pane_key
               AND (
                 newer.created_at > claim.created_at OR
                 (newer.created_at = claim.created_at AND newer.claim_id > claim.claim_id)
               )
           )
         ORDER BY claim.pane_key`
      )
      .all(route.hostPartitionKey, route.hostPartitionKey, ...paneKeys) as
      DashboardProjectionRow[]
    return rows.map((row) => ({
      paneKey: row.pane_key,
      conversationId: row.projected_conversation_id,
      issue:
        row.issue_id && row.issue_title && row.issue_state
          ? {
              id: row.issue_id,
              title: row.issue_title,
              typeLabel: row.issue_type_label,
              state: row.issue_state
            }
          : null,
      latestRound:
        row.round_id === null
          ? null
          : toRoundRecordPreview(roundRecordFromRow({ ...row, id: row.round_id }))
    }))
  }
}
