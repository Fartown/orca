import React, { useEffect, useState } from 'react'
import { AlertTriangle, Loader2 } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import type {
  IssueDigestConfirmationResult,
  IssueDigestPreparation,
  IssueDigestProjection,
  IssueDigestRecord,
  IssueDigestSections
} from '../../../../shared/issues/digest-types'
import type { TuiAgent } from '../../../../shared/tui-agent'

type IssueDigestProps = {
  projection?: IssueDigestProjection
  preparation?: IssueDigestPreparation | null
  activeAttempt?: IssueDigestRecord | null
  confirmation?: IssueDigestConfirmationResult | null
  status?: 'idle' | 'loading' | 'ready' | 'unsupported' | 'error'
  error?: string | null
  onPrepare?: () => void
  onGenerate?: (agent: TuiAgent) => void
  onUpdateDraft?: (patch: IssueDigestSections) => void
  onConfirm?: (confirmStaleAgainstFingerprint?: string) => void
  onCancel?: () => void
}

export function IssueDigest({
  projection,
  preparation = null,
  activeAttempt,
  confirmation = null,
  status = 'idle',
  error = null,
  onPrepare,
  onGenerate,
  onUpdateDraft,
  onConfirm,
  onCancel
}: IssueDigestProps): React.JSX.Element {
  const attempt = activeAttempt ?? projection?.latestAttempt ?? null
  const [draft, setDraft] = useState<IssueDigestSections>(() =>
    digestSections(attempt)
  )

  useEffect(() => {
    setDraft(digestSections(attempt))
  }, [attempt?.id, attempt?.revision])

  return (
    <section aria-labelledby="issue-current-answer-heading">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <h2 id="issue-current-answer-heading" className="text-sm font-semibold">
          Current answer
        </h2>
        {projection?.latestConfirmedIsStale ? (
          <Badge variant="outline">
            <AlertTriangle className="size-3" />
            Summary is out of date
          </Badge>
        ) : null}
        {attempt ? <Badge variant="secondary">{attempt.status}</Badge> : null}
      </div>
      {projection?.latestConfirmed ? (
        <DigestSections digest={projection.latestConfirmed} />
      ) : (
        <div className="rounded-lg border border-dashed border-border/70 bg-muted/20 px-4 py-4">
          <p className="text-sm font-medium">No confirmed summary yet.</p>
          <p className="mt-1 text-xs leading-5 text-muted-foreground">
            Recent source records remain available below with their capture
            completeness and storage state.
          </p>
        </div>
      )}
      <div className="mt-3 space-y-3 rounded-lg border border-border/60 bg-card/40 p-3">
        <DigestCoverage preparation={preparation} />
        {attempt?.status === 'draft' ? (
          <DigestDraftEditor
            draft={draft}
            disabled={status === 'loading'}
            onChange={setDraft}
            onSave={() => onUpdateDraft?.(draft)}
            onConfirm={() => onConfirm?.()}
          />
        ) : null}
        {attempt?.status === 'generating' ? (
          <div className="flex items-center justify-between gap-3 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <Loader2 className="size-3 animate-spin" />
              Generating a bounded draft from the frozen inputs.
            </span>
            {onCancel ? (
              <Button type="button" size="xs" variant="outline" onClick={onCancel}>
                Cancel generation
              </Button>
            ) : null}
          </div>
        ) : null}
        {confirmation?.status === 'stale' ? (
          <div className="rounded-md border border-border/60 bg-muted/30 p-3 text-xs">
            <p className="font-medium text-foreground">
              Source records changed before confirmation.
            </p>
            <p className="mt-1 text-muted-foreground">
              {confirmation.changeSummary}
            </p>
            {onConfirm ? (
              <Button
                type="button"
                size="xs"
                variant="outline"
                className="mt-2"
                onClick={() =>
                  onConfirm(confirmation.currentInputFingerprint)
                }
              >
                Confirm this stale summary
              </Button>
            ) : null}
          </div>
        ) : null}
        {error ? (
          <p role="alert" className="text-xs text-destructive">
            {error}
          </p>
        ) : null}
        <div className="flex flex-wrap gap-2">
          {onPrepare ? (
            <Button
              type="button"
              size="xs"
              variant="outline"
              disabled={status === 'loading'}
              onClick={onPrepare}
            >
              Prepare summary
            </Button>
          ) : null}
          {preparation && onGenerate && attempt?.status !== 'generating' ? (
            <Button
              type="button"
              size="xs"
              disabled={status === 'loading'}
              onClick={() => onGenerate('codex')}
            >
              Generate with codex
            </Button>
          ) : null}
        </div>
      </div>
    </section>
  )
}

function DigestCoverage({
  preparation
}: {
  preparation: IssueDigestPreparation | null
}): React.JSX.Element | null {
  if (!preparation) {
    return null
  }
  return (
    <div className="text-xs text-muted-foreground">
      <div className="flex flex-wrap items-center gap-2">
        <Badge variant={preparation.coverage.complete ? 'secondary' : 'outline'}>
          {preparation.coverage.complete ? 'Coverage complete' : 'Coverage incomplete'}
        </Badge>
        <span>
          {preparation.coverage.includedInputCount}/
          {preparation.coverage.totalInputCount} inputs ·{' '}
          {preparation.coverage.includedUtf8Bytes}/
          {preparation.coverage.totalUtf8Bytes} bytes
        </span>
      </div>
      {preparation.coverage.note ? (
        <p className="mt-1 leading-5">{preparation.coverage.note}</p>
      ) : null}
    </div>
  )
}

function DigestSections({
  digest
}: {
  digest: IssueDigestRecord
}): React.JSX.Element {
  const sections = [
    ['Problem', digest.problem],
    ['Conclusion', digest.conclusion],
    ['Key artifacts', digest.keyArtifacts],
    ['Open issues', digest.openIssues],
    ['Next steps', digest.nextSteps]
  ] as const
  return (
    <div className="grid gap-3 rounded-lg border border-border/60 bg-card/40 p-4">
      {sections
        .map(([label, value]) =>
          value ? (
            <div key={label}>
              <h3 className="text-xs font-medium text-muted-foreground">{label}</h3>
              <p className="mt-1 whitespace-pre-wrap text-sm leading-6">{value}</p>
            </div>
          ) : null
        )}
    </div>
  )
}

function DigestDraftEditor({
  draft,
  disabled,
  onChange,
  onSave,
  onConfirm
}: {
  draft: IssueDigestSections
  disabled: boolean
  onChange: (draft: IssueDigestSections) => void
  onSave: () => void
  onConfirm: () => void
}): React.JSX.Element {
  return (
    <div className="grid gap-2">
      {(
        [
          ['problem', 'Problem'],
          ['conclusion', 'Conclusion'],
          ['keyArtifacts', 'Key artifacts'],
          ['openIssues', 'Open issues'],
          ['nextSteps', 'Next steps']
        ] as const
      ).map(([field, label]) => (
        <label key={field} className="grid gap-1 text-xs font-medium">
          {label}
          <Textarea
            aria-label={label}
            rows={field === 'conclusion' ? 4 : 2}
            value={draft[field] ?? ''}
            disabled={disabled}
            onChange={(event) =>
              onChange({
                ...draft,
                [field]: event.target.value.trim() ? event.target.value : null
              })
            }
          />
        </label>
      ))}
      <div className="flex flex-wrap gap-2">
        <Button type="button" size="xs" variant="outline" disabled={disabled} onClick={onSave}>
          Save draft
        </Button>
        <Button type="button" size="xs" disabled={disabled} onClick={onConfirm}>
          Confirm summary
        </Button>
      </div>
    </div>
  )
}

function digestSections(digest: IssueDigestRecord | null): IssueDigestSections {
  return {
    problem: digest?.problem ?? null,
    conclusion: digest?.conclusion ?? null,
    keyArtifacts: digest?.keyArtifacts ?? null,
    openIssues: digest?.openIssues ?? null,
    nextSteps: digest?.nextSteps ?? null
  }
}
