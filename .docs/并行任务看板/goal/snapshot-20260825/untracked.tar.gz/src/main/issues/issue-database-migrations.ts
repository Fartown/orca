import type SyncDatabase from '../sqlite/sync-database'
import { ISSUE_DATABASE_CORE_SCHEMA } from './issue-database-core-schema'
import { ISSUE_DATABASE_ROUND_SCHEMA } from './issue-database-round-schema'
import { ISSUE_DATABASE_SUPPORT_SCHEMA } from './issue-database-support-schema'

export const ISSUE_DATABASE_SCHEMA_VERSION = 5

export type IssueDatabaseMigrationHooks = {
  beforeVersionBump?: (targetVersion: number) => void
}

export function migrateIssueDatabase(
  database: SyncDatabase.Database,
  hooks: IssueDatabaseMigrationHooks = {}
): void {
  const storedVersion = Number(database.pragma('user_version', { simple: true }) ?? 0)
  if (storedVersion > ISSUE_DATABASE_SCHEMA_VERSION) {
    throw new Error(
      `Issue database version ${storedVersion} is newer than supported version ${ISSUE_DATABASE_SCHEMA_VERSION}.`
    )
  }
  if (storedVersion === ISSUE_DATABASE_SCHEMA_VERSION) {
    return
  }

  database.exec('BEGIN IMMEDIATE')
  try {
    if (storedVersion < 1) {
      database.exec(ISSUE_DATABASE_CORE_SCHEMA)
      database.exec(ISSUE_DATABASE_ROUND_SCHEMA)
      database.exec(ISSUE_DATABASE_SUPPORT_SCHEMA)
    } else {
      if (storedVersion < 2) {
        database.exec(`
          ALTER TABLE conversations ADD COLUMN launch_failure TEXT;
          CREATE UNIQUE INDEX idx_launch_claim_active_token
            ON conversation_launch_claims(host_partition_key, launch_token_hash)
            WHERE consumed_at IS NULL;
          CREATE INDEX idx_launch_claim_pane
            ON conversation_launch_claims(
              host_partition_key, pane_key, consumed_at, expires_at
            );
        `)
      }
      if (storedVersion < 3) {
        database.exec(`
          CREATE UNIQUE INDEX idx_round_refs_provider_turn
            ON round_refs(ref_kind, value)
            WHERE ref_kind = 'provider-turn';
        `)
      }
      if (storedVersion < 4) {
        database.exec(`
          ALTER TABLE issues ADD COLUMN source_refresh_attempted_at INTEGER;
          ALTER TABLE issues ADD COLUMN source_refresh_error TEXT;
          ALTER TABLE issues ADD COLUMN source_availability TEXT
            CHECK(
              source_availability IS NULL OR
              source_availability IN ('available', 'unavailable')
            );
          UPDATE issues
          SET source_refresh_attempted_at = source_synced_at,
              source_availability = 'available'
          WHERE source_kind = 'external';
        `)
      }
      if (storedVersion < 5) {
        database.exec(`
          ALTER TABLE issue_digest_inputs RENAME TO issue_digest_inputs_v4;
          CREATE TABLE issue_digest_inputs (
            digest_id      TEXT NOT NULL REFERENCES issue_digests(id) ON DELETE CASCADE,
            input_kind     TEXT NOT NULL CHECK(input_kind IN (
                             'direct-round', 'direct-child-digest', 'user-artifact'
                           )),
            input_id       TEXT NOT NULL,
            input_version  INTEGER NOT NULL,
            title_snapshot TEXT,
            PRIMARY KEY(digest_id, input_kind, input_id)
          );
          INSERT INTO issue_digest_inputs (
            digest_id, input_kind, input_id, input_version, title_snapshot
          )
          SELECT digest_id, input_kind, input_id, input_version, title_snapshot
          FROM issue_digest_inputs_v4;
          DROP TABLE issue_digest_inputs_v4;
        `)
      }
    }
    hooks.beforeVersionBump?.(ISSUE_DATABASE_SCHEMA_VERSION)
    database.pragma(`user_version = ${ISSUE_DATABASE_SCHEMA_VERSION}`)
    database.exec('COMMIT')
  } catch (error) {
    database.exec('ROLLBACK')
    throw error
  }
}
