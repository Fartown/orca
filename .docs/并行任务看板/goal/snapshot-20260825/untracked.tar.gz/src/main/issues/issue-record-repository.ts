import { randomUUID } from 'node:crypto'
import type {
  DeleteIssuePreparation,
  IssueRecord
} from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { IssueDeleteRepository } from './issue-delete-repository'
import { issueEventRef, IssueEventRepository } from './issue-event-repository'
import { ExternalIssueRepository } from './external-issue-repository'
import { IssueHierarchyMutation } from './issue-hierarchy-mutation'
import { assertIssueParent } from './issue-hierarchy-validation'
import { bumpIssueHostRevisions, ensureIssueHostState } from './issue-host-state'
import { hostPartitionForExecutionHost } from './issue-host-partition'
import { IssueLifecycleRepository } from './issue-lifecycle-repository'
import { executeIssueMutation } from './issue-mutation-receipt'
import {
  allocateLocalIssueNumber,
  getIssueRecord,
  listIssueRecords,
  requireIssueRecord
} from './issue-record-queries'
import { IssueRepositoryError } from './issue-repository-error'
import { insertIssueAtSiblingIndex } from './issue-sibling-order'
import type {
  ArchiveIssueInput,
  ArchiveIssueResult,
  CommitDeleteIssueInput,
  CommitDeleteIssueResult,
  CreateIssueInput,
  FailExternalIssueRefreshInput,
  IssueListFilter,
  IssueMutationParams,
  RefreshExternalIssueInput,
  ReopenIssueInput,
  ReparentIssueInput,
  ReparentIssueResult,
  TrackExternalIssueInput,
  UpdateIssueInput
} from './issue-repository-types'

export type IssueRecordRepositoryDependencies = {
  events: IssueEventRepository
  hierarchy: IssueHierarchyMutation
  lifecycle: IssueLifecycleRepository
  deletion: IssueDeleteRepository
  external: ExternalIssueRepository
}

export class IssueRecordRepository {
  constructor(
    private readonly database: IssueDatabase,
    private readonly dependencies: IssueRecordRepositoryDependencies
  ) {}

  create(params: IssueMutationParams<CreateIssueInput>): IssueRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.create',
      payload: params.input,
      operation: () => this.createRecord(params.input)
    })
  }

  trackExternal(params: IssueMutationParams<TrackExternalIssueInput>): IssueRecord {
    return this.dependencies.external.track(params)
  }

  refreshExternal(params: IssueMutationParams<RefreshExternalIssueInput>): IssueRecord {
    return this.dependencies.external.refresh(params)
  }

  failExternalRefresh(
    params: IssueMutationParams<FailExternalIssueRefreshInput>
  ): IssueRecord {
    return this.dependencies.external.recordRefreshFailure(params)
  }

  get(id: string): IssueRecord | undefined {
    return getIssueRecord(this.database, id)
  }

  list(filter: IssueListFilter = {}): IssueRecord[] {
    return listIssueRecords(this.database, filter)
  }

  update(params: IssueMutationParams<UpdateIssueInput>): IssueRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.update',
      payload: params.input,
      operation: () => this.updateRecord(params.input)
    })
  }

  reparent(params: IssueMutationParams<ReparentIssueInput>): ReparentIssueResult {
    return this.dependencies.hierarchy.reparent(params)
  }

  archive(params: IssueMutationParams<ArchiveIssueInput>): ArchiveIssueResult {
    return this.dependencies.lifecycle.archive(params)
  }

  reopen(params: IssueMutationParams<ReopenIssueInput>): IssueRecord {
    return this.dependencies.lifecycle.reopen(params)
  }

  prepareDelete(id: string): DeleteIssuePreparation {
    return this.dependencies.deletion.prepare(id)
  }

  delete(
    params: IssueMutationParams<CommitDeleteIssueInput>
  ): CommitDeleteIssueResult {
    return this.dependencies.deletion.commit(params)
  }

  private createRecord(input: CreateIssueInput): IssueRecord {
    const title = input.title.trim()
    if (!title) {
      throw new Error('Local Issue title cannot be empty.')
    }
    const hostPartitionKey = hostPartitionForExecutionHost(input.executionHostId)
    const now = Date.now()
    ensureIssueHostState(this.database, hostPartitionKey, now)
    assertIssueParent({
      database: this.database,
      parentId: input.parentId ?? null,
      hostPartitionKey,
      executionHostId: input.executionHostId
    })
    const id = randomUUID()
    const number = allocateLocalIssueNumber(this.database, hostPartitionKey)
    this.database
      .prepare(
        `INSERT INTO issues (
           id, host_partition_key, execution_host_id, source_kind,
           source_provider, source_scope_key, source_external_id, source_number,
           source_identifier, source_url, source_title, source_state, source_synced_at,
           source_refresh_attempted_at, source_refresh_error, source_availability,
           source_context_json, native_parent_json, local_title, type_label, note,
           state, parent_id, sibling_order, created_at, updated_at, archived_at
         ) VALUES (
           ?, ?, ?, 'local', NULL, NULL, NULL, ?,
           NULL, NULL, NULL, NULL, NULL,
           NULL, NULL, NULL, NULL, NULL, ?, ?, ?,
           'active', ?, 0, ?, ?, NULL
         )`
      )
      .run(
        id,
        hostPartitionKey,
        input.executionHostId,
        number,
        title,
        input.typeLabel ?? null,
        input.note ?? null,
        input.parentId ?? null,
        now,
        now
      )
    insertIssueAtSiblingIndex({
      database: this.database,
      hostPartitionKey,
      parentId: input.parentId ?? null,
      issueId: id,
      index: input.index,
      now
    })
    const revisions = bumpIssueHostRevisions(
      this.database,
      hostPartitionKey,
      { tree: true, searchable: true },
      now
    )
    const issue = requireIssueRecord(this.database, id)
    this.dependencies.events.appendWithinTransaction({
      hostPartitionKey,
      kind: 'created',
      issueRefs: [issueEventRef(issue, 'issue')],
      payload: { sourceKind: 'local' },
      occurredAt: now,
      factsRevision: revisions.factsRevision
    })
    return issue
  }

  private updateRecord(input: UpdateIssueInput): IssueRecord {
    if (Object.hasOwn(input, 'executionHostId')) {
      throw new IssueRepositoryError(
        'issue_host_immutable',
        `Issue ${input.id} cannot change executionHostId.`
      )
    }
    for (const field of ['state', 'archivedAt', 'parentId']) {
      if (Object.hasOwn(input, field)) {
        throw new IssueRepositoryError(
          'issue_operation_requires_specialized_mutation',
          `Issue ${field} must use its dedicated mutation.`
        )
      }
    }
    const current = requireIssueRecord(this.database, input.id)
    if (current.source.kind === 'external' && Object.hasOwn(input, 'localTitle')) {
      throw new IssueRepositoryError(
        'external_issue_source_invalid',
        'External Issue titles are provider-owned.'
      )
    }
    const localTitle = Object.hasOwn(input, 'localTitle')
      ? (input.localTitle?.trim() || null)
      : current.localTitle
    if (current.source.kind === 'local' && !localTitle) {
      throw new Error('Local Issue title cannot be empty.')
    }
    const typeLabel = Object.hasOwn(input, 'typeLabel')
      ? (input.typeLabel ?? null)
      : current.typeLabel
    const note = Object.hasOwn(input, 'note') ? (input.note ?? null) : current.note
    if (
      localTitle === current.localTitle &&
      typeLabel === current.typeLabel &&
      note === current.note
    ) {
      return current
    }

    const now = Date.now()
    this.database
      .prepare(
        `UPDATE issues
         SET local_title = ?, type_label = ?, note = ?, updated_at = ?
         WHERE id = ?`
      )
      .run(localTitle, typeLabel, note, now, current.id)
    const revisions = bumpIssueHostRevisions(
      this.database,
      current.hostPartitionKey,
      { tree: false, searchable: true },
      now
    )
    const issue = requireIssueRecord(this.database, current.id)
    this.dependencies.events.appendWithinTransaction({
      hostPartitionKey: current.hostPartitionKey,
      kind: 'metadata-updated',
      issueRefs: [issueEventRef(issue, 'issue')],
      payload: {
        fields: [
          ...(localTitle !== current.localTitle ? ['localTitle'] : []),
          ...(typeLabel !== current.typeLabel ? ['typeLabel'] : []),
          ...(note !== current.note ? ['note'] : [])
        ]
      },
      occurredAt: now,
      factsRevision: revisions.factsRevision
    })
    return issue
  }
}
