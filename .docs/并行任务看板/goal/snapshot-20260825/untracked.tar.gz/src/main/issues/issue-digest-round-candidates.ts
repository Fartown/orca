import type {
  IssueDigestInputCompleteness
} from '../../shared/issues/digest-types'
import type { IssueRecord, RoundRecord } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import type { IssueDigestInputCandidate } from './issue-digest-input-candidate'
import { roundRecordFromRow, type RoundRecordRow } from './issue-row-mappers'
import { createHash } from 'node:crypto'

type RoundCandidateRow = RoundRecordRow & {
  conversation_title: string | null
  workspace_name_snapshot: string
}

export function readOutstandingDigestRoundCandidates(
  database: IssueDatabase,
  issue: IssueRecord,
  coversUntil: number
): IssueDigestInputCandidate[] {
  return readDigestRoundCandidates(database, issue, coversUntil, true)
}

export function readResolvedDigestRoundCandidates(
  database: IssueDatabase,
  issue: IssueRecord,
  coversUntil: number
): IssueDigestInputCandidate[] {
  return readDigestRoundCandidates(database, issue, coversUntil, false)
}

function readDigestRoundCandidates(
  database: IssueDatabase,
  issue: IssueRecord,
  coversUntil: number,
  outstanding: boolean
): IssueDigestInputCandidate[] {
  const rows = database
    .prepare(
      `SELECT round.*, conversation.title AS conversation_title,
              conversation.workspace_name_snapshot
       FROM round_record_effective_state round
       JOIN conversations conversation ON conversation.id = round.conversation_id
       WHERE conversation.host_partition_key = ?
         AND conversation.issue_id = ?
         AND round.occurred_at <= ?
         AND round.effective_resolved_at IS ${outstanding ? '' : 'NOT '}NULL
       ORDER BY round.occurred_at DESC, round.id`
    )
    .all(issue.hostPartitionKey, issue.id, coversUntil) as RoundCandidateRow[]
  return rows.map(roundDigestCandidate)
}

function roundDigestCandidate(row: RoundCandidateRow): IssueDigestInputCandidate {
  const round = roundRecordFromRow(row)
  const materialized = materializeRoundForDigest(round)
  return {
    kind: 'direct-round',
    inputId: round.id,
    inputVersion: round.bodyRevision,
    titleSnapshot:
      row.conversation_title ?? row.workspace_name_snapshot ?? `Round ${round.id}`,
    occurredAt: round.occurredAt,
    content: materialized.content,
    sourceCompleteness: materialized.completeness,
    sourceFingerprint: {
      bodyRevision: round.bodyRevision,
      kind: round.kind,
      effectiveResolvedAt: round.effectiveResolvedAt,
      effectiveResolution: round.effectiveResolution,
      userInput: roundTextFingerprint(round.userInput),
      agentOutput: roundTextFingerprint(round.agentOutput),
      pendingQuestion: roundTextFingerprint(round.pendingQuestion),
      contentHash: createHash('sha256').update(materialized.content).digest('hex')
    }
  }
}

function materializeRoundForDigest(round: RoundRecord): {
  content: string
  completeness: IssueDigestInputCompleteness
} {
  const fields = [
    ['User input', round.userInput],
    ['Agent output', round.agentOutput],
    ['Pending question', round.pendingQuestion]
  ] as const
  const sections: string[] = [
    `Kind: ${round.kind}`,
    `Occurred at: ${new Date(round.occurredAt).toISOString()}`,
    `Effective state: ${round.effectiveResolvedAt === null ? 'outstanding' : `resolved (${round.effectiveResolution ?? 'unknown'})`}`
  ]
  let partial = false
  let captured = false
  for (const [label, field] of fields) {
    const text = field.text ?? field.preview
    if (text) {
      captured = true
      sections.push(
        `${label} [${field.completeness}; storage=${field.storage}]:\n${text}`
      )
    }
    if (field.completeness !== 'complete' || field.storage !== 'full') {
      partial = true
    }
  }
  return {
    content: sections.join('\n\n'),
    completeness: captured ? (partial ? 'partial' : 'complete') : 'unavailable'
  }
}

function roundTextFingerprint(text: RoundRecord['userInput']): unknown {
  return {
    completeness: text.completeness,
    storage: text.storage,
    bytes: text.bytes,
    previewBytes: text.previewBytes
  }
}
