import { useEffect, useMemo, useRef } from 'react'
import { useStore } from 'zustand'
import type { DashboardSnapshot } from '../../../shared/dashboard-snapshot'
import { acquireIssueDashboardEvents } from './issue-dashboard-event-lease'
import { issueDashboardStore } from './issue-dashboard-store'
import { overlayIssueDashboardSnapshot } from './issue-dashboard-overlay'

export function useIssueDashboardSnapshot(
  snapshot: DashboardSnapshot
): DashboardSnapshot {
  const partitionsByRoute = useStore(
    issueDashboardStore,
    (state) => state.partitionsByRoute
  )
  const firstSyncRef = useRef(true)

  useEffect(() => {
    void issueDashboardStore.getState().syncCards(snapshot.cards, {
      forceRefresh: firstSyncRef.current
    })
    firstSyncRef.current = false
  }, [snapshot.cards])

  useEffect(() => acquireIssueDashboardEvents(), [])

  return useMemo(
    () => overlayIssueDashboardSnapshot(snapshot, partitionsByRoute),
    [partitionsByRoute, snapshot]
  )
}
