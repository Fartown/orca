import { randomUUID } from 'node:crypto'
import type { IssueRecord } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import {
  externalIssueSourceScopeKey,
  normalizeExternalIssueSourceContext
} from './external-issue-source-identity'
import { issueEventRef, IssueEventRepository } from './issue-event-repository'
import { assertIssueParent } from './issue-hierarchy-validation'
import { bumpIssueHostRevisions, ensureIssueHostState } from './issue-host-state'
import { hostPartitionForExecutionHost } from './issue-host-partition'
import { executeIssueMutation } from './issue-mutation-receipt'
import { getIssueRecord, requireIssueRecord } from './issue-record-queries'
import { IssueRepositoryError } from './issue-repository-error'
import { insertIssueAtSiblingIndex } from './issue-sibling-order'
import type {
  FailExternalIssueRefreshInput,
  IssueMutationParams,
  RefreshExternalIssueInput,
  TrackExternalIssueInput
} from './issue-repository-types'

const MAX_SOURCE_ERROR_LENGTH = 2_048

export class ExternalIssueRepository {
  constructor(
    private readonly database: IssueDatabase,
    private readonly events: IssueEventRepository
  ) {}

  track(params: IssueMutationParams<TrackExternalIssueInput>): IssueRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.trackExternal',
      payload: params.input,
      operation: () => this.trackWithinTransaction(params.input)
    })
  }

  refresh(params: IssueMutationParams<RefreshExternalIssueInput>): IssueRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.refreshExternal',
      payload: params.input,
      operation: () => this.refreshWithinTransaction(params.input)
    })
  }

  recordRefreshFailure(
    params: IssueMutationParams<FailExternalIssueRefreshInput>
  ): IssueRecord {
    return executeIssueMutation({
      database: this.database,
      identity: params.identity,
      method: 'issues.failExternalRefresh',
      payload: params.input,
      operation: () => this.failWithinTransaction(params.input)
    })
  }

  private trackWithinTransaction(input: TrackExternalIssueInput): IssueRecord {
    const hostPartitionKey = hostPartitionForExecutionHost(input.executionHostId)
    const sourceContext = normalizeExternalIssueSourceContext({
      provider: input.provider,
      sourceContext: input.sourceContext,
      hostPartitionKey
    })
    const sourceScopeKey = externalIssueSourceScopeKey({
      provider: input.provider,
      sourceContext,
      hostPartitionKey
    })
    const snapshot = normalizeSnapshot(input.snapshot)
    const existing = this.database
      .prepare(
        `SELECT id FROM issues
         WHERE host_partition_key = ?
           AND source_provider = ?
           AND source_scope_key = ?
           AND source_external_id = ?`
      )
      .get(hostPartitionKey, input.provider, sourceScopeKey, snapshot.externalId) as
      | { id: string }
      | undefined
    if (existing) {
      throw new IssueRepositoryError(
        'external_issue_already_tracked',
        `External Issue is already tracked as ${existing.id}.`,
        { issueId: existing.id }
      )
    }

    const now = input.refreshAttemptedAt ?? Date.now()
    ensureIssueHostState(this.database, hostPartitionKey, now)
    assertIssueParent({
      database: this.database,
      parentId: input.parentId ?? null,
      hostPartitionKey,
      executionHostId: input.executionHostId
    })
    const id = randomUUID()
    this.database
      .prepare(
        `INSERT INTO issues (
           id, host_partition_key, execution_host_id, source_kind,
           source_provider, source_scope_key, source_external_id, source_number,
           source_identifier, source_url, source_title, source_state, source_synced_at,
           source_refresh_attempted_at, source_refresh_error, source_availability,
           source_context_json, native_parent_json, local_title, type_label, note,
           state, parent_id, sibling_order, created_at, updated_at, archived_at
         ) VALUES (
           ?, ?, ?, 'external', ?, ?, ?, ?, ?, ?, ?, ?, ?,
           ?, NULL, 'available', ?, ?, NULL, ?, ?,
           'active', ?, 0, ?, ?, NULL
         )`
      )
      .run(
        id,
        hostPartitionKey,
        input.executionHostId,
        input.provider,
        sourceScopeKey,
        snapshot.externalId,
        snapshot.number ?? null,
        snapshot.identifier ?? null,
        snapshot.url,
        snapshot.title,
        snapshot.state ?? null,
        now,
        now,
        JSON.stringify(sourceContext),
        serializeNativeParent(snapshot, input.provider, sourceContext, hostPartitionKey),
        input.typeLabel ?? null,
        input.note ?? null,
        input.parentId ?? null,
        now,
        now
      )
    insertIssueAtSiblingIndex({
      database: this.database,
      hostPartitionKey,
      parentId: input.parentId ?? null,
      issueId: id,
      now
    })
    const revisions = bumpIssueHostRevisions(
      this.database,
      hostPartitionKey,
      { tree: true, searchable: true },
      now
    )
    const issue = requireIssueRecord(this.database, id)
    this.events.appendWithinTransaction({
      hostPartitionKey,
      kind: 'created',
      issueRefs: [issueEventRef(issue, 'issue')],
      payload: { sourceKind: 'external', provider: input.provider },
      occurredAt: now,
      factsRevision: revisions.factsRevision
    })
    return issue
  }

  private refreshWithinTransaction(input: RefreshExternalIssueInput): IssueRecord {
    const issue = requireExternalIssue(this.database, input.id)
    const snapshot = normalizeSnapshot(input.snapshot)
    if (snapshot.externalId !== issue.source.externalId) {
      throw new IssueRepositoryError(
        'external_issue_identity_mismatch',
        'External Issue refresh cannot change the external identity.'
      )
    }
    const context = issue.source.sourceContext
    if (!context) {
      throw new IssueRepositoryError(
        'external_issue_source_invalid',
        'External Issue is missing its source context.'
      )
    }
    this.database
      .prepare(
        `UPDATE issues
         SET source_number = ?, source_identifier = ?, source_url = ?,
             source_title = ?, source_state = ?, source_synced_at = ?,
             source_refresh_attempted_at = ?, source_refresh_error = NULL,
             source_availability = 'available', native_parent_json = ?,
             updated_at = ?
         WHERE id = ?`
      )
      .run(
        snapshot.number ?? null,
        snapshot.identifier ?? null,
        snapshot.url,
        snapshot.title,
        snapshot.state ?? null,
        input.attemptedAt,
        input.attemptedAt,
        serializeNativeParent(
          snapshot,
          issue.source.provider,
          context,
          issue.hostPartitionKey
        ),
        input.attemptedAt,
        issue.id
      )
    return this.finishRefresh(issue, input.attemptedAt, null)
  }

  private failWithinTransaction(input: FailExternalIssueRefreshInput): IssueRecord {
    const issue = requireExternalIssue(this.database, input.id)
    const error = input.error.trim().slice(0, MAX_SOURCE_ERROR_LENGTH)
    if (!error) {
      throw new IssueRepositoryError(
        'external_issue_source_invalid',
        'External Issue refresh failure requires an error.'
      )
    }
    this.database
      .prepare(
        `UPDATE issues
         SET source_refresh_attempted_at = ?, source_refresh_error = ?,
             source_availability = ?, updated_at = ?
         WHERE id = ?`
      )
      .run(
        input.attemptedAt,
        error,
        input.availability ?? 'unavailable',
        input.attemptedAt,
        issue.id
      )
    return this.finishRefresh(issue, input.attemptedAt, error)
  }

  private finishRefresh(
    previous: IssueRecord,
    attemptedAt: number,
    error: string | null
  ): IssueRecord {
    const revisions = bumpIssueHostRevisions(
      this.database,
      previous.hostPartitionKey,
      { tree: false, searchable: error === null },
      attemptedAt
    )
    const issue = requireIssueRecord(this.database, previous.id)
    this.events.appendWithinTransaction({
      hostPartitionKey: previous.hostPartitionKey,
      kind: 'source-refreshed',
      issueRefs: [issueEventRef(issue, 'issue')],
      payload: {
        status: error === null ? 'available' : 'unavailable',
        ...(error ? { error } : {})
      },
      occurredAt: attemptedAt,
      factsRevision: revisions.factsRevision
    })
    return issue
  }
}

function normalizeSnapshot(
  snapshot: TrackExternalIssueInput['snapshot']
): TrackExternalIssueInput['snapshot'] {
  const externalId = snapshot.externalId.trim()
  const url = snapshot.url.trim()
  const title = snapshot.title.trim()
  if (!externalId || !url || !title) {
    throw new IssueRepositoryError(
      'external_issue_source_invalid',
      'External Issue snapshot requires id, URL, and title.'
    )
  }
  return {
    ...snapshot,
    externalId,
    url,
    title,
    ...(snapshot.identifier ? { identifier: snapshot.identifier.trim() } : {}),
    ...(snapshot.state ? { state: snapshot.state.trim() } : {})
  }
}

function serializeNativeParent(
  snapshot: TrackExternalIssueInput['snapshot'],
  provider: TrackExternalIssueInput['provider'],
  sourceContext: TrackExternalIssueInput['sourceContext'],
  hostPartitionKey: IssueRecord['hostPartitionKey']
): string | null {
  if (!snapshot.nativeParent) {
    return null
  }
  const parentContext = snapshot.nativeParent.sourceContext ?? sourceContext
  return JSON.stringify({
    sourceScopeKey: externalIssueSourceScopeKey({
      provider,
      sourceContext: parentContext,
      hostPartitionKey
    }),
    externalId: snapshot.nativeParent.externalId,
    title: snapshot.nativeParent.title
  })
}

function requireExternalIssue(database: IssueDatabase, id: string): IssueRecord & {
  source: Extract<IssueRecord['source'], { kind: 'external' }>
} {
  const issue = getIssueRecord(database, id)
  if (!issue) {
    throw new IssueRepositoryError('issue_not_found', `Issue ${id} was not found.`)
  }
  if (issue.source.kind !== 'external') {
    throw new IssueRepositoryError(
      'external_issue_source_invalid',
      `Issue ${id} is not externally tracked.`
    )
  }
  return issue as IssueRecord & {
    source: Extract<IssueRecord['source'], { kind: 'external' }>
  }
}
