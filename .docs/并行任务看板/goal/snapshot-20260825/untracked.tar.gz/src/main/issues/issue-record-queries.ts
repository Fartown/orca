import type { AuthorityHostPartitionKey, IssueRecord } from '../../shared/issues/types'
import type { IssueDatabase } from './issue-database'
import { IssueRepositoryError } from './issue-repository-error'
import type { IssueListFilter } from './issue-repository-types'
import { issueFromRow, type IssueRow } from './issue-row-mappers'

export function getIssueRecord(database: IssueDatabase, id: string): IssueRecord | undefined {
  const row = database.prepare('SELECT * FROM issues WHERE id = ?').get(id) as IssueRow | undefined
  return row ? issueFromRow(row) : undefined
}

export function requireIssueRecord(database: IssueDatabase, id: string): IssueRecord {
  const issue = getIssueRecord(database, id)
  if (!issue) {
    throw new IssueRepositoryError('issue_not_found', `Issue ${id} was not found.`)
  }
  return issue
}

export function listIssueRecords(database: IssueDatabase, filter: IssueListFilter): IssueRecord[] {
  const conditions: string[] = []
  const bindings: (string | number)[] = []
  if (filter.executionHostId) {
    conditions.push('execution_host_id = ?')
    bindings.push(filter.executionHostId)
  }
  if (filter.state) {
    conditions.push('state = ?')
    bindings.push(filter.state)
  }
  const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : ''
  const rows = database
    .prepare(
      `SELECT * FROM issues ${where}
       ORDER BY host_partition_key, parent_id, sibling_order, id`
    )
    .all(...bindings) as IssueRow[]
  return rows.map(issueFromRow)
}

export function allocateLocalIssueNumber(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey
): number {
  const row = database
    .prepare(
      `SELECT next_local_issue_number AS number
       FROM issue_host_state WHERE host_partition_key = ?`
    )
    .get(hostPartitionKey) as { number: number }
  database
    .prepare(
      `UPDATE issue_host_state
       SET next_local_issue_number = next_local_issue_number + 1
       WHERE host_partition_key = ?`
    )
    .run(hostPartitionKey)
  return row.number
}

export function nextIssueSiblingOrder(
  database: IssueDatabase,
  hostPartitionKey: AuthorityHostPartitionKey,
  parentId: string | null
): number {
  const row = database
    .prepare(
      `SELECT COALESCE(MAX(sibling_order), -1) + 1 AS next_order
       FROM issues WHERE host_partition_key = ? AND parent_id IS ?`
    )
    .get(hostPartitionKey, parentId) as { next_order: number }
  return row.next_order
}

export function countIssueDependents(
  database: IssueDatabase,
  table: 'issues' | 'conversations',
  id: string
): number {
  const column = table === 'issues' ? 'parent_id' : 'issue_id'
  return (
    database.prepare(`SELECT COUNT(*) AS count FROM ${table} WHERE ${column} = ?`).get(id) as {
      count: number
    }
  ).count
}
