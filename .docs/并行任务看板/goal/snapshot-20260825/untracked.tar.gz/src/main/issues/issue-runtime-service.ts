import type { ExecutionHostId } from '../../shared/execution-host'
import type {
  IssueDigestConfirmationResult,
  IssueDigestMutationResult,
  IssueDigestPreparation,
  IssueDigestSections
} from '../../shared/issues/digest-types'
import type { IssueMobilePendingPage } from '../../shared/issues/mobile-types'
import type {
  ConversationBindingMutationResult,
  ConversationPage,
  ConversationSummary,
  IssueArchiveMutationResult,
  IssueActivityPage,
  IssueDashboardProjection,
  IssueDeletePreparationResult,
  IssueDetail,
  IssueFactsChangedEvent,
  IssueListResult,
  IssueMutationResult,
  IssueSearchResult,
  LegacyActivityMigrationEntry,
  LegacyActivityMigrationResult,
  RoundRecordBodyField,
  RoundRecordBodyReadResult,
  RoundRecordPage
} from '../../shared/issues/types'
import type { TaskProvider } from '../../shared/task-providers'
import type { TaskSourceContext } from '../../shared/task-source-context'
import type { TuiAgent } from '../../shared/tui-agent'
import type { ExternalIssueTrackingService } from './external-issue-adapters'
import {
  issueAuthorityDescriptor,
  resolveIssueAuthorityRoute,
  type IssueAuthorityRoute
} from './issue-authority-route'
import type { IssueFactsChanged } from './issue-database'
import {
  IssueDigestRuntimeCoordinator,
  type IssueDigestGenerationExecutor
} from './issue-digest-runtime-coordinator'
import { IssueActivityQuery } from './issue-activity-query'
import { IssueDashboardProjectionQuery } from './issue-dashboard-projection'
import { IssueMobilePendingQuery } from './issue-mobile-pending-query'
import { LegacyActivityMigration } from './legacy-activity-migration'
import { readHostRevisions } from './issue-query-projections'
import { IssueQueryService } from './issue-query-service'
import { issueMutationIdentity, type IssueRepository } from './issue-repository'
import { IssueRepositoryError } from './issue-repository-error'

type MutationContext = {
  callerFingerprint: string
  mutationId: string
}

type IssueCreateInput = {
  executionHostId: ExecutionHostId
  source:
    | { kind: 'local'; title: string }
    | {
        kind: 'external'
        provider: TaskProvider
        selection: unknown
        sourceContext: TaskSourceContext
      }
  parentId?: string | null
  index?: number
  typeLabel?: string | null
  note?: string | null
}

export type IssueRuntimeServiceOptions = {
  isManagedSshTarget?: (targetId: string) => boolean
  externalIssues?: ExternalIssueTrackingService
  digestExecutor?: IssueDigestGenerationExecutor
}

export class IssueRuntimeService {
  private readonly query: IssueQueryService
  private readonly activityQuery: IssueActivityQuery
  private readonly dashboardProjectionQuery: IssueDashboardProjectionQuery
  private readonly mobilePendingQuery: IssueMobilePendingQuery
  private readonly legacyActivityMigration: LegacyActivityMigration
  private readonly digestCoordinator: IssueDigestRuntimeCoordinator

  constructor(
    private readonly repository: IssueRepository,
    private readonly options: IssueRuntimeServiceOptions = {}
  ) {
    this.query = new IssueQueryService(repository.database)
    this.activityQuery = new IssueActivityQuery(repository.database)
    this.dashboardProjectionQuery = new IssueDashboardProjectionQuery(repository.database)
    this.mobilePendingQuery = new IssueMobilePendingQuery(repository.database)
    this.legacyActivityMigration = new LegacyActivityMigration(repository, {
      isManagedSshTarget: options.isManagedSshTarget
    })
    this.digestCoordinator = new IssueDigestRuntimeCoordinator(
      repository,
      options.digestExecutor
    )
  }

  onFactsChanged(listener: (event: IssueFactsChangedEvent) => void): () => void {
    return this.repository.database.onFactsChanged((change) => {
      listener(toIssueFactsChangedEvent(change))
    })
  }

  list(
    params:
      | {
          mode: 'start'
          executionHostId: ExecutionHostId
          filter: 'all' | 'needs-me' | 'archived'
          sinceFactsRevision?: number
          limit: number
        }
      | {
          mode: 'continue'
          executionHostId: ExecutionHostId
          filter: 'all' | 'needs-me' | 'archived'
          snapshotFactsRevision: number
          snapshotTreeRevision: number
          cursor: string
          limit: number
        }
  ): IssueListResult {
    const route = this.resolveRoute(params.executionHostId)
    const { executionHostId: _executionHostId, ...query } = params
    return this.query.list(route, query)
  }

  get(params: { executionHostId: ExecutionHostId; issueId: string }): IssueDetail {
    return this.query.get(this.resolveRoute(params.executionHostId), params.issueId)
  }

  getConversation(params: {
    executionHostId: ExecutionHostId
    conversationId: string
  }): ConversationSummary {
    return this.query.getConversation(
      this.resolveRoute(params.executionHostId),
      params.conversationId
    )
  }

  async create(params: IssueCreateInput, context: MutationContext): Promise<IssueMutationResult> {
    const route = this.resolveRoute(params.executionHostId)
    if (
      params.source.kind === 'external' &&
      params.source.provider !== params.source.sourceContext.provider
    ) {
      throw new IssueRepositoryError(
        'external_issue_source_invalid',
        'External Issue provider does not match its source context.'
      )
    }
    const identity = issueMutationIdentity(context.callerFingerprint, context.mutationId)
    const base = {
      executionHostId: route.authorityExecutionHostId,
      parentId: params.parentId,
      index: params.index,
      typeLabel: params.typeLabel,
      note: params.note
    }
    const issue =
      params.source.kind === 'local'
        ? this.repository.issues.create({
            identity,
            input: {
              kind: 'local',
              title: params.source.title,
              ...base
            }
          })
        : await this.requireExternalIssues().track({
            identity,
            input: {
              sourceContext: params.source.sourceContext,
              selection: params.source.selection,
              ...base
            }
          })
    return this.mutationResult(route, [issue.id])
  }

  update(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      issueId: string
      localTitle?: string | null
      typeLabel?: string | null
      note?: string | null
    },
    callerFingerprint: string
  ): IssueMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    this.requireIssueForRoute(route, params.issueId)
    const issue = this.repository.issues.update({
      identity: issueMutationIdentity(callerFingerprint, params.mutationId),
      input: {
        id: params.issueId,
        ...(Object.hasOwn(params, 'localTitle') ? { localTitle: params.localTitle } : {}),
        ...(Object.hasOwn(params, 'typeLabel') ? { typeLabel: params.typeLabel } : {}),
        ...(Object.hasOwn(params, 'note') ? { note: params.note } : {})
      }
    })
    return this.mutationResult(route, [issue.id])
  }

  archive(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      issueId: string
      expectedFactsRevision?: number
    },
    callerFingerprint: string
  ): IssueArchiveMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    this.requireIssueForRoute(route, params.issueId)
    const result = this.repository.issues.archive({
      identity: issueMutationIdentity(callerFingerprint, params.mutationId),
      input: {
        id: params.issueId,
        expectedFactsRevision: params.expectedFactsRevision
      }
    })
    if (result.status === 'blocked') {
      return {
        status: 'blocked',
        authority: issueAuthorityDescriptor(this.repository.database, route),
        issueId: result.issueId,
        blockers: result.blockers
      }
    }
    return {
      status: 'archived',
      archivedAt: result.archivedAt,
      resolvedCompletionIds: result.resolvedCompletionIds,
      mutation: this.mutationResult(route, [result.issueId])
    }
  }

  reopen(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      issueId: string
      expectedFactsRevision?: number
    },
    callerFingerprint: string
  ): IssueMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    this.requireIssueForRoute(route, params.issueId)
    const issue = this.repository.issues.reopen({
      identity: issueMutationIdentity(callerFingerprint, params.mutationId),
      input: {
        id: params.issueId,
        expectedFactsRevision: params.expectedFactsRevision
      }
    })
    return this.mutationResult(route, [issue.id])
  }

  reparent(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      issueId: string
      parentId: string | null
      index: number
      expectedTreeRevision: number
    },
    callerFingerprint: string
  ): IssueMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    this.requireIssueForRoute(route, params.issueId)
    if (params.parentId) {
      this.requireIssueForRoute(route, params.parentId)
    }
    const result = this.repository.issues.reparent({
      identity: issueMutationIdentity(callerFingerprint, params.mutationId),
      input: {
        issueId: params.issueId,
        parentId: params.parentId,
        index: params.index,
        expectedTreeRevision: params.expectedTreeRevision
      }
    })
    return this.mutationResult(route, result.affectedIssueIds)
  }

  prepareDelete(params: {
    executionHostId: ExecutionHostId
    issueId: string
  }): IssueDeletePreparationResult {
    const route = this.resolveRoute(params.executionHostId)
    this.requireIssueForRoute(route, params.issueId)
    return {
      authority: issueAuthorityDescriptor(this.repository.database, route),
      ...this.repository.issues.prepareDelete(params.issueId)
    }
  }

  delete(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      plan: Parameters<IssueRepository['issues']['delete']>[0]['input']
    },
    callerFingerprint: string
  ): IssueMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    this.requireIssueForRoute(route, params.plan.issueId)
    const result = this.repository.issues.delete({
      identity: issueMutationIdentity(callerFingerprint, params.mutationId),
      input: params.plan
    })
    return this.mutationResult(
      route,
      [result.deletedIssueId, ...result.affectedIssueIds],
      result.affectedConversationIds
    )
  }

  bindConversation(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      conversationId: string
      issueId: string | null
      expectedFactsRevision: number
    },
    callerFingerprint: string
  ): ConversationBindingMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    const previous = this.requireConversationForRoute(route, params.conversationId)
    if (params.issueId) {
      this.requireIssueForRoute(route, params.issueId)
    }
    const current = this.repository.conversations.bindIssue({
      identity: issueMutationIdentity(callerFingerprint, params.mutationId),
      input: {
        id: params.conversationId,
        issueId: params.issueId,
        expectedFactsRevision: params.expectedFactsRevision
      }
    })
    return {
      ...this.mutationResult(
        route,
        [previous.issueId, current.issueId].filter((id): id is string => id !== null),
        [current.id]
      ),
      conversationId: current.id,
      previousIssueId: previous.issueId,
      issueId: current.issueId
    }
  }

  listUnassigned(params: {
    executionHostId: ExecutionHostId
    cursor?: string
    limit: number
  }): ConversationPage {
    const route = this.resolveRoute(params.executionHostId)
    return this.query.listUnassigned(route, {
      cursor: params.cursor,
      limit: params.limit
    })
  }

  listActivity(params: {
    executionHostId: ExecutionHostId
    cursor?: string
    limit: number
  }): IssueActivityPage {
    return this.activityQuery.list(this.resolveRoute(params.executionHostId), {
      cursor: params.cursor,
      limit: params.limit
    })
  }

  pendingForMobile(params: {
    executionHostId: ExecutionHostId
    cursor?: string
    limit: number
  }): IssueMobilePendingPage {
    return this.mobilePendingQuery.list(this.resolveRoute(params.executionHostId), params)
  }

  search(params: {
    executionHostId: ExecutionHostId
    query: string
    cursor?: string
    limit: number
  }): IssueSearchResult {
    const route = this.resolveRoute(params.executionHostId)
    return this.repository.searchIndex.search(route, {
      query: params.query,
      cursor: params.cursor,
      limit: params.limit
    })
  }

  projectDashboardPanes(params: {
    executionHostId: ExecutionHostId
    paneKeys: string[]
  }): IssueDashboardProjection {
    return this.dashboardProjectionQuery.project(
      this.resolveRoute(params.executionHostId),
      params.paneKeys
    )
  }

  migrateLegacyActivity(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      entries: LegacyActivityMigrationEntry[]
    },
    callerFingerprint: string
  ): LegacyActivityMigrationResult {
    return this.legacyActivityMigration.migrate(
      params,
      callerFingerprint
    )
  }

  listRounds(params: {
    executionHostId: ExecutionHostId
    issueId?: string
    conversationId?: string
    cursor?: string
    limit: number
  }): RoundRecordPage {
    const route = this.resolveRoute(params.executionHostId)
    if (params.issueId) {
      this.requireIssueForRoute(route, params.issueId)
    }
    if (params.conversationId) {
      this.requireConversationForRoute(route, params.conversationId)
    }
    return this.query.listRounds(route, params)
  }

  readRoundBody(params: {
    executionHostId: ExecutionHostId
    roundRecordId: string
    field: RoundRecordBodyField
    expectedBodyRevision: number
    expectedStorage?: 'none' | 'preview' | 'full' | 'evicted-preview' | 'evicted' | 'deleted'
    offset: number
    maxBytes: number
    allowTranscriptFallback?: boolean
  }): RoundRecordBodyReadResult {
    const route = this.resolveRoute(params.executionHostId)
    this.requireRoundForRoute(route, params.roundRecordId)
    return this.query.readRoundBody(route, params)
  }

  markRead(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      roundRecordIds: string[]
      readAt: number
    },
    callerFingerprint: string
  ): IssueMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    for (const id of params.roundRecordIds) {
      this.requireRoundForRoute(route, id)
    }
    const rounds = this.repository.rounds.markRead({
      identity: issueMutationIdentity(callerFingerprint, params.mutationId),
      input: { ids: params.roundRecordIds, readAt: params.readAt }
    })
    return this.mutationResult(
      route,
      [],
      [],
      rounds.map((round) => round.id)
    )
  }

  resolveRound(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      roundRecordId: string
      resolvedAt: number
    },
    callerFingerprint: string
  ): IssueMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    this.requireRoundForRoute(route, params.roundRecordId)
    const round = this.repository.rounds.resolve({
      identity: issueMutationIdentity(callerFingerprint, params.mutationId),
      input: { id: params.roundRecordId, resolvedAt: params.resolvedAt }
    })
    return this.mutationResult(route, [], [], [round.id])
  }

  prepareDigest(params: {
    executionHostId: ExecutionHostId
    issueId: string
    coversUntil?: number
  }): IssueDigestPreparation {
    const route = this.resolveRoute(params.executionHostId)
    return this.digestCoordinator.prepare(
      route,
      this.requireIssueForRoute(route, params.issueId),
      params.coversUntil
    )
  }

  generateDigest(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      issueId: string
      coversUntil?: number
      agent: TuiAgent
      expectedInputFingerprint: string
    },
    callerFingerprint: string
  ): IssueDigestMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    return this.digestCoordinator.generate(
      route,
      this.requireIssueForRoute(route, params.issueId),
      {
        identity: issueMutationIdentity(callerFingerprint, params.mutationId),
        coversUntil: params.coversUntil,
        agent: params.agent,
        expectedInputFingerprint: params.expectedInputFingerprint
      }
    )
  }

  cancelDigest(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      digestId: string
    },
    callerFingerprint: string
  ): Promise<IssueDigestMutationResult> {
    const route = this.resolveRoute(params.executionHostId)
    const digest = this.requireDigestForRoute(route, params.digestId)
    return this.digestCoordinator.cancel(
      route,
      this.requireIssueForRoute(route, digest.issueId),
      {
        identity: issueMutationIdentity(callerFingerprint, params.mutationId),
        digestId: digest.id
      }
    )
  }

  updateDigestDraft(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      digestId: string
      expectedDigestRevision: number
    } & Partial<IssueDigestSections>,
    callerFingerprint: string
  ): IssueDigestMutationResult {
    const route = this.resolveRoute(params.executionHostId)
    this.requireDigestForRoute(route, params.digestId)
    const patch: Partial<IssueDigestSections> = {}
    for (const field of [
      'problem',
      'conclusion',
      'keyArtifacts',
      'openIssues',
      'nextSteps'
    ] as const) {
      if (Object.hasOwn(params, field)) {
        patch[field] = params[field]
      }
    }
    return this.digestCoordinator.updateDraft(route, {
      identity: issueMutationIdentity(callerFingerprint, params.mutationId),
      digestId: params.digestId,
      expectedRevision: params.expectedDigestRevision,
      patch
    })
  }

  confirmDigest(
    params: {
      executionHostId: ExecutionHostId
      mutationId: string
      digestId: string
      expectedDigestRevision: number
      inputFingerprint: string
      confirmStaleAgainstFingerprint?: string
    },
    callerFingerprint: string
  ): IssueDigestConfirmationResult {
    const route = this.resolveRoute(params.executionHostId)
    const digest = this.requireDigestForRoute(route, params.digestId)
    return this.digestCoordinator.confirm(
      route,
      this.requireIssueForRoute(route, digest.issueId),
      {
        identity: issueMutationIdentity(callerFingerprint, params.mutationId),
        digestId: digest.id,
        expectedRevision: params.expectedDigestRevision,
        inputFingerprint: params.inputFingerprint,
        confirmStaleAgainstFingerprint: params.confirmStaleAgainstFingerprint
      }
    )
  }

  private resolveRoute(executionHostId: ExecutionHostId): IssueAuthorityRoute {
    return resolveIssueAuthorityRoute(executionHostId, {
      isManagedSshTarget: this.options.isManagedSshTarget
    })
  }

  private requireExternalIssues(): ExternalIssueTrackingService {
    if (!this.options.externalIssues) {
      throw new IssueRepositoryError(
        'external_issue_unavailable',
        'External Issue tracking is not available on this runtime.'
      )
    }
    return this.options.externalIssues
  }

  private requireIssueForRoute(route: IssueAuthorityRoute, issueId: string) {
    const issue = this.repository.issues.get(issueId)
    if (!issue) {
      throw new IssueRepositoryError('issue_not_found', `Issue ${issueId} was not found.`)
    }
    if (issue.hostPartitionKey !== route.hostPartitionKey) {
      throw new IssueRepositoryError(
        'issue_route_invalid',
        `Issue ${issueId} belongs to another host partition.`
      )
    }
    return issue
  }

  private requireConversationForRoute(route: IssueAuthorityRoute, conversationId: string) {
    const conversation = this.repository.conversations.get(conversationId)
    if (!conversation) {
      throw new IssueRepositoryError(
        'conversation_not_found',
        `Conversation ${conversationId} was not found.`
      )
    }
    if (conversation.hostPartitionKey !== route.hostPartitionKey) {
      throw new IssueRepositoryError(
        'issue_route_invalid',
        `Conversation ${conversationId} belongs to another host partition.`
      )
    }
    return conversation
  }

  private requireRoundForRoute(route: IssueAuthorityRoute, roundRecordId: string) {
    const round = this.repository.rounds.get(roundRecordId)
    if (!round) {
      throw new IssueRepositoryError(
        'round_not_found',
        `Round Record ${roundRecordId} was not found.`
      )
    }
    this.requireConversationForRoute(route, round.conversationId)
    return round
  }

  private requireDigestForRoute(route: IssueAuthorityRoute, digestId: string) {
    const digest = this.repository.digests.require(digestId)
    this.requireIssueForRoute(route, digest.issueId)
    return digest
  }

  private mutationResult(
    route: IssueAuthorityRoute,
    affectedIssueIds: string[] = [],
    affectedConversationIds: string[] = [],
    affectedRoundRecordIds: string[] = []
  ): IssueMutationResult {
    const revisions = readHostRevisions(this.repository.database, route.hostPartitionKey)
    return {
      authority: issueAuthorityDescriptor(this.repository.database, route),
      factsRevision: revisions.factsRevision,
      treeRevision: revisions.treeRevision,
      affectedIssueIds: [...new Set(affectedIssueIds)],
      affectedConversationIds: [...new Set(affectedConversationIds)],
      affectedRoundRecordIds: [...new Set(affectedRoundRecordIds)]
    }
  }
}

function toIssueFactsChangedEvent(change: IssueFactsChanged): IssueFactsChangedEvent {
  return {
    type: 'issueFactsChanged',
    authorityId: change.authorityId,
    hostPartitionKey: change.hostPartitionKey,
    factsRevision: change.factsRevision,
    treeRevision: change.treeRevision
  }
}
