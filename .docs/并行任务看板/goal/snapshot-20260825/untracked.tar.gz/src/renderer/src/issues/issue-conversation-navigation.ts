import { toast } from 'sonner'
import type { AiVaultAgent } from '../../../shared/ai-vault-types'
import {
  agentProviderSessionsEqual,
  isResumableTuiAgent,
  type AgentProviderSessionMetadata
} from '../../../shared/agent-session-resume'
import type { ExecutionHostId } from '../../../shared/execution-host'
import type { ConversationNavigationTarget } from '../../../shared/issues/types'
import { folderWorkspaceKey } from '../../../shared/workspace-scope'
import { resolveOriginalPaneTarget } from '../components/right-sidebar/ai-vault-original-pane'
import { activateTabAndFocusPane } from '../lib/activate-tab-and-focus-pane'
import { buildAiVaultResumeStartupForWorktree } from '../lib/ai-vault-resume-command'
import { launchAiVaultSessionInNewTab } from '../lib/launch-ai-vault-session'
import {
  activateAndRevealFolderWorkspace,
  activateAndRevealWorktree
} from '../lib/worktree-activation'
import { useAppStore } from '../store'

type ConversationPaneTarget = {
  paneKey: string
  worktreeId: string
  tabId: string
  leafId: string
}

export type IssueConversationNavigationResult =
  | { status: 'focused'; tabId: string; leafId: string }
  | { status: 'resumed'; tabId: string | null }
  | { status: 'unavailable'; reason: string }

export type IssueConversationNavigationDependencies = {
  resolvePaneTarget: (
    conversation: ConversationNavigationTarget,
    routeExecutionHostId: ExecutionHostId
  ) => ConversationPaneTarget | null
  findProviderPaneTarget: (
    conversation: ConversationNavigationTarget,
    routeExecutionHostId: ExecutionHostId
  ) => ConversationPaneTarget | null
  findQueuedProviderTab: (
    conversation: ConversationNavigationTarget,
    routeExecutionHostId: ExecutionHostId
  ) => string | null
  activateWorkspace: (
    conversation: ConversationNavigationTarget,
    routeExecutionHostId: ExecutionHostId
  ) => boolean
  focusPane: (tabId: string, leafId: string | null) => void
  launchResume: (
    conversation: ConversationNavigationTarget,
    routeExecutionHostId: ExecutionHostId
  ) => Promise<
    { status: 'resumed'; tabId: string | null } | { status: 'unavailable'; reason: string }
  >
  notifyUnavailable: (reason: string) => void
}

export async function openIssueConversation({
  routeExecutionHostId,
  conversation
}: {
  routeExecutionHostId: ExecutionHostId
  conversation: ConversationNavigationTarget
}): Promise<IssueConversationNavigationResult> {
  return openIssueConversationWithDependencies(
    { routeExecutionHostId, conversation },
    defaultDependencies
  )
}

export async function openIssueConversationWithDependencies(
  {
    routeExecutionHostId,
    conversation
  }: {
    routeExecutionHostId: ExecutionHostId
    conversation: ConversationNavigationTarget
  },
  dependencies: IssueConversationNavigationDependencies
): Promise<IssueConversationNavigationResult> {
  const navigation = conversation.navigation
  if (!navigation?.paneKey && !navigation?.providerSession) {
    return unavailable(dependencies, 'identity-unavailable')
  }

  const hintedPane = navigation.paneKey
    ? dependencies.resolvePaneTarget(conversation, routeExecutionHostId)
    : null
  const providerPane =
    hintedPane ??
    (navigation.providerSession
      ? dependencies.findProviderPaneTarget(conversation, routeExecutionHostId)
      : null)
  if (providerPane) {
    if (!dependencies.activateWorkspace(conversation, routeExecutionHostId)) {
      return unavailable(dependencies, 'workspace-unavailable')
    }
    dependencies.focusPane(providerPane.tabId, providerPane.leafId)
    return {
      status: 'focused',
      tabId: providerPane.tabId,
      leafId: providerPane.leafId
    }
  }

  if (!navigation.providerSession) {
    return unavailable(dependencies, 'pane-unavailable')
  }
  if (!dependencies.activateWorkspace(conversation, routeExecutionHostId)) {
    return unavailable(dependencies, 'workspace-unavailable')
  }

  const activatedPane = dependencies.findProviderPaneTarget(conversation, routeExecutionHostId)
  if (activatedPane) {
    dependencies.focusPane(activatedPane.tabId, activatedPane.leafId)
    return {
      status: 'focused',
      tabId: activatedPane.tabId,
      leafId: activatedPane.leafId
    }
  }
  const queuedTab = dependencies.findQueuedProviderTab(conversation, routeExecutionHostId)
  if (queuedTab) {
    dependencies.focusPane(queuedTab, null)
    return { status: 'resumed', tabId: queuedTab }
  }

  try {
    const result = await dependencies.launchResume(conversation, routeExecutionHostId)
    if (result.status === 'unavailable') {
      dependencies.notifyUnavailable(result.reason)
    }
    return result
  } catch {
    return unavailable(dependencies, 'resume-failed')
  }
}

function unavailable(
  dependencies: IssueConversationNavigationDependencies,
  reason: string
): IssueConversationNavigationResult {
  dependencies.notifyUnavailable(reason)
  return { status: 'unavailable', reason }
}

const defaultDependencies: IssueConversationNavigationDependencies = {
  resolvePaneTarget: (conversation) => {
    const paneKey = conversation.navigation?.paneKey
    if (!paneKey) {
      return null
    }
    return resolveConversationPaneTarget(conversation, paneKey)
  },
  findProviderPaneTarget: (conversation) => findProviderPaneTarget(conversation),
  findQueuedProviderTab: (conversation) => findQueuedProviderTab(conversation),
  activateWorkspace: (conversation, routeExecutionHostId) => {
    if (conversation.workspaceRef.type === 'folder') {
      return Boolean(
        activateAndRevealFolderWorkspace(conversation.workspaceRef.folderWorkspaceId, {
          executionHostId: routeExecutionHostId
        })
      )
    }
    return Boolean(
      activateAndRevealWorktree(conversation.workspaceRef.worktreeId, {
        executionHostId: routeExecutionHostId
      })
    )
  },
  focusPane: activateTabAndFocusPane,
  launchResume: launchConversationResume,
  notifyUnavailable: (reason) => {
    toast.error('Conversation unavailable', {
      description: unavailableDescription(reason)
    })
  }
}

function workspaceStoreKey(conversation: ConversationNavigationTarget): string {
  return conversation.workspaceRef.type === 'folder'
    ? folderWorkspaceKey(conversation.workspaceRef.folderWorkspaceId)
    : conversation.workspaceRef.worktreeId
}

function resolveConversationPaneTarget(
  conversation: ConversationNavigationTarget,
  paneKey: string
): ConversationPaneTarget | null {
  const workspaceKey = workspaceStoreKey(conversation)
  const target = resolveOriginalPaneTarget({
    state: useAppStore.getState(),
    paneKey,
    worktreeIdHint: workspaceKey
  })
  return target?.worktreeId === workspaceKey ? target : null
}

function findProviderPaneTarget(
  conversation: ConversationNavigationTarget
): ConversationPaneTarget | null {
  const providerSession = conversation.navigation?.providerSession
  if (!providerSession) {
    return null
  }
  const state = useAppStore.getState()
  for (const entry of Object.values(state.agentStatusByPaneKey)) {
    if (
      entry.agentType === conversation.agent &&
      agentProviderSessionsEqual(conversation.agent, entry.providerSession, providerSession)
    ) {
      const target = resolveConversationPaneTarget(conversation, entry.paneKey)
      if (target) {
        return target
      }
    }
  }
  for (const retained of Object.values(state.retainedAgentsByPaneKey)) {
    if (
      retained.agentType === conversation.agent &&
      agentProviderSessionsEqual(
        conversation.agent,
        retained.entry.providerSession,
        providerSession
      )
    ) {
      const target = resolveConversationPaneTarget(conversation, retained.entry.paneKey)
      if (target) {
        return target
      }
    }
  }
  for (const record of Object.values(state.sleepingAgentSessionsByPaneKey)) {
    if (
      record.agent === conversation.agent &&
      agentProviderSessionsEqual(conversation.agent, record.providerSession, providerSession)
    ) {
      const target = resolveConversationPaneTarget(conversation, record.paneKey)
      if (target) {
        return target
      }
    }
  }
  return null
}

function findQueuedProviderTab(conversation: ConversationNavigationTarget): string | null {
  const providerSession = conversation.navigation?.providerSession
  if (!providerSession) {
    return null
  }
  const state = useAppStore.getState()
  const workspaceKey = workspaceStoreKey(conversation)
  for (const tab of state.tabsByWorktree[workspaceKey] ?? []) {
    const startup = state.pendingStartupByTabId[tab.id]
    if (
      startup?.launchAgent === conversation.agent &&
      agentProviderSessionsEqual(conversation.agent, startup.resumeProviderSession, providerSession)
    ) {
      return tab.id
    }
    const claim = state.automaticAgentResumeClaimsByTabId[tab.id]
    if (
      claim?.worktreeId === workspaceKey &&
      claim.launchAgent === conversation.agent &&
      agentProviderSessionsEqual(conversation.agent, claim.providerSession, providerSession)
    ) {
      return tab.id
    }
  }
  return null
}

async function launchConversationResume(
  conversation: ConversationNavigationTarget,
  routeExecutionHostId: ExecutionHostId
): Promise<
  { status: 'resumed'; tabId: string | null } | { status: 'unavailable'; reason: string }
> {
  const navigation = conversation.navigation
  const providerSession = navigation?.providerSession
  if (!providerSession || !isResumableTuiAgent(conversation.agent)) {
    return { status: 'unavailable', reason: 'resume-unsupported' }
  }
  const resumeLocator = navigation.resumeLocator ?? providerSession.transcriptPath
  const effectiveProviderSession: AgentProviderSessionMetadata =
    resumeLocator && (conversation.agent === 'pi' || conversation.agent === 'prime-agent')
      ? { ...providerSession, transcriptPath: resumeLocator }
      : providerSession
  const workspaceKey = workspaceStoreKey(conversation)
  const state = useAppStore.getState()
  const agent = conversation.agent as AiVaultAgent
  const startup = buildAiVaultResumeStartupForWorktree({
    state,
    worktreeId: workspaceKey,
    session: {
      agent,
      sessionId: effectiveProviderSession.id,
      cwd: conversation.workspaceSnapshot.path,
      codexHome: null,
      executionHostId: routeExecutionHostId,
      ...(resumeLocator ? { filePath: resumeLocator } : {})
    },
    commandOverride: state.settings?.agentCmdOverrides?.[conversation.agent]
  })
  if (
    !startup.providerSession ||
    !agentProviderSessionsEqual(
      conversation.agent,
      startup.providerSession,
      effectiveProviderSession
    )
  ) {
    return { status: 'unavailable', reason: 'resume-unsupported' }
  }
  const launched = launchAiVaultSessionInNewTab({
    agent,
    worktreeId: workspaceKey,
    command: startup.command,
    ...(startup.cwd ? { cwd: startup.cwd } : {}),
    ...(startup.env ? { env: startup.env } : {}),
    ...(startup.envToDelete ? { envToDelete: startup.envToDelete } : {}),
    ...(startup.launchConfig ? { launchConfig: startup.launchConfig } : {}),
    providerSession: startup.providerSession
  })
  if (launched.tabId !== null) {
    return { status: 'resumed', tabId: launched.tabId }
  }
  const outcome = await launched.runtimeLaunch
  return outcome.status === 'created'
    ? { status: 'resumed', tabId: null }
    : { status: 'unavailable', reason: 'resume-failed' }
}

function unavailableDescription(reason: string): string {
  switch (reason) {
    case 'identity-unavailable':
      return 'This Conversation has no precise pane or provider identity.'
    case 'pane-unavailable':
      return 'The original pane is gone and this Conversation has no resume identity.'
    case 'workspace-unavailable':
      return 'The Conversation Workspace is unavailable on this host.'
    case 'resume-unsupported':
      return 'This agent session cannot be resumed automatically.'
    default:
      return 'Orca could not reopen this Conversation.'
  }
}
