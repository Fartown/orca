import type { IssueAuthorityDescriptor } from '../../../shared/issues/types'
import { useAppStore } from '../store'
import type { AppState } from '../store/types'
import type { WorktreeNavHistoryIssueDetailEntry } from '../store/slices/worktree-nav-history'
import {
  issuesDomainStore,
  type IssuesDomainState
} from './issues-domain-store'

export type IssueNavigationTarget = {
  authority: IssueAuthorityDescriptor
  issueId: string
}

export type IssueNavigationDependencies = {
  getAppState: () => Pick<
    AppState,
    | 'isNavigatingHistory'
    | 'openIssuesPage'
    | 'recordViewVisit'
    | 'setActiveView'
  >
  getIssuesState: () => Pick<IssuesDomainState, 'selectIssue'>
}

const defaultDependencies: IssueNavigationDependencies = {
  getAppState: () => useAppStore.getState(),
  getIssuesState: () => issuesDomainStore.getState()
}

export function issueNavigationHistoryEntry({
  authority,
  issueId
}: IssueNavigationTarget): WorktreeNavHistoryIssueDetailEntry {
  return {
    kind: 'issue-detail',
    authorityId: authority.authorityId,
    hostPartitionKey: authority.hostPartitionKey,
    routeExecutionHostId: authority.routeExecutionHostId,
    issueId
  }
}

export function openIssueDetail(
  target: IssueNavigationTarget,
  dependencies: IssueNavigationDependencies = defaultDependencies
): void {
  dependencies
    .getIssuesState()
    .selectIssue(target.authority.routeExecutionHostId, target.issueId)
  const app = dependencies.getAppState()
  if (!app.isNavigatingHistory) {
    app.recordViewVisit(issueNavigationHistoryEntry(target))
  }
  app.openIssuesPage()
}

export function replayIssueDetailHistoryEntry(
  entry: WorktreeNavHistoryIssueDetailEntry,
  dependencies: IssueNavigationDependencies = defaultDependencies
): void {
  dependencies
    .getIssuesState()
    .selectIssue(entry.routeExecutionHostId, entry.issueId)
  dependencies.getAppState().setActiveView('issues')
}
